package com.moorestephens.sbfa;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class FragmentActiveSync extends Fragment {

	public static final String EXTRA_MESSAGE = "EXTRA_MESSAGE";

	Context mContext;

	Bundle bundle;
	String theMessage;
    String theDescription;

	TextView txtAlert;
	TextView txtDescription;

	public FragmentActiveSync(){
		
	}
	
	public static final FragmentActiveSync newInstance(String message){

		FragmentActiveSync f = new FragmentActiveSync();
		Bundle bdl = new Bundle(1);
		bdl.putString(EXTRA_MESSAGE, message);
		f.setArguments(bdl);
		return f;

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View v = inflater.inflate(R.layout.frag_active_sync, container, false);
		
		mContext = getActivity();
		bundle = getArguments();

		return v;
	}
	
	@Override
	public void onAttach(Activity activity){
		super.onAttach(activity);
		
		
	}
	
	
}
