package com.moorestephens.sbfa;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class FragmentErrorBox extends Fragment {

	public static final String EXTRA_MESSAGE = "EXTRA_MESSAGE";

	Context mContext;
	
	Bundle bundle;
	String theMessage;
    String theDescription;
	
	TextView txtAlert;
	TextView txtDescription;
	
	public FragmentErrorBox(){
		
	}
	
	public static final FragmentErrorBox newInstance(String message){

		FragmentErrorBox f = new FragmentErrorBox();
		Bundle bdl = new Bundle(1);
		bdl.putString(EXTRA_MESSAGE, message);
		f.setArguments(bdl);
		return f;

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View v = inflater.inflate(R.layout.frag_error, container, false);
		
		mContext = getActivity();
		bundle = getArguments();

		theMessage =  bundle.getString("theMessage");
		theDescription = bundle.getString("theDescription");

		txtAlert = (TextView)v.findViewById(R.id.lblErrMessage);
		txtDescription = (TextView)v.findViewById(R.id.lblErrorContent);
		
		txtAlert.setText(theMessage);
        txtDescription.setText(theDescription);
				
		Button cmdOK = (Button)v.findViewById(R.id.cmdCloseError);
	
		cmdOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
						
				getActivity().getSupportFragmentManager().beginTransaction().remove(FragmentErrorBox.this).commit();
				
			}
		});
		
		return v;
	}
	
	@Override
	public void onAttach(Activity activity){
		super.onAttach(activity);
		
		
	}
	
	
}
