package com.moorestephens.sbfa;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class FragmentScheduledSiteVisits extends Fragment {

	public static final String EXTRA_MESSAGE = "EXTRA_MESSAGE";

	Context mContext;

	Bundle bundle;

	ImageButton cmdCloseLightBox;

	ArrayList<String> siteVisits;
	ArrayList<String> lmids;
	ListView lv;
	View v;

	RelativeLayout relNoData;

	public FragmentScheduledSiteVisits(){
		
	}
	
	public static final FragmentScheduledSiteVisits newInstance(String message){

		FragmentScheduledSiteVisits f = new FragmentScheduledSiteVisits();
		Bundle bdl = new Bundle(1);
		bdl.putString(EXTRA_MESSAGE, message);
		f.setArguments(bdl);
		return f;

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		v = inflater.inflate(R.layout.frag_site_vist_list, container, false);

		mContext = getActivity();


		lv = (ListView)v.findViewById(R.id.lstSiteVisits);
		relNoData = (RelativeLayout)v.findViewById(R.id.relNoData);

		cmdCloseLightBox = (ImageButton)v.findViewById(R.id.cmdCloseLightbox);
		cmdCloseLightBox.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				closeLightbox();
				CommonFunctions.removeBackOfLightBox(mContext);
			}
		});

		loadList();

		return v;
	}

	private void loadList(){

		siteVisits = new ArrayList<>();
		lmids = new ArrayList<>();

		DBHelper helper = new DBHelper(mContext);
		SQLiteDatabase database = helper.getReadableDatabase();

		Cursor c = database.rawQuery("SELECT * FROM tblScheduledSiteVisits",null);

		try
		{
			c.moveToFirst();

			while (!c.isAfterLast()){
				siteVisits.add(c.getString(c.getColumnIndex("Id")) + ";" + c.getString(c.getColumnIndex("VisitDate")) + ";" + c.getString(c.getColumnIndex("VisitTime")) + ";" + c.getString(c.getColumnIndex("VisitAddress")));
				lmids.add(c.getString(c.getColumnIndex("FK_LM")));

				c.moveToNext();
			}

		}catch(Exception ex){

		}finally{
			database.close();
		}

		if (siteVisits.size() == 0){
			relNoData.setVisibility(View.VISIBLE);
		}else
		{
			relNoData.setVisibility(View.GONE);
		}

		SpecialAdapterSiteVisits arrayAdapter = new SpecialAdapterSiteVisits(mContext,android.R.layout.simple_list_item_1, siteVisits);
		arrayAdapter.notifyDataSetChanged();
		lv.setAdapter(arrayAdapter);

		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				TextView lblDate = (TextView)view.findViewById(R.id.lblDate);
				TextView lblTime = (TextView)view.findViewById(R.id.lblTime);
				TextView lblLocation = (TextView)view.findViewById(R.id.lblLocation);
				TextView lblID = (TextView)view.findViewById(R.id.lblID);

				String siteVisitID = lblID.getText().toString();

				Intent intent = new Intent(mContext, SiteVisitActivity.class);
				intent.putExtra("siteVisitID", siteVisitID);
				intent.putExtra("LMID",lmids.get(position).toString());
				intent.putExtra("BusinessRegistrationNumber","0");
				intent.putExtra("Date", lblDate.getText().toString());
				intent.putExtra("Time", lblTime.getText().toString());
				intent.putExtra("Location", lblLocation.getText().toString());

				startActivity(intent);
			}
		});

	}

	@Override
	public void onAttach(Activity activity){
		super.onAttach(activity);
		
		
	}

	public void closeLightbox(){

		Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.slidedown_info);

		animation.setAnimationListener(new Animation.AnimationListener() {
			@Override
			public void onAnimationEnd(Animation animation) {
				//This is the key, when the animation is finished, remove the fragment.
				getActivity().getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.slidedown_info, 0, R.anim.slidedown_info, 0).remove(FragmentScheduledSiteVisits.this).commit();

			}

			@Override
			public void onAnimationRepeat(Animation arg0) {

			}

			@Override
			public void onAnimationStart(Animation animation) {

				//GlobalVariables gv = new GlobalVariables();
				//gv.removeBackOfLightBox(getActivity());
			}
		});

		//Start the animation.
		getView().startAnimation(animation);
	}



}
