package com.moorestephens.sbfa;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.NinePatch;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;


public class NewPreregistrationActivity extends AppCompatActivity {

    Button cmdCloseBox, cmdAssess, cmdCancel, cmdCheckNIN, cmdCheckBIN;
    ImageButton cmdSettings;
    RelativeLayout relQualifies, relMenu;
    ImageView imgNINStatus;

    EditText txtName, txtSurname, txtNIN, txtEmail, txtAddress, txtBIN, txtBusinessName, txtSEnPAReg, txtLoanAmount, txtEmployeeNo;
    Spinner spnBusinessType, spnSEnPARegistered, spnTurnover, spnSecurity;

    Button cmdMenuMyAccount, cmdMenuLock, cmdMenuLogout;

    boolean menuVisible, ninValid;
    ImageView imgBINStatus;

    RelativeLayout relVerifying;

    TextView lblVerification;

    Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_preregistration);

        mContext = this;

        menuVisible = false;
        ninValid = false;

        loadUserDetails();

        txtName = (EditText) findViewById(R.id.txtName);
        txtSurname = (EditText) findViewById(R.id.txtSurname);
        txtNIN = (EditText) findViewById(R.id.txtNIN);
        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtAddress = (EditText) findViewById(R.id.txtHomeAddress);
        txtBIN = (EditText) findViewById(R.id.txtBIN);
        txtBusinessName = (EditText) findViewById(R.id.txtBusinessName);
        txtSEnPAReg = (EditText) findViewById(R.id.txtSEnPARegistrationNo);
        txtLoanAmount = (EditText) findViewById(R.id.txtLoanAmount);
        txtEmployeeNo = (EditText) findViewById(R.id.txtEmployeeNo);

        lblVerification = (TextView)findViewById(R.id.lblVerifying);

        spnBusinessType = (Spinner) findViewById(R.id.spnBusinesstype);
        spnSecurity = (Spinner) findViewById(R.id.spnSecurity);
        spnSEnPARegistered = (Spinner) findViewById(R.id.spnSEnPARegistered);
        spnTurnover = (Spinner) findViewById(R.id.spnTurnoverRange);

        spnSEnPARegistered.setOnItemSelectedListener(new SpnSEnPASelector());

        relQualifies = (RelativeLayout) findViewById(R.id.relQualifies);
        relMenu = (RelativeLayout) findViewById(R.id.relMenu);

        imgNINStatus = (ImageView)findViewById(R.id.imgNINStatus);

        cmdCheckNIN = (Button)findViewById(R.id.cmdCheckNIN);
        cmdCloseBox = (Button) findViewById(R.id.cmdCloseBox);
        cmdAssess = (Button) findViewById(R.id.cmdAssess);
        cmdCancel = (Button) findViewById(R.id.cmdCancel);
        cmdSettings = (ImageButton) findViewById(R.id.cmdSettings);

        cmdCheckBIN = (Button)findViewById(R.id.cmdCheckBIN);
        imgBINStatus = (ImageView)findViewById(R.id.imgBINStatus);

        cmdMenuLock = (Button) findViewById(R.id.cmdLock);
        cmdMenuLogout = (Button) findViewById(R.id.cmdLogOut);
        cmdMenuMyAccount = (Button) findViewById(R.id.cmdMenuMyAccount);

        relVerifying = (RelativeLayout)findViewById(R.id.relVerifying);

        loadSpinnerData();

        cmdCheckNIN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String nin = txtNIN.getText().toString();
                if (!nin.isEmpty()){
                    dismissKeyboard(NewPreregistrationActivity.this);
                    relVerifying.setVisibility(View.VISIBLE);
                    lblVerification.setText("Verifying the National Identification Number!");
                    imgNINStatus.setVisibility(View.GONE);
                    CheckNIN task = new CheckNIN();
                    task.execute(txtNIN.getText().toString());
                }

            }
        });

        cmdCheckBIN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String bin = txtBIN.getText().toString();
                if (!bin.isEmpty()){
                    dismissKeyboard(NewPreregistrationActivity.this);
                    relVerifying.setVisibility(View.VISIBLE);
                    lblVerification.setText("Verifying the Business Registration Number!");
                    imgBINStatus.setVisibility(View.GONE);
                    CheckBIN task = new CheckBIN();
                    task.execute(txtBIN.getText().toString());
                }

            }
        });

        cmdMenuLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                relMenu.setVisibility(View.GONE);
                menuVisible = false;

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                FragmentScreenLock fragError = new FragmentScreenLock();

                fragmentTransaction.add(R.id.relFragHolder, fragError, "View");

                fragmentTransaction.commit();
            }
        });
        cmdMenuLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(NewPreregistrationActivity.this, LoginActivity.class));
                finish();
            }
        });
        cmdMenuMyAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                relMenu.setVisibility(View.GONE);
                menuVisible = false;

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                FragmentChangePassword fragError = new FragmentChangePassword();

                fragmentTransaction.add(R.id.relFragHolder, fragError, "View");

                fragmentTransaction.commit();
            }
        });


        cmdSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (menuVisible == false) {
                    relMenu.setVisibility(View.VISIBLE);
                    menuVisible = true;
                } else {
                    relMenu.setVisibility(View.GONE);
                    menuVisible = false;
                }
            }
        });

        cmdCloseBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                relQualifies.setVisibility(View.GONE);
            }
        });

        cmdAssess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name, surname, nin, email, address, bin, businessName, businessType, senpaRegistered, senpaNo, loanAmountRequired, noOfEmployees, turnover, security;

                name = txtName.getText().toString();
                surname = txtSurname.getText().toString();
                nin = txtNIN.getText().toString();
                email = txtEmail.getText().toString();
                address = txtAddress.getText().toString();
                bin = txtBIN.getText().toString();
                businessName = txtBusinessName.getText().toString();
                senpaNo = txtSEnPAReg.getText().toString();
                loanAmountRequired = txtLoanAmount.getText().toString();
                noOfEmployees = txtEmployeeNo.getText().toString();

                businessType = spnBusinessType.getSelectedItem().toString();
                senpaRegistered = spnSEnPARegistered.getSelectedItem().toString();
                turnover = spnTurnover.getSelectedItem().toString();
                security = spnSecurity.getSelectedItem().toString();


                //do validations first
                if (name.isEmpty()) {
                    showErrorMessage("Missing Info!", "Please enter the person's name.");
                    return;
                }
                if (surname.isEmpty()) {
                    showErrorMessage("Missing Info!", "Please enter the person's surname.");
                    return;
                }

                if (nin.isEmpty()) {
                    showErrorMessage("Missing Info!", "Please enter the NIN.");
                    return;
                }
                if (ninValid == false) {
                    showErrorMessage("Invalid NIN!", "The NIN you entered is invalid.");
                    return;
                }
                if (email.isEmpty()) {
                    //showErrorMessage("Missing Info!", "Please enter the person's email address.");
                    //return;
                }
                if (address.isEmpty()) {
                    //showErrorMessage("Missing Info!", "Please enter the person's email address.");
                    //return;
                }
                if (bin.isEmpty()) {
                    showErrorMessage("Missing Info!", "Please enter the Business Registration Number.");
                    return;
                }
                if (businessName.isEmpty()) {
                    showErrorMessage("Missing Info!", "Please enter the business name.");
                    return;
                }
                if (loanAmountRequired.isEmpty()) {
                    showErrorMessage("Missing Info!", "Please enter the loan amount.");
                    return;
                }
                if (noOfEmployees.isEmpty()) {
                    showErrorMessage("Missing Info!", "Please enter the number of employees.");
                    return;
                }


                if (businessType.equals("Select business type...")) {
                    showErrorMessage("Missing Info!", "Please select the business type.");
                    return;
                }

                if (senpaRegistered.equals("Select Option...")) {
                    showErrorMessage("Missing Info!", "Please select whether they are registered with SEnPA or not.");
                    return;
                }

                if (turnover.equals("Select Option...")) {
                    showErrorMessage("Missing Info!", "Please select the turnover.");
                    return;
                }

                if (security.equals("Select Option...")) {
                    showErrorMessage("Missing Info!", "Please select the security option.");
                    return;
                }


                //APPLY THE RULES
                boolean qualifies = false;
                String disqualificationReport = "";

                //1. Valid NIN

                //2. Loan amount must be over SCR300,000
                double loadAmount = Double.parseDouble(loanAmountRequired);
                //3. Less than 10 employees

                //4. Annual Turnover less than $1,000,000

                //5. Must have security (that is not just insurance)


                relQualifies.setVisibility(View.VISIBLE);
            }
        });

        cmdCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    public void loadUserDetails(){
        TextView lblName = (TextView)findViewById(R.id.lblName);
        TextView lblUserType = (TextView)findViewById(R.id.lblUserType);

        lblName.setText(GlobalVariables.getFullName(mContext));
        lblUserType.setText(GlobalVariables.getLoggedInUserType(mContext));
    }

    private void loadSpinnerData(){
        //spnBusinessType, spnSEnPARegistered, spnTurnover, spnSecurity;

        spnBusinessType = (Spinner) findViewById(R.id.spnBusinesstype);
        spnSecurity = (Spinner) findViewById(R.id.spnSecurity);
        spnTurnover = (Spinner) findViewById(R.id.spnTurnoverRange);


        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,CommonFunctions.GetReferenceDataName(mContext,"businessTypes"));
        spnBusinessType.setAdapter(spinnerArrayAdapter);

        spinnerArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,CommonFunctions.GetReferenceDataName(mContext,"securityTypes"));
        spnSecurity.setAdapter(spinnerArrayAdapter);

        spinnerArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,CommonFunctions.GetReferenceDataName(mContext,"annualTurnover"));
        spnTurnover.setAdapter(spinnerArrayAdapter);

    }

    public class SpnSEnPASelector implements AdapterView.OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {


        }

        public void onNothingSelected(AdapterView parent) {
            // Do nothing.
        }
    }

    public void showErrorMessage(String theMessage, String theDescription) {
        Bundle bundle = new Bundle();
        bundle.putString("theMessage", theMessage);
        bundle.putString("theDescription", theDescription);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentErrorBox fragError = new FragmentErrorBox();

        fragError.setArguments(bundle);

        fragmentTransaction.add(R.id.relFragHolder, fragError, "View");

        fragmentTransaction.commit();

    }

    public class CheckNIN extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            String result = null;
            ConnProperties conProp = new ConnProperties();

            String NiN = params[0];

            String Reg_SOAP_ACTION = "http://sbfa.com/GetUserDetailsByNIN";
            String METHOD_NAME = "GetUserDetailsByNIN";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            request.addProperty("NIN", NiN);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL, 100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                String resultValue = envelope.getResponse().toString();

                result = resultValue;
                if (result == null) {
                    Log.d("conn_error", "Result is NULL");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            relVerifying.setVisibility(View.GONE);
            try {
                if (!result.equals("1;0")) {
                    imgNINStatus.setVisibility(View.VISIBLE);
                    if (result.startsWith("1;")){
                        ninValid = true;
                        imgNINStatus.setImageResource(R.drawable.ic_accepted);

                        //FirstName,Surname,Nationality,DateOfBirth,Status
                        String[] person = result.split(";");

                        txtName.setText(person[1]);
                        txtSurname.setText(person[2]);

                    }else{
                        ninValid = false;
                        imgNINStatus.setImageResource(R.drawable.ic_declined);
                    }
                } else {
                    imgNINStatus.setVisibility(View.VISIBLE);
                    ninValid = false;
                    imgNINStatus.setImageResource(R.drawable.ic_declined);
                }

                Log.i("Connection", result);
            } catch (Exception ex) {
                ex.printStackTrace();
                showConnectionError();
            }

        }

    }

    public class CheckBIN extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            String result = null;
            ConnProperties conProp = new ConnProperties();

            String BIN = params[0];

            String Reg_SOAP_ACTION = "http://sbfa.com/GetBusinessDetailsByBRN";
            String METHOD_NAME = "GetBusinessDetailsByBRN";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            request.addProperty("BRN", BIN);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL, 100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                String resultValue = envelope.getResponse().toString();

                result = resultValue;
                if (result == null) {
                    Log.d("conn_error", "Result is NULL");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            relVerifying.setVisibility(View.GONE);
            try {
                if (!result.equals("1;0")) {
                    imgBINStatus.setVisibility(View.VISIBLE);
                    if (result.startsWith("1;")){
                        //ninValid = true;
                        imgBINStatus.setImageResource(R.drawable.ic_accepted);

                        //Name,AddressLine1,business.AddressLine2;
                        String[] business = result.split(";");

                        txtBusinessName.setText(business[1]);
                    }else{
                        //ninValid = false;
                        imgBINStatus.setImageResource(R.drawable.ic_declined);
                    }
                } else {
                    imgBINStatus.setVisibility(View.VISIBLE);
                    imgBINStatus.setImageResource(R.drawable.ic_declined);
                }

                Log.i("Connection", result);
            } catch (Exception ex) {
                ex.printStackTrace();
                showConnectionError();
            }

        }

    }

    public void showConnectionError(){

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentConnectionErrorBox fragError = new FragmentConnectionErrorBox();

        fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

        fragmentTransaction.commit();

    }


    public void dismissKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (null != activity.getCurrentFocus())
            imm.hideSoftInputFromWindow(activity.getCurrentFocus()
                    .getApplicationWindowToken(), 0);
    }
}
