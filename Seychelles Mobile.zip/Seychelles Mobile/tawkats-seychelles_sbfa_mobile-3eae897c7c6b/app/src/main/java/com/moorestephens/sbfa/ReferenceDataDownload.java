package com.moorestephens.sbfa;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

/**
 * Created by Tawanda on 8/10/2017.
 */

public class ReferenceDataDownload {

    String id, name;
    SoapObject resultValue, resultValue2;

    Context mActivity;

    public ReferenceDataDownload(Context context){
        mActivity = context;
    }

    public void GetAllData(){
        GetBusinessTypes getBusinessTypesTask = new GetBusinessTypes();
        getBusinessTypesTask.execute();

    }

    public class GetBusinessTypes extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... params) {
            String result = "0";
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/GetBusinessTypes";
            String METHOD_NAME = "GetBusinessTypes";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                resultValue2 = (SoapObject) envelope.getResponse();
                result = "1";
                //result = resultValue;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result){

            try{
                if (result.equals("1")){
                    SaveReferenceData(resultValue2,"tblRefBusinessTypes");
                    Log.e("ReferenceData","downloaded");
                }
                else
                {
                    Log.e("ReferenceData","No businesstypes");
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }

            //now get the educational levels
            GetIslands getIslands = new GetIslands();
            getIslands.execute();
        }

    }

    public class GetIslands extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... params) {
            String result = "0";
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/GetIslands";
            String METHOD_NAME = "GetIslands";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                resultValue2 = (SoapObject) envelope.getResponse();
                result = "1";
                //result = resultValue;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result){

            try{
                if (result.equals("1")){
                    SaveReferenceData(resultValue2,"tblRefIslands");
                    Log.e("ReferenceData","downloaded");
                }
                else
                {
                    Log.e("ReferenceData","No educationallevel");
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }


            GetTitles getTitles = new GetTitles();
            getTitles.execute();
        }

    }


    public class GetTitles extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... params) {
            String result = "0";
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/GetTitles";
            String METHOD_NAME = "GetTitles";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                resultValue2 = (SoapObject) envelope.getResponse();
                result = "1";
                //result = resultValue;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result){

            try{
                if (result.equals("1")){
                    SaveReferenceData(resultValue2,"tblRefTitles");
                    Log.e("ReferenceData","downloaded");
                }
                else
                {
                    Log.e("ReferenceData","No titles");
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }

            GetDistricts getDistricts = new GetDistricts();
            getDistricts.execute();
        }

    }

    public class GetDistricts extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... params) {
            String result = "0";
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/GetDistricts";
            String METHOD_NAME = "GetDistricts";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                resultValue2 = (SoapObject) envelope.getResponse();
                result = "1";
                //result = resultValue;

            } catch (Exception e) {
                e.printStackTrace();
            }


            return result;

        }

        @Override
        protected void onPostExecute(String result){

            try{
                if (result.equals("1")){
                    String[] refList = new String[resultValue2.getPropertyCount()];

                    DBHelper helper = new DBHelper(mActivity);
                    SQLiteDatabase database = helper.getReadableDatabase();
                    database.execSQL("DELETE FROM " + "tblRefDistricts");
                    database.close();

                    for(int i=0;i<resultValue2.getPropertyCount();i++) {
                        refList[i] = resultValue2.getPropertyAsString(i).toString();

                        String id, island, name;
                        String[] section = refList[i].split(";");

                        id = section[0];
                        island = section[1];
                        name = section[2];

                        //inserting the results into the DB
                        ContentValues insertValues = new ContentValues();
                        insertValues.put("Id", id);
                        insertValues.put("IslandID", island);
                        insertValues.put("Name", name);

                        database = helper.getReadableDatabase();
                        database.insert("tblRefDistricts", null, insertValues);

                        database.close();
                    }
                }
                else
                {
                    Log.e("ReferenceData","No titles");
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }

            GetAnnualTurnover getAnnualTurnover = new GetAnnualTurnover();
            getAnnualTurnover.execute();

        }

    }

    public class GetAnnualTurnover extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... params) {
            String result = "0";
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/GetAnnualTurnovers";
            String METHOD_NAME = "GetAnnualTurnovers";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                resultValue2 = (SoapObject) envelope.getResponse();
                result = "1";
                //result = resultValue;

            } catch (Exception e) {
                e.printStackTrace();
            }


            return result;

        }

        @Override
        protected void onPostExecute(String result){

            try{
                if (result.equals("1")){
                    SaveReferenceData(resultValue2,"tblRefAnnualTurnover");
                    Log.e("ReferenceData","downloaded");
                }
                else
                {
                    Log.e("ReferenceData","No titles");
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }

            GetSecurities getSecurities = new GetSecurities();
            getSecurities.execute();

        }

    }

    public class GetSecurities extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... params) {
            String result = "0";
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/GetSecurityTypes";
            String METHOD_NAME = "GetSecurityTypes";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                resultValue2 = (SoapObject) envelope.getResponse();
                result = "1";
                //result = resultValue;

            } catch (Exception e) {
                e.printStackTrace();
            }


            return result;

        }

        @Override
        protected void onPostExecute(String result){

            try{
                if (result.equals("1")){
                    SaveReferenceData(resultValue2,"tblRefSecurity");
                    Log.e("ReferenceData","downloaded");
                }
                else
                {
                    Log.e("ReferenceData","No titles");
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }

            try{
                MainActivity mainAct = (MainActivity)GlobalVariables.mainActivity;
                hideSyncingTab(mActivity);
            }catch(Exception ex){

            }

        }

    }

    protected void SaveReferenceData(SoapObject resultValue, String tableName){

        String[] refList = new String[resultValue.getPropertyCount()];

        DBHelper helper = new DBHelper(mActivity);
        SQLiteDatabase database = helper.getReadableDatabase();
        database.execSQL("DELETE FROM " + tableName);
        database.close();

        for(int i=0;i<resultValue.getPropertyCount();i++){
            refList[i] = resultValue.getPropertyAsString(i).toString();

            String id, name;
            String[] section = refList[i].split(";");

            id = section[0];
            name = section[1];

            //inserting the results into the DB
            ContentValues insertValues = new ContentValues();
            insertValues.put("Id",id);
            insertValues.put("Name", name);

            database = helper.getReadableDatabase();
            database.insert(tableName,null,insertValues);

            database.close();

        }

    }

    public static void hideSyncingTab(final Context mContext){
        final FragmentManager fragmentManager = ((MainActivity) mContext).getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentActiveSync fragSync;

        Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.slidedown_info);

        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationEnd(Animation animation) {
                //This is the key, when the animation is finished, remove the fragment.
                try{
                    fragmentTransaction.remove(fragmentManager.findFragmentById(R.id.relFragHolder)).commit();
                }catch(Exception ex){

                }

            }

            @Override
            public void onAnimationRepeat(Animation arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAnimationStart(Animation animation) {

            }
        });

        //Start the animation.
        fragSync = (FragmentActiveSync) fragmentManager.findFragmentById(R.id.relFragHolder);
        fragSync.getView().startAnimation(animation);

        //fragmentTransaction.commit();
    }
}
