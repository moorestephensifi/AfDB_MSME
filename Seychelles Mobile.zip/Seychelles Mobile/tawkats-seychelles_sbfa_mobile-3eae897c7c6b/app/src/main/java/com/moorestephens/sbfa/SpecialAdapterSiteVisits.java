package com.moorestephens.sbfa;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Tawanda on 9/16/2016.
 */
public class SpecialAdapterSiteVisits extends ArrayAdapter<String> {
    private int[] colors = new int[] { Color.parseColor("#F0F0F0"), Color.parseColor("#D2E4FC") };
    Context mContext; //This context is added to prevent the error of getLayoutInflater()
    ArrayList<String> menuData;

    private Typeface mTypeFaceLight;
    private Typeface mTypeFaceRegular;

    public SpecialAdapterSiteVisits(Context context, int layoutResourceId, ArrayList<String> data) {
        super(context, layoutResourceId, data);
        this.mContext = context; //assigning the activity's context to pass to getLayoutInflater
        menuData = data;

        //mTypeFaceLight = Typeface.createFromAsset(context.getAssets(), "OpenSans-Light.ttf");
        //mTypeFaceRegular = Typeface.createFromAsset(context.getAssets(), "OpenSans-Regular.ttf");
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;

        if (convertView == null){
            viewHolder = new ViewHolder();

            LayoutInflater inflater = ((Activity)mContext).getLayoutInflater ();  // we get a reference to the activity
            convertView = inflater.inflate(R.layout.row_site_visit, parent, false);

            viewHolder.lblDate = (TextView)convertView.findViewById(R.id.lblDate);
            viewHolder.lblID = (TextView)convertView.findViewById(R.id.lblID);
            viewHolder.lblLocation = (TextView)convertView.findViewById(R.id.lblLocation);
            viewHolder.lblTime = (TextView)convertView.findViewById(R.id.lblTime);

            convertView.setTag(viewHolder);
        }else
        {
            viewHolder = (ViewHolder) convertView.getTag();
        }


        //menuData.get(position)

        viewHolder.lblDate.setText(getDate(menuData.get(position)));
        viewHolder.lblID.setText(getID(menuData.get(position)));
        viewHolder.lblLocation.setText(getAddress(menuData.get(position)));
        viewHolder.lblTime.setText(getTime(menuData.get(position)));



        /*
        Picasso.with(mContext)
                .load(getImageURL(menuData.get(position)))
                .placeholder(R.drawable.avatar_with_border) // optional
                .error(R.drawable.avatar_with_border)
                .resize(128, 128)
                .into(viewHolder.avatar);


        if ( position % 2 == 0 )
            convertView.setBackgroundResource(R.drawable.greyback);
        else
            convertView.setBackgroundResource(R.drawable.whiteback);

*/
        return convertView;
    }

    public class ViewHolder{

        TextView lblDate;
        TextView lblTime;
        TextView lblLocation;
        TextView lblID;
    }

    private String getID(String fullString){
        String parts[] = fullString.split(";");
        return parts[0];
    }
    private String getDate(String fullString){
        String parts[] = fullString.split(";");
        return parts[1];
    }
    private String getTime(String fullString){
        String parts[] = fullString.split(";");
        return parts[2];
    }
    private String getAddress(String fullString){
        String parts[] = fullString.split(";");
        return parts[3];
    }

}