package com.moorestephens.sbfa;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class FragmentScreenLock extends Fragment {

	public static final String EXTRA_MESSAGE = "EXTRA_MESSAGE";

	Context mContext;

	Bundle bundle;

	EditText txtPassCode;
	Button cmdUnlock;

	public FragmentScreenLock(){
		
	}
	
	public static final FragmentScreenLock newInstance(String message){

		FragmentScreenLock f = new FragmentScreenLock();
		Bundle bdl = new Bundle(1);
		bdl.putString(EXTRA_MESSAGE, message);
		f.setArguments(bdl);
		return f;

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View v = inflater.inflate(R.layout.fragment_lock, container, false);

		txtPassCode = (EditText)v.findViewById(R.id.txtPasscode);
		cmdUnlock = (Button)v.findViewById(R.id.cmdUnlock);
		mContext = getActivity();
		bundle = getArguments();

		final String currentPasscode = GlobalVariables.GetPassword(mContext);

		cmdUnlock.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {

				String enterdCode = txtPassCode.getText().toString();

				if (enterdCode.isEmpty()){
					showErrorMessage("Unlock failed!","Please enter the passcode to unlock the screen!");
					return;
				}

				if (!enterdCode.equals(currentPasscode)){
					showErrorMessage("Unlock failed!", "The passcode you have entered is incorrect!");
					return;
				}else
				{
					getActivity().getSupportFragmentManager().beginTransaction().remove(FragmentScreenLock.this).commit();
				}
			}
		});
		return v;
	}
	
	@Override
	public void onAttach(Activity activity){
		super.onAttach(activity);
		
		
	}

	/*
	public void showErrorMessage(String theMessage){
		Bundle bundle = new Bundle();
		bundle.putString("theMessage", theMessage);

		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		FragmentErrorBox fragError = new FragmentErrorBox();

		fragError.setArguments(bundle);

		fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

		fragmentTransaction.commit();

	}
*/

	public void showErrorMessage(String theMessage, String theDescription){
		Bundle bundle = new Bundle();
		bundle.putString("theMessage", theMessage);
        bundle.putString("theDescription", theDescription);

		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		FragmentErrorBox fragError = new FragmentErrorBox();

		fragError.setArguments(bundle);

		fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

		fragmentTransaction.commit();

	}

}
