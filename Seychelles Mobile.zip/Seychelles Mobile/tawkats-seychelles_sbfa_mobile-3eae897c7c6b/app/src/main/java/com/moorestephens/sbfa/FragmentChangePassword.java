package com.moorestephens.sbfa;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class FragmentChangePassword extends Fragment {

	public static final String EXTRA_MESSAGE = "EXTRA_MESSAGE";

	Context mContext;

	Bundle bundle;

	EditText txtOldPassword, txtPassword1, txtPassword2;
	Button cmdCancel, cmdChange;

	public FragmentChangePassword(){
		
	}
	
	public static final FragmentChangePassword newInstance(String message){

		FragmentChangePassword f = new FragmentChangePassword();
		Bundle bdl = new Bundle(1);
		bdl.putString(EXTRA_MESSAGE, message);
		f.setArguments(bdl);
		return f;

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View v = inflater.inflate(R.layout.frag_change_password, container, false);

		txtOldPassword = (EditText)v.findViewById(R.id.txtOldPassword);
        txtPassword1 = (EditText)v.findViewById(R.id.txtPassword);
        txtPassword2 = (EditText)v.findViewById(R.id.txtRePassword);

		cmdCancel = (Button)v.findViewById(R.id.cmdCancel);
        cmdChange = (Button)v.findViewById(R.id.cmdChange);

		mContext = getActivity();
		bundle = getArguments();

		final String currentPassword = GlobalVariables.GetPassword(mContext);

		cmdChange.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {

				if (txtOldPassword.getText().toString().isEmpty()){
					showErrorMessage("Missing password!", "Please enter your old password!");
					txtOldPassword.setText("");
					return;
				}

                if (!txtOldPassword.getText().toString().trim().equals(currentPassword)){
                    showErrorMessage("Wrong password!", "The old password you entered is incorrect. Please check that you entered it correctly and try again.");
                    txtOldPassword.setText("");
                    return;
                }

                String pass1, pass2;
                pass1 = txtPassword1.getText().toString();
                pass2 = txtPassword2.getText().toString();

				if (pass1.isEmpty()){
					showErrorMessage("Missing password!", "You cannot have a blank password!");
					txtOldPassword.setText("");
					return;
				}

				if (pass1.length() < 5){
					showErrorMessage("Too short!", "Your password must be at least 5 characters long");
					txtOldPassword.setText("");
					return;
				}

				if (!pass1.equals(pass2)){
                    showErrorMessage("Password Mismatch!", "The two new passwords you entered are not the same. Please re-enter them.");
                    txtPassword1.setText("");
                    txtPassword2.setText("");
                    return;
                }

                if (CommonFunctions.ResetPassword(mContext, pass1) == 1){
					getActivity().getSupportFragmentManager().beginTransaction().remove(FragmentChangePassword.this).commit();
                }else{

                }

			}
		});

		cmdCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showSuccessMessage("test","just testing");
				getActivity().getSupportFragmentManager().beginTransaction().remove(FragmentChangePassword.this).commit();

			}
		});
		return v;
	}
	
	@Override
	public void onAttach(Activity activity){
		super.onAttach(activity);
		
		
	}

	/*
	public void showErrorMessage(String theMessage){
		Bundle bundle = new Bundle();
		bundle.putString("theMessage", theMessage);

		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		FragmentErrorBox fragError = new FragmentErrorBox();

		fragError.setArguments(bundle);

		fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

		fragmentTransaction.commit();

	}
*/

	public void showErrorMessage(String theMessage, String theDescription){
		Bundle bundle = new Bundle();
		bundle.putString("theMessage", theMessage);
        bundle.putString("theDescription", theDescription);

		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		FragmentErrorBox fragError = new FragmentErrorBox();

		fragError.setArguments(bundle);

		fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

		fragmentTransaction.commit();

	}

	public void showSuccessMessage(String theMessage, String theDescription){
		Bundle bundle = new Bundle();
		bundle.putString("theMessage", theMessage);
		bundle.putString("theDescription", theDescription);

		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		FragmentSuccessBox fragError = new FragmentSuccessBox();

		fragError.setArguments(bundle);

		fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

		fragmentTransaction.commit();

	}

}
