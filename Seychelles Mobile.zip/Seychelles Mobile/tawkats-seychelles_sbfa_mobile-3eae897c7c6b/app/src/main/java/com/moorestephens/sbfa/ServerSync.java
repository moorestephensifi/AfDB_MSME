package com.moorestephens.sbfa;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.util.Log;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;

/**
 * Created by Tawanda on 11/14/2016.
 */
public class ServerSync {

    ArrayList<String> arrTransactions;
    String SiteVisitID, Background, Findings, Conclusion, Recommendation,UserID,CaptureTime,Synced, TransactionID;

    Context mActivity;
    SoapObject resultValue, resultValue2;

    public ServerSync(Context context){
        mActivity = context;
    }

    public void GetDailyData(){

        GetScheduledSiteVisits getScheduledSiteVisits = new GetScheduledSiteVisits();
        getScheduledSiteVisits.execute();
    }

    public void checkAndSendSiteVisits(Context mContext){

        DBHelper helper = new DBHelper(mContext);
        SQLiteDatabase database = helper.getReadableDatabase();

        Cursor cursor = database.rawQuery("SELECT * FROM tblSiteVisits WHERE synced = 0",null);

        if (cursor.getCount() != 0){

            cursor.moveToFirst();

            while (!cursor.isAfterLast()){

                SiteVisitID = cursor.getString(cursor.getColumnIndex("SiteVisitID"));
                Findings = cursor.getString(cursor.getColumnIndex("Findings"));
                Recommendation = cursor.getString(cursor.getColumnIndex("Recommendation"));
                Background = cursor.getString(cursor.getColumnIndex("Background"));
                Conclusion = cursor.getString(cursor.getColumnIndex("Conclusion"));
                UserID = cursor.getString(cursor.getColumnIndex("UserID"));
                CaptureTime = cursor.getString(cursor.getColumnIndex("CaptureTime"));
                Synced = cursor.getString(cursor.getColumnIndex("Synced"));
                TransactionID = cursor.getString(cursor.getColumnIndex("TransactionID"));

                //Attempt the upload
                UploadSiteVisits uploadTask = new UploadSiteVisits(mContext);
                uploadTask.execute(SiteVisitID, Background, Findings, Conclusion, Recommendation,UserID,CaptureTime,Synced, TransactionID);

                cursor.moveToNext();
            }

        }


    }

    public class GetScheduledSiteVisits extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            String result = "0";
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/GetScheduledSiteVisits";
            String METHOD_NAME = "GetScheduledSiteVisits";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            request.addProperty("userID", GlobalVariables.getLoggedInUserID(mActivity));

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                resultValue2 = (SoapObject) envelope.getResponse();
                result = "1";
                //result = resultValue;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result){

            try{
                if (result.equals("1")){
                    SaveScheduledSiteVisits(resultValue2);
                    Log.e("ScheduledSiteVisits","downloaded");
                }
                else
                {
                    Log.e("ScheduledSiteVisits","No businesstypes");
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }


        }

    }

    protected void SaveScheduledSiteVisits(SoapObject resultValue){

        String[] refList = new String[resultValue.getPropertyCount()];

        DBHelper helper = new DBHelper(mActivity);
        SQLiteDatabase database = helper.getReadableDatabase();
        database.execSQL("DELETE FROM " + "tblScheduledSiteVisits");
        database.close();

        for(int i=0;i<resultValue.getPropertyCount();i++){
            refList[i] = resultValue.getPropertyAsString(i).toString();

            String Id,theDate,theTime,VisitAddress,FK_BDM,FK_HR;
            String[] section = refList[i].split(";");

            Id = section[0];
            theDate = section[1];
            theTime = section[2];
            VisitAddress = section[3];
            FK_BDM = section[4];

            //inserting the results into the DB
            ContentValues insertValues = new ContentValues();
            insertValues.put("ID",Id);
            insertValues.put("FK_LM", FK_BDM);
            insertValues.put("VisitDate", theDate);
            insertValues.put("VisitTime", theTime);
            insertValues.put("VisitAddress", VisitAddress);


            database = helper.getReadableDatabase();
            database.insert("tblScheduledSiteVisits",null,insertValues);

            database.close();

        }

    }

}
