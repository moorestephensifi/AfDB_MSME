package com.moorestephens.sbfa;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Tawanda on 7/4/2017.
 */

public class GlobalVariables {

    public static Activity mainActivity;

    public static String GetPassword(Context mContext){
        return "admin";
    }

    public static void saveLoggedInUserID(Context context, String userID){

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("userID", userID);

        // Commit the edits!
        editor.commit();

    }

    public static String getLoggedInUserID(Context context){
        String userID = "0";

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        userID = settings.getString("userID","0");

        return userID;
    }

    public static void saveLoggedInUserName(Context context, String userName){

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("userName", userName);

        // Commit the edits!
        editor.commit();

    }

    public static String getLoggedInUserName(Context context){
        String userName = "0";

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        userName = settings.getString("userName","App User");

        return userName;
    }

    public static void saveLoggedInUserType(Context context, String userType){

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("userType", userType);

        // Commit the edits!
        editor.commit();

    }

    public static String getLoggedInUserType(Context context){
        String userType = "0";

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        userType = settings.getString("userType","-");

        return userType;
    }

    public static void savePasscode(Context context, String passcode){

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("passcode", passcode);

        // Commit the edits!
        editor.commit();

    }

    public static String getPasscode(Context context){
        String passcode = "0000";

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        passcode = settings.getString("passcode","-");

        return passcode;
    }

    public static void saveFullName(Context context, String fullName){

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("fullName", fullName);

        // Commit the edits!
        editor.commit();

    }

    public static String getFullName(Context context){
        String fullName = "0000";

        SharedPreferences settings = context.getSharedPreferences("SETTINGS", 0);
        fullName = settings.getString("fullName","-");

        return fullName;
    }

}
