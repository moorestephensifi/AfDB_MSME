package com.moorestephens.sbfa;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.moorestephens.sbfa.crop.CropImage;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.File;
import java.util.ArrayList;

public class SiteVisitActivity extends AppCompatActivity {

    String SiteVisitID, Background, Findings, Conclusion, Recommendation,UserID,CaptureTime,Synced, TransactionID;
    EditText txtBackground, txtFindings, txtConclusion, txtRecommendation;

    FloatingActionButton cmdTakePhoto;
    String tempImageName, fileName;
    Uri mImageCaptureUri;

    final int CROPPED = 03;
    final int PICKED = 04;

    Context mActivity;

    ArrayList<String> arrImages;

    Button cmdSave, cmdCancel;

    String LMID,BusinessRegistrationNumber ;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_site_visit);

        mActivity = this;

        intent = getIntent();

        SiteVisitID = intent.getStringExtra("siteVisitID");
        //todo: Get the registration number
        BusinessRegistrationNumber = "012345";
        LMID = intent.getStringExtra("LMID");

        loadUserDetails();

        arrImages = new ArrayList<>();

        cmdTakePhoto = (FloatingActionButton)findViewById(R.id.cmdTakePhoto);
        cmdSave = (Button)findViewById(R.id.cmdSave);
        cmdCancel = (Button)findViewById(R.id.cmdCancel);

        txtBackground = (EditText)findViewById(R.id.txtBackGround);
        txtFindings = (EditText)findViewById(R.id.txtFindings);
        txtConclusion = (EditText)findViewById(R.id.txtConclusion);
        txtRecommendation = (EditText)findViewById(R.id.txtRecommendation);

        cmdSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Background = txtBackground.getText().toString();
                Findings = txtFindings.getText().toString();
                Conclusion = txtConclusion.getText().toString();
                Recommendation = txtRecommendation.getText().toString();
                UserID = GlobalVariables.getLoggedInUserID(mActivity);

                DateTime dtNow = new DateTime();
                DateTimeFormatter sdf2 = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");

                CaptureTime = dtNow.toString(sdf2);

                TransactionID = CommonFunctions.generateTransactionID(mActivity);

                //SAVING THE DATA TO THE DATABASE
                DBHelper helper = new DBHelper(mActivity);
                SQLiteDatabase database = helper.getReadableDatabase();

                ContentValues cv = new ContentValues();
                cv.put("ID",TransactionID);
                cv.put("SiteVisitID",SiteVisitID);
                cv.put("Background",Background);
                cv.put("Findings",Findings);
                cv.put("Conclusion",Conclusion);
                cv.put("Recommendation",Recommendation);
                cv.put("UserID",UserID);
                cv.put("CaptureTime",CaptureTime);
                cv.put("Synced","0");
                cv.put("TransactionID",TransactionID);

                database.insert("tblSiteVisits",null,cv);
                database.close();

                showSuccessMessage("Saving Successful", "The site visit details saved successfully and will be sent to the server momentarily.");

                //then initiate the sending to the server as a seperate process
                ServerSync serverSync = new ServerSync(mActivity);
                serverSync.checkAndSendSiteVisits(mActivity);

            }
        });

        cmdCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        cmdTakePhoto.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            tempImageName = "attach_raw.jpg";
            fileName = generateFileID(mActivity) + ".jpg";

            String path = Environment.getExternalStorageDirectory().getAbsolutePath();
            path += "/SBFA/Images/" + tempImageName;
            try{
                File oldFile = new File(path);
                oldFile.delete();
            }catch(Exception ex){

            }

            File file = new File( path );
            Uri outputFileUri = Uri.fromFile( file );
            mImageCaptureUri = outputFileUri;

            //for gallery
            Intent pickIntent = new Intent();
            pickIntent.setType("image/*");
            pickIntent.setAction(Intent.ACTION_GET_CONTENT);

            //for photo
            Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);

            String pickTitle = "Select or take a new Picture"; // Or get from strings.xml
            Intent chooserIntent = Intent.createChooser(pickIntent, pickTitle);
            chooserIntent.putExtra
                    (
                            Intent.EXTRA_INITIAL_INTENTS,
                            new Intent[] { takePhotoIntent }
                    );

            try{
                startActivityForResult(chooserIntent, PICKED);
            }catch(Exception ex){
                ex.printStackTrace();
            }

        }
    });
    }

    public void loadUserDetails(){
        TextView lblName = (TextView)findViewById(R.id.lblName);
        TextView lblUserType = (TextView)findViewById(R.id.lblUserType);

        lblName.setText(GlobalVariables.getFullName(mActivity));
        lblUserType.setText(GlobalVariables.getLoggedInUserType(mActivity));
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            switch(requestCode){
                case PICKED:
                    Uri tempUri = null;

                    try{
                        tempUri = data.getData();
                    }
                    catch(Exception ex){

                    }

                    String imagePath;

                    String path2 = Environment.getExternalStorageDirectory().getAbsolutePath();
                    path2 += "/SBFA/Images/" + tempImageName;

                    File file = new File( path2 );
                    Uri outputFileUri = Uri.fromFile( file );

                    if (tempUri == null){
                        imagePath = path2;
                    }else
                    {
                        try{
                            OpenFilesPath ofp = new OpenFilesPath();
                            //imagePath = getRealPathFromURI(tempUri);
                            imagePath = ofp.getPath(mActivity, tempUri);
                        }catch(Exception ex){
                            imagePath = path2;
                        }

                    }

                    String path = Environment.getExternalStorageDirectory().getAbsolutePath();
                    path += "/SBFA/Images/" + fileName;


                    Intent intent = new Intent(mActivity, CropImage.class);

                    //intent.putExtra("outputX", 400);
                    //intent.putExtra("outputY", 400);
                    //intent.putExtra("aspectX", 1);
                    //intent.putExtra("aspectY", 1);
                    intent.putExtra("scale", true);
                    intent.putExtra("return-data", false);
                    intent.putExtra("output", path);
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, path);
                    intent.putExtra("image-path", imagePath );
                    startActivityForResult(intent, CROPPED);

                    break;
                case CROPPED:
                    final Bundle extras = data.getExtras();

                    if (extras != null) {

                        String imgpath = Environment.getExternalStorageDirectory().getAbsolutePath();
                        imgpath += "/SBFA/Images/" + fileName;
                        arrImages.add(imgpath);

                        loadImages();
                    }

                    break;
            }
        }else{
            tempImageName = "-";
        }
    }



    private void loadImages(){

    }


    public String generateFileID(Context mContext){
        String transID;
        //couple deviceID and a non repeating number
        transID = SiteVisitID + "_" + String.valueOf(System.currentTimeMillis());
        return transID;
    }

    public void showErrorMessage(String errTitle, String errMessage){
        Bundle bundle = new Bundle();
        bundle.putString("theMessage", errTitle);
        bundle.putString("theDescription", errMessage);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentGeneralErrorBox fragError = new FragmentGeneralErrorBox();

        fragError.setArguments(bundle);

        fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

        fragmentTransaction.commit();

    }

    public void showSuccessMessage(String theMessage, String theDescription){
        Bundle bundle = new Bundle();
        bundle.putString("theMessage", theMessage);
        bundle.putString("theDescription", theDescription);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentSuccessBox fragError = new FragmentSuccessBox();

        fragError.setArguments(bundle);

        fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

        fragmentTransaction.commit();

    }

    public void showConnectionError(){

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentConnectionErrorBox fragError = new FragmentConnectionErrorBox();

        fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

        fragmentTransaction.commit();

    }

}
