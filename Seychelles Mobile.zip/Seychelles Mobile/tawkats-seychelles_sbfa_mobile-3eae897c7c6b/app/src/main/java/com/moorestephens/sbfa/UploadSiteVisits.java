package com.moorestephens.sbfa;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

/**
 * Created by Tawanda on 10/11/2016.
 */
public class UploadSiteVisits extends AsyncTask<String, String, String> {


    String SiteVisitID, Background, Findings, Conclusion, Recommendation,UserID,CaptureTime,Synced, TransactionID;
    Context mContext;

    public UploadSiteVisits(Context context) {
        super();
        mContext = context;
    }

    @Override
    protected String doInBackground(String... params) {
        String result = null;
        ConnProperties conProp = new ConnProperties();

        SiteVisitID = params[0];
        Background = params[1];
        Findings = params[2];
        Conclusion = params[3];
        Recommendation = params[4];
        UserID = params[5];
        CaptureTime = params[6];
        Synced = params[7];
        TransactionID = params[8];

        String Reg_SOAP_ACTION="http://sbfa.com/SaveMobileSiteVisit";
        String METHOD_NAME = "SaveMobileSiteVisit";

        SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

        request.addProperty("SiteVisitID",SiteVisitID);
        request.addProperty("Background",Background);
        request.addProperty("Findings",Findings);
        request.addProperty("Conclusion",Conclusion);
        request.addProperty("Recommendation",Recommendation);
        request.addProperty("UserID",UserID);
        request.addProperty("CaptureTime",CaptureTime);
        request.addProperty("Synced",Synced);
        request.addProperty("TransactionID",TransactionID);
        request.addProperty("UserName",GlobalVariables.getLoggedInUserName(mContext));

        //Declare the version of the SOAP request
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

        envelope.setOutputSoapObject(request);
        envelope.dotNet = true;

        try {
            HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

            //the call
            androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

            //the response
            String resultValue = envelope.getResponse().toString();

            result = resultValue;
            if(result == null)
            {
                Log.d("conn_error", "Result is NULL");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(String result) {

        try{
            if (!result.contains("failed")) {


                String transactionID, serverIdentityID;
                String responseBundle[] = result.split(";");

                transactionID = responseBundle[0];
                serverIdentityID = responseBundle[1];

                //changin the status of a payment to 1 to show that the payment was successful
                CommonFunctions.markSiteVisitAsUploaded(mContext, transactionID, serverIdentityID);


            }
            else{

            }

            Log.i("Connection", result);
        }catch(Exception ex)
        {
            ex.printStackTrace();

        }

    }


}