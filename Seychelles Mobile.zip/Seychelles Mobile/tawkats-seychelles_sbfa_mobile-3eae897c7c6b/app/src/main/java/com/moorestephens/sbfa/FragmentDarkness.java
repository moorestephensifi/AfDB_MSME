package com.moorestephens.sbfa;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;

public class FragmentDarkness extends Fragment {

	public static final String EXTRA_MESSAGE = "EXTRA_MESSAGE";

	public static final FragmentDarkness newInstance(String message){
			
		FragmentDarkness f = new FragmentDarkness();
		Bundle bdl = new Bundle(1);
		bdl.putString(EXTRA_MESSAGE, message);
		f.setArguments(bdl);
		return f;
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		View v = inflater.inflate(R.layout.frag_darkness, container, false);
		v.setLayerType(View.LAYER_TYPE_HARDWARE, null);
		return v;
	}
	
	@Override
	public void onAttach(Activity activity){
		super.onAttach(activity);
		
	}
	
	public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
	    Animation animation = super.onCreateAnimation(transit, enter, nextAnim);

	    // HW layer support only exists on API 11+
	    if (Build.VERSION.SDK_INT >= 11) {
	        if (animation == null && nextAnim != 0) {
	            animation = AnimationUtils.loadAnimation(getActivity(), nextAnim);
	        }

	        if (animation != null) {
	            getView().setLayerType(View.LAYER_TYPE_HARDWARE, null);

	            animation.setAnimationListener(new AnimationListener() {
	                public void onAnimationEnd(Animation animation) {
	                    getView().setLayerType(View.LAYER_TYPE_NONE, null);
	                }

					@Override
					public void onAnimationRepeat(Animation animation) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onAnimationStart(Animation animation) {
						// TODO Auto-generated method stub
						
					}

	                // ...other AnimationListener methods go here...
	            });
	        }
	    }

	    return animation;
	}


	
@Override
public void onActivityCreated (Bundle savedInstanceState)
{
	super.onActivityCreated(savedInstanceState);	
	
}
}
