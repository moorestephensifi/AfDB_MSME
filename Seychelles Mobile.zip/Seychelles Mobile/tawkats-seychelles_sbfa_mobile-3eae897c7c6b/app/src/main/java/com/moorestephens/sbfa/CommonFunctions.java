package com.moorestephens.sbfa;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.Settings;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import java.util.ArrayList;

/**
 * Created by Tawanda on 7/5/2017.
 */

public class CommonFunctions {

    public static int ResetPassword(Context mContext, String newPassword){
        return 1;
    }

    public static void showBackOfLightBox(Context mContext){
        FragmentManager fragmentManager = ((MainActivity) mContext).getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentDarkness fragDarkness = new FragmentDarkness();

        fragmentTransaction.setCustomAnimations(R.anim.lightbox_fade_in, 0);
        fragmentTransaction.add(R.id.relDarkness,fragDarkness, "Background");

        fragmentTransaction.commitAllowingStateLoss();
    }

    public static void removeBackOfLightBox(final Context mContext){
        final FragmentManager fragmentManager = ((MainActivity) mContext).getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentDarkness fragDarkness = new FragmentDarkness();

        Animation animation = AnimationUtils.loadAnimation(mContext, R.anim.lightbox_fade_out);

        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationEnd(Animation animation) {
                //This is the key, when the animation is finished, remove the fragment.
                try{
                    fragmentTransaction.remove(fragmentManager.findFragmentById(R.id.relDarkness)).commit();
                }catch(Exception ex){

                }

            }

            @Override
            public void onAnimationRepeat(Animation arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAnimationStart(Animation animation) {

            }
        });

        //Start the animation.
        fragDarkness = (FragmentDarkness) fragmentManager.findFragmentById(R.id.relDarkness);
        fragDarkness.getView().startAnimation(animation);

        //fragmentTransaction.commit();
    }

    public static String generateTransactionID(Context mContext){
        String transID;
        //couple deviceID and a non repeating number
        transID = getDeviceID(mContext) + "_" + String.valueOf(System.currentTimeMillis());
        return transID;
    }

    public static String getDeviceID(Context mContext){
        String ID = "00000";
        try{
            ID = Settings.Secure.getString(mContext.getContentResolver(), Settings.Secure.ANDROID_ID);
        }catch (Exception ex){

        }

        return ID;
    }

    public static void markSiteVisitAsUploaded(Context mContext, String transactionID, String serverIdentityID){
        DBHelper helper = new DBHelper(mContext);
        SQLiteDatabase database = helper.getReadableDatabase();

        database.execSQL("UPDATE tblSiteVisits SET synced = 1, ID = " + serverIdentityID + " WHERE TransactionID = '" + transactionID + "'");
        database.close();
    }

    public static ArrayList<String> GetReferenceDataName(Context mContext, String referenceName){

        ArrayList<String> data = new ArrayList<>();
        String tableName = "";

        String spinnerPlaceHolder = "Select Option...";

        if (referenceName.equals("securityTypes")){
            tableName = "tblRefSecurity";

        }else if (referenceName.equals("businessTypes")){
            tableName = "tblRefBusinessTypes";

        }else if (referenceName.equals("islands")){
            tableName = "tblRefIslands";

        }else if (referenceName.equals("titles")){
            tableName = "tblRefTitles";
            spinnerPlaceHolder = "Select...";

        }else if (referenceName.equals("annualTurnover")){
            tableName = "tblRefAnnualTurnover";
        }

        DBHelper helper = new DBHelper(mContext);
        SQLiteDatabase database = helper.getReadableDatabase();

        Cursor c = database.rawQuery("SELECT * FROM " + tableName,null);

        data.add(spinnerPlaceHolder);

        try
        {
            c.moveToFirst();

            while (!c.isAfterLast()){
                data.add(c.getString(c.getColumnIndex("Name")));
                c.moveToNext();
            }

        }catch(Exception ex){

        }finally{
            database.close();
        }

        return data;
    }

    public static ArrayList<String> GetDistrictsInIsland(Context mContext, String islandName) {
        ArrayList<String> data = new ArrayList<>();
        String tableName = "tblRefDistricts";
        String islandID = GetReferenceItemID(mContext,"islands", islandName);

        DBHelper helper = new DBHelper(mContext);
        SQLiteDatabase database = helper.getReadableDatabase();

        Cursor c = database.rawQuery("SELECT Name FROM " + tableName + " WHERE IslandID = " + islandID,null);

        data.add("Select option...");

        try
        {
            c.moveToFirst();


            while (!c.isAfterLast()){
                data.add(c.getString(c.getColumnIndex("Name")));
                c.moveToNext();
            }

        }catch(Exception ex){

        }finally{
            database.close();
        }

        return data;
    }

    public static String GetReferenceItemID(Context mContext, String referenceName, String referenceItem){

        String data = "0";
        String tableName = "";

        if (referenceName.equals("registrationTypes")){
            tableName = "tblRefRegistrationTypes";

        }else if (referenceName.equals("businessTypes")){
            tableName = "tblRefBusinessTypes";

        }else if (referenceName.equals("islands")){
            tableName = "tblRefIslands";

        }else if (referenceName.equals("districts")){
            tableName = "tblRefDistricts";

        }else if (referenceName.equals("educationLevels")){
            tableName = "tblRefEducationalLevel";
        }

        DBHelper helper = new DBHelper(mContext);
        SQLiteDatabase database = helper.getReadableDatabase();

        Cursor c = database.rawQuery("SELECT ID FROM " + tableName + " WHERE Name = '" + referenceItem.trim() + "'",null);

        try
        {
            c.moveToFirst();

            while (!c.isAfterLast()){
                data = c.getString(c.getColumnIndex("ID"));
                c.moveToNext();
            }

        }catch(Exception ex){

        }finally{
            database.close();
        }

        return data;
    }

}
