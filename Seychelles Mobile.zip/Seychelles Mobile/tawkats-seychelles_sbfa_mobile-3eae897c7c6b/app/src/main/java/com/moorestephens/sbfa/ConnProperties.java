package com.moorestephens.sbfa;

/**
 * Created by Tawanda on 3/27/2017.
 */

public class ConnProperties {

    String host = "10.128.2.167:8090";
    //String host = "192.168.0.18";
    String URL = "http://" + host +"/AppWebServices/SBFA_Service.asmx";

    String NAMESPACE = "http://sbfa.com/";

    String WebResponse;

}
