package com.moorestephens.sbfa;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {

    RelativeLayout relError;
    Button cmdCloseError;
    EditText txtUsername, txtPassword;
    String username, fullname, userID;

    String Reg_SOAP_ACTION="http://sbfa.com/LoginUser";
    String METHOD_NAME = "LoginUser";

    String Reg_SOAP_ACTION2="http://sbfa.com/ResetPassword";
    String METHOD_NAME2 = "ResetPassword";

    String userName, password, pass;
    RelativeLayout relSigningIn, relFailed, relForgot;

    Context mActivity;

    TextView lblReason;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mActivity = this;

        relError = (RelativeLayout)findViewById(R.id.relError);
        cmdCloseError = (Button)findViewById(R.id.cmdCloseError);

        txtUsername = (EditText)findViewById(R.id.txtUsername);
        txtPassword = (EditText)findViewById(R.id.txtPassword);

        relSigningIn = (RelativeLayout)findViewById(R.id.relSigningIn);
        relFailed = (RelativeLayout)findViewById(R.id.relError);
        relForgot = (RelativeLayout)findViewById(R.id.relForgot);

        lblReason = (TextView)findViewById(R.id.textView6);

        cmdCloseError.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                relError.setVisibility(View.GONE);
            }
        });


        //initialise the DB if it hasnt already
        try{
            initDatabase(mActivity);
        }catch(Exception ex){

        }


        Button cmdLogin = (Button)findViewById(R.id.cmdLogin);
        cmdLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dismissKeyboard(LoginActivity.this);
                username = txtUsername.getText().toString();
                password = txtPassword.getText().toString();

                if (username.isEmpty()){
                    showErrorMessage("Validation Error", "Please enter your username to log in!");
                    return;
                }

                if (password.isEmpty()){
                    showErrorMessage("Validation Error",  "Please enter your password to log in!");
                    return;
                }

                //startActivity(new Intent(LoginActivity.this, MainActivity.class));



                // GlobalVariables.saveLoggedInUserID(mActivity,"1");
                //doOfflineLogin(username, password);

                relSigningIn.setVisibility(View.VISIBLE);
                LoginTask loginTask = new LoginTask();
                loginTask.execute();

            }
        });
    }

    public void initDatabase(Context context) throws IOException {
        //this procedure will initialise the database
        DBHelper helper = new DBHelper(context);
        SQLiteDatabase database = helper.getReadableDatabase();

        try {
            helper.createDataBase(context);

            Cursor c = database.rawQuery("SELECT * FROM tblUser", null);

        } catch (Exception ioe) {
            try {
                helper.copyDataBase();

                //once copied, tag it as registered
                //markAsRegistered();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        database.close();
    }

    public String doOfflineLogin(String userCode, String passCode){

        DBHelper helper = new DBHelper(mActivity);
        SQLiteDatabase database = helper.getReadableDatabase();


        Cursor cursor = database.rawQuery("SELECT * FROM tblUser WHERE userName = '" + userCode + "' AND password = '" + passCode + "'",null);

        if (cursor.getCount() == 0){
            //do the online sign in
            LoginTask task = new LoginTask();
            task.execute();
        }else{
            //if login is successful

            cursor.moveToFirst();

            GlobalVariables.saveLoggedInUserID(mActivity, userCode);
            GlobalVariables.saveLoggedInUserName(mActivity, cursor.getString(cursor.getColumnIndex("userName")));
            GlobalVariables.saveLoggedInUserType(mActivity, cursor.getString(cursor.getColumnIndex("userType")));

            cursor.close();
            database.close();

            UpdateDetailsTask task = new UpdateDetailsTask();
            task.execute();

            Intent myIntent = new Intent(LoginActivity.this, MainActivity.class);
            ActivityOptions options =
                    ActivityOptions.makeCustomAnimation(mActivity, R.anim.slideup_info, R.anim.slidedown_info);
            startActivity(myIntent, options.toBundle());
            finish();


        }

        return "";
    }

    public class LoginTask extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            String result = null;
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/LoginUser";
            String METHOD_NAME = "LoginUser";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            request.addProperty("userName", username);
            request.addProperty("password", password);
            request.addProperty("deviceID", CommonFunctions.getDeviceID(mActivity));

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                String resultValue = envelope.getResponse().toString();

                result = resultValue;
                if(result == null)
                {
                    Log.d("conn_error", "Result is NULL");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {

            relSigningIn.setVisibility(View.GONE);

            try{

                if (!result.contains("failed") ) {

                    if (result.equals("inactive")){
                        relFailed.setVisibility(View.VISIBLE);
                        //lblFailedHeading.setText("Login Failed!");
                        lblReason.setText("Your account has been disabled. Please contact the Administrator.");
                        return;
                    }

                    if (result.equals("locked")){
                        relFailed.setVisibility(View.VISIBLE);
                        //lblFailedHeading.setText("Login Failed!");
                        lblReason.setText("Your account has been locked. Please contact the Administrator.");
                        return;
                    }

                    //Id,FK_RoleGroup,FirstName,Surname,EmailAddress,MobileNumber
                    String[] userDetails = result.split(";");
                    GlobalVariables.saveLoggedInUserID(mActivity, userDetails[0]);
                    GlobalVariables.saveLoggedInUserName(mActivity, username);
                    GlobalVariables.saveLoggedInUserType(mActivity, userDetails[1]);

                    fullname = userDetails[2] + " " + userDetails[3];
                    GlobalVariables.saveFullName(mActivity,fullname);

                    DBHelper helper = new DBHelper(mActivity);
                    //delete the particular to get new details from the
                    SQLiteDatabase database2 = helper.getReadableDatabase();
                    database2.execSQL("DELETE FROM tblUser WHERE id = '" + userDetails[0] + "'");
                    database2.close();
                    //save the details to the database

                    SQLiteDatabase database = helper.getReadableDatabase();

                    ContentValues cv = new ContentValues();
                    cv.put("id", userDetails[0]);
                    cv.put("username",username);
                    cv.put("password",password);
                    cv.put("fullName",userDetails[2] + userDetails[3]);
                    cv.put("userType",userDetails[1]);
                    cv.put("emailAddress",userDetails[4]);
                    cv.put("mobileNumber",userDetails[5]);

                    database.insert("tblUser",null,cv);
                    database.close();

                    Intent myIntent = new Intent(LoginActivity.this, MainActivity.class);
                    ActivityOptions options =
                            ActivityOptions.makeCustomAnimation(mActivity, R.anim.slideup_info, R.anim.slidedown_info);
                    startActivity(myIntent, options.toBundle());
                    finish();

                }
                else{
                    relFailed.setVisibility(View.VISIBLE);
                }

                Log.i("Connection", result);
            }catch(Exception ex)
            {
                doOfflineLogin(username, password);
                ex.printStackTrace();
                //showErrorMessage("Connection Error", "Error connecting to the server, please try again.");

            }

        }

    }

    public void showErrorMessage(String errTitle, String errMessage){
        Bundle bundle = new Bundle();
        bundle.putString("theMessage", errTitle);
        bundle.putString("theDescription", errMessage);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        FragmentGeneralErrorBox fragError = new FragmentGeneralErrorBox();

        fragError.setArguments(bundle);

        fragmentTransaction.add(R.id.relFragHolder,fragError, "View");

        fragmentTransaction.commit();

    }

    public class ResetCodeTask extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            String result = null;
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION="http://sbfa.com/ResetPassword";
            String METHOD_NAME = "ResetPassword";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);

            request.addProperty("userID", userID);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL,100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                String resultValue = envelope.getResponse().toString();

                result = resultValue;
                if(result == null)
                {
                    Log.d("conn_error", "Result is NULL");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {

            relSigningIn.setVisibility(View.GONE);

            try{

                if (!result.contains("failed") ) {

                    if (result.equals("1")){
                        relForgot.setVisibility(View.GONE);
                        Toast.makeText(LoginActivity.this, "Your passcode has been reset. Please check for the details on your phone via SMS.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (result.equals("notcashier")){
                        relFailed.setVisibility(View.VISIBLE);
                        //lblFailedHeading.setText("Reset Failed!");
                        //lblFailedMessage.setText("Your account type is cannot be used on the device. Please contact the Administrator.");
                        return;
                    }
                    if (result.equals("usernotfound")){
                        relFailed.setVisibility(View.VISIBLE);
                        //lblFailedHeading.setText("Reset Failed!");
                        //lblFailedMessage.setText("Could not find the cashier code you entered. Please re-enter it and try again.");
                        return;
                    }
                    if (result.equals("nophoneno")){
                        relFailed.setVisibility(View.VISIBLE);
                        //lblFailedHeading.setText("Reset Failed!");
                        //lblFailedMessage.setText("Your account has missing details. Please contact the Administrator.");
                        return;
                    }
                    if (result.equals("nopasscode")){
                        relFailed.setVisibility(View.VISIBLE);
                        //lblFailedHeading.setText("Reset Failed!");
                        //lblFailedMessage.setText("There is an issue with your account. Please contact the Administrator.");
                        return;
                    }

                    relFailed.setVisibility(View.GONE);

                }
                else{
                    relFailed.setVisibility(View.VISIBLE);
                }

                Log.i("Connection", result);
            }catch(Exception ex)
            {
                ex.printStackTrace();
                showErrorMessage("Connection Error", "Error connecting to the server, please try again.");

            }

        }

    }

    public class UpdateDetailsTask extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            String result = null;
            ConnProperties conProp = new ConnProperties();

            String Reg_SOAP_ACTION = "http://sbfa.com/GetAppUser";
            String METHOD_NAME = "GetAppUser";

            SoapObject request = new SoapObject(conProp.NAMESPACE, METHOD_NAME);


            //get current username and password
            try{
                DBHelper helper = new DBHelper(mActivity);
                SQLiteDatabase database = helper.getReadableDatabase();

                String userName, officeID, municipalityID, officeName, officeLocation, deviceNumber;
                Cursor cursor = database.rawQuery("SELECT * FROM tblUser WHERE userID = '" + GlobalVariables.getLoggedInUserID(mActivity) + "'",null);
                cursor.moveToFirst();

                pass =  cursor.getString(cursor.getColumnIndex("passCode"));

            }
            catch (Exception ex){
                return "0";
            }


            request.addProperty("userID", GlobalVariables.getLoggedInUserID(mActivity));
            request.addProperty("deviceID", CommonFunctions.getDeviceID(mActivity));

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(conProp.URL, 100000);

                //the call
                androidHttpTransport.call(Reg_SOAP_ACTION, envelope); // Exception is coming here

                //the response
                String resultValue = envelope.getResponse().toString();

                result = resultValue;
                if (result == null) {
                    Log.d("conn_error", "Result is NULL");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {

            //relSigningIn.setVisibility(View.GONE);

            try {


                String[] userDetails = result.split(";");

                DBHelper helper = new DBHelper(mActivity);
                //delete the particular to get new details from the
                SQLiteDatabase database2 = helper.getReadableDatabase();
                database2.execSQL("DELETE FROM tblUser WHERE userID = '" + userDetails[0] + "'");
                database2.close();
                //save the details to the database

                SQLiteDatabase database = helper.getReadableDatabase();

                ContentValues cv = new ContentValues();
                cv.put("userID", GlobalVariables.getLoggedInUserID(mActivity));
                cv.put("passCode", pass);
                cv.put("userName", userDetails[1]);
                cv.put("officeID", userDetails[4]);
                cv.put("municipalID", userDetails[5]);
                cv.put("officeName", userDetails[6]);
                cv.put("officeLocation", userDetails[7]);

                if (userDetails[2].equals("True")) {
                    //true if its a trade officer
                    cv.put("userType", "tradeOfficer");
                } else {
                    //else its a cashier
                    cv.put("userType", "cashier");
                }

                database.insert("tblUser", null, cv);
                database.close();

                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();


                Log.i("Connection", result);
            } catch (Exception ex) {
                ex.printStackTrace();
                showErrorMessage("Connection Error", "Error connecting to the server, please try again.");

            }

        }
    }

    public void dismissKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (null != activity.getCurrentFocus())
            imm.hideSoftInputFromWindow(activity.getCurrentFocus()
                    .getApplicationWindowToken(), 0);
    }

}
