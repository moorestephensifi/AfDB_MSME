﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SBFA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "sbfa" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select sbfa.svc or sbfa.svc.cs at the Solution Explorer and start debugging.
    public class SBFA : ISBFA
    {
        #region messaging
        public bool SendBasicEmail(string to, string subject, string message)
        {
            return Utilities.SendEmail(to, subject, message);
        }

        public bool SendSMS(string to, string message)
        {
            return Utilities.SendSMS(to, message);
        }

        public long SendGroupEmail(string to, string subject, string message)
        {
            return Utilities.SendGroupEmail(to, subject, message);
        }

        public long SendGroupSMS(string to, string message)
        {
            return Utilities.SendGroupSMS(to, message);
        }

        //get emails
        public List<Email> GetEmails(string filterText)
        {
            return Utilities.GetEmails(filterText);
        }

        //clear emails
        public bool ClearEmails()
        {
            return Utilities.ClearEmails();
        }

        //clear sms
        public bool ClearSMSs()
        {
            return Utilities.ClearSMSs();
        }

        //get smss
        public List<SMS> GetSMSs(string filterText)
        {
            return Utilities.GetSMSs(filterText);
        }

        //get list of Email Message Designs
        public List<EmailMessageDesign> GetEmailMessageDesigns()
        {
            return Utilities.GetEmailMessageDesigns();
        }

        //get Email Message Design
        public EmailMessageDesign GetEmailMessageDesign(string design)
        {
            return Utilities.GetEmailMessageDesign(design);
        }

        #endregion

        #region workflow

        public DocumentWorkflow SubmitWorkFlowDocument(long workFlowId, string documentId, string documentType)
        {
            return Utilities.SubmitWorkFlowDocument(workFlowId, documentId, documentType);
        }

        public string GetNextWorkFlowStage(long Id, string entityType)
        {
            return Utilities.GetNextWorkFlowStage(Id, entityType);
        }

        public string GetCurrentWorkFlowStage(long Id, string entityType)
        {
            return Utilities.GetCurrentWorkFlowStage(Id, entityType);
        }

        public DocumentWorkflow UpdateWorkFlowStage(long Id, string entityType)
        {
            return Utilities.UpdateWorkFlowStage(Id, entityType);
        }

        public DocumentWorkflow TerminateWorkFlowStage(long Id, string entityType)
        {
            return Utilities.TerminateWorkFlowStage(Id, entityType);
        }

        public bool AssignWorkFlowStage(string username, long Id, string entityType)
        {
            return Utilities.AssignWorkFlowStage(username, Id, entityType);
        }

        public List<ApplicationUserSummary> GetAssigningUserList(long Id, string entityType)
        {
            return Utilities.GetAssigningUserList(Id, entityType);
        }

        public List<WorkFlowStageDocuments> GetDocumentsRequiredList(long Id, string entityType)
        {
            return Utilities.GetDocumentsRequiredList(Id, entityType);
        }

        public string CheckCurrentStageDocumentRequirements(long Id, string entityType)
        {
            return Utilities.CheckCurrentStageDocumentRequirements(Id, entityType);
        }

        public bool CheckCurrentStagePaymentRequirements(long Id, string entityType)
        {
            return Utilities.CheckCurrentStagePaymentRequirements(Id, entityType);
        }

        public string CheckCurrentStageSiteVisitRequirements(long Id, string entityType)
        {
            return Utilities.CheckCurrentStageSiteVisitRequirements(Id, entityType);
        }

        public string CheckCurrentStageRecommandationSiteVisitRequirements(long Id, string entityType, long recommendationId, int stakeholderId)
        {
            return Utilities.CheckCurrentStageSiteVisitRequirements(Id, entityType, recommendationId, stakeholderId);
        }

        public string CheckCurrentStageRecommendationsRequirements(long Id, string entityType)
        {
            return Utilities.CheckCurrentStageRecommendationsRequirements(Id, entityType);
        }

        public bool UploadWorkFlowDocument(long Id, string entityType, string fileName, byte[] fileData, int documentTypeId, long documentFolderId, bool businessAssesment)
        {
            return ((Utilities.UploadWorkFlowDocument(Id, entityType, fileName, fileData, documentTypeId, documentFolderId, businessAssesment) > 0) ? true : false);
        }

        //get document list for a workflow, without the actual document
        public List<DocumentLibrary> GetWorkFlowDocuments(long Id, string entityType)
        {
            return Utilities.GetWorkFlowDocuments(Id, entityType);
        }

        public WorkFlows GetWorkFlow(long Id)
        {
            return Utilities.GetWorkFlow(Id);
        }

        public bool UpdateWorkFlow(WorkFlows wrkFlow)
        {
            return Utilities.UpdateWorkFlow(wrkFlow);
        }

        public long CreateWorkFlow(string workFlowName, string workFlowDescription, long startRoleGroupId, long endRoleGroupId)
        {
            return Utilities.CreateWorkFlow(workFlowName, workFlowDescription, startRoleGroupId, endRoleGroupId);
        }

        public List<WorkFlows> GetWorkFlows()
        {
            return Utilities.GetWorkFlows();
        }

        public WorkFlowStages GetWorkFlowStage(long Id)
        {
            return Utilities.GetWorkFlowStage(Id);
        }

        public WorkFlowStages GetDocumentWorkFlowStage(long Id, string entityType)
        {
            return Utilities.GetWorkFlowStage(Id, entityType);
        }

        public bool UpdateWorkFlowStageRecord(WorkFlowStages wrkFlow)
        {
            return Utilities.UpdateWorkFlowStage(wrkFlow);
        }

        public long CreateWorkFlowStage(long workFlowId, int stagePosition, string stageName, string stageDescription, long roleGroupId, int stageAssignMode, bool stageOptional, bool requireDocuments, bool requirePayment, bool requireSiteVisit, bool requireRecommendations, string fK_AutoDocumentName, int sendEmail, int sendSMS)
        {
            return Utilities.CreateWorkFlowStage(workFlowId, stagePosition, stageName, stageDescription, roleGroupId, stageAssignMode, stageOptional, requireDocuments, requirePayment, requireSiteVisit, requireRecommendations, fK_AutoDocumentName, sendEmail, sendSMS);

        }

        public List<WorkFlowStages> GetWorkFlowStages(long Id)
        {
            return Utilities.GetWorkFlowStages(Id);
        }

        public WorkFlowStageDocuments GetWorkFlowStageDocument(long Id)
        {
            return Utilities.GetWorkFlowStageDocument(Id);
        }

        public bool UpdateWorkFlowStageDocument(WorkFlowStageDocuments wrkFlow)
        {
            return Utilities.UpdateWorkFlowStageDocument(wrkFlow);
        }

        public bool CreateWorkFlowStageDocument(long stageId, int documentTypeId, bool documentRequired)
        {
            return Utilities.CreateWorkFlowStageDocument(stageId, documentTypeId, documentRequired);
        }

        public List<WorkFlowStageDocuments> GetWorkFlowStageDocuments(long Id)
        {
            return Utilities.GetDocumentsRequiredList(Id);
        }

        public List<DocumentWorkFlowProgress> GetWorkFlowProgress(long Id)
        {
            return Utilities.GetWorkFlowProgress(Id);
        }

        public List<WorkFlowStageDocumentStatus> GetDocumentsRequiredStatus(long Id, string entityType)
        {
            return Utilities.GetDocumentsRequiredStatus(Id, entityType);
        }

        public bool CheckAccessToStage(long Id, string entityType)
        {
            return Utilities.CheckAccessToStage(Id, entityType);
        }

        public List<WorkFlowStageDocumentStatus> GetAllRequiredDocuments(long Id, string entityType)
        {
            return Utilities.GetAllRequiredDocuments(Id, entityType);
        }

        public List<WorkFlowFieldValidations> GetValidationsList(string docType)
        {
            return Utilities.GetValidationsList(docType);
        }

        public List<FeeRules> GetFeeRulesList(string docType)
        {
            return Utilities.GetFeeRulesList(docType);
        }

        public bool SkipOptionalStage(long Id, string entityType)
        {
            return Utilities.SkipOptionalStage(Id, entityType);
        }

        public bool ReverseStage(long Id, string entityType)
        {
            return Utilities.ReverseStage(Id, entityType);
        }

        public List<WorkFlowStagesAutoDocuments> GetWorkFlowStagesAutoDocuments(long Id)
        {
            return Utilities.GetWorkFlowStagesAutoDocuments(Id);
        }

        public long CreateWorkFlowStagesAutoDocument(long workFlowStageId, string fK_AutoDocumentName, int sendEmail, int sendSMS, bool active)
        {
            return Utilities.CreateWorkFlowStagesAutoDocument(workFlowStageId, fK_AutoDocumentName, sendEmail, sendSMS, active);
        }

        public WorkFlowStagesAutoDocuments GetWorkFlowStagesAutoDocument(long Id)
        {
            return Utilities.GetWorkFlowStagesAutoDocument(Id);
        }

        public bool SwitchStages(long IdUp, long IdDown)
        {
            return Utilities.SwitchStages(IdUp, IdDown);
        }

        public bool DeleteStage(long workId, long delId)
        {
            return Utilities.DeleteStage(workId, delId);
        }

        public long GetWorkFlowId(long Id, string entityType)
        {
            return Utilities.GetWorkFlowId(Id, entityType);
        }
        #endregion

        #region documents

        public bool UploadDocument(long Id, string fileName, byte[] fileData, int documentTypeId, long documentFolderId)
        {
            return Utilities.UploadDocument(Id, fileName, fileData, documentTypeId, documentFolderId);
        }

        //get document list of documents without the actual document
        public List<DocumentLibrary> GetDocuments(long Id)
        {
            return Utilities.GetDocuments(Id);

        }

        public List<DocumentLibrary> GetFolderDocuments(long Id)
        {
            return Utilities.GetFolderDocuments(Id);

        }

        public List<DocumentLibrary> GetRegistrationsFolderDocuments(long Id)
        {
            return Utilities.GetRegistrationsFolderDocuments(Id);

        }

        //get actual file
        public DocumentLibrary GetDocument(long Id)
        {
            return Utilities.GetDocument(Id);

        }

        //get folder list
        public List<DocumentFolders> GetFolders(long parentId)
        {
            return Utilities.GetFolders(parentId);
        }

        //create new folder
        public long CreateFolder(string folderName, long parentId)
        {
            return Utilities.CreateFolder(folderName, parentId);
        }

        //rename folder
        public bool RenameFolder(long Id, string newName)
        {
            return Utilities.RenameFolder(Id, newName);
        }

        public List<DocumentTypes> GetDocumentTypes()
        {
            return Utilities.GetDocumentTypes();
        }

        public List<DocumentLibrary> SearchDocuments(long Id, string filterText)
        {
            return Utilities.GetDocuments(Id, filterText);
        }

        public List<DocumentLibrary> SearchRegistrationDocuments(long Id, string filterText)
        {
            return Utilities.GetRegistrationDocuments(Id, filterText);
        }

        public string GetFolderName(long Id)
        {
            return Utilities.GetFolderName(Id);
        }

        public string GetFolderPath(long Id)
        {
            return Utilities.GetFolderPath(Id);
        }

        public long GetParentFolderId(long Id)
        {
            return Utilities.GetParentFolderId(Id);
        }

        public bool UploadTemplateDocument(string name, string fileName, byte[] fileData)
        {
            return Utilities.UploadTemplateDocument(name, fileName, fileData);
        }

        public  DocumentTemplateLibrary GetDocumentTemplate(string name)
        {
            return Utilities.GetDocumentTemplate(name);
        }
        public List<DocumentTemplateLibrary> GetDocumentTemplates()
        {
            return Utilities.GetDocumentTemplates();
        }
        #endregion

        #region sbfa
        public long SaveLoanRequest(LoanRequest loan)
        {
            return Utilities.SaveLoanRequest(loan);
        }

        public bool RegisterLoan(long Id, string entityType)
        {
            return Utilities.RegisterLoan(Id, entityType);
        }

        public bool RegisterDeclineLoan(long Id, string entityType)
        {
            return Utilities.RegisterDeclineLoan(Id, entityType);
        }

        public List<LoanRequest> GetLoanRequests(string filterText)
        {
            return Utilities.GetLoanRequests(filterText);
        }

        public LoanRequest GetLoanRequest(long Id)
        {
            return Utilities.GetLoanRequest(Id);
        }

        public long SaveDisbursementRequest(DisbursementRequest disbursement)
        {
            return Utilities.SaveDisbursementRequest(disbursement);
        }

        public List<DisbursementRequest> GetDisbursementRequests(string filterText)
        {
            return Utilities.GetDisbursementRequests(filterText);
        }

        public List<DisbursementRequest> GetActiveDisbursementRequests(string filterText)
        {
            return Utilities.GetActiveDisbursementRequests(filterText);
        }

        public DisbursementRequest GetDisbursementRequest(long Id)
        {
            return Utilities.GetDisbursementRequest(Id);
        }

        public List<DisbursementRequest> GetLoanDisbursementRequests(long Id)
        {
            return Utilities.GetDisbursementRequests(Id);
        }

        public List<AutoDocument> CheckAutoDocument(long Id, string entityType)
        {
            return Utilities.CheckAutoDocument(Id, entityType);
        }

        public Byte[] GetAutoDocument(string docType, long Id)
        {
            return Utilities.GetAutoDocument(docType, Id);
        }

        public Byte[] GetDisbursementDocument(long Id)
        {
            return Utilities.GetDisbursementDocument(Id);
        }

        public bool CreateLoanApproval(long Id)
        {
            return Utilities.CreateLoanApproval(Id);
        }

        public LoanRequestApproval GetLoanApproval(long Id)
        {
            return Utilities.GetLoanApproval(Id);
        }

        public QuickStats GetQuickStats()
        {
            return Utilities.GetQuickStats();
        }

        public List<Notifications> CheckNotifications(string filterText, bool pending)
        {
            return Utilities.CheckNotifications(filterText, pending);
        }

        public bool UpdateNotifications(long Id, bool status)
        {
            return Utilities.UpdateNotifications(Id, status);
        }

        public Guarantor GetGuarantor(string nin)
        {
            return Utilities.GetGuarantor(nin);
        }

        public List<Guarantor> GetGuarantors(long Id)
        {
            return Utilities.GetGuarantors(Id);
        }

        public long SaveLoanRequestGuarantor(Guarantor guarantor)
        {
            return Utilities.SaveLoanRequestGuarantor(guarantor);
        }

        public Guarantor GetLoanRequestGuarantor(string nin, long Id)
        {
            return Utilities.GetLoanRequestGuarantor(nin, Id);
        }

        public BusinessRegistration GetBusinessRegistration(string nin)
        {
            return Utilities.GetBusinessRegistration(nin);
        }

        public bool SaveLoanAssesment(LoanAssesment loanAss)
        {
            return Utilities.SaveLoanAssesment(loanAss);
        }

        public bool DeleteLoanAssesment(LoanAssesment loanAss)
        {
            return Utilities.DeleteLoanAssesment(loanAss);
        }

        public LoanAssesment GetLoanAssesment(long requestId)
        {
            return Utilities.GetLoanAssesment(requestId);
        }

        public LoanAssesment GetDisbursementLoanAssesment(long requestId)
        {
            return Utilities.GetDisbursementLoanAssesment(requestId);
        }

        public bool SaveRecommendation(long fK_LoanRequestId, string fK_Stage, bool approved, string recommendation)
        {
            return Utilities.SaveRecommendation(fK_LoanRequestId, fK_Stage, approved, recommendation);
        }

        public List<LoanApprovalRecommendations> GetLoanApprovalRecommendations(long requestId)
        {
            return Utilities.GetLoanApprovalRecommendations(requestId);
        }

        public List<Loan> GetLoans(string filterText)
        {
            return Utilities.GetLoans(filterText);
        }

        public Loan GetLoan(long Id)
        {
            return Utilities.GetLoan(Id);
        }

        public bool UpdateDisbursementStatus(long Id)
        {
            return Utilities.UpdateDisbursementStatus(Id);
        }

        public Loan GetLoanByRequestId(long requestId)
        {
            return Utilities.GetLoanByRequestId(requestId);
        }

        public bool CheckVoucher(long disId)
        {
            return Utilities.CheckVoucher(disId);
        }

        public long SaveVoucher(PaymentVoucher voucher)
        {
            return Utilities.SaveVoucher(voucher);
        }

        public PaymentVoucher GetPaymentVoucher(long requestId)
        {
            return Utilities.GetPaymentVoucher(requestId);
        }

        public List<BusinessAccount> GetBusinessAccounts(string filterText)
        {
            return Utilities.GetBusinessAccounts(filterText);

        }

        public BusinessAccount GetBusinessAccount(string NIN)
        {
            return Utilities.GetBusinessAccount(NIN);
        }

        public float CalculateMonthlyRepayment(int months, long requestId)
        {
            return Utilities.CalculateMonthlyRepayment(months, requestId);
        }

        public bool DisburseDisbursement(long Id)
        {
            return Utilities.DisburseDisbursement(Id);
        }

        public BusinessAccount GetBusinessAccountByAccount(string acc)
        {
            return Utilities.GetBusinessAccountByAccount(acc);
        }

        public BusinessAccountOld GetOldBusinessAccountByAccount(string acc, string loan)
        {
            return Utilities.GetOldBusinessAccountByAccount(acc,loan);
        }

        public List<RepaymentSchedule> GetRepaymentSchedules(string acc)
        {
            return Utilities.GetRepaymentSchedules(acc);
        }

        public BusinessRegistration GetBusinessRegistrationByRegistration(string reg)
        {
            return Utilities.GetBusinessRegistrationByRegistration(reg);
        }

        public BusinessRegistration GetOldBusinessRegistrationByRegistration(string account, string loan)
        {
            return Utilities.GetOldBusinessRegistrationByRegistration(account, loan);
        }

        public float CalculateMonthlyRepaymentByBalance(int months, string account, float amount)
        {
            return Utilities.CalculateMonthlyRepayment(months, account, amount);
        }

        public bool GenerateMonthlyRepayments(int months, string account, float amount, DateTime start)
        {
            return Utilities.GenerateMonthlyRepayments(months, account, amount, start);
        }

        public bool CheckFullDisbursement(string account)
        {
            return Utilities.CheckFullDisbursement(account);
        }

        public string ReceiptRepayment(string account, string currency, float balance, float amount, int fK_PayBranchId, int fK_PaymentMethodId, DateTime lastPaymentDate)
        {
            return Utilities.ReceiptRepayment(account, currency, balance, amount, fK_PayBranchId, fK_PaymentMethodId, lastPaymentDate);
        }
                
            public string OldReceiptRepayment(string account,string loan, string currency, float balance, float amount, int fK_PayBranchId, int fK_PaymentMethodId, DateTime lastPaymentDate)
        {
            return Utilities.OldReceiptRepayment(account,loan, currency, balance, amount, fK_PayBranchId, fK_PaymentMethodId, lastPaymentDate);
        }

        public string ReceiptFeeRepayment(string account, string currency, float amount, int fK_PayBranchId, int fK_PaymentMethodId)
        {
            return Utilities.ReceiptFeeRepayment(account, currency, amount, fK_PayBranchId, fK_PaymentMethodId);
        }

        public string OldReceiptFeeRepayment(string account,string loan, string currency, float amount, int fK_PayBranchId, int fK_PaymentMethodId)
        {
            return Utilities.OldReceiptFeeRepayment(account,loan, currency, amount, fK_PayBranchId, fK_PaymentMethodId);
        }
        
        public List<RepaymentSchedule> FindPendingRepaymentSchedules(string filterText)
        {
            return Utilities.FindPendingRepaymentSchedules(filterText);
        }

        public WarningLetter GetWarningStage(long fK_RepaymentId)
        {
            return Utilities.GetWarningStage(fK_RepaymentId);
        }

        public bool SetWarningStage(long fK_RepaymentId, string warningStage, string remark, bool responded)
        {
            return Utilities.SetWarningStage(fK_RepaymentId, warningStage, remark, responded);
        }

        public List<BusinessAccountOld> GetOldBusinessAccounts(string filterText)
        {
            return Utilities.GetOldBusinessAccounts(filterText);

        }
        #endregion

        #region administration
        public List<PickList> GetPickList(string type)
        {
            return Utilities.GetPickList(type);
        }

        public List<PickList> GetChildPickList(string type, int parentId)
        {
            return Utilities.GetPickList(type, parentId);
        }

        public List<PickList> GetUserPickList(string groupType)
        {
            return Utilities.GetUserPickList(groupType);
        }

        public string GetEntityName(long Id, string type)
        {
            return Utilities.GetEntityName(Id, type);
        }

        public string GetDocumentTypeName(long Id)
        {
            return Utilities.GetDocumentTypeName(Id);
        }

        public List<ReferenceTable> GetReferenceTableItems(string type)
        {
            return Utilities.GetReferenceTableItems(type);
        }

        public bool SaveReferenceTable(string name, string description, bool active, string type, int fK_ParentId)
        {
            return Utilities.SaveReferenceTable(name, description, active, type, fK_ParentId);
        }

        public ReferenceTable GetReferenceTableItem(long Id, string type)
        {
            return Utilities.GetReferenceTableItem(Id, type);
        }

        public ReferenceTable GetReferenceTableItemByName(string name, string type)
        {
            return Utilities.GetReferenceTableItem(name, type);
        }

        public List<Stakeholder> GetStakeholders()
        {
            return Utilities.GetStakeholders();
        }

        public long SaveStakeholder(string name, string description, string mobile, string email, bool active)
        {
            return Utilities.SaveStakeholder(name, description, mobile, email, active);
        }

        public Stakeholder GetStakeholder(long Id)
        {
            return Utilities.GetStakeholder(Id);
        }

        public List<Stakeholder> GetBusinessTypeStakeholders(int businessTypeId)
        {
            return Utilities.GetBusinessTypeStakeholders(businessTypeId);
        }

        public bool SaveBusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId, bool stakeholderRequired)
        {
            return Utilities.SaveBusinessTypeStakeholder(fK_BusinessTypeId, fK_StakeholderId, stakeholderRequired);
        }

        public BusinessTypeStakeholder GetBusinessTypeStakeholder(long Id)
        {
            return Utilities.GetBusinessTypeStakeholder(Id);
        }

        public List<ReferenceTable> GetStakeholderBusinessTypes(int stakeholderId)
        {
            return Utilities.GetStakeholderBusinessTypes(stakeholderId);
        }

        public bool RemoveBusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId)
        {
            return Utilities.RemoveBusinessTypeStakeholder(fK_BusinessTypeId, fK_StakeholderId);
        }

        public AutoDocumentsDesign GetAutoDocumentsDesign(string name)
        {
            return Utilities.GetAutoDocumentsDesign(name);
        }

        public List<AutoDocumentsDesign> GetAutoDocumentsDesigns()
        {
            return Utilities.GetAutoDocumentsDesigns();
        }

        public bool SaveAutoDocumentsDesign(string documentName, string documentDesignSMS, string documentDesign, string emailSubject, bool sms, bool email)
        {
            return Utilities.SaveAutoDocumentsDesign(documentName, documentDesignSMS, documentDesign, emailSubject, sms, email);
        }

        public WorkFlowFieldValidations GetValidation(long Id)
        {
            return Utilities.GetValidation(Id);
        }

        public long SaveValidation(long id, string documentType, string parameterField, string parameterDataType, string parameterFieldName, string parameterValue, string parameterMaxValue, string parameterEvaluationType, bool active)
        {
            return Utilities.SaveValidation(id, documentType, parameterField, parameterDataType, parameterFieldName, parameterValue, parameterMaxValue, parameterEvaluationType, active);

        }

        public FeeRules GetFeeRule(long Id)
        {
            return Utilities.GetFeeRule(Id);
        }

        public long SaveFeeRule(int id, string ruleName, string ruleType, string ruleField, string ruleExecutionType, string ruleExecutionValue, string ruleEvaluationField, string ruleEvaluationDataType, string ruleEvaluationType, string ruleEvaluationValue, string ruleEvaluationMaxValue, bool active)
        {
            return Utilities.SaveFeeRule(id, ruleName, ruleType, ruleField, ruleExecutionType, ruleExecutionValue, ruleEvaluationField, ruleEvaluationDataType, ruleEvaluationType, ruleEvaluationValue, ruleEvaluationMaxValue, active);
        }

        public bool RunEndOfPeriodLoanRecalculations()
        {
            return Utilities.RunEndOfPeriodLoanRecalculations();
        }

        public string CountEndOfPeriodLoanRecalculations()
        {
            return Utilities.CountEndOfPeriodLoanRecalculations();
        }
        #endregion

        #region security

        public SignoutResponse Signout(string username)
        {
            return Security.Signout(username);
        }

        public PasswordChangeResponse ChangePassword(string username, string oldPassword, string newPassword)
        {
            return Security.ChangePassword(username, oldPassword, newPassword);
        }

        public UserRoleActionResponse AddRole(string username, string userRole)
        {
            return Security.AddRole(username, userRole);
        }

        public UserRoleActionResponse RemoveRole(string username, string userRole)
        {
            return Security.RemoveRole(username, userRole);
        }

        public UserActionResponse AddUser(string username, string password, int stakeholderId, string roleGroup, string firstName, string surname, string emailAddress, string mobileNumber, bool passwordExpires, bool active, bool locked)
        {
            return Security.AddUser(username, password, stakeholderId, roleGroup, firstName, surname, emailAddress, mobileNumber, passwordExpires, active, locked);
        }

        public UserActionResponse UpdateUser(string username, string action)
        {
            return Security.UpdateUser(username, action);
        }

        public List<ApplicationUsers> GetUsers(string filterText)
        {
            return Security.GetUsers(filterText);
        }

        public ApplicationUsers GetUser(string username)
        {
            return Security.GetUser(username);
        }

        public List<ApplicationRoles> GetApplicationRoles(string username)
        {
            return Security.GetApplicationRoles(username);
        }

        public UserRoleActionResponse AddGroupRole(string username, string userRole)
        {
            return Security.AddGroupRole(username, userRole);
        }

        public UserRoleActionResponse RemoveGroupRole(string username, string userRole)
        {
            return Security.RemoveGroupRole(username, userRole);
        }

        public List<ApplicationRoleGroups> GetApplicationGroupRoles(string username)
        {
            return Security.GetApplicationRoleGroups(username);
        }

        public UserRoleActionResponse AddUserGroup(string group, string description)
        {
            return Security.AddUserGroup(group, description);
        }

        public List<ApplicationRoles> GetApplicationUserGroupRoles(string group)
        {
            return Security.GetApplicationUserGroupRoles(group);
        }

        public UserRoleActionResponse AddUserGroupRole(string group, string userRole)
        {
            return Security.AddUserGroupRole(group, userRole);
        }

        public UserRoleActionResponse RemoveUserGroupRole(string group, string userRole)
        {
            return Security.RemoveUserGroupRole(group, userRole);
        }

        public string DefaultPassword()
        {
            return Security.defaultPassword;
        }
        #endregion

        #region site visit
        public List<SiteVisitReport> GetSiteVisitReports(long siteVisitId)
        {
            return Utilities.GetSiteVisitReports(siteVisitId);
        }

        public long SaveSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId, string comments)
        {
            return Utilities.SaveSiteVisitReport(fK_SiteVisitId, fK_StakeholderId, comments);
        }

        public SiteVisitReport GetSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId)
        {
            return Utilities.GetSiteVisitReport(fK_SiteVisitId, fK_StakeholderId);
        }

        public bool RemoveSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId)
        {
            return Utilities.RemoveSiteVisitReport(fK_SiteVisitId, fK_StakeholderId);
        }

        public bool ConfirmSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId)
        {
            return Utilities.ConfirmSiteVisitReport(fK_SiteVisitId, fK_StakeholderId);
        }


        public long CreateWorkflowSiteVisit(long Id, string entityType)
        {
            return Utilities.CreateWorkflowSiteVisit(Id, entityType);
        }

        public long CreateWorkflowRecommendationSiteVisit(long Id, string entityType, long recommendationId)
        {
            return Utilities.CreateWorkflowSiteVisit(Id, entityType, recommendationId);
        }

        public SiteVisit GetCurrentWorkflowSiteVisit(long Id, string entityType)
        {
            return Utilities.GetCurrentWorkflowSiteVisit(Id, entityType);
        }

        public SiteVisit GetSiteVisit(long Id)
        {
            return Utilities.GetSiteVisit(Id);
        }

        public long CreateSiteVisit(long Id)
        {
            return Utilities.CreateSiteVisit(Id);
        }

        public SiteVisit GetCurrentWorkflowRecommendationSiteVisit(long recommendationId, long Id, string entityType)
        {
            return Utilities.GetCurrentWorkflowRecommendationSiteVisit(recommendationId, Id, entityType);
        }

        public bool UploadSiteVisitWorkFlowDocument(long siteVisitId, int stakeholderId, string comments, long Id, string entityType, string fileName, byte[] fileData, int documentTypeId, long documentFolderId)
        {
            return Utilities.UploadSiteVisitWorkFlowDocument(siteVisitId, stakeholderId, comments, Id, entityType, fileName, fileData, documentTypeId, documentFolderId);
        }

        public bool SaveSiteVisit(SiteVisit site)
        {
            return Utilities.SaveSiteVisit(site);
        }

        public bool ScheduleSiteVisit(SiteVisit site)
        {
            return Utilities.ScheduleSiteVisit(site);
        }

        public bool NotifySiteVisit(long Id)
        {
            return Utilities.NotifySiteVisit(Id);
        }

        public bool UpdateSiteVisitRequest(long siteId, bool require, string comment, bool officer, long Id, string entityType)
        {
            return Utilities.UpdateSiteVisitRequest(siteId, require, comment, officer, Id, entityType);
        }

        public bool ConfirmSiteVisit(long Id)
        {
            return Utilities.ConfirmSiteVisit(Id);
        }

        public bool UnConfirmSiteVisit(long Id)
        {
            return Utilities.UnConfirmSiteVisit(Id);
        }

        public List<SiteVisit> GetSiteVisits(long busId)
        {
            return Utilities.GetSiteVisits(busId);
        }

        public bool CheckDisbursementLetter(string docName, long requestId)
        {
            return Utilities.CheckDisbursementLetter(docName, requestId);
        }


        #endregion

        #region invoices
        public List<Invoice> GetInvoices(string filterText)
        {
            return Utilities.GetInvoices(filterText);
        }

        public Invoice GetInvoice(long Id)
        {
            return Utilities.GetInvoice(Id);
        }

        public string PayInvoice(long Id, string currency, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId)
        {
            return Utilities.PayInvoice(Id, currency, amount, change, fK_PayBranchId, fK_PaymentMethodId);
        }

        public List<InvoiceItem> GetInvoiceItems(long Id)
        {
            return Utilities.GetInvoiceItems(Id);
        }
        #endregion

        #region recommendations
        public List<RecommendedAction> GetRecommendedActions(long fK_RecommendationId)
        {
            return Utilities.GetRecommendedActions(fK_RecommendationId);
        }

        public long SaveRecommendedAction(long fK_RecommendationId, int fK_StakeholderId, int fK_ActionId, string details, bool reminder, string status, string statusReason, bool active)
        {
            return Utilities.SaveRecommendedAction(fK_RecommendationId, fK_StakeholderId, fK_ActionId, details, reminder, status, statusReason, active);

        }

        public RecommendedAction GetRecommendedAction(long fK_RecommendationId, int fK_StakeholderId)
        {
            return Utilities.GetRecommendedAction(fK_RecommendationId, fK_StakeholderId);

        }

        public long CreateWorkflowRecommendations(long Id, string entityType)
        {
            return Utilities.CreateWorkflowRecommendations(Id, entityType);
        }

        public Recommendations GetCurrentWorkflowRecommendations(long Id, string entityType)
        {
            return Utilities.GetCurrentWorkflowRecommendations(Id, entityType);
        }
        #endregion

        #region national residence
        public Resident GetResident(string nIN)
        {
            return NPDUtilities.GetResident(nIN);
        }

        public Business GetBusiness(string bRN)
        {
            return BRUtilities.GetBusiness(bRN);
        }
        #endregion

        #region old db

        public List<oldLoanRequest> GetoldLoanRequests(string filterText)
        {
            return Utilities.GetoldLoanRequests(filterText);
        }

        public List<oldRecovery> GetoldRecoverys(string filterText)
        {
            return Utilities.GetoldRecoverys(filterText);
        }

        public List<oldRepayments> GetoldRepayments(string filterText)
        {
            return Utilities.GetoldRepayments(filterText);
        }

        #endregion
    }


}
