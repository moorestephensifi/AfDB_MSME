﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SBFA
{

        public partial class NPDUtilities
        {          

            //Search for a single resident using NIN
            public static Resident GetResident(string nIN)
            {
                Resident resident = new Resident();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select * from [NPD] where [NPDNIN] = '" + nIN + "';","npd");

                    if (dr.Reader.Read())
                    {
                        resident.NIN = dr.Reader["NPDNIN"].ToString().Trim();
                        resident.FirstName = dr.Reader["NPDONAME"].ToString().Trim();
                        resident.Surname = dr.Reader["NPDSNAME"].ToString().Trim();
                        resident.MaidenSurname = dr.Reader["NPDMSNAME"].ToString().Trim();
                        resident.Nationality = dr.Reader["NPDNATIO"].ToString().Trim();
                        resident.Type = dr.Reader["NPDPTYPE"].ToString().Trim();
                        resident.Status = dr.Reader["NPDSTAT1"].ToString().Trim();
                        resident.DateOfBirth = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("NPDBIRTH"));
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("GetResident", ex);
                }

                return resident;
            }

            //Search for residents using names, NIN or nationality code
            public static ArrayList SearchForResidents(string searchText)
            {
                ArrayList residents = new ArrayList();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select * from [NPD] where [NPDNIN] like '%" + searchText + "%' Or [NPDONAME] like '%" + searchText + "%' Or [NPDSNAME] like '%" + searchText + "%' Or [NPDMSNAME] like '%" + searchText + "%' Or [NPDNATIO] like '%" + searchText + "%';","npd");

                    while (dr.Reader.Read())
                    {
                        Resident resident = new Resident();
                        resident.NIN = dr.Reader["NPDNIN"].ToString().Trim();
                        resident.FirstName = dr.Reader["NPDONAME"].ToString().Trim();
                        resident.Surname = dr.Reader["NPDSNAME"].ToString().Trim();
                        resident.MaidenSurname = dr.Reader["NPDMSNAME"].ToString().Trim();
                        resident.Nationality = dr.Reader["NPDNATIO"].ToString().Trim();
                        resident.Type = dr.Reader["NPDPTYPE"].ToString().Trim();
                        resident.Status = dr.Reader["NPDSTAT1"].ToString().Trim();
                        resident.DateOfBirth = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("NPDBIRTH"));

                        residents.Add(resident);
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("SearchForResidents", ex);
                }

                return residents;
            }
        }

        //Represents Seychelles resident in the National Population Database
        public class Resident
        {
            private string nIN = string.Empty, firstName = string.Empty, surname = string.Empty, maidenSurname = string.Empty, nationality = string.Empty, type = string.Empty, status = string.Empty;
            private DateTime dateOfBirth = DateTime.Now;

            public string NIN { get => nIN; set => nIN = value; }
            public string FirstName { get => firstName; set => firstName = value; }
            public string Surname { get => surname; set => surname = value; }
            public string MaidenSurname { get => maidenSurname; set => maidenSurname = value; }
            public string Nationality { get => nationality; set => nationality = value; }
            public string Type { get => type; set => type = value; }
            public string Status { get => status; set => status = value; }
            public DateTime DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        }

        public partial class BRUtilities
        {           
            //Search for a single business using BRN
            public static Business GetBusiness(string bRN)
            {
                Business business = new Business();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("SELECT [RegistrationEntity].RegistrationNumber, [RegistrationEntity].Name, [RegistrationEntity].RegistrationDate, [RegistrationEntity].CommencementDate, [RegistrationEntity].RegistrationStatusId, [RegistrationEntityAddress].AddressLine1, [RegistrationEntityAddress].AddressLine2 FROM [RegistrationEntity],[RegistrationEntityAddress] where [RegistrationEntity].Id = [RegistrationEntityAddress].RegistrationEntityId And [RegistrationNumber] = '" + bRN + "';","registra");

                    if (dr.Reader.Read())
                    {
                        business.RegistrationNumber = dr.Reader["RegistrationNumber"].ToString().Trim();
                        business.Name = dr.Reader["Name"].ToString().Trim();
                        business.RegistrationDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("RegistrationDate"));
                        business.CommencementDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("CommencementDate"));
                        business.RegistrationStatusId = dr.Reader.GetInt16(dr.Reader.GetOrdinal("RegistrationStatusId"));
                        business.AddressLine1 = dr.Reader["AddressLine1"].ToString().Trim();
                        business.AddressLine2 = dr.Reader["AddressLine2"].ToString().Trim();
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("GetBusiness", ex);
                }

                return business;
            }

            //Search for businesses using names or BRN
            public static ArrayList SearchForBusinesses(string searchText)
            {
                ArrayList businesses = new ArrayList();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("SELECT [RegistrationEntity].RegistrationNumber, [RegistrationEntity].Name, [RegistrationEntity].RegistrationDate, [RegistrationEntity].CommencementDate, [RegistrationEntity].RegistrationStatusId, [RegistrationEntityAddress].AddressLine1, [RegistrationEntityAddress].AddressLine2 FROM [RegistrationEntity],[RegistrationEntityAddress] where [RegistrationEntity].Id = [RegistrationEntityAddress].RegistrationEntityId And ([RegistrationNumber] like '%" + searchText + "%' Or [Name] like '%" + searchText + "%' Or [AddressLine1] like '%" + searchText + "%' Or [AddressLine2] like '%" + searchText + "%');","registra");

                    while (dr.Reader.Read())
                    {
                        Business business = new Business();
                        business.RegistrationNumber = dr.Reader["RegistrationNumber"].ToString().Trim();
                        business.Name = dr.Reader["Name"].ToString().Trim();
                        business.RegistrationDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("RegistrationDate"));
                        business.CommencementDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("CommencementDate"));
                        business.RegistrationStatusId = dr.Reader.GetInt16(dr.Reader.GetOrdinal("RegistrationStatusId"));
                        business.AddressLine1 = dr.Reader["AddressLine1"].ToString().Trim();
                        business.AddressLine2 = dr.Reader["AddressLine2"].ToString().Trim();

                        businesses.Add(business);
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("SearchForBusinesses", ex);
                }

                return businesses;
            }
        }

        //Represents Seychelles business in the Business Registrar Database
        public class Business
        {
            private string registrationNumber = string.Empty, name = string.Empty, addressLine1 = string.Empty, addressLine2 = string.Empty;
            private DateTime registrationDate = DateTime.Now, commencementDate = DateTime.Now;
            private int registrationStatusId;

            public string RegistrationNumber { get => registrationNumber; set => registrationNumber = value; }
            public string Name { get => name; set => name = value; }
            public string AddressLine1 { get => addressLine1; set => addressLine1 = value; }
            public string AddressLine2 { get => addressLine2; set => addressLine2 = value; }
            public DateTime RegistrationDate { get => registrationDate; set => registrationDate = value; }
            public DateTime CommencementDate { get => commencementDate; set => commencementDate = value; }
            public int RegistrationStatusId { get => registrationStatusId; set => registrationStatusId = value; }
        }

        public partial class SLAUtilities
        {
            //Database Connection String
            private static string DBCONNECTIONSTRING = "Data Source=.\\BISERVER;Initial Catalog=COTTAGEDB;Integrated Security=True;";

            //Read database recordset
            private static DatabaseReader ExecuteReader(string sqlCommandText)
            {
                return new DatabaseReader(sqlCommandText);
            }

            private class DatabaseReader
            {
                public SqlDataReader Reader;
                SqlConnection Connection;
                SqlCommand Command;

                public DatabaseReader(string sqlCommandText)
                {
                    this.Connection = new SqlConnection(DBCONNECTIONSTRING);
                    this.Command = new SqlCommand(sqlCommandText, this.Connection);

                    try
                    {
                        this.Connection.Open();

                        this.Reader = this.Command.ExecuteReader();
                    }
                    catch (Exception ex)
                    {
                        Utilities.LogError("DataBaseReader", ex);

                        this.Close();
                    }
                }

                public void Close()
                {
                    if (this.Connection != null)
                    {
                        this.Connection.Dispose();
                    }
                }
            }

            //Search for a single business or individual using their BRN or NIN
            public static SLARegisteredEntity GetRegisteredEntity(string iN)
            {
                SLARegisteredEntity registeredEntity = new SLARegisteredEntity();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select [A].ENTITYNO, [A].FirstName, [A].LastNameOrBusinessName, [A].GENDER, [A].DateOfBirthOrIncorporation, [A].PhysicalAddress,[DISTRICT].DISTNAME As District,[A].Telephone, [A].[Type], [A].[Status] From (Select [ENTITY].ENTITYNO, [ENTITY].OTHNAME As FirstName, [ENTITY].LORGNAME As LastNameOrBusinessName, [ENTITY].GENDER, [ENTITY].STARTDATE As DateOfBirthOrIncorporation, [ENTITY].ADDRESS1 As PhysicalAddress, [ENTITY].FK_DISTRICTID, [ENTITY].TEL1 As Telephone,[ENTITYTYPE].ENTITYTYPEDESC As [Type], [ENTITYSTATUS].ENTITYSTATUSDESC As [Status] FROM [ENTITY],[ENTITYTYPE],[ENTITYSTATUS] where [ENTITY].FK_ENTITYTYPEID = [ENTITYTYPE].ENTITYTYPEID And [ENTITY].FK_ENTITYSTATUS = [ENTITYSTATUS].ENTITYSTATUSID And [ENTITY].ENTITYNO = '" + iN + "')A Left Join [DISTRICT] On [A].FK_DISTRICTID = [DISTRICT].DISTRICTID");

                    if (dr.Reader.Read())
                    {
                        registeredEntity.EntityNumber = dr.Reader["ENTITYNO"].ToString().Trim();
                        registeredEntity.FirstName = dr.Reader["FirstName"].ToString().Trim();
                        registeredEntity.LastNameOrBusinessName = dr.Reader["LastNameOrBusinessName"].ToString().Trim();
                        registeredEntity.Gender = dr.Reader["GENDER"].ToString().Trim();
                        registeredEntity.DateOfBirthOrIncorporation = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("DateOfBirthOrIncorporation"));
                        registeredEntity.PhysicalAddress = dr.Reader["PhysicalAddress"].ToString().Trim();
                        registeredEntity.District = dr.Reader["District"].ToString().Trim();
                        registeredEntity.Telephone = dr.Reader["Telephone"].ToString().Trim();
                        registeredEntity.Type = dr.Reader["Type"].ToString().Trim();
                        registeredEntity.Status = dr.Reader["Status"].ToString().Trim();
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("GetRegisteredEntity", ex);
                }

                return registeredEntity;
            }

            //Search for businesses and individuals using names, ids and other details
            public static ArrayList SearchForRegisteredEntities(string searchText)
            {
                ArrayList registeredEntities = new ArrayList();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select [A].ENTITYNO, [A].FirstName, [A].LastNameOrBusinessName, [A].GENDER, [A].DateOfBirthOrIncorporation, [A].PhysicalAddress,[DISTRICT].DISTNAME As District,[A].Telephone, [A].[Type], [A].[Status] From (Select [ENTITY].ENTITYNO, [ENTITY].OTHNAME As FirstName, [ENTITY].LORGNAME As LastNameOrBusinessName, [ENTITY].GENDER, [ENTITY].STARTDATE As DateOfBirthOrIncorporation, [ENTITY].ADDRESS1 As PhysicalAddress, [ENTITY].FK_DISTRICTID, [ENTITY].TEL1 As Telephone,[ENTITYTYPE].ENTITYTYPEDESC As [Type], [ENTITYSTATUS].ENTITYSTATUSDESC As [Status] FROM [ENTITY],[ENTITYTYPE],[ENTITYSTATUS] where [ENTITY].FK_ENTITYTYPEID = [ENTITYTYPE].ENTITYTYPEID And [ENTITY].FK_ENTITYSTATUS = [ENTITYSTATUS].ENTITYSTATUSID)A Left Join [DISTRICT] On [A].FK_DISTRICTID = [DISTRICT].DISTRICTID And ([FirstName] like '%" + searchText + "%' Or [LastNameOrBusinessName] like '%" + searchText + "%' Or [PhysicalAddress] like '%" + searchText + "%' Or [District] like '%" + searchText + "%' Or [Telephone] like '%" + searchText + "%');");

                    while (dr.Reader.Read())
                    {
                        SLARegisteredEntity registeredEntity = new SLARegisteredEntity();
                        registeredEntity.EntityNumber = dr.Reader["ENTITYNO"].ToString().Trim();
                        registeredEntity.FirstName = dr.Reader["FirstName"].ToString().Trim();
                        registeredEntity.LastNameOrBusinessName = dr.Reader["LastNameOrBusinessName"].ToString().Trim();
                        registeredEntity.Gender = dr.Reader["GENDER"].ToString().Trim();
                        registeredEntity.DateOfBirthOrIncorporation = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("DateOfBirthOrIncorporation"));
                        registeredEntity.PhysicalAddress = dr.Reader["PhysicalAddress"].ToString().Trim();
                        registeredEntity.District = dr.Reader["District"].ToString().Trim();
                        registeredEntity.Telephone = dr.Reader["Telephone"].ToString().Trim();
                        registeredEntity.Type = dr.Reader["Type"].ToString().Trim();
                        registeredEntity.Status = dr.Reader["Status"].ToString().Trim();

                        registeredEntities.Add(registeredEntity);
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("SearchForRegisteredEntities", ex);
                }

                return registeredEntities;
            }

            //Search for license using License number
            public static SLALicense GetLicense(string licenseNumber)
            {
                SLALicense license = new SLALicense();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select [ENTITY].ENTITYNO, [LICENSE].LICENSENO, [LICENSE].COMMENCEMENTDATE, [LICENSE].EXPIRYDATE, [LICENSETYPE].LICENSETYPEDESC, [LICENSESTATUS].LICENSESTATUSDESC FROM [ENTITY],[LICENSE],[LICENSETYPE],[LICENSESTATUS] where [LICENSE].LICENSENO = '" + licenseNumber + "' And [ENTITY].ENTITYID = [LICENSE].FK_ENTITYID And [LICENSE].FK_LICENSETYPEID = [LICENSETYPE].LICENSETYPEID And [LICENSE].FK_LICENSESTATUS = [LICENSESTATUS].LICENSESTATUSID");

                    if (dr.Reader.Read())
                    {
                        license.EntityNumber = dr.Reader["ENTITYNO"].ToString().Trim();
                        license.LicenseNumber = dr.Reader["LICENSENO"].ToString().Trim();
                        license.CommencementDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("COMMENCEMENTDATE"));
                        license.ExpiryDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("EXPIRYDATE"));
                        license.Type = dr.Reader["LICENSETYPEDESC"].ToString().Trim();
                        license.Status = dr.Reader["LICENSESTATUSDESC"].ToString().Trim();
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("GetLicense", ex);
                }

                return license;
            }

            //Search for licenses using owning entity id and other details
            public static ArrayList SearchForLicenses(string searchText)
            {
                ArrayList licenses = new ArrayList();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select [ENTITY].ENTITYNO, [LICENSE].LICENSENO, [LICENSE].COMMENCEMENTDATE, [LICENSE].EXPIRYDATE, [LICENSETYPE].LICENSETYPEDESC, [LICENSESTATUS].LICENSESTATUSDESC FROM [ENTITY],[LICENSE],[LICENSETYPE],[LICENSESTATUS] where [ENTITY].ENTITYID = [LICENSE].FK_ENTITYID And [LICENSE].FK_LICENSETYPEID = [LICENSETYPE].LICENSETYPEID And [LICENSE].FK_LICENSESTATUS = [LICENSESTATUS].LICENSESTATUSID And ([ENTITYNO] like '%" + searchText + "%' Or [LICENSENO] like '%" + searchText + "%' Or [LICENSETYPEDESC] like '%" + searchText + "%');");

                    while (dr.Reader.Read())
                    {
                        SLALicense license = new SLALicense();
                        license.EntityNumber = dr.Reader["ENTITYNO"].ToString().Trim();
                        license.LicenseNumber = dr.Reader["LICENSENO"].ToString().Trim();
                        license.CommencementDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("COMMENCEMENTDATE"));
                        license.ExpiryDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("EXPIRYDATE"));
                        license.Type = dr.Reader["LICENSETYPEDESC"].ToString().Trim();
                        license.Status = dr.Reader["LICENSESTATUSDESC"].ToString().Trim();

                        licenses.Add(license);
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("SearchForLicenses", ex);
                }

                return licenses;
            }
        }

        //Represents business or individual registered with SLA
        public class SLARegisteredEntity
        {
            private string entityNumber = string.Empty, firstName = string.Empty, lastNameOrBusinessName = string.Empty, gender = string.Empty, physicalAddress = string.Empty, district = string.Empty, telephone = string.Empty, type = string.Empty, status = string.Empty;
            private DateTime dateOfBirthOrIncorporation = DateTime.Now;

            public string EntityNumber { get => entityNumber; set => entityNumber = value; }
            public string FirstName { get => firstName; set => firstName = value; }
            public string LastNameOrBusinessName { get => lastNameOrBusinessName; set => lastNameOrBusinessName = value; }
            public string Gender { get => gender; set => gender = value; }
            public DateTime DateOfBirthOrIncorporation { get => dateOfBirthOrIncorporation; set => dateOfBirthOrIncorporation = value; }
            public string PhysicalAddress { get => physicalAddress; set => physicalAddress = value; }
            public string District { get => district; set => district = value; }
            public string Telephone { get => telephone; set => telephone = value; }
            public string Type { get => type; set => type = value; }
            public string Status { get => status; set => status = value; }
        }

        public class SLALicense
        {
            private string entityNumber = string.Empty, licenseNumber = string.Empty, type = string.Empty, status = string.Empty;
            private DateTime commencementDate = DateTime.Now, expiryDate = DateTime.Now;

            public string EntityNumber { get => entityNumber; set => entityNumber = value; }
            public string LicenseNumber { get => licenseNumber; set => licenseNumber = value; }
            public string Type { get => type; set => type = value; }
            public string Status { get => status; set => status = value; }
            public DateTime CommencementDate { get => commencementDate; set => commencementDate = value; }
            public DateTime ExpiryDate { get => expiryDate; set => expiryDate = value; }
        }

        public partial class VRUtilities
        {
            //Database Connection String
            private static string DBCONNECTIONSTRING = "Data Source=.;Initial Catalog=BLSDB;Integrated Security=True;";

            //Read database recordset
            private static DatabaseReader ExecuteReader(string sqlCommandText)
            {
                return new DatabaseReader(sqlCommandText);
            }

            private class DatabaseReader
            {
                public SqlDataReader Reader;
                SqlConnection Connection;
                SqlCommand Command;

                public DatabaseReader(string sqlCommandText)
                {
                    this.Connection = new SqlConnection(DBCONNECTIONSTRING);
                    this.Command = new SqlCommand(sqlCommandText, this.Connection);

                    try
                    {
                        this.Connection.Open();

                        this.Reader = this.Command.ExecuteReader();
                    }
                    catch (Exception ex)
                    {
                        Utilities.LogError("DataBaseReader", ex);

                        this.Close();
                    }
                }

                public void Close()
                {
                    if (this.Connection != null)
                    {
                        this.Connection.Dispose();
                    }
                }
            }

            //Search for a single business or individual owner using their BRN or NIN
            public static VRRegisteredEntity GetRegisteredEntity(string iN)
            {
                VRRegisteredEntity registeredEntity = new VRRegisteredEntity();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select [A].ENTITYNO, [A].FirstName, [A].LastNameOrBusinessName, [A].GENDER, [A].DateOfBirthOrIncorporation, [A].PhysicalAddress,[DISTRICT].DISTNAME As District,[A].Telephone, [A].[Type], [A].[Status] From (Select [ENTITY].ENTITYNO, [ENTITY].OTHNAME As FirstName, [ENTITY].LORGNAME As LastNameOrBusinessName, [ENTITY].GENDER, [ENTITY].STARTDATE As DateOfBirthOrIncorporation, [ENTITY].ADDRESS1 As PhysicalAddress, [ENTITY].FK_DISTRICTID, [ENTITY].TEL1 As Telephone,[ENTITYTYPE].ENTITYTYPEDESC As [Type], [ENTITYSTATUS].ENTITYSTATUSDESC As [Status] FROM [ENTITY],[ENTITYTYPE],[ENTITYSTATUS] where [ENTITY].FK_ENTITYTYPEID = [ENTITYTYPE].ENTITYTYPEID And [ENTITY].FK_ENTITYSTATUS = [ENTITYSTATUS].ENTITYSTATUSID And [ENTITY].ENTITYNO = '" + iN + "')A Left Join [DISTRICT] On [A].FK_DISTRICTID = [DISTRICT].DISTRICTID");

                    if (dr.Reader.Read())
                    {
                        registeredEntity.EntityNumber = dr.Reader["ENTITYNO"].ToString().Trim();
                        registeredEntity.FirstName = dr.Reader["FirstName"].ToString().Trim();
                        registeredEntity.LastNameOrBusinessName = dr.Reader["LastNameOrBusinessName"].ToString().Trim();
                        registeredEntity.Gender = dr.Reader["GENDER"].ToString().Trim();
                        registeredEntity.DateOfBirthOrIncorporation = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("DateOfBirthOrIncorporation"));
                        registeredEntity.PhysicalAddress = dr.Reader["PhysicalAddress"].ToString().Trim();
                        registeredEntity.District = dr.Reader["District"].ToString().Trim();
                        registeredEntity.Telephone = dr.Reader["Telephone"].ToString().Trim();
                        registeredEntity.Type = dr.Reader["Type"].ToString().Trim();
                        registeredEntity.Status = dr.Reader["Status"].ToString().Trim();
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("GetRegisteredEntity", ex);
                }

                return registeredEntity;
            }

            //Search for businesses and individuals using names, ids and other details
            public static ArrayList SearchForRegisteredEntities(string searchText)
            {
                ArrayList registeredEntities = new ArrayList();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select [A].ENTITYNO, [A].FirstName, [A].LastNameOrBusinessName, [A].GENDER, [A].DateOfBirthOrIncorporation, [A].PhysicalAddress,[DISTRICT].DISTNAME As District,[A].Telephone, [A].[Type], [A].[Status] From (Select [ENTITY].ENTITYNO, [ENTITY].OTHNAME As FirstName, [ENTITY].LORGNAME As LastNameOrBusinessName, [ENTITY].GENDER, [ENTITY].STARTDATE As DateOfBirthOrIncorporation, [ENTITY].ADDRESS1 As PhysicalAddress, [ENTITY].FK_DISTRICTID, [ENTITY].TEL1 As Telephone,[ENTITYTYPE].ENTITYTYPEDESC As [Type], [ENTITYSTATUS].ENTITYSTATUSDESC As [Status] FROM [ENTITY],[ENTITYTYPE],[ENTITYSTATUS] where [ENTITY].FK_ENTITYTYPEID = [ENTITYTYPE].ENTITYTYPEID And [ENTITY].FK_ENTITYSTATUS = [ENTITYSTATUS].ENTITYSTATUSID)A Left Join [DISTRICT] On [A].FK_DISTRICTID = [DISTRICT].DISTRICTID And ([FirstName] like '%" + searchText + "%' Or [LastNameOrBusinessName] like '%" + searchText + "%' Or [PhysicalAddress] like '%" + searchText + "%' Or [District] like '%" + searchText + "%' Or [Telephone] like '%" + searchText + "%');");

                    while (dr.Reader.Read())
                    {
                        SLARegisteredEntity registeredEntity = new SLARegisteredEntity();
                        registeredEntity.EntityNumber = dr.Reader["ENTITYNO"].ToString().Trim();
                        registeredEntity.FirstName = dr.Reader["FirstName"].ToString().Trim();
                        registeredEntity.LastNameOrBusinessName = dr.Reader["LastNameOrBusinessName"].ToString().Trim();
                        registeredEntity.Gender = dr.Reader["GENDER"].ToString().Trim();
                        registeredEntity.DateOfBirthOrIncorporation = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("DateOfBirthOrIncorporation"));
                        registeredEntity.PhysicalAddress = dr.Reader["PhysicalAddress"].ToString().Trim();
                        registeredEntity.District = dr.Reader["District"].ToString().Trim();
                        registeredEntity.Telephone = dr.Reader["Telephone"].ToString().Trim();
                        registeredEntity.Type = dr.Reader["Type"].ToString().Trim();
                        registeredEntity.Status = dr.Reader["Status"].ToString().Trim();

                        registeredEntities.Add(registeredEntity);
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("SearchForRegisteredEntities", ex);
                }

                return registeredEntities;
            }

            //Search for vehicle using vehicle Registration number
            public static VRVehicle GetVehicle(string registrationNumber)
            {
                VRVehicle vehicle = new VRVehicle();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select ENTITY.ENTITYNO, dvl.VEHICLEOWNER.STARTDATE, dvl.REGISTRATION.REGISTRATIONNUMBER, dvl.VEHICLE.CHASSISNO, dvl.VEHICLEMAKE.MAKE, dvl.VEHICLEMODEL.MODEL, dvl.VEHICLE.YEAROFMANUFACTURE from ENTITY, dvl.VEHICLEOWNER, dvl.VEHICLE, dvl.VEHICLEMAKE, dvl.VEHICLEMODEL, dvl.REGISTRATIONLINK, dvl.REGISTRATION where ENTITY.ENTITYID = dvl.VEHICLEOWNER.FK_ENTITYID And dvl.VEHICLEOWNER.ENDDATE is null And dvl.VEHICLEOWNER.FK_VEHICLEID = dvl.VEHICLE.VEHICLEID And dvl.VEHICLEMAKE.VEHICLEMAKEID = dvl.VEHICLE.FK_VEHICLEMAKEID And dvl.VEHICLE.FK_VEHICLEMODELID = dvl.VEHICLEMODEL.VEHICLEMODELID And dvl.REGISTRATIONLINK.FK_VEHICLEID = dvl.VEHICLE.VEHICLEID And dvl.REGISTRATION.REGISTRATIONID = dvl.REGISTRATIONLINK.FK_REGISTRATIONID And dvl.REGISTRATIONLINK.ENDATE is null order by ENTITY.ENTITYNO And dvl.REGISTRATION.REGISTRATIONNUMBER = " + registrationNumber + ";");

                    if (dr.Reader.Read())
                    {
                        vehicle.EntityNumber = dr.Reader["ENTITYNO"].ToString().Trim();
                        vehicle.ChassisNumber = dr.Reader["CHASSISNO"].ToString().Trim();
                        vehicle.StartDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("STARTDATE"));
                        vehicle.YearOfManufacture = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("YEAROFMANUFACTURE"));
                        vehicle.Make = dr.Reader["MAKE"].ToString().Trim();
                        vehicle.Model = dr.Reader["MODEL"].ToString().Trim();
                        vehicle.RegistrationNumber = dr.Reader["REGISTRATIONNUMBER"].ToString().Trim();
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("GetVehicle", ex);
                }

                return vehicle;
            }

            //Search for vehicles using owning entity id and other details
            public static ArrayList SearchForVehicles(string searchText)
            {
                ArrayList vehicles = new ArrayList();

                try
                {
                    Utilities.DatabaseReader dr = Utilities.ExecuteReader("Select ENTITY.ENTITYNO, dvl.VEHICLEOWNER.STARTDATE, dvl.REGISTRATION.REGISTRATIONNUMBER, dvl.VEHICLE.CHASSISNO, dvl.VEHICLEMAKE.MAKE, dvl.VEHICLEMODEL.MODEL, dvl.VEHICLE.YEAROFMANUFACTURE from ENTITY, dvl.VEHICLEOWNER, dvl.VEHICLE, dvl.VEHICLEMAKE, dvl.VEHICLEMODEL, dvl.REGISTRATIONLINK, dvl.REGISTRATION where ENTITY.ENTITYID = dvl.VEHICLEOWNER.FK_ENTITYID And dvl.VEHICLEOWNER.ENDDATE is null And dvl.VEHICLEOWNER.FK_VEHICLEID = dvl.VEHICLE.VEHICLEID And dvl.VEHICLEMAKE.VEHICLEMAKEID = dvl.VEHICLE.FK_VEHICLEMAKEID And dvl.VEHICLE.FK_VEHICLEMODELID = dvl.VEHICLEMODEL.VEHICLEMODELID And dvl.REGISTRATIONLINK.FK_VEHICLEID = dvl.VEHICLE.VEHICLEID And dvl.REGISTRATION.REGISTRATIONID = dvl.REGISTRATIONLINK.FK_REGISTRATIONID And dvl.REGISTRATIONLINK.ENDATE is null order by ENTITY.ENTITYNO And (ENTITY.ENTITYNO like '%" + searchText + "%' Or dvl.REGISTRATION.REGISTRATIONNUMBER = " + searchText + " Or dvl.VEHICLE.CHASSISNO like '%" + searchText + "%');");

                    while (dr.Reader.Read())
                    {
                        VRVehicle vehicle = new VRVehicle();
                        vehicle.EntityNumber = dr.Reader["ENTITYNO"].ToString().Trim();
                        vehicle.ChassisNumber = dr.Reader["CHASSISNO"].ToString().Trim();
                        vehicle.StartDate = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("STARTDATE"));
                        vehicle.YearOfManufacture = dr.Reader.GetDateTime(dr.Reader.GetOrdinal("YEAROFMANUFACTURE"));
                        vehicle.Make = dr.Reader["MAKE"].ToString().Trim();
                        vehicle.Model = dr.Reader["MODEL"].ToString().Trim();
                        vehicle.RegistrationNumber = dr.Reader["REGISTRATIONNUMBER"].ToString().Trim();

                        vehicles.Add(vehicle);
                    }

                    dr.Close();
                }
                catch (Exception ex)
                {
                    Utilities.LogError("SearchForVehicles", ex);
                }

                return vehicles;
            }
        }

        //Represents business or individual vehicle owner registered with SLA
        public class VRRegisteredEntity
        {
            private string entityNumber = string.Empty, firstName = string.Empty, lastNameOrBusinessName = string.Empty, gender = string.Empty, physicalAddress = string.Empty, district = string.Empty, telephone = string.Empty, type = string.Empty, status = string.Empty;
            private DateTime dateOfBirthOrIncorporation = DateTime.Now;

            public string EntityNumber { get => entityNumber; set => entityNumber = value; }
            public string FirstName { get => firstName; set => firstName = value; }
            public string LastNameOrBusinessName { get => lastNameOrBusinessName; set => lastNameOrBusinessName = value; }
            public string Gender { get => gender; set => gender = value; }
            public DateTime DateOfBirthOrIncorporation { get => dateOfBirthOrIncorporation; set => dateOfBirthOrIncorporation = value; }
            public string PhysicalAddress { get => physicalAddress; set => physicalAddress = value; }
            public string District { get => district; set => district = value; }
            public string Telephone { get => telephone; set => telephone = value; }
            public string Type { get => type; set => type = value; }
            public string Status { get => status; set => status = value; }
        }

        public class VRVehicle
        {
            private string entityNumber = string.Empty, registrationNumber = string.Empty, chassisNumber = string.Empty, make = string.Empty, model = string.Empty;
            private DateTime startDate = DateTime.Now, yearOfManufacture = DateTime.Now;

            public string EntityNumber { get => entityNumber; set => entityNumber = value; }
            public string RegistrationNumber { get => registrationNumber; set => registrationNumber = value; }
            public string ChassisNumber { get => chassisNumber; set => chassisNumber = value; }
            public string Make { get => make; set => make = value; }
            public string Model { get => model; set => model = value; }
            public DateTime StartDate { get => startDate; set => startDate = value; }
            public DateTime YearOfManufacture { get => yearOfManufacture; set => yearOfManufacture = value; }
        }
   
}