﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;

namespace SBFA
{
    public partial class Utilities
    {
        public static List<Invoice> GetInvoices(string filterText)
        {
            List<Invoice> response = new List<Invoice>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " * from Invoice where FK_ReferenceNumber like '%" + filterText + "%' or ((select left(FK_ReferenceNumber, charindex('_', FK_ReferenceNumber+'_') - 1) as column1) in (select RegistrationNumber from BusinessRegistration where NIN like '%" + filterText + "%' or FirstNames like '%" + filterText + "%' or LastName like '%" + filterText + "%' or BusinessName like '%" + filterText+ "%')) or (FK_ReferenceNumber in (select ReferenceNumber from LoanRequest where NIN like '%" + filterText + "%' or FirstNames like '%" + filterText + "%' or LastName like '%" + filterText + "%' or BusinessName like '%" + filterText + "%')) order by Created Desc");
            while (reader.Reader.Read())
            {
                Invoice invoice = new Invoice();
                invoice.Id = long.Parse(reader.Reader["Id"].ToString());
                invoice.FK_ReferenceNumber = (reader.Reader["FK_ReferenceNumber"].ToString());
                invoice.DocumentType = (reader.Reader["DocumentType"].ToString());
                invoice.InvoiceDate = DateTime.Parse(reader.Reader["InvoiceDate"].ToString());
                invoice.FK_InvoicedBy = (reader.Reader["FK_InvoicedBy"].ToString());
                invoice.Currency = (reader.Reader["Currency"].ToString());
                invoice.Amount = float.Parse(reader.Reader["Amount"].ToString());
                invoice.AmountSurcharge = float.Parse(reader.Reader["AmountSurcharge"].ToString());
                invoice.AmountDiscount = float.Parse(reader.Reader["AmountDiscount"].ToString());
                invoice.AmountTotal = float.Parse(reader.Reader["AmountTotal"].ToString());
                invoice.AllowPartPayment = bool.Parse(reader.Reader["AllowPartPayment"].ToString());
                invoice.FK_PayBranchId = int.Parse(reader.Reader["FK_PayBranchId"].ToString());
                invoice.FK_PaymentMethodId = int.Parse(reader.Reader["FK_PaymentMethodId"].ToString());
                invoice.CurrencyPaid = (reader.Reader["CurrencyPaid"].ToString());
                invoice.AmountPaid = float.Parse(reader.Reader["AmountPaid"].ToString());
                invoice.PaymentDate = DateTime.Parse(reader.Reader["PaymentDate"].ToString());
                invoice.ReceiptNumber = (reader.Reader["ReceiptNumber"].ToString());
                invoice.Comments = (reader.Reader["Comments"].ToString());
                invoice.FK_ReceiptedBy = (reader.Reader["FK_ReceiptedBy"].ToString());
                invoice.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                invoice.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                invoice.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                invoice.Created = DateTime.Now;
                invoice.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                invoice.LastModified = DateTime.Now;
                invoice.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(invoice);
            }
            reader.Close();
            return response;
        }

        public static Invoice GetInvoice(long Id)
        {
            Invoice invoice = new Invoice(Id);
            return invoice;
        }

        public static string PayInvoice(long Id, string currency, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId)
        {
            Invoice invoice = new Invoice(Id);
            string receipt = invoice.Pay(currency, amount, change, fK_PayBranchId, fK_PaymentMethodId);
            invoice.ReceiptNumber = receipt;
            if (receipt != "0")
            {
                try
                {
                    // Utilities.GenerateDocument("ackPayment", invoice, true, true);
                }
                catch { }
                DocumentWorkflow updWrkFlow = Utilities.UpdateWorkFlowStage(invoice.FK_DocumentId, invoice.DocumentType);
            }

            return receipt;
        }

        public static List<FeeRules> GetFeeRulesList(string docType)
        {
            List<FeeRules> response = new List<FeeRules>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from FeeRules where FK_FeeId in (select Id from Fees where FeeType='" + docType + "')");
            while (reader.Reader.Read())
            {
                FeeRules doc = new FeeRules();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.RuleExecutionType = (reader.Reader["RuleExecutionType"].ToString());
                doc.RuleName = (reader.Reader["RuleName"].ToString());
                doc.RuleType = (reader.Reader["RuleType"].ToString());
                doc.RuleField = (reader.Reader["RuleField"].ToString());
                doc.FK_FeeId = int.Parse(reader.Reader["FK_FeeId"].ToString());
                doc.RuleExecutionValue = (reader.Reader["RuleExecutionValue"].ToString());
                doc.RuleEvaluationField = (reader.Reader["RuleEvaluationField"].ToString());
                doc.RuleEvaluationDataType = (reader.Reader["RuleEvaluationDataType"].ToString());
                doc.RuleEvaluationType = (reader.Reader["RuleEvaluationType"].ToString());
                doc.RuleEvaluationValue = (reader.Reader["RuleEvaluationValue"].ToString());
                doc.RuleEvaluationMaxValue = (reader.Reader["RuleEvaluationMaxValue"].ToString());
                doc.Active = bool.Parse(reader.Reader["Active"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();

            return response;
        }

        public static FeeRules GetFeeRule(long Id)
        {
            FeeRules fee = new FeeRules(Id);
            return fee;
        }

        public static long SaveFeeRule(int id, string ruleName, string ruleType, string ruleField, string ruleExecutionType, string ruleExecutionValue, string ruleEvaluationField, string ruleEvaluationDataType, string ruleEvaluationType, string ruleEvaluationValue, string ruleEvaluationMaxValue, bool active)
        {
            FeeRules fee = new FeeRules(id, ruleName, ruleType, ruleField, ruleExecutionType, ruleExecutionValue, ruleEvaluationField, ruleEvaluationDataType, ruleEvaluationType, ruleEvaluationValue, ruleEvaluationMaxValue, active);
            return fee.Save();
        }

        public static float CalculateLoanFee(FeeRules rule, LoanRequest loan)
        {
            object fieldVal = null;
            object evalFieldVal = null;
            bool found = false;
            FieldInfo[] fields = loan.GetType().GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (FieldInfo f in fields)
            {
                //<Created>k__BackingField
                if (f.Name.Split('<')[1].Split('>')[0] == rule.RuleField)
                {
                    fieldVal = f.GetValue(loan);
                    found = true;

                }

                if (f.Name.Split('<')[1].Split('>')[0] == rule.RuleEvaluationField)
                {
                    evalFieldVal = f.GetValue(loan);
                    found = true;

                }

            }

            if (found)
                return CalculateFee(rule, fieldVal, evalFieldVal);
            else
                return 0;
        }

        static float CalculateFee(FeeRules rule, object val, object evalVal)
        {
            bool executeCalculate = false;
            float value = 0;
            float valF = float.Parse(val.ToString());
            float ruleExecutionValue = float.Parse(rule.RuleExecutionValue);
            try
            {
                if (rule.RuleEvaluationDataType == "quantity")
                {
                    if (rule.RuleEvaluationType == "less")
                    {
                        if (float.Parse(evalVal.ToString()) < float.Parse(rule.RuleEvaluationValue))
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "greater")
                    {
                        if (float.Parse(evalVal.ToString()) > float.Parse(rule.RuleEvaluationValue))
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "equal")
                    {
                        if (float.Parse(evalVal.ToString()) == float.Parse(rule.RuleEvaluationValue))
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "not")
                    {
                        if (float.Parse(evalVal.ToString()) != float.Parse(rule.RuleEvaluationValue))
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "in")
                    {
                        if ((float.Parse(evalVal.ToString()) >= float.Parse(rule.RuleEvaluationValue)) && (float.Parse(evalVal.ToString()) <= float.Parse(rule.RuleEvaluationMaxValue)))
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "between")
                    {
                        if ((float.Parse(evalVal.ToString()) > float.Parse(rule.RuleEvaluationValue)) && (float.Parse(evalVal.ToString()) < float.Parse(rule.RuleEvaluationMaxValue)))
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "out")
                    {
                        if ((float.Parse(evalVal.ToString()) < float.Parse(rule.RuleEvaluationValue)) || (float.Parse(evalVal.ToString()) > float.Parse(rule.RuleEvaluationMaxValue)))
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                }
                else
                {
                    if (rule.RuleEvaluationType == "equal")
                    {
                        if (evalVal.ToString() == rule.RuleEvaluationValue)
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "not")
                    {
                        if (evalVal.ToString() != rule.RuleEvaluationValue)
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "like")
                    {
                        if (evalVal.ToString().IndexOf(rule.RuleEvaluationValue) > -1)
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }
                    else if (rule.RuleEvaluationType == "not like")
                    {
                        if (evalVal.ToString().IndexOf(rule.RuleEvaluationValue) < 0)
                            executeCalculate = true;
                        else
                            executeCalculate = false;
                    }

                }

                if (executeCalculate)
                {
                    if (rule.RuleType == "percentage")
                    {

                        if (rule.RuleExecutionType == "add")
                        {
                            value = float.Parse(Math.Round(((ruleExecutionValue * valF) / 100), 2).ToString());

                        }
                        else if (rule.RuleExecutionType == "subtract")
                        {
                            value = (-1 * float.Parse(Math.Round(((ruleExecutionValue * valF) / 100), 2).ToString()));
                        }

                    }
                    else
                    {
                        if (rule.RuleExecutionType == "add")
                        {
                            value = ruleExecutionValue;
                        }
                        else if (rule.RuleExecutionType == "subtract")
                        {
                            value = ruleExecutionValue * -1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utilities.LogError("mes", ex);
            }
            return value;

        }

        public static float CalculatePenaltyFee(FeeRules rule, RepaymentSchedule repay)
        {
            object fieldVal = null;
            object evalFieldVal = null;
            bool found = false;
            FieldInfo[] fields = repay.GetType().GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (FieldInfo f in fields)
            {
                //<Created>k__BackingField
                if (f.Name.Split('<')[1].Split('>')[0] == rule.RuleField)
                {
                    fieldVal = f.GetValue(repay);
                    found = true;

                }

                if (f.Name.Split('<')[1].Split('>')[0] == rule.RuleEvaluationField)
                {
                    evalFieldVal = f.GetValue(repay);
                    found = true;

                }

            }

            if (found)
                return CalculateFee(rule, fieldVal, evalFieldVal);
            else
                return 0;
        }

        public static List<InvoiceItem> GetInvoiceItems(long Id)
        {
            List<InvoiceItem> response = new List<InvoiceItem>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from InvoiceItem where FK_InvoiceId=" + Id);
            while (reader.Reader.Read())
            {
                InvoiceItem invoice = new InvoiceItem();
                invoice.Id = long.Parse(reader.Reader["Id"].ToString());
                invoice.FK_InvoiceId = long.Parse(reader.Reader["FK_InvoiceId"].ToString());
                invoice.Currency = (reader.Reader["Currency"].ToString());
                invoice.Amount = float.Parse(reader.Reader["Amount"].ToString());
                invoice.Description = (reader.Reader["Description"].ToString());
                invoice.Created = DateTime.Now;
                invoice.CreatedBy = (reader.Reader["CreatedBy"].ToString());

                response.Add(invoice);
            }
            reader.Close();
            return response;
        }
    }

    public class Invoice
    {
        public Invoice() { }

        public Invoice(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Invoice where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_ReferenceNumber = (reader.Reader["FK_ReferenceNumber"].ToString());
                this.DocumentType = (reader.Reader["DocumentType"].ToString());
                this.InvoiceDate = DateTime.Parse(reader.Reader["InvoiceDate"].ToString());
                this.FK_InvoicedBy = (reader.Reader["FK_InvoicedBy"].ToString());
                this.Currency = (reader.Reader["Currency"].ToString());
                this.Amount = float.Parse(reader.Reader["Amount"].ToString());
                this.AmountSurcharge = float.Parse(reader.Reader["AmountSurcharge"].ToString());
                this.AmountDiscount = float.Parse(reader.Reader["AmountDiscount"].ToString());
                this.AmountTotal = float.Parse(reader.Reader["AmountTotal"].ToString());
                this.AllowPartPayment = bool.Parse(reader.Reader["AllowPartPayment"].ToString());
                this.FK_PayBranchId = int.Parse(reader.Reader["FK_PayBranchId"].ToString());
                this.FK_PaymentMethodId = int.Parse(reader.Reader["FK_PaymentMethodId"].ToString());
                this.CurrencyPaid = (reader.Reader["CurrencyPaid"].ToString());
                this.AmountPaid = float.Parse(reader.Reader["AmountPaid"].ToString());
                this.PaymentDate = DateTime.Parse(reader.Reader["PaymentDate"].ToString());
                this.ReceiptNumber = (reader.Reader["ReceiptNumber"].ToString());
                this.Comments = (reader.Reader["Comments"].ToString());
                this.FK_ReceiptedBy = (reader.Reader["FK_ReceiptedBy"].ToString());
                this.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                this.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                this.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public Invoice(string fK_ReferenceNumber, string currency, float amount, bool allowPartPayment, string documentType, long fK_DocumentId = 0, long fK_DocumentWorkFlowId = 0, long fK_WorkFlowStageId = 0, float amountSurcharge = 0, float amountDiscount = 0)
        {
            this.FK_ReferenceNumber = fK_ReferenceNumber;
            this.Currency = currency;
            this.Amount = amount;
            this.AllowPartPayment = allowPartPayment;
            this.DocumentType = documentType;
            this.FK_DocumentId = fK_DocumentId;
            this.FK_DocumentWorkFlowId = fK_DocumentWorkFlowId;
            this.FK_WorkFlowStageId = fK_WorkFlowStageId;
            this.AmountSurcharge = amountSurcharge;
            this.AmountDiscount = amountDiscount;

            this.AmountTotal = (this.Amount + this.AmountSurcharge) - this.AmountDiscount;
            this.AmountPaid = 0;
            this.FK_PayBranchId = 0;
            this.FK_PaymentMethodId = 0;
        }

        public long Save()
        {
            SqlCommand command = new SqlCommand("insert into Invoice(FK_ReferenceNumber,DocumentType,InvoiceDate,FK_InvoicedBy,Currency,Amount,AmountSurcharge,AmountDiscount,AmountTotal,AllowPartPayment,FK_PayBranchId,FK_PaymentMethodId,CurrencyPaid,AmountPaid,PaymentDate,ReceiptNumber,FK_ReceiptedBy,Comments,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,Created,CreatedBy,LastModified,LastModifiedBy) values(@FK_ReferenceNumber,@DocumentType,CURRENT_TIMESTAMP,@FK_InvoicedBy,@Currency,@Amount,@AmountSurcharge,@AmountDiscount,@AmountTotal,@AllowPartPayment,@FK_PayBranchId,@FK_PaymentMethodId,@CurrencyPaid,@AmountPaid,CURRENT_TIMESTAMP,@ReceiptNumber,@FK_ReceiptedBy,@Comments,@FK_DocumentId,@FK_DocumentWorkFlowId,@FK_WorkFlowStageId,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");

            command.Parameters.Add(new SqlParameter("@FK_ReferenceNumber", this.FK_ReferenceNumber));
            command.Parameters.Add(new SqlParameter("@DocumentType", this.DocumentType));
            command.Parameters.Add(new SqlParameter("@FK_InvoicedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@Currency", this.Currency));
            command.Parameters.Add(new SqlParameter("@Amount", this.Amount));
            command.Parameters.Add(new SqlParameter("@AmountSurcharge", this.AmountSurcharge));
            command.Parameters.Add(new SqlParameter("@AmountDiscount", this.AmountDiscount));
            command.Parameters.Add(new SqlParameter("@AmountTotal", this.AmountTotal));
            command.Parameters.Add(new SqlParameter("@AllowPartPayment", this.AllowPartPayment));
            command.Parameters.Add(new SqlParameter("@FK_PayBranchId", this.FK_PayBranchId));
            command.Parameters.Add(new SqlParameter("@FK_PaymentMethodId", this.FK_PaymentMethodId));
            command.Parameters.Add(new SqlParameter("@CurrencyPaid", this.Currency));
            command.Parameters.Add(new SqlParameter("@AmountPaid", this.AmountPaid));
            command.Parameters.Add(new SqlParameter("@ReceiptNumber", ""));
            command.Parameters.Add(new SqlParameter("@FK_ReceiptedBy", ""));
            command.Parameters.Add(new SqlParameter("@Comments", ""));
            command.Parameters.Add(new SqlParameter("@FK_DocumentId", this.FK_DocumentId));
            command.Parameters.Add(new SqlParameter("@FK_DocumentWorkFlowId", this.FK_DocumentWorkFlowId));
            command.Parameters.Add(new SqlParameter("@FK_WorkFlowStageId", this.FK_WorkFlowStageId));
            command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));

            long x = Utilities.ExecuteNewRecord(command);
            return x;
        }

        public string Pay(string currency, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId)
        {
            Receipt receipt = new Receipt(this.Id, this.Currency, (this.AmountTotal - this.AmountPaid), currency, amount, change);
            long receiptNo = receipt.Save();
            if (receiptNo > 0)
            {
                int x = Utilities.ExecuteNonQuery("update Invoice set CurrencyPaid='" + currency + "',AmountPaid+=" + amount + ",FK_PayBranchId=" + fK_PayBranchId + ",FK_PaymentMethodId=" + fK_PaymentMethodId + ",PaymentDate=CURRENT_TIMESTAMP,ReceiptNumber='" + receiptNo.ToString().PadLeft(10, '0') + "',FK_ReceiptedBy='" + Security.actingUser + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "'  where Id=" + this.Id);
                return receiptNo.ToString().PadLeft(10, '0');
            }
            else
                return "0";
        }

        public long Id { get; set; }
        public string FK_ReferenceNumber { get; set; }
        public string DocumentType { get; set; }
        public DateTime InvoiceDate { get; set; }
        public string FK_InvoicedBy { get; set; }
        public string Currency { get; set; }
        public float Amount { get; set; }
        public float AmountSurcharge { get; set; }
        public float AmountDiscount { get; set; }
        public float AmountTotal { get; set; }
        public bool AllowPartPayment { get; set; }
        public int FK_PayBranchId { get; set; }
        public int FK_PaymentMethodId { get; set; }
        public string CurrencyPaid { get; set; }
        public float AmountPaid { get; set; }
        public DateTime PaymentDate { get; set; }
        public string ReceiptNumber { get; set; }
        public string Comments { get; set; }
        public string FK_ReceiptedBy { get; set; }
        public long FK_DocumentId { get; set; }
        public long FK_DocumentWorkFlowId { get; set; }
        public long FK_WorkFlowStageId { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }

    }

    public class Fees
    {
        public Fees() { }
        public Fees(string feeType, long stageId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Fees where FeeType='" + feeType + "' and FK_WorkFlowStageId=" + stageId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                this.FeeType = (reader.Reader["FeeType"].ToString());
                this.Currency = (reader.Reader["Currency"].ToString());
                this.Amount = float.Parse(reader.Reader["Amount"].ToString());
                this.AllowPartPayment = bool.Parse(reader.Reader["AllowPartPayment"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }
        public long Id { get; set; }
        public long FK_WorkFlowStageId { get; set; }
        public string FeeType { get; set; }
        public string Currency { get; set; }
        public float Amount { get; set; }
        public bool AllowPartPayment { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class FeeRules
    {
        public FeeRules() { }

        public FeeRules(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from FeeRules where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.RuleExecutionType = (reader.Reader["RuleExecutionType"].ToString());
                this.RuleName = (reader.Reader["RuleName"].ToString());
                this.RuleType = (reader.Reader["RuleType"].ToString());
                this.RuleField = (reader.Reader["RuleField"].ToString());
                this.FK_FeeId = int.Parse(reader.Reader["FK_FeeId"].ToString());
                this.RuleExecutionValue = (reader.Reader["RuleExecutionValue"].ToString());
                this.RuleEvaluationField = (reader.Reader["RuleEvaluationField"].ToString());
                this.RuleEvaluationDataType = (reader.Reader["RuleEvaluationDataType"].ToString());
                this.RuleEvaluationType = (reader.Reader["RuleEvaluationType"].ToString());
                this.RuleEvaluationValue = (reader.Reader["RuleEvaluationValue"].ToString());
                this.RuleEvaluationMaxValue = (reader.Reader["RuleEvaluationMaxValue"].ToString());
                this.Active = bool.Parse(reader.Reader["Active"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public FeeRules(int id, string ruleName, string ruleType, string ruleField, string ruleExecutionType, string ruleExecutionValue, string ruleEvaluationField, string ruleEvaluationDataType, string ruleEvaluationType, string ruleEvaluationValue, string ruleEvaluationMaxValue, bool active)
        {
            this.RuleExecutionType = ruleExecutionType;
            this.RuleName = ruleName;
            this.RuleType = ruleType;
            this.RuleField = ruleField;
            this.FK_FeeId = id;
            this.RuleExecutionValue = ruleExecutionValue;
            this.RuleEvaluationField = ruleEvaluationField;
            this.RuleEvaluationDataType = ruleEvaluationDataType;
            this.RuleEvaluationType = ruleEvaluationType;
            this.RuleEvaluationValue = ruleEvaluationValue;
            this.RuleEvaluationMaxValue = ruleEvaluationMaxValue;
            this.Active = active;
        }


        public long Save()
        {
            long x = 0;
            if (this.Id == 0)
                x = Utilities.ExecuteNewRecord("insert into FeeRules(FK_FeeId,RuleName,RuleType,RuleField,RuleExecutionType,RuleExecutionValue,RuleEvaluationField,RuleEvaluationDataType,RuleEvaluationType,RuleEvaluationValue,RuleEvaluationMaxValue,Active,Created,CreatedBy,LastModified,LastModifiedBy) values('" + FK_FeeId + "','" + RuleName + "','" + RuleType + "','" + RuleField + "','" + RuleExecutionType + "','" + RuleExecutionValue + "','" + RuleEvaluationField + "','" + RuleEvaluationDataType + "','" + RuleEvaluationType + "','" + RuleEvaluationValue + "','" + RuleEvaluationMaxValue + "','" + ((this.Active) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            else
            {
                x = Utilities.ExecuteNonQuery("update FeeRules set RuleType='" + RuleType + "',RuleField='" + RuleField + "',RuleExecutionType='" + RuleExecutionType + "',RuleExecutionValue='" + RuleExecutionValue + "',RuleEvaluationField='" + RuleEvaluationField + "',RuleEvaluationDataType='" + RuleEvaluationDataType + "',RuleEvaluationType='" + RuleEvaluationType + "',RuleEvaluationValue='" + RuleEvaluationValue + "',RuleEvaluationMaxValue='" + RuleEvaluationMaxValue + "',Active='" + ((this.Active) ? "True" : "False") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where RuleName='" + this.RuleName + "'");
                if (x == 0) x = -1;
                else x = this.Id;
            }
            return this.Id;
        }

        public long Id { get; set; }
        public string RuleExecutionType { get; set; }
        public string RuleName { get; set; }
        public string RuleType { get; set; }
        public string RuleField { get; set; }
        public int FK_FeeId { get; set; }
        public string RuleExecutionValue { get; set; }
        public string RuleEvaluationField { get; set; }
        public string RuleEvaluationDataType { get; set; }
        public string RuleEvaluationType { get; set; }
        public string RuleEvaluationValue { get; set; }
        public string RuleEvaluationMaxValue { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class Receipt
    {
        public Receipt() { }
        public Receipt(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Receipt where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_InvoiceId = long.Parse(reader.Reader["FK_InvoiceId"].ToString());
                this.Currency = (reader.Reader["Currency"].ToString());
                this.Amount = float.Parse(reader.Reader["Amount"].ToString());
                this.CurrencyTendered = (reader.Reader["CurrencyTendered"].ToString());
                this.AmountTendered = float.Parse(reader.Reader["AmountTendered"].ToString());
                this.Change = float.Parse(reader.Reader["Change"].ToString());
                this.Printed = int.Parse(reader.Reader["Printed"].ToString());
                this.LastPrinted = DateTime.Parse(reader.Reader["LastPrinted"].ToString());
                this.PrintedBy = (reader.Reader["PrintedBy"].ToString());
                this.Receipted = DateTime.Parse(reader.Reader["Receipted"].ToString());
                this.ReceiptedBy = (reader.Reader["ReceiptedBy"].ToString());
            }
            reader.Close();
        }

        public Receipt(long fK_InvoiceId, string currency, float amount, string currencyTendered, float amountTendered, float change)
        {
            this.FK_InvoiceId = fK_InvoiceId;
            this.Currency = currency;
            this.Amount = amount;
            this.CurrencyTendered = currencyTendered;
            this.AmountTendered = amountTendered;
            this.Change = change;
        }

        public long Save()
        {
            return Utilities.ExecuteNewRecord("insert into Receipt(FK_InvoiceId,Currency,Amount,CurrencyTendered,AmountTendered,Change,Printed,LastPrinted,PrintedBy,Receipted,ReceiptedBy) values(" + this.FK_InvoiceId + ",'" + this.Currency + "'," + this.Amount + ",'" + this.CurrencyTendered + "'," + this.AmountTendered + "," + this.Change + ",0,CURRENT_TIMESTAMP,'',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
        }

        public long Id { get; set; }
        public long FK_InvoiceId { get; set; }
        public string Currency { get; set; }
        public float Amount { get; set; }
        public string CurrencyTendered { get; set; }
        public float AmountTendered { get; set; }
        public float Change { get; set; }
        public int Printed { get; set; }
        public DateTime LastPrinted { get; set; }
        public string PrintedBy { get; set; }
        public DateTime Receipted { get; set; }
        public string ReceiptedBy { get; set; }
    }

    public class InvoiceItem
    {
        public InvoiceItem() { }

        public InvoiceItem(long invoiceId, string currency, float amount, string description)
        {
            this.Amount = amount;
            this.Currency = currency;
            this.FK_InvoiceId = invoiceId;
            this.Description = description;
        }

        public long Save()
        {
            return Utilities.ExecuteNewRecord("insert into InvoiceItem(FK_InvoiceId,Currency,Amount,Description,Created,CreatedBy) values(" + this.FK_InvoiceId + ",'" + this.Currency + "'," + this.Amount + ",'" + this.Description + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
        }

        public long Id { get; set; }
        public long FK_InvoiceId { get; set; }
        public string Description { get; set; }
        public string Currency { get; set; }
        public float Amount { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
    }
}