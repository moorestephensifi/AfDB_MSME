﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SBFA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IsbfaOnlineSecurity" in both code and config file together.
    [ServiceContract(Namespace = "ISBFAOnlineSecurity/JSONData")]
    public interface ISBFAOnlineSecurity
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
                            ResponseFormat = WebMessageFormat.Json,
                            BodyStyle = WebMessageBodyStyle.WrappedRequest,
                            UriTemplate = "Authenticate")]
        AuthenticationResponse Authenticate(string username, string password);

        [OperationContract]
        [WebInvoke(Method = "POST",
                            ResponseFormat = WebMessageFormat.Json,
                            BodyStyle = WebMessageBodyStyle.WrappedRequest,
                            UriTemplate = "Signout")]
        SignoutResponse Signout(string username);

        [OperationContract]
        [WebInvoke(Method = "POST",
                            ResponseFormat = WebMessageFormat.Json,
                            BodyStyle = WebMessageBodyStyle.WrappedRequest,
                            UriTemplate = "ChangePassword")]
        PasswordChangeResponse ChangePassword(string username, string oldPassword, string newPassword);
        
        [OperationContract]
        [WebInvoke(Method = "POST",
                           ResponseFormat = WebMessageFormat.Json,
                           BodyStyle = WebMessageBodyStyle.WrappedRequest,
                           UriTemplate = "AddRole")]
        UserRoleActionResponse AddRole(string username, string userRole);

        [OperationContract]
        [WebInvoke(Method = "POST",
                           ResponseFormat = WebMessageFormat.Json,
                           BodyStyle = WebMessageBodyStyle.WrappedRequest,
                           UriTemplate = "RemoveRole")]
        UserRoleActionResponse RemoveRole(string username, string userRole);
        
        [OperationContract]
        [WebInvoke(Method = "POST",
                           ResponseFormat = WebMessageFormat.Json,
                           BodyStyle = WebMessageBodyStyle.WrappedRequest,
                           UriTemplate = "UpdateUser")]
        UserActionResponse UpdateUser(string username, string action);
    }
}
