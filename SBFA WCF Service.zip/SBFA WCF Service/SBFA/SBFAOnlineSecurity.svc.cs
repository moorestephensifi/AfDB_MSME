﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SBFA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "sbfaOnlineSecurity" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select sbfaOnlineSecurity.svc or sbfaOnlineSecurity.svc.cs at the Solution Explorer and start debugging.
    public class SBFAOnlineSecurity : ISBFAOnlineSecurity
    {
        public AuthenticationResponse Authenticate(string username, string password)
        {
            return Security.Authenticate(username, password);
        }

        public SignoutResponse Signout(string username)
        {
            return Security.Signout(username);
        }

        public PasswordChangeResponse ChangePassword(string username, string oldPassword, string newPassword)
        {
            return Security.ChangePassword(username, oldPassword, newPassword);
        }
        
        public UserRoleActionResponse AddRole(string username, string userRole)
        {
            return Security.AddRole(username, userRole);
        }

        public UserRoleActionResponse RemoveRole(string username, string userRole)
        {
            return Security.RemoveRole(username, userRole);
        }

        public UserActionResponse UpdateUser(string username, string action)
        {
            return Security.UpdateUser(username, action);
        }
    }
}
