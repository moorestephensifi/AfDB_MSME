﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SBFA
{
    public class PickList
    {
        public long Id { get; set; }
        public string Text { get; set; }
    }

    public class LoanRequest
    {
        public LoanRequest() { }

        public LoanRequest(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from LoanRequest where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.ReferenceNumber = (reader.Reader["ReferenceNumber"].ToString());
                this.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                this.BusinessName = (reader.Reader["BusinessName"].ToString());
                this.FK_BusinessTypeId = int.Parse(reader.Reader["FK_BusinessTypeId"].ToString());
                this.FK_BusinessRegistrationTypeId = int.Parse(reader.Reader["FK_BusinessRegistrationTypeId"].ToString());
                this.SEnPARegistrationNo = (reader.Reader["SEnPARegistrationNo"].ToString());
                this.FK_BusinessIslandLocationId = int.Parse(reader.Reader["FK_BusinessIslandLocationId"].ToString());
                this.FK_BusinessIslandDistrictId = int.Parse(reader.Reader["FK_BusinessIslandDistrictId"].ToString());
                this.NIN = (reader.Reader["NIN"].ToString());
                this.FirstNames = (reader.Reader["FirstNames"].ToString());
                this.LastName = (reader.Reader["LastName"].ToString());
                this.Salutation = (reader.Reader["Salutation"].ToString());
                this.Gender = (reader.Reader["Gender"].ToString());
                this.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                this.Age = int.Parse(reader.Reader["Age"].ToString());
                this.FK_ResidenceIslandLocationId = int.Parse(reader.Reader["FK_ResidenceIslandLocationId"].ToString());
                this.FK_ResidenceDistrictLocationId = int.Parse(reader.Reader["FK_ResidenceDistrictLocationId"].ToString());
                this.Mobile = (reader.Reader["Mobile"].ToString());
                this.HomeTelephone = (reader.Reader["HomeTelephone"].ToString());
                this.WorkTelephone = (reader.Reader["WorkTelephone"].ToString());
                this.Email = (reader.Reader["Email"].ToString());
                this.FK_LoansOfficerId = int.Parse(reader.Reader["FK_LoansOfficerId"].ToString());
                this.NoOfEmployees = int.Parse(reader.Reader["NoOfEmployees"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.DocumentType = (reader.Reader["DocumentType"].ToString());
                this.RequireWorkFlow = bool.Parse(reader.Reader["RequireWorkFlow"].ToString());
                this.WorkFlowId = long.Parse(reader.Reader["WorkFlowId"].ToString());
                this.WorkFlowStatus = (reader.Reader["WorkFlowStatus"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                //employment details
                this.Employed = bool.Parse(reader.Reader["Employed"].ToString());
                this.EmploymentDetails = reader.Reader["EmploymentDetails"].ToString();
                this.NameOfEmployer = reader.Reader["NameOfEmployer"].ToString();
                this.CurrentNoOfYears = long.Parse(reader.Reader["CurrentNoOfYears"].ToString());
                this.CurrentPosition = reader.Reader["CurrentPosition"].ToString();
                this.PreviousEmployer = reader.Reader["PreviousEmployer"].ToString();
                this.PreviousNoOfYears = long.Parse(reader.Reader["PreviousNoOfYears"].ToString());
                this.PreviousPosition = reader.Reader["PreviousPosition"].ToString();
                this.BackgroundExperience = reader.Reader["BackgroundExperience"].ToString();

                //financial details
                this.CostOfProject = float.Parse(reader.Reader["CostOfProject"].ToString());
                this.MonthlyIncome = float.Parse(reader.Reader["MonthlyIncome"].ToString());
                this.OtherIncome = float.Parse(reader.Reader["OtherIncome"].ToString());
                this.BusinessMonthlyIncome = float.Parse(reader.Reader["BusinessMonthlyIncome"].ToString());
                this.PersonalExpenditure = float.Parse(reader.Reader["PersonalExpenditure"].ToString());
                this.BusinessExpenditureLoan = float.Parse(reader.Reader["BusinessExpenditureLoan"].ToString());
                this.BusinessExpenditureRent = float.Parse(reader.Reader["BusinessExpenditureRent"].ToString());
                this.BusinessExpenditureUtilityBills = float.Parse(reader.Reader["BusinessExpenditureUtilityBills"].ToString());
                this.BusinessExpenditureStaffSalaries = float.Parse(reader.Reader["BusinessExpenditureStaffSalaries"].ToString());
                this.BusinessExpenditureOther = float.Parse(reader.Reader["BusinessExpenditureOther"].ToString());
                this.PersonalIncomeTotal = float.Parse(reader.Reader["PersonalIncomeTotal"].ToString());
                this.PersonalExpenditureTotal = float.Parse(reader.Reader["PersonalExpenditureTotal"].ToString());
                this.BusinessIncomeTotal = float.Parse(reader.Reader["BusinessIncomeTotal"].ToString());
                this.BusinessExpenditureTotal = float.Parse(reader.Reader["BusinessExpenditureTotal"].ToString());
                this.NameOfBank = reader.Reader["NameOfBank"].ToString();
                this.AccountNo = reader.Reader["AccountNo"].ToString();
                this.TypeOfAccount = reader.Reader["TypeOfAccount"].ToString();
                this.DateOfLastPayment = DateTime.Parse(reader.Reader["DateOfLastPayment"].ToString());
                this.LoanBalance = float.Parse(reader.Reader["LoanBalance"].ToString());

                //loan details
                this.LoanAmountRequested = float.Parse(reader.Reader["LoanAmountRequested"].ToString());
                this.AnnualTurnoverRange = reader.Reader["AnnualTurnoverRange"].ToString();
                this.HasSecurity = bool.Parse(reader.Reader["HasSecurity"].ToString());
                this.TypeOfSecurity = reader.Reader["TypeOfSecurity"].ToString();
                this.PurposeOfLoan = reader.Reader["PurposeOfLoan"].ToString();

                //Guarantor details
                this.GuarantorNIN = reader.Reader["GuarantorNIN"].ToString();
                this.GuarantorName = reader.Reader["GuarantorName"].ToString();
                this.GuarantorSurname = reader.Reader["GuarantorSurname"].ToString();
                this.GuarantorDOB = DateTime.Parse(reader.Reader["GuarantorDOB"].ToString());
                this.GuarantorAddress = reader.Reader["GuarantorAddress"].ToString();
                this.GuarantorContactNo = reader.Reader["GuarantorContactNo"].ToString();
                this.GuarantorMaritalStatus = reader.Reader["GuarantorMaritalStatus"].ToString();
                this.GuarantorNoOfDependents = reader.Reader["GuarantorNoOfDependents"].ToString();
                this.GuarantorEmploymentStatus = reader.Reader["GuarantorEmploymentStatus"].ToString();
                this.GuarantorEmployersAddress = reader.Reader["GuarantorEmployersAddress"].ToString();
                this.GuarantorEmployersName = reader.Reader["GuarantorEmployersName"].ToString();
                this.GuarantorCurrentPosition = reader.Reader["GuarantorCurrentPosition"].ToString();
                this.GuarantorNoOfYears = long.Parse(reader.Reader["GuarantorNoOfYears"].ToString());
                this.GuarantorTotalMonthlyIncome = float.Parse(reader.Reader["GuarantorTotalMonthlyIncome"].ToString());
                this.GuarantorTotalMonthlyExpenditure = float.Parse(reader.Reader["GuarantorTotalMonthlyExpenditure"].ToString());
            }
            reader.Close();
        }

        public long Save()
        {
            this.DocumentType = "loan";
            this.RequireWorkFlow = true;
            this.WorkFlowId = Utilities.GetEntityWorkFlow(this.DocumentType);
            this.WorkFlowStatus = "";
            try
            {
                int c = int.Parse(Utilities.ExecuteScalar("select count(Id) from LoanRequest where ReferenceNumber='" + this.ReferenceNumber + "'"));

                SqlCommand command;

                if (c < 1)
                    command = new SqlCommand("insert into LoanRequest(ReferenceNumber,BusinessRegistrationNumber,BusinessName,FK_BusinessTypeId,FK_BusinessRegistrationTypeId,FK_BusinessIslandLocationId,FK_BusinessIslandDistrictId,NIN,FirstNames,LastName,Salutation,Gender,DOB,Age,FK_ResidenceIslandLocationId,FK_ResidenceDistrictLocationId,Mobile,HomeTelephone,WorkTelephone,Email,FK_LoansOfficerId,SEnPARegistrationNo,NoOfEmployees,Employed,EmploymentDetails,NameOfEmployer,CurrentNoOfYears,CurrentPosition,PreviousEmployer,PreviousNoOfYears,PreviousPosition,BackgroundExperience,CostOfProject,MonthlyIncome,OtherIncome,BusinessMonthlyIncome,PersonalExpenditure,BusinessExpenditureLoan,BusinessExpenditureRent,BusinessExpenditureUtilityBills,BusinessExpenditureStaffSalaries,BusinessExpenditureOther,PersonalIncomeTotal,PersonalExpenditureTotal,BusinessIncomeTotal,BusinessExpenditureTotal,NameOfBank,AccountNo,TypeOfAccount,DateOfLastPayment,LoanBalance,LoanAmountRequested,AnnualTurnoverRange,HasSecurity,TypeOfSecurity,PurposeOfLoan,GuarantorNIN,GuarantorName,GuarantorSurname,GuarantorDOB,GuarantorAddress,GuarantorContactNo,GuarantorMaritalStatus,GuarantorNoOfDependents,GuarantorEmploymentStatus,GuarantorEmployersAddress,GuarantorEmployersName,GuarantorCurrentPosition,GuarantorNoOfYears,GuarantorTotalMonthlyIncome,GuarantorTotalMonthlyExpenditure,Status,StatusReason,DocumentType,RequireWorkFlow,WorkFlowId,WorkFlowStatus,Created,CreatedBy,LastModified,LastModifiedBy) values(@ReferenceNumber,@BusinessRegistrationNumber,@BusinessName,@FK_BusinessTypeId,@FK_BusinessRegistrationTypeId,@FK_BusinessIslandLocationId,@FK_BusinessIslandDistrictId,@NIN,@FirstNames,@LastName,@Salutation,@Gender,@DOB,@Age,@FK_ResidenceIslandLocationId,@FK_ResidenceDistrictLocationId,@Mobile,@HomeTelephone,@WorkTelephone,@Email,@FK_LoansOfficerId,@SEnPARegistrationNo,@NoOfEmployees,@Employed,@EmploymentDetails,@NameOfEmployer,@CurrentNoOfYears,@CurrentPosition,@PreviousEmployer,@PreviousNoOfYears,@PreviousPosition,@BackgroundExperience,@CostOfProject,@MonthlyIncome,@OtherIncome,@BusinessMonthlyIncome,@PersonalExpenditure,@BusinessExpenditureLoan,@BusinessExpenditureRent,@BusinessExpenditureUtilityBills,@BusinessExpenditureStaffSalaries,@BusinessExpenditureOther,@PersonalIncomeTotal,@PersonalExpenditureTotal,@BusinessIncomeTotal,@BusinessExpenditureTotal,@NameOfBank,@AccountNo,@TypeOfAccount,@DateOfLastPayment,@LoanBalance,@LoanAmountRequested,@AnnualTurnoverRange,@HasSecurity,@TypeOfSecurity,@PurposeOfLoan,@GuarantorNIN,@GuarantorName,@GuarantorSurname,@GuarantorDOB,@GuarantorAddress,@GuarantorContactNo,@GuarantorMaritalStatus,@GuarantorNoOfDependents,@GuarantorEmploymentStatus,@GuarantorEmployersAddress,@GuarantorEmployersName,@GuarantorCurrentPosition,@GuarantorNoOfYears,@GuarantorTotalMonthlyIncome,@GuarantorTotalMonthlyExpenditure,@Status,@StatusReason,@DocumentType,@RequireWorkFlow,@WorkFlowId,@WorkFlowStatus,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");
                else
                    command = new SqlCommand("update LoanRequest set BusinessRegistrationNumber=@BusinessRegistrationNumber,BusinessName=@BusinessName,FK_BusinessTypeId=@FK_BusinessTypeId,FK_BusinessRegistrationTypeId=@FK_BusinessRegistrationTypeId,FK_BusinessIslandLocationId=@FK_BusinessIslandLocationId,FK_BusinessIslandDistrictId=@FK_BusinessIslandDistrictId,NIN=@NIN,FirstNames=@FirstNames,LastName=@LastName,Salutation=@Salutation,Gender=@Gender,DOB=@DOB,Age=@Age,FK_ResidenceIslandLocationId=@FK_ResidenceIslandLocationId,FK_ResidenceDistrictLocationId=@FK_ResidenceDistrictLocationId,Mobile=@Mobile,HomeTelephone=@HomeTelephone,WorkTelephone=@WorkTelephone,Email=@Email,LastModified=CURRENT_TIMESTAMP,LastModifiedBy=@LastModifiedBy,SEnPARegistrationNo=@SEnPARegistrationNo,FK_LoansOfficerId=@FK_LoansOfficerId,TypeOfSecurity=@TypeOfSecurity,Employed=@Employed,EmploymentDetails=@EmploymentDetails,NameOfEmployer=@NameOfEmployer,CurrentNoOfYears=@CurrentNoOfYears,CurrentPosition=@CurrentPosition,PreviousEmployer=@PreviousEmployer,PreviousNoOfYears=@PreviousNoOfYears,PreviousPosition=@PreviousPosition,BackgroundExperience=@BackgroundExperience,CostOfProject=@CostOfProject,MonthlyIncome=@MonthlyIncome,OtherIncome=@OtherIncome,BusinessMonthlyIncome=@BusinessMonthlyIncome,PersonalExpenditure=@PersonalExpenditure,BusinessExpenditureLoan=@BusinessExpenditureLoan,BusinessExpenditureRent=@BusinessExpenditureRent,BusinessExpenditureUtilityBills=@BusinessExpenditureUtilityBills,BusinessExpenditureStaffSalaries=@BusinessExpenditureStaffSalaries,BusinessExpenditureOther=@BusinessExpenditureOther,PersonalIncomeTotal=@PersonalIncomeTotal,PersonalExpenditureTotal=@PersonalExpenditureTotal,BusinessIncomeTotal=@BusinessIncomeTotal,BusinessExpenditureTotal=@BusinessExpenditureTotal,NameOfBank=@NameOfBank,AccountNo=@AccountNo,TypeOfAccount=@TypeOfAccount,DateOfLastPayment=@DateOfLastPayment,LoanBalance=@LoanBalance,LoanAmountRequested=@LoanAmountRequested,AnnualTurnoverRange=@AnnualTurnoverRange,HasSecurity=@HasSecurity,PurposeOfLoan=@PurposeOfLoan,GuarantorNIN=@GuarantorNIN,GuarantorName=@GuarantorName,GuarantorSurname=@GuarantorSurname,GuarantorDOB=@GuarantorDOB,GuarantorAddress=@GuarantorAddress,GuarantorContactNo=@GuarantorContactNo,GuarantorMaritalStatus=@GuarantorMaritalStatus,GuarantorNoOfDependents=@GuarantorNoOfDependents,GuarantorEmploymentStatus=@GuarantorEmploymentStatus,GuarantorEmployersAddress=@GuarantorEmployersAddress,GuarantorEmployersName=@GuarantorEmployersName,GuarantorCurrentPosition=@GuarantorCurrentPosition,GuarantorNoOfYears=@GuarantorNoOfYears,GuarantorTotalMonthlyIncome=@GuarantorTotalMonthlyIncome,GuarantorTotalMonthlyExpenditure=@GuarantorTotalMonthlyExpenditure,NoOfEmployees=@NoOfEmployees where ReferenceNumber =@ReferenceNumber");

                command.Parameters.Add(new SqlParameter("@ReferenceNumber", this.ReferenceNumber));
                command.Parameters.Add(new SqlParameter("@BusinessRegistrationNumber", this.BusinessRegistrationNumber));
                command.Parameters.Add(new SqlParameter("@BusinessName", this.BusinessName));
                command.Parameters.Add(new SqlParameter("@FK_BusinessTypeId", this.FK_BusinessTypeId));
                command.Parameters.Add(new SqlParameter("@FK_BusinessRegistrationTypeId", this.FK_BusinessRegistrationTypeId));
                command.Parameters.Add(new SqlParameter("@FK_BusinessIslandLocationId", this.FK_BusinessIslandLocationId));
                command.Parameters.Add(new SqlParameter("@FK_BusinessIslandDistrictId", this.FK_BusinessIslandDistrictId));
                command.Parameters.Add(new SqlParameter("@NIN", this.NIN));
                command.Parameters.Add(new SqlParameter("@FirstNames", this.FirstNames));
                command.Parameters.Add(new SqlParameter("@LastName", this.LastName));
                command.Parameters.Add(new SqlParameter("@Salutation", this.Salutation));
                command.Parameters.Add(new SqlParameter("@Gender", this.Gender));
                command.Parameters.Add(new SqlParameter("@DOB", this.DOB));
                command.Parameters.Add(new SqlParameter("@FK_ResidenceIslandLocationId", this.FK_ResidenceIslandLocationId));
                command.Parameters.Add(new SqlParameter("@FK_ResidenceDistrictLocationId", this.FK_ResidenceDistrictLocationId));
                command.Parameters.Add(new SqlParameter("@Mobile", this.Mobile));
                command.Parameters.Add(new SqlParameter("@HomeTelephone", this.HomeTelephone));
                command.Parameters.Add(new SqlParameter("@WorkTelephone", this.WorkTelephone));
                command.Parameters.Add(new SqlParameter("@Email", this.Email));
                command.Parameters.Add(new SqlParameter("@Age", this.Age));
                command.Parameters.Add(new SqlParameter("@FK_LoansOfficerId", this.FK_LoansOfficerId));
                command.Parameters.Add(new SqlParameter("@NoOfEmployees", this.NoOfEmployees));
                command.Parameters.Add(new SqlParameter("@TypeOfSecurity", this.TypeOfSecurity));
                command.Parameters.Add(new SqlParameter("@Status", this.Status));
                command.Parameters.Add(new SqlParameter("@StatusReason", this.StatusReason));
                command.Parameters.Add(new SqlParameter("@DocumentType", this.DocumentType));
                command.Parameters.Add(new SqlParameter("@RequireWorkFlow", this.RequireWorkFlow));
                command.Parameters.Add(new SqlParameter("@WorkFlowId", this.WorkFlowId));
                command.Parameters.Add(new SqlParameter("@WorkFlowStatus", this.WorkFlowStatus));
                command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
                command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));
                command.Parameters.Add(new SqlParameter("@Employed", this.Employed));
                command.Parameters.Add(new SqlParameter("@EmploymentDetails", this.EmploymentDetails));
                command.Parameters.Add(new SqlParameter("@NameOfEmployer", this.NameOfEmployer));
                command.Parameters.Add(new SqlParameter("@CurrentNoOfYears", this.CurrentNoOfYears));
                command.Parameters.Add(new SqlParameter("@CurrentPosition", this.CurrentPosition));
                command.Parameters.Add(new SqlParameter("@PreviousEmployer", this.PreviousEmployer));
                command.Parameters.Add(new SqlParameter("@PreviousNoOfYears", this.PreviousNoOfYears));
                command.Parameters.Add(new SqlParameter("@PreviousPosition", this.PreviousPosition));
                command.Parameters.Add(new SqlParameter("@BackgroundExperience", this.BackgroundExperience));
                command.Parameters.Add(new SqlParameter("@CostOfProject", this.CostOfProject));
                command.Parameters.Add(new SqlParameter("@MonthlyIncome", this.MonthlyIncome));
                command.Parameters.Add(new SqlParameter("@OtherIncome", this.OtherIncome));
                command.Parameters.Add(new SqlParameter("@BusinessMonthlyIncome", this.BusinessMonthlyIncome));
                command.Parameters.Add(new SqlParameter("@PersonalExpenditure", this.PersonalExpenditure));
                command.Parameters.Add(new SqlParameter("@BusinessExpenditureLoan", this.BusinessExpenditureLoan));
                command.Parameters.Add(new SqlParameter("@BusinessExpenditureRent", this.BusinessExpenditureRent));
                command.Parameters.Add(new SqlParameter("@BusinessExpenditureUtilityBills", this.BusinessExpenditureUtilityBills));
                command.Parameters.Add(new SqlParameter("@BusinessExpenditureStaffSalaries", this.BusinessExpenditureStaffSalaries));
                command.Parameters.Add(new SqlParameter("@BusinessExpenditureOther", this.BusinessExpenditureOther));
                command.Parameters.Add(new SqlParameter("@PersonalIncomeTotal", this.PersonalIncomeTotal));
                command.Parameters.Add(new SqlParameter("@PersonalExpenditureTotal", this.PersonalExpenditureTotal));
                command.Parameters.Add(new SqlParameter("@BusinessIncomeTotal", this.BusinessIncomeTotal));
                command.Parameters.Add(new SqlParameter("@BusinessExpenditureTotal", this.BusinessExpenditureTotal));
                command.Parameters.Add(new SqlParameter("@NameOfBank", this.NameOfBank));
                command.Parameters.Add(new SqlParameter("@AccountNo", this.AccountNo));
                command.Parameters.Add(new SqlParameter("@TypeOfAccount", this.TypeOfAccount));
                command.Parameters.Add(new SqlParameter("@DateOfLastPayment", this.DateOfLastPayment));
                command.Parameters.Add(new SqlParameter("@LoanBalance", this.LoanBalance));
                command.Parameters.Add(new SqlParameter("@LoanAmountRequested", this.LoanAmountRequested));
                command.Parameters.Add(new SqlParameter("@AnnualTurnoverRange", this.AnnualTurnoverRange));
                command.Parameters.Add(new SqlParameter("@HasSecurity", this.HasSecurity));
                command.Parameters.Add(new SqlParameter("@PurposeOfLoan", this.PurposeOfLoan));
                command.Parameters.Add(new SqlParameter("@GuarantorNIN", this.GuarantorNIN));
                command.Parameters.Add(new SqlParameter("@GuarantorName", this.GuarantorName));
                command.Parameters.Add(new SqlParameter("@GuarantorSurname", this.GuarantorSurname));
                command.Parameters.Add(new SqlParameter("@GuarantorDOB", this.GuarantorDOB));
                command.Parameters.Add(new SqlParameter("@GuarantorAddress", this.GuarantorAddress));
                command.Parameters.Add(new SqlParameter("@GuarantorContactNo", this.GuarantorContactNo));
                command.Parameters.Add(new SqlParameter("@GuarantorMaritalStatus", this.GuarantorMaritalStatus));
                command.Parameters.Add(new SqlParameter("@GuarantorNoOfDependents", this.GuarantorNoOfDependents));
                command.Parameters.Add(new SqlParameter("@GuarantorEmploymentStatus", this.GuarantorEmploymentStatus));
                command.Parameters.Add(new SqlParameter("@GuarantorEmployersAddress", this.GuarantorEmployersAddress));
                command.Parameters.Add(new SqlParameter("@GuarantorEmployersName", this.GuarantorEmployersName));
                command.Parameters.Add(new SqlParameter("@GuarantorCurrentPosition", this.GuarantorCurrentPosition));
                command.Parameters.Add(new SqlParameter("@GuarantorNoOfYears", this.GuarantorNoOfYears));
                command.Parameters.Add(new SqlParameter("@GuarantorTotalMonthlyIncome", this.GuarantorTotalMonthlyIncome));
                command.Parameters.Add(new SqlParameter("@GuarantorTotalMonthlyExpenditure", this.GuarantorTotalMonthlyExpenditure));

                command.Parameters.Add(new SqlParameter("@SEnPARegistrationNo", this.SEnPARegistrationNo));

                if (c < 1)
                {
                    this.Id = Utilities.ExecuteNewRecord(command);
                    UpdateLoanRequestReferenceNumber(this.Id);
                    
                    if (this.Id > 0)
                    {
                        ///create assesment form
                        LoanAssesment lass = new LoanAssesment();
                        lass.FK_LoanRequestId = this.Id;
                        lass.LoanAmount = this.LoanAmountRequested;
                        lass.Create();

                        if (this.RequireWorkFlow)
                        {
                            //submit to workflow
                            DocumentWorkflow wrkDoc = Utilities.SubmitWorkFlowDocument(this.WorkFlowId, this.Id.ToString(), this.DocumentType);
                            this.WorkFlowStatus = wrkDoc.WorkFlowStatus;
                            UpdateWorkFlowStatus();

                        }
                    }
                    else
                    {


                    }
                }
                else
                {
                    //get current amount
                    long g = 0;
                    try
                    {
                        g = long.Parse(Utilities.ExecuteScalar("select Id from LoanRequest where ReferenceNumber='" + this.ReferenceNumber + "'"));
                        LoanRequest temp = new LoanRequest(g);
                    }
                    catch
                    {

                    }

                    int x = Utilities.ExecuteNonQuery(command);
                    if (x > 0)
                    {
                        this.Id = long.Parse(Utilities.ExecuteScalar("select Id from LoanRequest where ReferenceNumber='" + this.ReferenceNumber + "'"));
                        if (g > 0 && g!= this.LoanAmountRequested)
                        {
                            LoanAssesment lass = new LoanAssesment(this.Id);
                            lass.Update(this.LoanAmountRequested);
                        }
                    }
                    else
                        this.Id = x;
                }
            }
            catch
            {

            }

            return this.Id;
        }

        private void UpdateLoanRequestReferenceNumber(long index)
        {
            string refNo = Utilities.GenerateReferenceNumber("loanapplication", index);

            SqlCommand command = new SqlCommand("UPDATE LoanRequest SET ReferenceNumber = '" + refNo + "' WHERE Id = " + index.ToString());

            Utilities.ExecuteNonQuery(command);
        }
        
        public bool UpdateWorkFlowStatus()
        {
            int x = Utilities.ExecuteNonQuery("update LoanRequest set WorkFlowStatus='" + this.WorkFlowStatus + "',Status='" + this.WorkFlowStatus + "' where Id=" + this.Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public string ReferenceNumber { get; set; }
        public string BusinessRegistrationNumber { get; set; }
        public string BusinessName { get; set; }
        public int FK_BusinessTypeId { get; set; }
        public int FK_BusinessRegistrationTypeId { get; set; }
        public int FK_BusinessIslandLocationId { get; set; }
        public int FK_BusinessIslandDistrictId { get; set; }
        public string NIN { get; set; }
        public string FirstNames { get; set; }
        public string LastName { get; set; }
        public string Salutation { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public int Age { get; set; }
        public int FK_ResidenceIslandLocationId { get; set; }
        public int FK_ResidenceDistrictLocationId { get; set; }
        public string Mobile { get; set; }
        public string HomeTelephone { get; set; }
        public string WorkTelephone { get; set; }
        public string Email { get; set; }
        public int FK_LoansOfficerId { get; set; }
        public bool RequireWorkFlow { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public string DocumentType { get; set; }
        public long WorkFlowId { get; set; }
        public string WorkFlowStatus { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }

        public string SEnPARegistrationNo { get; set; }
        public int NoOfEmployees { get; set; }

        //Employment Info
        public bool Employed { get; set; }
        public string EmploymentDetails { get; set; }
        public string NameOfEmployer { get; set; }
        public long CurrentNoOfYears { get; set; }
        public string CurrentPosition { get; set; }
        public string PreviousEmployer { get; set; }
        public long PreviousNoOfYears { get; set; }
        public string PreviousPosition { get; set; }
        public string BackgroundExperience { get; set; }

        //Financial Details
        public float CostOfProject { get; set; }
        public float MonthlyIncome { get; set; }
        public float OtherIncome { get; set; }
        public float BusinessMonthlyIncome { get; set; }
        public float PersonalExpenditure { get; set; }
        public float BusinessExpenditureLoan { get; set; }
        public float BusinessExpenditureRent { get; set; }
        public float BusinessExpenditureUtilityBills { get; set; }
        public float BusinessExpenditureStaffSalaries { get; set; }
        public float BusinessExpenditureOther { get; set; }
        public float PersonalIncomeTotal { get; set; }
        public float PersonalExpenditureTotal { get; set; }
        public float BusinessIncomeTotal { get; set; }
        public float BusinessExpenditureTotal { get; set; }
        public string NameOfBank { get; set; }
        public string AccountNo { get; set; }
        public string TypeOfAccount { get; set; }
        public DateTime DateOfLastPayment { get; set; }
        public float LoanBalance { get; set; }

        //Loan Details
        public float LoanAmountRequested { get; set; }
        public string AnnualTurnoverRange { get; set; }
        public bool HasSecurity { get; set; }
        public string TypeOfSecurity { get; set; }
        public string PurposeOfLoan { get; set; }

        //Guarantor Details
        public string GuarantorNIN { get; set; }
        public string GuarantorName { get; set; }
        public string GuarantorSurname { get; set; }
        public DateTime GuarantorDOB { get; set; }
        public string GuarantorAddress { get; set; }
        public string GuarantorContactNo { get; set; }
        public string GuarantorMaritalStatus { get; set; }
        public string GuarantorNoOfDependents { get; set; }
        public string GuarantorEmploymentStatus { get; set; }
        public string GuarantorEmployersAddress { get; set; }
        public string GuarantorEmployersName { get; set; }
        public string GuarantorCurrentPosition { get; set; }
        public long GuarantorNoOfYears { get; set; }
        public float GuarantorTotalMonthlyIncome { get; set; }
        public float GuarantorTotalMonthlyExpenditure { get; set; }

    }

    public class BusinessRegistration
    {
        public BusinessRegistration() { }

        public BusinessRegistration(string nin)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BusinessRegistration where NIN='" + nin + "'");
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.RegistrationNumber = (reader.Reader["RegistrationNumber"].ToString());
                this.SEnPARegistrationNo = (reader.Reader["SEnPARegistrationNo"].ToString());
                this.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                this.BusinessName = (reader.Reader["BusinessName"].ToString());
                this.NoOfEmployees = int.Parse(reader.Reader["NoOfEmployees"].ToString());
                this.FK_BusinessTypeId = int.Parse(reader.Reader["FK_BusinessTypeId"].ToString());
                this.FK_BusinessRegistrationTypeId = int.Parse(reader.Reader["FK_BusinessRegistrationTypeId"].ToString());
                this.FK_BusinessIslandLocationId = int.Parse(reader.Reader["FK_BusinessIslandLocationId"].ToString());
                this.FK_BusinessIslandDistrictId = int.Parse(reader.Reader["FK_BusinessIslandDistrictId"].ToString());
                this.NIN = (reader.Reader["NIN"].ToString());
                this.FirstNames = (reader.Reader["FirstNames"].ToString());
                this.LastName = (reader.Reader["LastName"].ToString());
                this.Salutation = (reader.Reader["Salutation"].ToString());
                this.Citizenship = (reader.Reader["Citizenship"].ToString());
                this.Gender = (reader.Reader["Gender"].ToString());
                this.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                this.FK_ResidenceIslandLocationId = int.Parse(reader.Reader["FK_ResidenceIslandLocationId"].ToString());
                this.FK_ResidenceDistrictLocationId = int.Parse(reader.Reader["FK_ResidenceDistrictLocationId"].ToString());
                this.Mobile = (reader.Reader["Mobile"].ToString());
                this.HomeTelephone = (reader.Reader["HomeTelephone"].ToString());
                this.WorkTelephone = (reader.Reader["WorkTelephone"].ToString());
                this.Email = (reader.Reader["Email"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public BusinessRegistration(string Id, bool regNo = true)
        {
            //check if in new tables
            bool newAcc = true;

            if (newAcc)
            {
                Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BusinessRegistration where " + ((regNo) ? "RegistrationNumber='" + Id + "'" : "Id=" + Id));
                while (reader.Reader.Read())
                {
                    this.Id = long.Parse(reader.Reader["Id"].ToString());
                    this.RegistrationNumber = (reader.Reader["RegistrationNumber"].ToString());
                    this.SEnPARegistrationNo = (reader.Reader["SEnPARegistrationNo"].ToString());
                    this.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                    this.BusinessName = (reader.Reader["BusinessName"].ToString());
                    this.NoOfEmployees = int.Parse(reader.Reader["NoOfEmployees"].ToString());
                    this.FK_BusinessTypeId = int.Parse(reader.Reader["FK_BusinessTypeId"].ToString());
                    this.FK_BusinessRegistrationTypeId = int.Parse(reader.Reader["FK_BusinessRegistrationTypeId"].ToString());
                    this.FK_BusinessIslandLocationId = int.Parse(reader.Reader["FK_BusinessIslandLocationId"].ToString());
                    this.FK_BusinessIslandDistrictId = int.Parse(reader.Reader["FK_BusinessIslandDistrictId"].ToString());
                    this.NIN = (reader.Reader["NIN"].ToString());
                    this.FirstNames = (reader.Reader["FirstNames"].ToString());
                    this.LastName = (reader.Reader["LastName"].ToString());
                    this.Salutation = (reader.Reader["Salutation"].ToString());
                    this.Citizenship = (reader.Reader["Citizenship"].ToString());
                    this.Gender = (reader.Reader["Gender"].ToString());
                    this.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                    this.FK_ResidenceIslandLocationId = int.Parse(reader.Reader["FK_ResidenceIslandLocationId"].ToString());
                    this.FK_ResidenceDistrictLocationId = int.Parse(reader.Reader["FK_ResidenceDistrictLocationId"].ToString());
                    this.Mobile = (reader.Reader["Mobile"].ToString());
                    this.HomeTelephone = (reader.Reader["HomeTelephone"].ToString());
                    this.WorkTelephone = (reader.Reader["WorkTelephone"].ToString());
                    this.Email = (reader.Reader["Email"].ToString());
                    this.Status = (reader.Reader["Status"].ToString());
                    this.StatusReason = (reader.Reader["StatusReason"].ToString());
                    this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                    this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                    this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                    this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                    this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                }
                reader.Close();
            }
            else
            {

            }
        }

        public BusinessRegistration(long Id, bool regNo = true)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BusinessRegistration where " + ((regNo) ? "RegistrationNumber='" + Id + "'" : "Id=" + Id));
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.RegistrationNumber = (reader.Reader["RegistrationNumber"].ToString());
                this.SEnPARegistrationNo = (reader.Reader["SEnPARegistrationNo"].ToString());
                this.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                this.BusinessName = (reader.Reader["BusinessName"].ToString());
                this.NoOfEmployees = int.Parse(reader.Reader["NoOfEmployees"].ToString());
                this.FK_BusinessTypeId = int.Parse(reader.Reader["FK_BusinessTypeId"].ToString());
                this.FK_BusinessRegistrationTypeId = int.Parse(reader.Reader["FK_BusinessRegistrationTypeId"].ToString());
                this.FK_BusinessIslandLocationId = int.Parse(reader.Reader["FK_BusinessIslandLocationId"].ToString());
                this.FK_BusinessIslandDistrictId = int.Parse(reader.Reader["FK_BusinessIslandDistrictId"].ToString());
                this.NIN = (reader.Reader["NIN"].ToString());
                this.FirstNames = (reader.Reader["FirstNames"].ToString());
                this.LastName = (reader.Reader["LastName"].ToString());
                this.Salutation = (reader.Reader["Salutation"].ToString());
                this.Citizenship = (reader.Reader["Citizenship"].ToString());
                this.Gender = (reader.Reader["Gender"].ToString());
                this.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                this.FK_ResidenceIslandLocationId = int.Parse(reader.Reader["FK_ResidenceIslandLocationId"].ToString());
                this.FK_ResidenceDistrictLocationId = int.Parse(reader.Reader["FK_ResidenceDistrictLocationId"].ToString());
                this.Mobile = (reader.Reader["Mobile"].ToString());
                this.HomeTelephone = (reader.Reader["HomeTelephone"].ToString());
                this.WorkTelephone = (reader.Reader["WorkTelephone"].ToString());
                this.Email = (reader.Reader["Email"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public BusinessRegistration(string account, string loan)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from oldRecovery where LoanNo='" + loan + "' and AccounNo='"+account+"'");
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["FK_LOANREQUESTID"].ToString());
                this.RegistrationNumber = (reader.Reader["AccounNo"].ToString());
                this.SEnPARegistrationNo = "";
                this.BusinessRegistrationNumber = "";
                this.BusinessName = "";
                this.NoOfEmployees = 0;
                this.FK_BusinessTypeId = 0;
                this.FK_BusinessRegistrationTypeId = 0;
                this.FK_BusinessIslandLocationId = 1;
                this.FK_BusinessIslandDistrictId = 0;
                this.NIN = (reader.Reader["NIN"].ToString());
                this.FirstNames = (reader.Reader["FirstName"].ToString());
                this.LastName = (reader.Reader["Surname"].ToString());
                this.Salutation = "";
                this.Citizenship = "";
                this.Gender = "";
                this.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                this.FK_ResidenceIslandLocationId = 1;
                this.FK_ResidenceDistrictLocationId = 1;
                this.Mobile = "";
                this.HomeTelephone = "";
                this.WorkTelephone = "";
                this.Email = "";
                this.Status = "";
                this.StatusReason = "";
                this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LOANREQUESTID"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = "";
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = "";

            }
            reader.Close();
        }

        public BusinessRegistration(string account, int old)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top 1 * from oldRecovery where AccounNo='" + account + "'");
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["FK_LOANREQUESTID"].ToString());
                this.RegistrationNumber = (reader.Reader["AccounNo"].ToString());
                this.SEnPARegistrationNo = "";
                this.BusinessRegistrationNumber = "";
                this.BusinessName = "";
                this.NoOfEmployees = 0;
                this.FK_BusinessTypeId = 0;
                this.FK_BusinessRegistrationTypeId = 0;
                this.FK_BusinessIslandLocationId = 1;
                this.FK_BusinessIslandDistrictId = 0;
                this.NIN = (reader.Reader["NIN"].ToString());
                this.FirstNames = (reader.Reader["FirstName"].ToString());
                this.LastName = (reader.Reader["Surname"].ToString());
                this.Salutation = "";
                this.Citizenship = "";
                this.Gender = "";
                this.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                this.FK_ResidenceIslandLocationId = 1;
                this.FK_ResidenceDistrictLocationId = 1;
                this.Mobile = "";
                this.HomeTelephone = "";
                this.WorkTelephone = "";
                this.Email = "";
                this.Status = "";
                this.StatusReason = "";
                this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LOANREQUESTID"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = "";
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = "";

            }
            reader.Close();
        }

        public long Save()
        {
            int c = int.Parse(Utilities.ExecuteScalar("select count(Id) from BusinessRegistration where RegistrationNumber='" + this.RegistrationNumber + "'"));

            SqlCommand command;

            if (c < 1)
                command = new SqlCommand("insert into BusinessRegistration(RegistrationNumber,SEnPARegistrationNo,BusinessRegistrationNumber,BusinessName,NoOfEmployees,FK_BusinessTypeId,FK_BusinessRegistrationTypeId,FK_BusinessIslandLocationId,FK_BusinessIslandDistrictId,NIN,FirstNames,LastName,Salutation,Citizenship,Gender,DOB,FK_ResidenceIslandLocationId,FK_ResidenceDistrictLocationId,Mobile,HomeTelephone,WorkTelephone,Email,Status,StatusReason,FK_LoanRequestId,Created,CreatedBy,LastModified,LastModifiedBy) values(@RegistrationNumber,@SEnPARegistrationNo,@BusinessRegistrationNumber,@BusinessName,@NoOfEmployees,@FK_BusinessTypeId,@FK_BusinessRegistrationTypeId,@FK_BusinessIslandLocationId,@FK_BusinessIslandDistrictId,@NIN,@FirstNames,@LastName,@Salutation,@Citizenship,@Gender,@DOB,@FK_ResidenceIslandLocationId,@FK_ResidenceDistrictLocationId,@Mobile,@HomeTelephone,@WorkTelephone,@Email,@Status,@StatusReason,@FK_LoanRequestId,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");
            else
                command = new SqlCommand("update BusinessRegistration set FK_BusinessIslandLocationId=@FK_BusinessIslandLocationId,FK_BusinessIslandDistrictId=@FK_BusinessIslandDistrictId,FirstNames=@FirstNames,LastName=@LastName,Salutation=@Salutation,FK_ResidenceIslandLocationId=@FK_ResidenceIslandLocationId,FK_ResidenceDistrictLocationId=@FK_ResidenceDistrictLocationId,Mobile=@Mobile,HomeTelephone=@HomeTelephone,WorkTelephone=@WorkTelephone,Email=@Email,LastModified=CURRENT_TIMESTAMP,LastModifiedBy=@LastModifiedBy where RegistrationNumber=@RegistrationNumber");

            command.Parameters.Add(new SqlParameter("@RegistrationNumber", this.RegistrationNumber));
            command.Parameters.Add(new SqlParameter("@SEnPARegistrationNo", this.SEnPARegistrationNo));
            command.Parameters.Add(new SqlParameter("@BusinessRegistrationNumber", this.BusinessRegistrationNumber));
            command.Parameters.Add(new SqlParameter("@BusinessName", this.BusinessName));
            command.Parameters.Add(new SqlParameter("@NoOfEmployees", this.NoOfEmployees));
            command.Parameters.Add(new SqlParameter("@FK_BusinessTypeId", this.FK_BusinessTypeId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessRegistrationTypeId", this.FK_BusinessRegistrationTypeId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessIslandLocationId", this.FK_BusinessIslandLocationId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessIslandDistrictId", this.FK_BusinessIslandDistrictId));
            command.Parameters.Add(new SqlParameter("@NIN", this.NIN));
            command.Parameters.Add(new SqlParameter("@FirstNames", this.FirstNames));
            command.Parameters.Add(new SqlParameter("@LastName", this.LastName));
            command.Parameters.Add(new SqlParameter("@Salutation", this.Salutation));
            command.Parameters.Add(new SqlParameter("@Citizenship", this.Citizenship));
            command.Parameters.Add(new SqlParameter("@Gender", this.Gender));
            command.Parameters.Add(new SqlParameter("@DOB", this.DOB));
            command.Parameters.Add(new SqlParameter("@FK_ResidenceIslandLocationId", this.FK_ResidenceIslandLocationId));
            command.Parameters.Add(new SqlParameter("@FK_ResidenceDistrictLocationId", this.FK_ResidenceDistrictLocationId));
            command.Parameters.Add(new SqlParameter("@Mobile", this.Mobile));
            command.Parameters.Add(new SqlParameter("@HomeTelephone", this.HomeTelephone));
            command.Parameters.Add(new SqlParameter("@WorkTelephone", this.WorkTelephone));
            command.Parameters.Add(new SqlParameter("@Email", this.Email));
            command.Parameters.Add(new SqlParameter("@Status", this.Status));
            command.Parameters.Add(new SqlParameter("@StatusReason", this.StatusReason));
            command.Parameters.Add(new SqlParameter("@FK_LoanRequestId", this.FK_LoanRequestId));
            command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));

            if (c < 1)
            {
                this.Id = Utilities.ExecuteNewRecord(command);
            }
            else
            {
                int x = Utilities.ExecuteNonQuery(command);
                if (x > 0)
                    this.Id = long.Parse(Utilities.ExecuteScalar("select Id from BusinessRegistration where RegistrationNumber='" + this.RegistrationNumber + "'"));
                else
                    this.Id = x;
            }

            return this.Id;
        }

        public long Id { get; set; }
        public string RegistrationNumber { get; set; }
        public string BusinessRegistrationNumber { get; set; }
        public string BusinessName { get; set; }
        public int FK_BusinessTypeId { get; set; }
        public int FK_BusinessRegistrationTypeId { get; set; }
        public int FK_BusinessIslandLocationId { get; set; }
        public int FK_BusinessIslandDistrictId { get; set; }
        public string NIN { get; set; }
        public string FirstNames { get; set; }
        public string LastName { get; set; }
        public string Salutation { get; set; }
        public string Citizenship { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public int FK_ResidenceIslandLocationId { get; set; }
        public int FK_ResidenceDistrictLocationId { get; set; }
        public string Mobile { get; set; }
        public string HomeTelephone { get; set; }
        public string WorkTelephone { get; set; }
        public string Email { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public long FK_LoanRequestId { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }

        public string SEnPARegistrationNo { get; set; }
        public int NoOfEmployees { get; set; }
    }

    public class Guarantor
    {        
        public Guarantor() { }

        public Guarantor(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Guarantor where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());                
                this.FK_BusinessRegistrationId = int.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
               
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());                

                //Guarantor details
                this.GuarantorNIN = reader.Reader["GuarantorNIN"].ToString();
                this.GuarantorName = reader.Reader["GuarantorName"].ToString();
                this.GuarantorSurname = reader.Reader["GuarantorSurname"].ToString();
                this.GuarantorDOB = DateTime.Parse(reader.Reader["GuarantorDOB"].ToString());
                this.GuarantorAddress = reader.Reader["GuarantorAddress"].ToString();
                this.GuarantorContactNo = reader.Reader["GuarantorContactNo"].ToString();
                this.GuarantorMaritalStatus = reader.Reader["GuarantorMaritalStatus"].ToString();
                this.GuarantorNoOfDependents = reader.Reader["GuarantorNoOfDependents"].ToString();
                this.GuarantorEmploymentStatus = reader.Reader["GuarantorEmploymentStatus"].ToString();
                this.GuarantorEmployersAddress = reader.Reader["GuarantorEmployersAddress"].ToString();
                this.GuarantorEmployersName = reader.Reader["GuarantorEmployersName"].ToString();
                this.GuarantorCurrentPosition = reader.Reader["GuarantorCurrentPosition"].ToString();
                this.GuarantorNoOfYears = long.Parse(reader.Reader["GuarantorNoOfYears"].ToString());
                this.GuarantorTotalMonthlyIncome = float.Parse(reader.Reader["GuarantorTotalMonthlyIncome"].ToString());
                this.GuarantorTotalMonthlyExpenditure = float.Parse(reader.Reader["GuarantorTotalMonthlyExpenditure"].ToString());
            }
            reader.Close();
        }

        public Guarantor(string guarantorNIN)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Guarantor where GuarantorNIN='" + guarantorNIN+"'");
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_BusinessRegistrationId = int.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());

                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                //Guarantor details
                this.GuarantorNIN = reader.Reader["GuarantorNIN"].ToString();
                this.GuarantorName = reader.Reader["GuarantorName"].ToString();
                this.GuarantorSurname = reader.Reader["GuarantorSurname"].ToString();
                this.GuarantorDOB = DateTime.Parse(reader.Reader["GuarantorDOB"].ToString());
                this.GuarantorAddress = reader.Reader["GuarantorAddress"].ToString();
                this.GuarantorContactNo = reader.Reader["GuarantorContactNo"].ToString();
                this.GuarantorMaritalStatus = reader.Reader["GuarantorMaritalStatus"].ToString();
                this.GuarantorNoOfDependents = reader.Reader["GuarantorNoOfDependents"].ToString();
                this.GuarantorEmploymentStatus = reader.Reader["GuarantorEmploymentStatus"].ToString();
                this.GuarantorEmployersAddress = reader.Reader["GuarantorEmployersAddress"].ToString();
                this.GuarantorEmployersName = reader.Reader["GuarantorEmployersName"].ToString();
                this.GuarantorCurrentPosition = reader.Reader["GuarantorCurrentPosition"].ToString();
                this.GuarantorNoOfYears = long.Parse(reader.Reader["GuarantorNoOfYears"].ToString());
                this.GuarantorTotalMonthlyIncome = float.Parse(reader.Reader["GuarantorTotalMonthlyIncome"].ToString());
                this.GuarantorTotalMonthlyExpenditure = float.Parse(reader.Reader["GuarantorTotalMonthlyExpenditure"].ToString());
            }
            reader.Close();
        }

        public Guarantor(string guarantorNIN,long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from LoanRequestGuarantor where FK_LoanRequestId=" + id+" and GuarantorNIN=" + guarantorNIN);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_BusinessRegistrationId = int.Parse(reader.Reader["FK_LoanRequestId"].ToString());

                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                //Guarantor details
                this.GuarantorNIN = reader.Reader["GuarantorNIN"].ToString();
                this.GuarantorName = reader.Reader["GuarantorName"].ToString();
                this.GuarantorSurname = reader.Reader["GuarantorSurname"].ToString();
                this.GuarantorDOB = DateTime.Parse(reader.Reader["GuarantorDOB"].ToString());
                this.GuarantorAddress = reader.Reader["GuarantorAddress"].ToString();
                this.GuarantorContactNo = reader.Reader["GuarantorContactNo"].ToString();
                this.GuarantorMaritalStatus = reader.Reader["GuarantorMaritalStatus"].ToString();
                this.GuarantorNoOfDependents = reader.Reader["GuarantorNoOfDependents"].ToString();
                this.GuarantorEmploymentStatus = reader.Reader["GuarantorEmploymentStatus"].ToString();
                this.GuarantorEmployersAddress = reader.Reader["GuarantorEmployersAddress"].ToString();
                this.GuarantorEmployersName = reader.Reader["GuarantorEmployersName"].ToString();
                this.GuarantorCurrentPosition = reader.Reader["GuarantorCurrentPosition"].ToString();
                this.GuarantorNoOfYears = long.Parse(reader.Reader["GuarantorNoOfYears"].ToString());
                this.GuarantorTotalMonthlyIncome = float.Parse(reader.Reader["GuarantorTotalMonthlyIncome"].ToString());
                this.GuarantorTotalMonthlyExpenditure = float.Parse(reader.Reader["GuarantorTotalMonthlyExpenditure"].ToString());
            }
            reader.Close();
        }


        public long Save()
        {          
            try
            {
                int c = int.Parse(Utilities.ExecuteScalar("select count(Id) from Guarantor where GuarantorNIN='" + this.GuarantorNIN + "'"));

                SqlCommand command;

                if (c < 1)
                    command = new SqlCommand("insert into Guarantor(FK_BusinessRegistrationId,GuarantorNIN,GuarantorName,GuarantorSurname,GuarantorDOB,GuarantorAddress,GuarantorContactNo,GuarantorMaritalStatus,GuarantorNoOfDependents,GuarantorEmploymentStatus,GuarantorEmployersAddress,GuarantorEmployersName,GuarantorCurrentPosition,GuarantorNoOfYears,GuarantorTotalMonthlyIncome,GuarantorTotalMonthlyExpenditure,Created,CreatedBy,LastModified,LastModifiedBy) values(@FK_BusinessRegistrationId,@GuarantorNIN,@GuarantorName,@GuarantorSurname,@GuarantorDOB,@GuarantorAddress,@GuarantorContactNo,@GuarantorMaritalStatus,@GuarantorNoOfDependents,@GuarantorEmploymentStatus,@GuarantorEmployersAddress,@GuarantorEmployersName,@GuarantorCurrentPosition,@GuarantorNoOfYears,@GuarantorTotalMonthlyIncome,@GuarantorTotalMonthlyExpenditure,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");
                else
                    command = new SqlCommand("update Guarantor set GuarantorName=@GuarantorName,GuarantorSurname=@GuarantorSurname,GuarantorDOB=@GuarantorDOB,GuarantorAddress=@GuarantorAddress,GuarantorContactNo=@GuarantorContactNo,GuarantorMaritalStatus=@GuarantorMaritalStatus,GuarantorNoOfDependents=@GuarantorNoOfDependents,GuarantorEmploymentStatus=@GuarantorEmploymentStatus,GuarantorEmployersAddress=@GuarantorEmployersAddress,GuarantorEmployersName=@GuarantorEmployersName,GuarantorCurrentPosition=@GuarantorCurrentPosition,GuarantorNoOfYears=@GuarantorNoOfYears,GuarantorTotalMonthlyIncome=@GuarantorTotalMonthlyIncome,GuarantorTotalMonthlyExpenditure=@GuarantorTotalMonthlyExpenditure where GuarantorNIN=@GuarantorNIN");

                command.Parameters.Add(new SqlParameter("@FK_BusinessRegistrationId", this.FK_BusinessRegistrationId));
                command.Parameters.Add(new SqlParameter("@GuarantorNIN", this.GuarantorNIN));
                command.Parameters.Add(new SqlParameter("@GuarantorName", this.GuarantorName));
                command.Parameters.Add(new SqlParameter("@GuarantorSurname", this.GuarantorSurname));
                command.Parameters.Add(new SqlParameter("@GuarantorDOB", this.GuarantorDOB));
                command.Parameters.Add(new SqlParameter("@GuarantorAddress", this.GuarantorAddress));
                command.Parameters.Add(new SqlParameter("@GuarantorContactNo", this.GuarantorContactNo));
                command.Parameters.Add(new SqlParameter("@GuarantorMaritalStatus", this.GuarantorMaritalStatus));
                command.Parameters.Add(new SqlParameter("@GuarantorNoOfDependents", this.GuarantorNoOfDependents));
                command.Parameters.Add(new SqlParameter("@GuarantorEmploymentStatus", this.GuarantorEmploymentStatus));
                command.Parameters.Add(new SqlParameter("@GuarantorEmployersAddress", this.GuarantorEmployersAddress));
                command.Parameters.Add(new SqlParameter("@GuarantorEmployersName", this.GuarantorEmployersName));
                command.Parameters.Add(new SqlParameter("@GuarantorCurrentPosition", this.GuarantorCurrentPosition));
                command.Parameters.Add(new SqlParameter("@GuarantorNoOfYears", this.GuarantorNoOfYears));
                command.Parameters.Add(new SqlParameter("@GuarantorTotalMonthlyIncome", this.GuarantorTotalMonthlyIncome));
                command.Parameters.Add(new SqlParameter("@GuarantorTotalMonthlyExpenditure", this.GuarantorTotalMonthlyExpenditure));
                command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
                command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));

                if (c < 1)
                {
                    this.Id = Utilities.ExecuteNewRecord(command);
                }
                else
                {
                    int x = Utilities.ExecuteNonQuery(command);
                    if (x > 0)
                        this.Id = long.Parse(Utilities.ExecuteScalar("select Id from Guarantor where GuarantorNIN='" + this.GuarantorNIN + "'"));
                    else
                        this.Id = x;
                }
            }
            catch
            {

            }

            return this.Id;
        }

        public long SaveRequest()
        {
            try
            {
                int c = int.Parse(Utilities.ExecuteScalar("select count(Id) from LoanRequestGuarantor where FK_LoanRequestId="+this.FK_BusinessRegistrationId+" and GuarantorNIN='" + this.GuarantorNIN + "'"));

                SqlCommand command;

                if (c < 1)
                    command = new SqlCommand("insert into LoanRequestGuarantor(FK_LoanRequestId,GuarantorNIN,GuarantorName,GuarantorSurname,GuarantorDOB,GuarantorAddress,GuarantorContactNo,GuarantorMaritalStatus,GuarantorNoOfDependents,GuarantorEmploymentStatus,GuarantorEmployersAddress,GuarantorEmployersName,GuarantorCurrentPosition,GuarantorNoOfYears,GuarantorTotalMonthlyIncome,GuarantorTotalMonthlyExpenditure,Created,CreatedBy,LastModified,LastModifiedBy) values(@FK_BusinessRegistrationId,@GuarantorNIN,@GuarantorName,@GuarantorSurname,@GuarantorDOB,@GuarantorAddress,@GuarantorContactNo,@GuarantorMaritalStatus,@GuarantorNoOfDependents,@GuarantorEmploymentStatus,@GuarantorEmployersAddress,@GuarantorEmployersName,@GuarantorCurrentPosition,@GuarantorNoOfYears,@GuarantorTotalMonthlyIncome,@GuarantorTotalMonthlyExpenditure,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");
                else
                    command = new SqlCommand("update LoanRequestGuarantor set GuarantorName=@GuarantorName,GuarantorSurname=@GuarantorSurname,GuarantorDOB=@GuarantorDOB,GuarantorAddress=@GuarantorAddress,GuarantorContactNo=@GuarantorContactNo,GuarantorMaritalStatus=@GuarantorMaritalStatus,GuarantorNoOfDependents=@GuarantorNoOfDependents,GuarantorEmploymentStatus=@GuarantorEmploymentStatus,GuarantorEmployersAddress=@GuarantorEmployersAddress,GuarantorEmployersName=@GuarantorEmployersName,GuarantorCurrentPosition=@GuarantorCurrentPosition,GuarantorNoOfYears=@GuarantorNoOfYears,GuarantorTotalMonthlyIncome=@GuarantorTotalMonthlyIncome,GuarantorTotalMonthlyExpenditure=@GuarantorTotalMonthlyExpenditure where GuarantorNIN=@GuarantorNIN");

                command.Parameters.Add(new SqlParameter("@FK_BusinessRegistrationId", this.FK_BusinessRegistrationId));
                command.Parameters.Add(new SqlParameter("@GuarantorNIN", this.GuarantorNIN));
                command.Parameters.Add(new SqlParameter("@GuarantorName", this.GuarantorName));
                command.Parameters.Add(new SqlParameter("@GuarantorSurname", this.GuarantorSurname));
                command.Parameters.Add(new SqlParameter("@GuarantorDOB", this.GuarantorDOB));
                command.Parameters.Add(new SqlParameter("@GuarantorAddress", this.GuarantorAddress));
                command.Parameters.Add(new SqlParameter("@GuarantorContactNo", this.GuarantorContactNo));
                command.Parameters.Add(new SqlParameter("@GuarantorMaritalStatus", this.GuarantorMaritalStatus));
                command.Parameters.Add(new SqlParameter("@GuarantorNoOfDependents", this.GuarantorNoOfDependents));
                command.Parameters.Add(new SqlParameter("@GuarantorEmploymentStatus", this.GuarantorEmploymentStatus));
                command.Parameters.Add(new SqlParameter("@GuarantorEmployersAddress", this.GuarantorEmployersAddress));
                command.Parameters.Add(new SqlParameter("@GuarantorEmployersName", this.GuarantorEmployersName));
                command.Parameters.Add(new SqlParameter("@GuarantorCurrentPosition", this.GuarantorCurrentPosition));
                command.Parameters.Add(new SqlParameter("@GuarantorNoOfYears", this.GuarantorNoOfYears));
                command.Parameters.Add(new SqlParameter("@GuarantorTotalMonthlyIncome", this.GuarantorTotalMonthlyIncome));
                command.Parameters.Add(new SqlParameter("@GuarantorTotalMonthlyExpenditure", this.GuarantorTotalMonthlyExpenditure));
                command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
                command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));

                if (c < 1)
                {
                    this.Id = Utilities.ExecuteNewRecord(command);
                }
                else
                {
                    int x = Utilities.ExecuteNonQuery(command);
                    if (x > 0)
                        this.Id = long.Parse(Utilities.ExecuteScalar("select Id from LoanRequestGuarantor where FK_LoanRequestId=" + this.FK_BusinessRegistrationId+" and GuarantorNIN='" + this.GuarantorNIN + "'"));
                    else
                        this.Id = x;
                }
            }
            catch
            {

            }

            return this.Id;
        }

        public long Id { get; set; }
        public long FK_BusinessRegistrationId { get; set; }
        public string GuarantorNIN { get; set; }
        public string GuarantorName { get; set; }
        public string GuarantorSurname { get; set; }
        public DateTime GuarantorDOB { get; set; }
        public string GuarantorAddress { get; set; }
        public string GuarantorContactNo { get; set; }
        public string GuarantorMaritalStatus { get; set; }
        public string GuarantorNoOfDependents { get; set; }
        public string GuarantorEmploymentStatus { get; set; }
        public string GuarantorEmployersAddress { get; set; }
        public string GuarantorEmployersName { get; set; }
        public string GuarantorCurrentPosition { get; set; }
        public long GuarantorNoOfYears { get; set; }
        public float GuarantorTotalMonthlyIncome { get; set; }
        public float GuarantorTotalMonthlyExpenditure { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class AutoDocument
    {
        public AutoDocument() { }
        public long Id { get; set; }
        public string DocumentType { get; set; }
        public string DocumentTypeName { get; set; }
    }

    public class LoanRequestApproval
    {
        public LoanRequestApproval() { }

        public LoanRequestApproval(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from LoanRequestApproval where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.DocumentType = (reader.Reader["DocumentType"].ToString());
                this.RequireWorkFlow = bool.Parse(reader.Reader["RequireWorkFlow"].ToString());
                this.WorkFlowId = long.Parse(reader.Reader["WorkFlowId"].ToString());
                this.WorkFlowStatus = (reader.Reader["WorkFlowStatus"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public bool Save()
        {
            this.DocumentType = "loaapp";
            this.RequireWorkFlow = true;
            this.WorkFlowStatus = "";

            SqlCommand command = new SqlCommand("insert into LoanRequestApproval(Id,Status,StatusReason,DocumentType,RequireWorkFlow,WorkFlowId,WorkFlowStatus,Created,CreatedBy,LastModified,LastModifiedBy) values(@Id,@Status,@StatusReason,@DocumentType,@RequireWorkFlow,@WorkFlowId,@WorkFlowStatus,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");

            command.Parameters.Add(new SqlParameter("@Id", this.Id));
            command.Parameters.Add(new SqlParameter("@Status", this.Status));
            command.Parameters.Add(new SqlParameter("@StatusReason", this.StatusReason));
            command.Parameters.Add(new SqlParameter("@DocumentType", this.DocumentType));
            command.Parameters.Add(new SqlParameter("@RequireWorkFlow", this.RequireWorkFlow));
            command.Parameters.Add(new SqlParameter("@WorkFlowId", this.WorkFlowId));
            command.Parameters.Add(new SqlParameter("@WorkFlowStatus", this.WorkFlowStatus));
            command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));

            int x = Utilities.ExecuteNonQuery(command);
            if (x > 0)
            {
                if (this.RequireWorkFlow)
                {
                    //submit to workflow
                    DocumentWorkflow wrkDoc = Utilities.SubmitWorkFlowDocument(this.WorkFlowId, this.Id.ToString(), this.DocumentType);
                    this.WorkFlowStatus = wrkDoc.WorkFlowStatus;
                    UpdateWorkFlowStatus();
                }
            }
            else
            {

            }

            return ((x > 0) ? true : false);
        }

        public bool UpdateWorkFlowStatus()
        {
            int x = Utilities.ExecuteNonQuery("update LoanRequestApproval set WorkFlowStatus='" + this.WorkFlowStatus + "',Status='" + this.WorkFlowStatus + "' where Id=" + this.Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public bool RequireWorkFlow { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public string DocumentType { get; set; }
        public long WorkFlowId { get; set; }
        public string WorkFlowStatus { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class LoanApprovalCriteria
    {
        public LoanApprovalCriteria() { }

        public long Id { get; set; }
        public int FK_WorkFlowId { get; set; }
        public string ParameterField { get; set; }
        public string ParameterDataType { get; set; }
        public string ParameterFieldName { get; set; }
        public string ParameterValue { get; set; }
        public string ParameterMaxValue { get; set; }
        public string ParameterEvaluationType { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
    
    public class QuickStats
    {
        public QuickStats()
        {
            this.RegisteredBusinessCount = long.Parse(Utilities.ExecuteScalar("select count(Id) from BusinessRegistration"));
            this.LoanCount = long.Parse(Utilities.ExecuteScalar("select count(Id) from Loan"));
            this.PendingLoanCount = long.Parse(Utilities.ExecuteScalar("select count(Id) from LoanRequest where Status<>'Complete'"));
            this.PendingSiteVisitsCount = long.Parse(Utilities.ExecuteScalar("select count(Id) from SiteVisit where VisitDate >CURRENT_TIMESTAMP"));
        }

        public long RegisteredBusinessCount { get; set; }
        public long LoanCount { get; set; }
        public long PendingLoanCount { get; set; }
        public long PendingSiteVisitsCount { get; set; }
    }

    public class Notifications
    {
        public Notifications() { }

        public Notifications(string fK_Username, string title, string documentType, long fK_DocumentId)
        {
            this.FK_Username = fK_Username;
            this.Title = title;
            this.DocumentType = documentType;
            this.FK_DocumentId = fK_DocumentId;
            this.Status = false;
            Save();
        }

        public bool Save()
        {
            long x = (Utilities.ExecuteNewRecord("insert into Notifications(FK_Username,Title,DocumentType,FK_DocumentId,Status,Created,CreatedBy,LastModified,LastModifiedBy) values('" + this.FK_Username + "','" + this.Title + "','" + this.DocumentType + "'," + this.FK_DocumentId + ",'" + ((this.Status) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')"));
            return ((x > 0) ? true : false);
        }

        public static bool Update(long id, bool status)
        {
            long x = (Utilities.ExecuteNewRecord("update Notifications set Status='" + ((status) ? "True" : "False") + "' where Id=" + id));
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public string FK_Username { get; set; }
        public string Title { get; set; }
        public string DocumentType { get; set; }
        public long FK_DocumentId { get; set; }
        public bool Status { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

}