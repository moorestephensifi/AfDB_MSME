﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SBFA
{
    public partial class Utilities
    {
        public static DocumentWorkflow SubmitWorkFlowDocument(long workFlowId, string documentId, string documentType)
        {
            DocumentWorkflow newDocument = new DocumentWorkflow(workFlowId, documentId, documentType);
            newDocument.SaveDocument();           
            return newDocument;
        }

        public static DocumentWorkflow SkipWorkFlowStage(long workFlowId, string documentId, string documentType)
        {
            DocumentWorkflow newDocument = new DocumentWorkflow(workFlowId, documentId, documentType);
            newDocument.SkipStage();
            return newDocument;
        }

        public static DocumentWorkflow TerminateWorkFlowStage(long workFlowId, string documentId, string documentType)
        {
            DocumentWorkflow newDocument = new DocumentWorkflow(workFlowId, documentId, documentType);
            newDocument.TerminateStage();
            return newDocument;
        }

        public static DocumentWorkflow ReverseWorkFlowStage(long workFlowId, string documentId, string documentType)
        {
            DocumentWorkflow newDocument = new DocumentWorkflow(workFlowId, documentId, documentType);
            newDocument.ReverseStage();
            return newDocument;
        }

        public static List<ApplicationUserSummary> GetAssigningUserList(long Id, string entityType)
        {
            List<ApplicationUserSummary> response = new List<ApplicationUserSummary>();
            long roleGroupId = 0;
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            roleGroupId = wrkDoc.FK_CurrentRoleGroupId;

            //retrieve user details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Username,FirstName,Surname,EmailAddress,MobileNumber from ApplicationUsers where Username in (select Username from ApplicationRoleGroupAssignedRoles where FK_RoleGroupId=" + roleGroupId + ")");
            while (reader.Reader.Read())
            {
                ApplicationUserSummary user = new ApplicationUserSummary();
                user.Id = int.Parse(reader.Reader["Id"].ToString());
                user.Username = (reader.Reader["Username"].ToString());
                user.FirstName = (reader.Reader["FirstName"].ToString());
                user.Surname = (reader.Reader["Surname"].ToString());
                user.EmailAddress = (reader.Reader["EmailAddress"].ToString());
                user.MobileNumber = (reader.Reader["MobileNumber"].ToString());

                response.Add(user);
            }
            reader.Close();

            return response;
        }

        public static bool AssignWorkFlowStage(string username, long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return false;
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                return wrkDoc.AssignDocument(username);
            }
        }

        public static string GetNextWorkFlowStage(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return "Complete";
            else
                return Utilities.GetNextWorkFlowStage(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
        }

        public static string GetCurrentWorkFlowStage(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return "Complete";
            else
            {
                DocumentWorkflow newDocument = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                return newDocument.WorkFlowStatus;
            }

        }

        public static DocumentWorkflow UpdateWorkFlowStage(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            if (wrkIdentity.WorkFlowStatus != "Complete")
            {
                DocumentWorkflow wrkDoc = Utilities.SubmitWorkFlowDocument(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                int x = Utilities.ExecuteNonQuery("update " + Utilities.GetEntityTable(entityType) + " set WorkFlowStatus='" + wrkDoc.WorkFlowStatus + "',Status='" + wrkDoc.WorkFlowStatus + "' where Id=" + Id);
                return wrkDoc;
            }
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                return wrkDoc;
            }
        }

        public static DocumentWorkflow TerminateWorkFlowStage(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            if (wrkIdentity.WorkFlowStatus != "Complete")
            {
                DocumentWorkflow wrkDoc = Utilities.TerminateWorkFlowStage(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                int x = Utilities.ExecuteNonQuery("update " + Utilities.GetEntityTable(entityType) + " set WorkFlowStatus='" + wrkDoc.WorkFlowStatus + "',Status='" + wrkDoc.WorkFlowStatus + "' where Id=" + Id);
                return wrkDoc;
            }
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                return wrkDoc;
            }
        }

        public static string GetNextWorkFlowStage(long workFlowId, string documentId, string documentType)
        {
            DocumentWorkflow newDocument = new DocumentWorkflow(workFlowId, documentId, documentType);
            return newDocument.GetNextWorkFlowStage();
        }

        public static string CheckCurrentStageDocumentRequirements(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return "None";
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                if (wrkStage.RequireDocuments)
                {
                    return CheckCurrentStageDocumentRequirements(wrkStage.Id, wrkDoc.Id, Id);
                }
                else
                {
                    return "None";
                }
            }
        }

        public static string CheckCurrentStageDocumentRequirements(long stageId, long docWorkFlowId, long documentId)
        {
            string missingDocuments = "None";
            //get document list
            List<WorkFlowStageDocuments> wrkRequiredDocuments = GetDocumentsRequiredList(stageId);
            foreach (WorkFlowStageDocuments doc in wrkRequiredDocuments)
            {
                if (doc.DocumentRequired)
                {
                    int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from DocumentLibrary where FK_DocumentTypeId=" + doc.FK_DocumentTypeId + " and FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
                    if (x < 1)
                    {
                        if (missingDocuments == "None")
                            missingDocuments = Utilities.GetDocumentTypeName(doc.FK_DocumentTypeId);//get document type name
                        else
                            missingDocuments = missingDocuments + "," + Utilities.GetDocumentTypeName(doc.FK_DocumentTypeId);
                    }
                }
            }
            return missingDocuments;
        }

        public static string CheckCurrentStageSiteVisitRequirements(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return "None";
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                if (wrkStage.RequireSiteVisit)
                {
                    return CheckCurrentStageSiteVisitRequirements(wrkStage.Id, wrkDoc.Id, Id);
                }
                else
                {
                    return "None";
                }
            }
        }

        public static string CheckCurrentStageSiteVisitRequirements(long Id, string entityType, long recommendationId, int stakeholderId)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return "None";
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                if (wrkStage.RequireRecommendations)
                {
                    return CheckCurrentStageSiteVisitRequirements(wrkStage.Id, wrkDoc.Id, Id, recommendationId, stakeholderId);
                }
                else
                {
                    return "None";
                }
            }
        }

        public static string CheckCurrentStageSiteVisitRequirements(long stageId, long docWorkFlowId, long documentId, long recommendationId, int stakeholderId)
        {
            string pendingSiteVisit = "None";
            //get pending site visit update list
            long x = long.Parse(Utilities.ExecuteScalar("select count(Id) from SiteVisit where FK_RecommendationId=" + recommendationId + " and FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
            if (x < 1)
            {
                pendingSiteVisit = "No scheduled visit";
            }
            else
            {
                 x = long.Parse(Utilities.ExecuteScalar("select Id from SiteVisit where FK_RecommendationId=" + recommendationId + " and FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
                int y = int.Parse(Utilities.ExecuteScalar("select count(Id) from SiteVisitReport where FK_StakeholderId=" + stakeholderId + " and FK_SiteVisitId= " + x + " and UploadStatus= 'False'"));
                if (y > 0)
                    pendingSiteVisit = "Pending site visit report";
            }

            return pendingSiteVisit;
        }

        public static string CheckCurrentStageSiteVisitRequirements(long stageId, long docWorkFlowId, long documentId,int origin=1)
        {
            string pendingSiteVisit = "None";
            //get pending site visit update list
            long x = long.Parse(Utilities.ExecuteScalar("select count(Id) from SiteVisit where Origin=" + origin + " and FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
            if (x < 1)
            {
                pendingSiteVisit = "No scheduled visit";
            }
            else
            {
                 x = long.Parse(Utilities.ExecuteScalar("select Id from SiteVisit where Origin=" + origin + " and FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
                int y = int.Parse(Utilities.ExecuteScalar("select count(Id) from SiteVisitReport where FK_SiteVisitId= " + x + " and UploadStatus= 'False'"));
                if (y > 0)
                    pendingSiteVisit = "Pending site visit report(s)";
            }

            return pendingSiteVisit;
        }

        public static string CheckCurrentStageRecommendationsRequirements(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return "None";
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                if (wrkStage.RequireRecommendations)
                {
                    return CheckCurrentStageRecommendationsRequirements(wrkStage.Id, wrkDoc.Id, Id);
                }
                else
                {
                    return "None";
                }
            }
        }

        public static string CheckCurrentStageRecommendationsRequirements(long stageId, long docWorkFlowId, long documentId)
        {
            string pendingrecommendation = "None";
            //get pending site visit update list
            long x = long.Parse(Utilities.ExecuteScalar("select count(Id) from Recommendations where FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
            if (x < 1)
            {
                pendingrecommendation = "No Recommendation(s) Provided";
            }
            else
            {
                x = long.Parse(Utilities.ExecuteScalar("select Id from Recommendations where FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
                int y = int.Parse(Utilities.ExecuteScalar("select count(Id) from RecommendedAction where FK_RecommendationId= " + x + " and Status<> 'Complete' and Status<> 'None'"));
                if (y > 0)
                    pendingrecommendation = "Pending unresolved recommendations";
            }

            return pendingrecommendation;
        }

        public static bool CheckCurrentStagePaymentRequirements(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return false;
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                if (wrkStage.RequireDocuments)
                {
                    return CheckCurrentStagePaymentRequirements(wrkStage.Id, wrkDoc.Id, Id);
                }
                else
                {
                    return false;
                }
            }
        }

        public static bool CheckCurrentStagePaymentRequirements(long stageId, long docWorkFlowId, long documentId)
        {
            bool missingPayment = true;

            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from Invoice where (AmountPaid>=AmountTotal) and FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
            missingPayment = ((x < 1) ? true : false);

            return missingPayment;
        }

        public static List<WorkFlowStageDocuments> GetDocumentsRequiredList(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
            if (wrkStage.RequireDocuments)
            {
                //get document list
                List<WorkFlowStageDocuments> wrkRequiredDocuments = GetDocumentsRequiredList(wrkStage.Id);
                return wrkRequiredDocuments;
            }
            else
            {
                return null;
            }
        }

        public static List<WorkFlowStageDocuments> GetDocumentsRequiredList(long Id)
        {
            List<WorkFlowStageDocuments> response = new List<WorkFlowStageDocuments>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_StageId,FK_DocumentTypeId,DocumentRequired,Created,CreatedBy,LastModified,LastModifiedBy from WorkFlowStageDocuments where FK_StageId=" + Id);
            while (reader.Reader.Read())
            {
                WorkFlowStageDocuments doc = new WorkFlowStageDocuments();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.FK_StageId = long.Parse(reader.Reader["FK_StageId"].ToString());
                doc.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                doc.DocumentRequired = bool.Parse(reader.Reader["DocumentRequired"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();

            return response;
        }

        public static List<WorkFlowStageDocuments> GetAllDocumentsRequiredList(long workFlowId,long docWorkFlowId,long documentId)
        {
            List<WorkFlowStageDocuments> response = new List<WorkFlowStageDocuments>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_StageId,FK_DocumentTypeId,DocumentRequired,Created,CreatedBy,LastModified,LastModifiedBy from WorkFlowStageDocuments where FK_StageId in (select Id from WorkFlowStages where RequireDocuments='True' and FK_WorkFlowId=" + workFlowId + ")");
            while (reader.Reader.Read())
            {
                WorkFlowStageDocuments doc = new WorkFlowStageDocuments();
                doc.Id = GetDocumentId(documentId, docWorkFlowId, long.Parse(reader.Reader["FK_StageId"].ToString()), int.Parse(reader.Reader["FK_DocumentTypeId"].ToString()));
                if (doc.Id != 0)
                {
                    doc.FK_StageId = long.Parse(reader.Reader["FK_StageId"].ToString());
                    doc.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                    doc.DocumentRequired = bool.Parse(reader.Reader["DocumentRequired"].ToString());
                    doc.Created = DateTime.Now;
                    doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                    doc.LastModified = DateTime.Now;
                    doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                    response.Add(doc);
                }
            }
            reader.Close();

            return response;
        }

        private static long GetDocumentId(long fK_DocumentId, long fK_DocumentWorkFlowId, long fK_WorkFlowStageId, int documentTypeId)
        {
            //count first
            int x= int.Parse(Utilities.ExecuteScalar("select count(Id) from DocumentLibrary where FK_DocumentId=" + fK_DocumentId + " and FK_DocumentWorkFlowId=" + fK_DocumentWorkFlowId + " and FK_WorkFlowStageId=" + fK_WorkFlowStageId + " and FK_DocumentTypeId=" + documentTypeId));

            if (x > 0)
                return long.Parse(Utilities.ExecuteScalar("select Id from DocumentLibrary where FK_DocumentId=" + fK_DocumentId + " and FK_DocumentWorkFlowId=" + fK_DocumentWorkFlowId + " and FK_WorkFlowStageId=" + fK_WorkFlowStageId + " and FK_DocumentTypeId=" + documentTypeId));
            else
                return 0;
        }

        public static List<WorkFlowStageDocumentStatus> GetDocumentsRequiredStatus(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);

            List<WorkFlowStageDocumentStatus> response = new List<WorkFlowStageDocumentStatus>();
            //get document list
            List<WorkFlowStageDocuments> wrkRequiredDocuments = GetDocumentsRequiredList(wrkStage.Id);
            foreach (WorkFlowStageDocuments reqDoc in wrkRequiredDocuments)
            {
                WorkFlowStageDocumentStatus temp = new WorkFlowStageDocumentStatus();
                temp.DocumentRequired = reqDoc.DocumentRequired;
                temp.FK_DocumentTypeId = reqDoc.FK_DocumentTypeId;
                temp.FK_StageId = reqDoc.FK_StageId;
                temp.Id = reqDoc.Id;
                temp.DocumentType = Utilities.GetDocumentTypeName(reqDoc.FK_DocumentTypeId);// GetReferenceTableItem(reqDoc.FK_DocumentTypeId, "doctyp").Name;
                temp.Uploaded = CheckCurrentStageDocumentStatus(reqDoc.FK_DocumentTypeId, reqDoc.FK_StageId, wrkDoc.Id, long.Parse(wrkIdentity.DocumentId));

                response.Add(temp);
            }
            return response;
        }

        public static bool CheckCurrentStageDocumentStatus(int fK_DocumentTypeId, long stageId, long docWorkFlowId, long documentId)
        {
            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from DocumentLibrary where FK_DocumentTypeId=" + fK_DocumentTypeId + " and FK_DocumentId= " + documentId + " and FK_DocumentWorkFlowId= " + docWorkFlowId + " and FK_WorkFlowStageId=" + stageId));
            return ((x < 1) ? false : true);

        }

        public static long GetEntityWorkFlow(string entityId)
        {
            long response = 0;
            switch (entityId.ToLower())
            {
                case "loan":
                    response = 1;
                    break;
                default:
                    response = 1;
                    break;
            }
            return response;
        }

        public static WorkFlows GetWorkFlow(long Id)
        {
            WorkFlows wrkFlow = new WorkFlows(Id);
            return wrkFlow;
        }

        public static bool UpdateWorkFlow(WorkFlows wrkFlow)
        {
            return wrkFlow.Update();
        }

        public static long CreateWorkFlow(string workFlowName, string workFlowDescription, long startRoleGroupId, long endRoleGroupId)
        {
            WorkFlows wrkFlow = new WorkFlows(workFlowName, workFlowDescription, startRoleGroupId, endRoleGroupId);
            return wrkFlow.Save();
        }

        public static List<WorkFlows> GetWorkFlows()
        {
            List<WorkFlows> response = new List<WorkFlows>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlows");
            while (reader.Reader.Read())
            {
                WorkFlows wrk = new WorkFlows();
                wrk.Id = long.Parse(reader.Reader["Id"].ToString());
                wrk.FK_StartRoleGroupId = long.Parse(reader.Reader["FK_StartRoleGroupId"].ToString());
                wrk.WorkFlowName = (reader.Reader["WorkFlowName"].ToString());
                wrk.WorkFlowDescription = (reader.Reader["WorkFlowDescription"].ToString());
                wrk.FK_EndRoleGroupId = long.Parse(reader.Reader["FK_EndRoleGroupId"].ToString());
                wrk.Created = DateTime.Now;
                wrk.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                wrk.LastModified = DateTime.Now;
                wrk.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(wrk);
            }
            reader.Close();

            return response;
        }

        public static WorkFlowStages GetWorkFlowStage(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            if (wrkDoc.WorkFlowStatus == "Complete")
            {

                WorkFlowStages wrkStage = new WorkFlowStages();
                wrkStage.Id = 1000;
                wrkStage.FK_WorkFlowId = 1000;
                wrkStage.StagePosition = 1000;
                wrkStage.StageName = "Complete";
                wrkStage.StageDescription = "";
                wrkStage.FK_RoleGroupId = 0;
                wrkStage.StageAssignMode = 0;
                wrkStage.StageOptional = false;
                wrkStage.RequireDocuments = false;
                wrkStage.RequirePayment = false;
                wrkStage.RequireSiteVisit = false;
                wrkStage.RequireRecommendations = false;
                wrkStage.Created = DateTime.Now;
                wrkStage.CreatedBy = "System";
                wrkStage.LastModified = DateTime.Now;
                wrkStage.LastModifiedBy = "System";
                return wrkStage;
            }
            else
            {
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                return wrkStage;
            }
        }

        public static bool UpdateWorkFlowStage(WorkFlowStages wrkFlow)
        {
            return ((wrkFlow.Update() > 0) ? true : false);
        }

        public static long CreateWorkFlowStage(long workFlowId, int stagePosition, string stageName, string stageDescription, long roleGroupId, int stageAssignMode, bool stageOptional, bool requireDocuments, bool requirePayment, bool requireSiteVisit, bool requireRecommendations, string fK_AutoDocumentName, int sendEmail, int sendSMS)
        {
            WorkFlowStages wrkFlow = new WorkFlowStages(workFlowId, stagePosition, stageName, stageDescription, roleGroupId, stageAssignMode, stageOptional, requireDocuments, requirePayment, requireSiteVisit, requireRecommendations, fK_AutoDocumentName, sendEmail, sendSMS);
            return wrkFlow.Save();
        }

        public static List<WorkFlowStages> GetWorkFlowStages(long Id)
        {
            List<WorkFlowStages> response = new List<WorkFlowStages>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowStages where FK_WorkFlowId=" + Id + " order by StagePosition asc");
            while (reader.Reader.Read())
            {
                WorkFlowStages wrk = new WorkFlowStages();
                wrk.Id = long.Parse(reader.Reader["Id"].ToString());
                wrk.FK_WorkFlowId = long.Parse(reader.Reader["FK_WorkFlowId"].ToString());
                wrk.StagePosition = int.Parse(reader.Reader["StagePosition"].ToString());
                wrk.StageName = (reader.Reader["StageName"].ToString());
                wrk.StageDescription = (reader.Reader["StageDescription"].ToString());
                wrk.FK_RoleGroupId = long.Parse(reader.Reader["FK_RoleGroupId"].ToString());
                wrk.StageAssignMode = int.Parse(reader.Reader["StageAssignMode"].ToString());
                wrk.StageOptional = bool.Parse(reader.Reader["StageOptional"].ToString());
                wrk.RequireDocuments = bool.Parse(reader.Reader["RequireDocuments"].ToString());
                wrk.RequirePayment = bool.Parse(reader.Reader["RequirePayment"].ToString());
                wrk.RequireSiteVisit = bool.Parse(reader.Reader["RequireSiteVisit"].ToString());
                wrk.RequireRecommendations = bool.Parse(reader.Reader["RequireRecommendations"].ToString());
                wrk.Created = DateTime.Now;
                wrk.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                wrk.LastModified = DateTime.Now;
                wrk.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(wrk);
            }
            reader.Close();
            return response;
        }

        public static WorkFlowStageDocuments GetWorkFlowStageDocument(long Id)
        {
            WorkFlowStageDocuments wrkFlow = new WorkFlowStageDocuments(Id);
            return wrkFlow;
        }

        public static bool UpdateWorkFlowStageDocument(WorkFlowStageDocuments wrkFlow)
        {
            return wrkFlow.Update();
        }

        public static bool CreateWorkFlowStageDocument(long stageId, int documentTypeId, bool documentRequired)
        {
            WorkFlowStageDocuments wrkFlow = new WorkFlowStageDocuments(stageId, documentTypeId, documentRequired);
            return wrkFlow.Save();
        }

        public static List<DocumentWorkFlowProgress> GetWorkFlowProgress(long Id)
        {
            List<DocumentWorkFlowProgress> response = new List<DocumentWorkFlowProgress>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from DocumentWorkFlowProgress where FK_DocumentWorkFlowId=" + Id);
            while (reader.Reader.Read())
            {
                DocumentWorkFlowProgress wrk = new DocumentWorkFlowProgress();
                wrk.Id = long.Parse(reader.Reader["Id"].ToString());
                wrk.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                wrk.FK_StageName = (reader.Reader["FK_StageName"].ToString());
                wrk.Created = DateTime.Now;
                wrk.CreatedBy = (reader.Reader["CreatedBy"].ToString());

                response.Add(wrk);
            }
            reader.Close();
            return response;
        }

        public static WorkFlowStages GetWorkFlowStage(long Id)
        {
            WorkFlowStages wrkFlow = new WorkFlowStages(Id);
            return wrkFlow;
        }

        public static bool CheckAccessToStage(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            if (wrkIdentity.WorkFlowStatus == "Complete")
            {
                return false;
            }
            DocumentWorkflow newDocument = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            WorkFlowStages flowStage = new WorkFlowStages(newDocument.FK_WorkFlowId, newDocument.WorkFlowStatus);
            //check if user is assigned the stage
            if ((newDocument.AssignedTo.ToLower() == Security.actingUser.ToLower()) || flowStage.CheckUserAccess())
            {
                return true;
            }
            else
                return false;
        }

        public static List<WorkFlowStageDocumentStatus> GetAllRequiredDocuments(long Id, string entityType)
        {
            //this method replaces the returned Id with the actual document Id in the document library
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
           
            List<WorkFlowStageDocumentStatus> response = new List<WorkFlowStageDocumentStatus>();
            //get document list
            List<WorkFlowStageDocuments> wrkRequiredDocuments = GetAllDocumentsRequiredList(wrkIdentity.WorkFlowId, wrkDoc.Id, Id);
            foreach (WorkFlowStageDocuments reqDoc in wrkRequiredDocuments)
            {
                WorkFlowStageDocumentStatus temp = new WorkFlowStageDocumentStatus();
                temp.DocumentRequired = reqDoc.DocumentRequired;
                temp.FK_DocumentTypeId = reqDoc.FK_DocumentTypeId;
                temp.FK_StageId = reqDoc.FK_StageId;
                temp.Id = reqDoc.Id;
                temp.DocumentType = Utilities.ExecuteScalar("select DocumentName from DocumentLibrary where Id="+ reqDoc.Id);//Utilities.GetDocumentTypeName(reqDoc.FK_DocumentTypeId);
                temp.Uploaded = CheckCurrentStageDocumentStatus(reqDoc.FK_DocumentTypeId, reqDoc.FK_StageId, wrkDoc.Id, long.Parse(wrkIdentity.DocumentId));

                response.Add(temp);
            }
            //get site visit reports
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId from DocumentLibrary where BusinessAssesment='True' and FK_DocumentId="+Id+" and FK_DocumentWorkFlowId="+wrkDoc.Id);
            while (reader.Reader.Read())
            {
                WorkFlowStageDocumentStatus temp = new WorkFlowStageDocumentStatus();
                temp.DocumentRequired = true;
                temp.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                temp.FK_StageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                temp.Id = long.Parse(reader.Reader["Id"].ToString());
                temp.DocumentType = Utilities.GetEntityName(int.Parse(Utilities.ExecuteScalar("select FK_StakeholderId from SiteVisitReport where DocumentLibraryId=" + temp.Id)),"stahol");
                temp.Uploaded = true;

                response.Add(temp);                
            }
            reader.Close();
            return response;
        }

        public static List<WorkFlowFieldValidations> GetValidationsList(string docType)
        {
            List<WorkFlowFieldValidations> response = new List<WorkFlowFieldValidations>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowFieldValidations where DocumentType='" + docType + "'");
            while (reader.Reader.Read())
            {
                WorkFlowFieldValidations doc = new WorkFlowFieldValidations();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.DocumentType = (reader.Reader["DocumentType"].ToString());
                doc.ParameterField = (reader.Reader["ParameterField"].ToString());
                doc.ParameterDataType = (reader.Reader["ParameterDataType"].ToString());
                doc.ParameterFieldName = (reader.Reader["ParameterFieldName"].ToString());
                doc.ParameterValue = (reader.Reader["ParameterValue"].ToString());
                doc.ParameterMaxValue = (reader.Reader["ParameterMaxValue"].ToString());
                doc.ParameterEvaluationType = (reader.Reader["ParameterEvaluationType"].ToString());
                doc.Active = bool.Parse(reader.Reader["Active"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();

            return response;
        }
        
        public static WorkFlowFieldValidations GetValidation(long Id)
        {
            WorkFlowFieldValidations val = new WorkFlowFieldValidations(Id);
            return val;
        }

        public static long SaveValidation(long id, string documentType, string parameterField, string parameterDataType, string parameterFieldName, string parameterValue, string parameterMaxValue, string parameterEvaluationType, bool active)
        {
            WorkFlowFieldValidations val = new WorkFlowFieldValidations(id, documentType, parameterField, parameterDataType, parameterFieldName, parameterValue, parameterMaxValue, parameterEvaluationType, active);
            return val.Save();
        }

        public static bool SkipOptionalStage(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            DocumentWorkflow wrkDoc = Utilities.SkipWorkFlowStage(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            int x = Utilities.ExecuteNonQuery("update " + Utilities.GetEntityTable(entityType) + " set WorkFlowStatus='" + wrkDoc.WorkFlowStatus + "',Status='" + wrkDoc.WorkFlowStatus + "' where Id=" + Id);
            return ((x > 0) ? true : false);
        }

        public static bool ReverseStage(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);

            DocumentWorkflow wrkDoc = Utilities.ReverseWorkFlowStage(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            int x = Utilities.ExecuteNonQuery("update " + Utilities.GetEntityTable(entityType) + " set WorkFlowStatus='" + wrkDoc.WorkFlowStatus + "',Status='" + wrkDoc.WorkFlowStatus + "' where Id=" + Id);
            return ((x > 0) ? true : false);
        }

        public static List<WorkFlowStagesAutoDocuments> GetWorkFlowStagesAutoDocuments(long Id)
        {
            List<WorkFlowStagesAutoDocuments> response = new List<WorkFlowStagesAutoDocuments>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowStagesAutoDocuments where FK_WorkFlowStageId=" + Id);
            while (reader.Reader.Read())
            {
                WorkFlowStagesAutoDocuments wrk = new WorkFlowStagesAutoDocuments();
                wrk.Id = long.Parse(reader.Reader["Id"].ToString());
                wrk.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                wrk.FK_AutoDocumentName = (reader.Reader["FK_AutoDocumentName"].ToString());
                wrk.Active = bool.Parse(reader.Reader["Active"].ToString());
                wrk.SendEmail = int.Parse(reader.Reader["SendEmail"].ToString());
                wrk.SendSMS = int.Parse(reader.Reader["SendSMS"].ToString());
                wrk.Created = DateTime.Now;
                wrk.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                wrk.LastModified = DateTime.Now;
                wrk.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(wrk);
            }
            reader.Close();
            return response;
        }

        public static long CreateWorkFlowStagesAutoDocument(long workFlowStageId, string fK_AutoDocumentName, int sendEmail, int sendSMS, bool active)
        {
            WorkFlowStagesAutoDocuments wrkFlow = new WorkFlowStagesAutoDocuments(workFlowStageId, fK_AutoDocumentName, sendEmail, sendSMS, active);
            return wrkFlow.Save();
        }

        public static WorkFlowStagesAutoDocuments GetWorkFlowStagesAutoDocument(long Id)
        {
            WorkFlowStagesAutoDocuments wrkFlow = new WorkFlowStagesAutoDocuments(Id);
            return wrkFlow;
        }

        public static bool SwitchStages(long IdUp, long IdDown)
        {
            return WorkFlowStages.Switch(IdUp, IdDown);
        }

        public static bool DeleteStage(long workId, long delId)
        {
            return WorkFlowStages.Delete(workId, delId);
        }

        public static long GetWorkFlowId(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            return wrkIdentity.WorkFlowId;
        }
    }

    public class WorkFlows
    {
        public WorkFlows() { }

        public WorkFlows(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlows where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                FK_StartRoleGroupId = long.Parse(reader.Reader["FK_StartRoleGroupId"].ToString());
                WorkFlowName = (reader.Reader["WorkFlowName"].ToString());
                WorkFlowDescription = (reader.Reader["WorkFlowDescription"].ToString());
                FK_EndRoleGroupId = long.Parse(reader.Reader["FK_EndRoleGroupId"].ToString());
                Created = DateTime.Now;
                CreatedBy = (reader.Reader["CreatedBy"].ToString());
                LastModified = DateTime.Now;
                LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public WorkFlows(string workFlowName, string workFlowDescription, long startRoleGroupId, long endRoleGroupId)
        {
            this.WorkFlowName = workFlowName;
            this.FK_StartRoleGroupId = startRoleGroupId;
            this.FK_EndRoleGroupId = endRoleGroupId;
            this.WorkFlowDescription = workFlowDescription;
        }

        public long Save()
        {
            long x = long.Parse(Utilities.ExecuteScalar("select count(Id) from WorkFlows where WorkFlowName='" + this.WorkFlowName + "'"));
            if (x < 1)
                x = Utilities.ExecuteNewRecord("insert into WorkFlows(WorkFlowName,WorkFlowDescription,FK_StartRoleGroupId,FK_EndRoleGroupId,Created,CreatedBy,LastModified,LastModifiedBy) values('" + this.WorkFlowName + "','" + this.WorkFlowDescription + "'," + this.FK_StartRoleGroupId + "," + this.FK_EndRoleGroupId + ",CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            else
            {
                x = Utilities.ExecuteNonQuery("update WorkFlows set WorkFlowDescription='" + this.WorkFlowDescription + "',Fk_StartRoleGroupId=" + this.FK_StartRoleGroupId + ",FK_EndRoleGroupId=" + this.FK_EndRoleGroupId + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where WorkFlowName='" + this.WorkFlowName + "'");
                x = ((x > 0) ? 0 : -1);
            }

            return x;
        }

        public bool Update()
        {
            int x = Utilities.ExecuteNonQuery("update WorkFlows set WorkFlowName='" + this.WorkFlowName + "',WorkFlowDescription='" + this.WorkFlowDescription + "',FK_StartRoleGroupId=" + this.FK_StartRoleGroupId + ",FK_EndRoleGroupId=" + this.FK_EndRoleGroupId + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);
            return ((x > 0) ? true : false);
        }

        public static int GetStartRoleGroup(long workFlowId)
        {
            return int.Parse(Utilities.ExecuteScalar("select FK_StartRoleGroupId from WorkFlows where Id=" + workFlowId));
        }

        public long Id { get; set; }
        public string WorkFlowName { get; set; }
        public string WorkFlowDescription { get; set; }
        public long FK_StartRoleGroupId { get; set; }
        public long FK_EndRoleGroupId { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class WorkFlowStageDocuments
    {
        public WorkFlowStageDocuments() { }
        public WorkFlowStageDocuments(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowStageDocuments where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.FK_StageId = long.Parse(reader.Reader["FK_StageId"].ToString());
                this.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                this.DocumentRequired = bool.Parse(reader.Reader["DocumentRequired"].ToString());
                Created = DateTime.Now;
                CreatedBy = (reader.Reader["CreatedBy"].ToString());
                LastModified = DateTime.Now;
                LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public WorkFlowStageDocuments(long stageId, int documentTypeId, bool documentRequired)
        {
            this.FK_StageId = stageId;
            this.FK_DocumentTypeId = documentTypeId;
            this.DocumentRequired = documentRequired;
        }

        public bool Save()
        {
            int x = Utilities.ExecuteNonQuery("insert into WorkFlowStageDocuments(FK_StageId,FK_DocumentTypeId,DocumentRequired, Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_StageId + "," + this.FK_DocumentTypeId + ",'" + ((this.DocumentRequired) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            return ((x > 0) ? true : false);
        }

        public bool Update()
        {
            int x = Utilities.ExecuteNonQuery("update WorkFlowStageDocuments set FK_StageId=" + this.FK_StageId + ",FK_DocumentTypeId=" + this.FK_DocumentTypeId + ",DocumentRequired='" + ((this.DocumentRequired) ? "True" : "False") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_StageId { get; set; }
        public int FK_DocumentTypeId { get; set; }
        public bool DocumentRequired { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class WorkFlowStages
    {
        public WorkFlowStages() { }

        public WorkFlowStages(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowStages where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.FK_WorkFlowId = long.Parse(reader.Reader["FK_WorkFlowId"].ToString());
                this.StagePosition = int.Parse(reader.Reader["StagePosition"].ToString());
                this.StageName = (reader.Reader["StageName"].ToString());
                this.StageDescription = (reader.Reader["StageDescription"].ToString());
                this.FK_RoleGroupId = long.Parse(reader.Reader["FK_RoleGroupId"].ToString());
                this.StageAssignMode = int.Parse(reader.Reader["StageAssignMode"].ToString());
                this.StageOptional = bool.Parse(reader.Reader["StageOptional"].ToString());
                this.RequireDocuments = bool.Parse(reader.Reader["RequireDocuments"].ToString());
                this.RequirePayment = bool.Parse(reader.Reader["RequirePayment"].ToString());
                this.RequireSiteVisit = bool.Parse(reader.Reader["RequireSiteVisit"].ToString());
                this.RequireRecommendations = bool.Parse(reader.Reader["RequireRecommendations"].ToString());
                this.FK_AutoDocumentName = (reader.Reader["FK_AutoDocumentName"].ToString());
                this.SendEmail = int.Parse(reader.Reader["SendEmail"].ToString());
                this.SendSMS = int.Parse(reader.Reader["SendSMS"].ToString());
                Created = DateTime.Now;
                CreatedBy = (reader.Reader["CreatedBy"].ToString());
                LastModified = DateTime.Now;
                LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public WorkFlowStages(long workFlowId, int stagePosition, string stageName, string stageDescription, long roleGroupId, int stageAssignMode, bool stageOptional, bool requireDocuments, bool requirePayment, bool requireSiteVisit, bool requireRecommendations, string fK_AutoDocumentName, int sendEmail, int sendSMS)
        {
            //check if exists
            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from WorkFlowStages where FK_WorkFlowId=" + workFlowId + " and StageName='" + stageName + "'"));
            if (x > 0)
            {
                exists = true;
                this.Id = long.Parse(Utilities.ExecuteScalar("select Id from WorkFlowStages where FK_WorkFlowId=" + workFlowId + " and StageName='" + stageName + "'"));
            }
            this.FK_WorkFlowId = workFlowId;
            this.StagePosition = ((stagePosition == 0) ? LastPosition(workFlowId) : stagePosition);
            this.StageName = stageName;
            this.StageDescription = stageDescription;
            this.FK_RoleGroupId = roleGroupId;
            this.StageAssignMode = stageAssignMode;
            this.StageOptional = stageOptional;
            this.RequireDocuments = requireDocuments;
            this.RequirePayment = requirePayment;
            this.RequireSiteVisit = requireSiteVisit;
            this.RequireRecommendations = requireRecommendations;
            this.FK_AutoDocumentName = fK_AutoDocumentName;
            this.SendEmail = sendEmail;
            this.SendSMS = sendSMS;
        }

        public long Save()
        {
            long x = 0;
            if (!exists)
            {
                x = Utilities.ExecuteNewRecord("insert into WorkFlowStages(FK_WorkFlowId,StagePosition,StageName,StageDescription,FK_RoleGroupId,StageAssignMode,StageOptional,RequireDocuments,RequirePayment,RequireSiteVisit,RequireRecommendations,FK_AutoDocumentName,SendEmail,SendSMS,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_WorkFlowId + "," + this.StagePosition + ",'" + this.StageName + "','" + this.StageDescription + "'," + this.FK_RoleGroupId + "," + StageAssignMode + ",'" + ((this.StageOptional) ? "True" : "False") + "','" + ((this.RequireDocuments) ? "True" : "False") + "','" + ((this.RequirePayment) ? "True" : "False") + "','" + ((this.RequireSiteVisit) ? "True" : "False") + "','" + ((this.RequireRecommendations) ? "True" : "False") + "','" + this.FK_AutoDocumentName + "'," + this.SendEmail + "," + this.SendSMS + ",CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
                if (x < 1)
                    x = -1;
            }
            else
                x = this.Update();
            return x;
        }

        public long Update()
        {
            int x = Utilities.ExecuteNonQuery("update WorkFlowStages set StageDescription='" + this.StageDescription + "',FK_RoleGroupId=" + this.FK_RoleGroupId + ",StageAssignMode=" + StageAssignMode + ",StageOptional='" + ((this.StageOptional) ? "True" : "False") + "',RequireDocuments='" + ((this.RequireDocuments) ? "True" : "False") + "',RequirePayment='" + ((this.RequirePayment) ? "True" : "False") + "',RequireSiteVisit='" + ((this.RequireSiteVisit) ? "True" : "False") + "',RequireRecommendations='" + ((this.RequireRecommendations) ? "True" : "False") + "',FK_AutoDocumentName='" + this.FK_AutoDocumentName + "',SendEmail=" + this.SendEmail + ",SendSMS=" + this.SendSMS + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);
            if (((x > 0) ? true : false))
            {
                return 0;
            }
            else
                return -1;
        }

        public WorkFlowStages(long workFlowId, string stageName)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowStages where FK_WorkFlowId=" + workFlowId + " and StageName='" + stageName + "'");
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.FK_WorkFlowId = long.Parse(reader.Reader["FK_WorkFlowId"].ToString());
                this.StagePosition = int.Parse(reader.Reader["StagePosition"].ToString());
                this.StageName = (reader.Reader["StageName"].ToString());
                this.StageDescription = (reader.Reader["StageDescription"].ToString());
                this.FK_RoleGroupId = int.Parse(reader.Reader["FK_RoleGroupId"].ToString());
                this.StageAssignMode = int.Parse(reader.Reader["StageAssignMode"].ToString());
                this.StageOptional = bool.Parse(reader.Reader["StageOptional"].ToString());
                this.RequireDocuments = bool.Parse(reader.Reader["RequireDocuments"].ToString());
                this.RequirePayment = bool.Parse(reader.Reader["RequirePayment"].ToString());
                this.RequireSiteVisit = bool.Parse(reader.Reader["RequireSiteVisit"].ToString());
                this.RequireRecommendations = bool.Parse(reader.Reader["RequireRecommendations"].ToString());
                this.FK_AutoDocumentName = (reader.Reader["FK_AutoDocumentName"].ToString());
                this.SendEmail = int.Parse(reader.Reader["SendEmail"].ToString());
                this.SendSMS = int.Parse(reader.Reader["SendSMS"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public bool MoveNextStage()
        {
            long currentId = this.Id;
            try
            {
                //check if not last stage
                int lastId = int.Parse(Utilities.ExecuteScalar("select top 1 Id from WorkFlowStages where FK_WorkFlowId=" + this.FK_WorkFlowId + " order by StagePosition desc"));

                if (lastId != currentId)
                {
                    Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowStages where FK_WorkFlowId=" + this.FK_WorkFlowId + " and StagePosition=" + (this.StagePosition + 1));
                    while (reader.Reader.Read())
                    {
                        this.Id = int.Parse(reader.Reader["Id"].ToString());
                        this.FK_WorkFlowId = long.Parse(reader.Reader["FK_WorkFlowId"].ToString());
                        this.StagePosition = int.Parse(reader.Reader["StagePosition"].ToString());
                        this.StageName = (reader.Reader["StageName"].ToString());
                        this.StageDescription = (reader.Reader["StageDescription"].ToString());
                        this.FK_RoleGroupId = int.Parse(reader.Reader["FK_RoleGroupId"].ToString());
                        this.StageAssignMode = int.Parse(reader.Reader["StageAssignMode"].ToString());
                        this.StageOptional = bool.Parse(reader.Reader["StageOptional"].ToString());
                        this.RequireDocuments = bool.Parse(reader.Reader["RequireDocuments"].ToString());
                        this.RequirePayment = bool.Parse(reader.Reader["RequirePayment"].ToString());
                        this.RequireSiteVisit = bool.Parse(reader.Reader["RequireSiteVisit"].ToString());
                        this.RequireRecommendations = bool.Parse(reader.Reader["RequireRecommendations"].ToString());
                        this.FK_AutoDocumentName = (reader.Reader["FK_AutoDocumentName"].ToString());
                        this.SendEmail = int.Parse(reader.Reader["SendEmail"].ToString());
                        this.SendSMS = int.Parse(reader.Reader["SendSMS"].ToString());
                        this.Created = DateTime.Now;
                        this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                        this.LastModified = DateTime.Now;
                        this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                    }
                    reader.Close();
                }
                else
                {
                    this.StageName = "Complete";
                }
            }
            catch (Exception ex)
            {

            }
            return ((this.Id != currentId) ? true : ((this.StageName == "Complete") ? true : false));
        }

        public bool MovePreviousStage()
        {
            long currentId = this.Id;
            try
            {
                if (0 != currentId)
                {
                    Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowStages where FK_WorkFlowId=" + this.FK_WorkFlowId + " and StagePosition=" + (this.StagePosition - 1));
                    while (reader.Reader.Read())
                    {
                        this.Id = int.Parse(reader.Reader["Id"].ToString());
                        this.FK_WorkFlowId = long.Parse(reader.Reader["FK_WorkFlowId"].ToString());
                        this.StagePosition = int.Parse(reader.Reader["StagePosition"].ToString());
                        this.StageName = (reader.Reader["StageName"].ToString());
                        this.StageDescription = (reader.Reader["StageDescription"].ToString());
                        this.FK_RoleGroupId = int.Parse(reader.Reader["FK_RoleGroupId"].ToString());
                        this.StageAssignMode = int.Parse(reader.Reader["StageAssignMode"].ToString());
                        this.StageOptional = bool.Parse(reader.Reader["StageOptional"].ToString());
                        this.RequireDocuments = bool.Parse(reader.Reader["RequireDocuments"].ToString());
                        this.RequirePayment = bool.Parse(reader.Reader["RequirePayment"].ToString());
                        this.RequireSiteVisit = bool.Parse(reader.Reader["RequireSiteVisit"].ToString());
                        this.RequireRecommendations = bool.Parse(reader.Reader["RequireRecommendations"].ToString());
                        this.FK_AutoDocumentName = (reader.Reader["FK_AutoDocumentName"].ToString());
                        this.SendEmail = int.Parse(reader.Reader["SendEmail"].ToString());
                        this.SendSMS = int.Parse(reader.Reader["SendSMS"].ToString());
                        this.Created = DateTime.Now;
                        this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                        this.LastModified = DateTime.Now;
                        this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                    }
                    reader.Close();
                }
                else
                {
                    this.StageName = "Saved";
                }
            }
            catch (Exception ex)
            {

            }
            return ((this.Id != currentId) ? true : ((this.StageName == "Saved") ? true : false));
        }

        public bool MoveLastStage()
        {
            long currentId = this.Id;
            try
            {
                this.StageName = "Complete";
            }
            catch (Exception ex)
            {

            }
            return ((this.Id != currentId) ? true : ((this.StageName == "Complete") ? true : false));
        }

        public bool CheckUserAccess()
        {
            return Security.CheckUserRolegroupAccess(Security.actingUser, this.FK_RoleGroupId);
        }

        public static bool Switch(long IdUp, long IdDown)
        {
            int posUpCurrent = int.Parse(Utilities.ExecuteScalar("select StagePosition from WorkFlowStages where Id=" + IdUp));
            int x = Utilities.ExecuteNonQuery("update WorkFlowStages set StagePosition=" + (posUpCurrent - 1) + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + IdUp);
            if (x > 0)
            {
                x = Utilities.ExecuteNonQuery("update WorkFlowStages set StagePosition=" + posUpCurrent + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + IdDown);

                if (x < 1)
                {
                    int y = Utilities.ExecuteNonQuery("update WorkFlowStages set StagePosition=" + posUpCurrent + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + IdUp);
                }
            }
            return ((x > 0) ? true : false);

        }

        public static bool Delete(long workId, long delId)
        {
            int posCurrent = int.Parse(Utilities.ExecuteScalar("select StagePosition from WorkFlowStages where Id=" + delId));

            int x = Utilities.ExecuteNonQuery("delete from WorkFlowStages where Id=" + delId);
            if (x > 0)
            {
                List<WorkFlowStages> allStages = Utilities.GetWorkFlowStages(workId);
                bool found = false;
                foreach (WorkFlowStages stage in allStages)
                {
                    if (found)
                    {
                        x = Utilities.ExecuteNonQuery("update WorkFlowStages set StagePosition=" + posCurrent + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + stage.Id);
                        posCurrent++;
                    }

                    if (stage.StagePosition == (posCurrent - 1))
                    {
                        found = true;
                    }
                }
            }

            return ((x > 0) ? true : false);
        }

        public static string GetFirstStage(long workFlowId)
        {
            return Utilities.ExecuteScalar("select StageName from WorkFlowStages where FK_WorkFlowId=" + workFlowId + " and StagePosition=0");
        }

        public static int LastPosition(long workFlowId)
        {
            return int.Parse(Utilities.ExecuteScalar("select count(Id) from WorkFlowStages where FK_WorkFlowId=" + workFlowId));
        }

        public long Id { get; set; }
        public long FK_WorkFlowId { get; set; }
        public int StagePosition { get; set; }
        public string StageName { get; set; }
        public string StageDescription { get; set; }
        public long FK_RoleGroupId { get; set; }
        public int StageAssignMode { get; set; }
        public bool StageOptional { get; set; }
        public bool RequireDocuments { get; set; }
        public bool RequirePayment { get; set; }
        public bool RequireSiteVisit { get; set; }
        public bool RequireRecommendations { get; set; }
        public string FK_AutoDocumentName { get; set; }
        public int SendEmail { get; set; }
        public int SendSMS { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        private bool exists = false;
    }

    public class DocumentWorkflow
    {
        public DocumentWorkflow() { }

        public DocumentWorkflow(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_WorkFlowId,FK_DocumentId,DocumentType,WorkFlowStatus,AssignedTo,FK_LastRoleGroupId,FK_CurrentRoleGroupId,FK_NextRoleGroupId,Created,CreatedBy,LastModified,LastModifiedBy from DocumentWorkflow where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                FK_WorkFlowId = long.Parse(reader.Reader["FK_WorkFlowId"].ToString());
                FK_DocumentId = (reader.Reader["FK_DocumentId"].ToString());
                DocumentType = (reader.Reader["DocumentType"].ToString());
                WorkFlowStatus = (reader.Reader["WorkFlowStatus"].ToString());
                AssignedTo = (reader.Reader["AssignedTo"].ToString());
                FK_LastRoleGroupId = int.Parse(reader.Reader["FK_LastRoleGroupId"].ToString());
                FK_CurrentRoleGroupId = int.Parse(reader.Reader["FK_CurrentRoleGroupId"].ToString());
                FK_NextRoleGroupId = int.Parse(reader.Reader["FK_NextRoleGroupId"].ToString());
                Created = DateTime.Now;
                CreatedBy = (reader.Reader["CreatedBy"].ToString());
                LastModified = DateTime.Now;
                LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public DocumentWorkflow(long workFlowId, string documentId, string documentType)
        {
            //check if already exists
            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from DocumentWorkflow where FK_WorkFlowId=" + workFlowId + " and FK_DocumentId='" + documentId + "' and DocumentType='" + documentType + "'"));
            //if x < 1 then create and add new document
            if (x < 1)
            {
                Id = 0;
                FK_WorkFlowId = workFlowId;
                FK_DocumentId = documentId;
                DocumentType = documentType;
                WorkFlowStatus = WorkFlowStages.GetFirstStage(workFlowId);
                AssignedTo = "";
                FK_LastRoleGroupId = WorkFlows.GetStartRoleGroup(workFlowId);
                FK_CurrentRoleGroupId = FK_LastRoleGroupId;
                FK_NextRoleGroupId = FK_CurrentRoleGroupId;
                Created = DateTime.Now;
                CreatedBy = Security.actingUser;
                LastModified = DateTime.Now;
                LastModifiedBy = Security.actingUser;
                this.Id = Utilities.ExecuteNewRecord("insert into DocumentWorkflow(FK_WorkFlowId,FK_DocumentId,DocumentType,WorkFlowStatus,AssignedTo,FK_LastRoleGroupId,FK_CurrentRoleGroupId,FK_NextRoleGroupId,Created,CreatedBy,LastModified,LastModifiedBy) values('" + this.FK_WorkFlowId + "','" + this.FK_DocumentId + "','" + this.DocumentType + "','" + this.WorkFlowStatus + "','" + this.AssignedTo + "', " + this.FK_LastRoleGroupId + ", " + this.FK_CurrentRoleGroupId + "," + this.FK_NextRoleGroupId + ",CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            }
            else //else retrieve current
            {
                Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_WorkFlowId,FK_DocumentId,DocumentType,WorkFlowStatus,AssignedTo,FK_LastRoleGroupId,FK_CurrentRoleGroupId,FK_NextRoleGroupId,Created,CreatedBy,LastModified,LastModifiedBy from DocumentWorkflow where FK_WorkFlowId=" + workFlowId + " and FK_DocumentId='" + documentId + "' and DocumentType='" + documentType + "'");
                while (reader.Reader.Read())
                {
                    this.Id = int.Parse(reader.Reader["Id"].ToString());
                    FK_WorkFlowId = long.Parse(reader.Reader["FK_WorkFlowId"].ToString());
                    FK_DocumentId = (reader.Reader["FK_DocumentId"].ToString());
                    DocumentType = (reader.Reader["DocumentType"].ToString());
                    WorkFlowStatus = (reader.Reader["WorkFlowStatus"].ToString());
                    AssignedTo = (reader.Reader["AssignedTo"].ToString());
                    FK_LastRoleGroupId = int.Parse(reader.Reader["FK_LastRoleGroupId"].ToString());
                    FK_CurrentRoleGroupId = int.Parse(reader.Reader["FK_CurrentRoleGroupId"].ToString());
                    FK_NextRoleGroupId = int.Parse(reader.Reader["FK_NextRoleGroupId"].ToString());
                    Created = DateTime.Now;
                    CreatedBy = (reader.Reader["CreatedBy"].ToString());
                    LastModified = DateTime.Now;
                    LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                }
                reader.Close();
            }
        }

        public bool SaveDocument()
        {
            WorkFlowStages flowStage = new WorkFlowStages(this.FK_WorkFlowId, this.WorkFlowStatus);
            //check if user is assigned the stage
            if ((this.AssignedTo.ToLower() == Security.actingUser.ToLower()) || flowStage.CheckUserAccess())
            {
                if (flowStage.RequirePayment && Utilities.CheckCurrentStagePaymentRequirements(flowStage.Id, this.Id, long.Parse(this.FK_DocumentId)))
                {
                    return false;
                }
                else
                {
                    //check for documents
                    if (Utilities.CheckCurrentStageDocumentRequirements(flowStage.Id, this.Id, long.Parse(this.FK_DocumentId)).ToLower() == "none")
                    {
                        //check recommendations
                        if (flowStage.RequireRecommendations && Utilities.CheckCurrentStageRecommendationsRequirements(flowStage.Id, this.Id, long.Parse(this.FK_DocumentId)).ToLower() != "none")
                        {
                            return false;
                        }
                        else
                        {
                            //check for site visit
                            if (flowStage.RequireSiteVisit && Utilities.CheckCurrentStageSiteVisitRequirements(flowStage.Id, this.Id, long.Parse(this.FK_DocumentId)).ToLower() != "none")
                            {
                                return false;
                            }
                            else
                            {
                                //log stage
                                DocumentWorkFlowProgress progress = new DocumentWorkFlowProgress(this.Id, flowStage.StageName);
                                progress.Save();
                                //process exit stage logic here
                                Utilities.SendDocument(flowStage.FK_AutoDocumentName, this.Id, flowStage.Id, ((flowStage.SendEmail == 1) ? true : false), ((flowStage.SendSMS == 1) ? true : false));
                                List<WorkFlowStagesAutoDocuments> moreDocs = Utilities.GetWorkFlowStagesAutoDocuments(flowStage.Id);
                                foreach (WorkFlowStagesAutoDocuments autoDoc in moreDocs)
                                {
                                    Utilities.SendDocument(autoDoc.FK_AutoDocumentName, this.Id, flowStage.Id, ((autoDoc.SendEmail == 1) ? true : false), ((autoDoc.SendSMS == 1) ? true : false));
                                }
                                //retrive next stage details            
                                flowStage.MoveNextStage();
                                //if new stage requires payment create invoice with basic fees
                                if (flowStage.RequirePayment)
                                {
                                    //if new stage requires payment create invoice with basic fees
                                    Fees stageFee = new Fees(this.DocumentType, flowStage.Id);
                                    float charge = stageFee.Amount;
                                    List<FeeRules> calcFee = Utilities.GetFeeRulesList(this.DocumentType);
                                    foreach (FeeRules rule in calcFee)
                                    {
                                        charge += Utilities.CalculateLoanFee(rule, Utilities.GetLoanRequest(long.Parse(this.FK_DocumentId)));
                                    }
                                    //get reference number
                                    string refNo = Utilities.ExecuteScalar("select ReferenceNumber from " + Utilities.GetEntityTable(this.DocumentType) + " where Id=" + this.FK_DocumentId);

                                    Invoice newInvoice = new Invoice(refNo, stageFee.Currency, charge, stageFee.AllowPartPayment, this.DocumentType, long.Parse(this.FK_DocumentId), this.Id, flowStage.Id, 0, 0);
                                    long invNum = newInvoice.Save();
                                    if (invNum > 0)
                                    {
                                        if (stageFee.Amount > 0)
                                        {
                                            InvoiceItem temp = new InvoiceItem(invNum, stageFee.Currency, stageFee.Amount, stageFee.FeeType.ToUpper() + " standard Fee");
                                            temp.Save();
                                        }
                                        foreach (FeeRules rule in calcFee)
                                        {
                                            float ruleAmount = Utilities.CalculateLoanFee(rule, Utilities.GetLoanRequest(long.Parse(this.FK_DocumentId)));
                                            if (ruleAmount > 0)
                                            {
                                                InvoiceItem temp = new InvoiceItem(invNum, stageFee.Currency, ruleAmount, rule.RuleName + " (" + ((rule.RuleType == "quantity") ? stageFee.Currency : "%") + rule.RuleExecutionValue + ")");
                                                temp.Save();
                                            }

                                        }
                                    }
                                }
                                //process enter stage logic here
                                Utilities.SendDocument(flowStage.FK_AutoDocumentName, this.Id, flowStage.Id, ((flowStage.SendEmail == 0) ? true : false), ((flowStage.SendSMS == 0) ? true : false));
                                foreach (WorkFlowStagesAutoDocuments autoDoc in moreDocs)
                                {
                                    Utilities.SendDocument(autoDoc.FK_AutoDocumentName, this.Id, flowStage.Id, ((autoDoc.SendEmail == 0) ? true : false), ((autoDoc.SendSMS == 0) ? true : false));
                                }
                                //update document state
                                return this.UpdateDocument(flowStage);
                            }
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            else
            {
                return false;
            }
        }

        public bool SkipStage()
        {
            WorkFlowStages flowStage = new WorkFlowStages(this.FK_WorkFlowId, this.WorkFlowStatus);

            //log stage
            DocumentWorkFlowProgress progress = new DocumentWorkFlowProgress(this.Id, flowStage.StageName);
            progress.Save();
            //retrive next stage details            
            flowStage.MoveNextStage();
            if (flowStage.RequirePayment)
            {
                //if new stage requires payment create invoice with basic fees
                Fees stageFee = new Fees(this.DocumentType, flowStage.Id);
                float charge = stageFee.Amount;
                List<FeeRules> calcFee = Utilities.GetFeeRulesList(this.DocumentType);
                foreach (FeeRules rule in calcFee)
                {
                    charge += Utilities.CalculateLoanFee(rule, Utilities.GetLoanRequest(long.Parse(this.FK_DocumentId)));
                }
                //get reference number
                string refNo = Utilities.ExecuteScalar("select ReferenceNumber from " + Utilities.GetEntityTable(this.DocumentType) + " where Id=" + this.FK_DocumentId);

                Invoice newInvoice = new Invoice(refNo, stageFee.Currency, charge, stageFee.AllowPartPayment, this.DocumentType, long.Parse(this.FK_DocumentId), this.Id, flowStage.Id, 0, 0);
                long invNum = newInvoice.Save();
                if (invNum > 0)
                {
                    if (stageFee.Amount > 0)
                    {
                        InvoiceItem temp = new InvoiceItem(invNum, stageFee.Currency, stageFee.Amount, stageFee.FeeType.ToUpper() + " standard Fee");
                        temp.Save();
                    }
                    foreach (FeeRules rule in calcFee)
                    {
                        float ruleAmount = Utilities.CalculateLoanFee(rule, Utilities.GetLoanRequest(long.Parse(this.FK_DocumentId)));
                        if (ruleAmount > 0)
                        {
                            InvoiceItem temp = new InvoiceItem(invNum, stageFee.Currency, ruleAmount, rule.RuleName + " (" + ((rule.RuleType == "quantity") ? stageFee.Currency : "%") + rule.RuleExecutionValue + ")");
                            temp.Save();
                        }

                    }
                }
            }
            //process enter stage logic here
            Utilities.SendDocument(flowStage.FK_AutoDocumentName, this.Id, flowStage.Id, ((flowStage.SendEmail == 0) ? true : false), ((flowStage.SendSMS == 0) ? true : false));
            List<WorkFlowStagesAutoDocuments> moreDocs = Utilities.GetWorkFlowStagesAutoDocuments(flowStage.Id);
            foreach (WorkFlowStagesAutoDocuments autoDoc in moreDocs)
            {
                Utilities.SendDocument(autoDoc.FK_AutoDocumentName, this.Id, flowStage.Id, ((autoDoc.SendEmail == 0) ? true : false), ((autoDoc.SendSMS == 0) ? true : false));
            }
            //update document state
            return this.UpdateDocument(flowStage);

        }

        public bool ReverseStage()
        {
            WorkFlowStages flowStage = new WorkFlowStages(this.FK_WorkFlowId, this.WorkFlowStatus);

            //log stage
            DocumentWorkFlowProgress progress = new DocumentWorkFlowProgress(this.Id, flowStage.StageName);
            progress.Save();
            //retrive next stage details            
            flowStage.MovePreviousStage();
            //update document state
            return this.UpdateDocument(flowStage);

        }

        public bool TerminateStage()
        {
            WorkFlowStages flowStage = new WorkFlowStages(this.FK_WorkFlowId, this.WorkFlowStatus);

            //log stage
            DocumentWorkFlowProgress progress = new DocumentWorkFlowProgress(this.Id, flowStage.StageName);
            progress.Save();
            //retrive next stage details            
            flowStage.MoveLastStage();            
            //process enter stage logic here
            Utilities.SendDocument(flowStage.FK_AutoDocumentName, this.Id, flowStage.Id, ((flowStage.SendEmail == 0) ? true : false), ((flowStage.SendSMS == 0) ? true : false));
            List<WorkFlowStagesAutoDocuments> moreDocs = Utilities.GetWorkFlowStagesAutoDocuments(flowStage.Id);
            foreach (WorkFlowStagesAutoDocuments autoDoc in moreDocs)
            {
                Utilities.SendDocument(autoDoc.FK_AutoDocumentName, this.Id, flowStage.Id, ((autoDoc.SendEmail == 0) ? true : false), ((autoDoc.SendSMS == 0) ? true : false));
            }
            //update document state
            return this.UpdateDocument(flowStage);
        }

        public bool UpdateDocument(WorkFlowStages newStage)
        {
            this.WorkFlowStatus = newStage.StageName;
            if (this.WorkFlowStatus != newStage.StageName)
            {
                //assign logic
                if (newStage.StageAssignMode == 0)//open assign to all in rolegroup
                {
                    this.AssignedTo = "";
                }
                else if (newStage.StageAssignMode == 1)//auto assign logic
                {
                    this.AssignedTo = "";
                }
            }
            this.FK_LastRoleGroupId = this.FK_CurrentRoleGroupId;
            this.FK_CurrentRoleGroupId = newStage.FK_RoleGroupId;
            //next role group
            this.FK_NextRoleGroupId = this.FK_CurrentRoleGroupId;

            //update to database
            int x = Utilities.ExecuteNonQuery("update DocumentWorkflow set WorkFlowStatus='" + this.WorkFlowStatus + "',AssignedTo='" + this.AssignedTo + "',FK_LastRoleGroupId=" + this.FK_LastRoleGroupId + ",FK_CurrentRoleGroupId=" + this.FK_CurrentRoleGroupId + ",FK_NextRoleGroupId=" + this.FK_NextRoleGroupId + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);
            return ((x > 0) ? true : false);
        }

        public string GetNextWorkFlowStage()
        {
            WorkFlowStages flowStage = new WorkFlowStages(this.FK_WorkFlowId, this.WorkFlowStatus);
            //retrive next stage details            
            flowStage.MoveNextStage();
            return flowStage.StageName;
        }

        public bool AssignDocument(string username)
        {
            this.AssignedTo = username;
            //update to database
            int x = Utilities.ExecuteNonQuery("update DocumentWorkflow set AssignedTo='" + this.AssignedTo + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_WorkFlowId { get; set; }
        public string FK_DocumentId { get; set; }
        public string DocumentType { get; set; }
        public string WorkFlowStatus { get; set; }
        public string AssignedTo { get; set; }
        public long FK_LastRoleGroupId { get; set; }
        public long FK_CurrentRoleGroupId { get; set; }
        public long FK_NextRoleGroupId { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class WorkFlowIdentity
    {
        public WorkFlowIdentity(long Id, string entityType)
        {
            WorkFlowId = 0;
            string entityTable = Utilities.GetEntityTable(entityType);
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select WorkFlowId,DocumentType,WorkFlowStatus from " + entityTable + " where Id=" + Id);
            while (reader.Reader.Read())
            {
                WorkFlowId = long.Parse(reader.Reader["WorkFlowId"].ToString());
                DocumentId = Id.ToString();
                DocumentType = (reader.Reader["DocumentType"].ToString());
                WorkFlowStatus = (reader.Reader["WorkFlowStatus"].ToString());
            }
            reader.Close();
        }
        public long WorkFlowId { get; set; }
        public string DocumentId { get; set; }
        public string DocumentType { get; set; }
        public string WorkFlowStatus { get; set; }
    }

    public class DocumentWorkFlowProgress
    {
        public DocumentWorkFlowProgress() { }
        public DocumentWorkFlowProgress(long workFlowId, string stageName)
        {
            this.FK_DocumentWorkFlowId = workFlowId;
            this.FK_StageName = stageName;
        }

        public bool Save()
        {
            int x = Utilities.ExecuteNonQuery("insert into DocumentWorkFlowProgress(FK_DocumentWorkFlowId,FK_StageName,Created,CreatedBy) values(" + this.FK_DocumentWorkFlowId + ",'" + this.FK_StageName + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            return ((x > 0) ? true : false);
        }
        public long Id { get; set; }
        public long FK_DocumentWorkFlowId { get; set; }
        public string FK_StageName { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
    }

    public class WorkFlowStageDocumentStatus
    {
        public WorkFlowStageDocumentStatus() { }

        public long Id { get; set; }
        public long FK_StageId { get; set; }
        public int FK_DocumentTypeId { get; set; }
        public string DocumentType { get; set; }
        public bool DocumentRequired { get; set; }
        public bool Uploaded { get; set; }
    }

    public class WorkFlowFieldValidations
    {
        public WorkFlowFieldValidations() { }

        public WorkFlowFieldValidations(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowFieldValidations where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.DocumentType = (reader.Reader["DocumentType"].ToString());
                this.ParameterField = (reader.Reader["ParameterField"].ToString());
                this.ParameterDataType = (reader.Reader["ParameterDataType"].ToString());
                this.ParameterFieldName = (reader.Reader["ParameterFieldName"].ToString());
                this.ParameterValue = (reader.Reader["ParameterValue"].ToString());
                this.ParameterMaxValue = (reader.Reader["ParameterMaxValue"].ToString());
                this.ParameterEvaluationType = (reader.Reader["ParameterEvaluationType"].ToString());
                this.Active = bool.Parse(reader.Reader["Active"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public WorkFlowFieldValidations(long id, string documentType, string parameterField, string parameterDataType, string parameterFieldName, string parameterValue, string parameterMaxValue, string parameterEvaluationType, bool active)
        {

            this.Id = id;
            this.DocumentType = documentType;
            this.ParameterField = parameterField;
            this.ParameterDataType = parameterDataType;
            this.ParameterFieldName = parameterFieldName;
            this.ParameterValue = parameterValue;
            this.ParameterMaxValue = parameterMaxValue;
            this.ParameterEvaluationType = parameterEvaluationType;
            this.Active = active;
        }

        public long Save()
        {
            long x = 0;
            if (this.Id == 0)
                x = Utilities.ExecuteNewRecord("insert into WorkFlowFieldValidations(DocumentType,ParameterField,ParameterDataType,ParameterFieldName,ParameterValue,ParameterMaxValue,ParameterEvaluationType,Active,Created,CreatedBy,LastModified,LastModifiedBy) values('" + DocumentType + "','" + ParameterField + "','" + ParameterDataType + "','" + ParameterFieldName + "','" + ParameterValue + "','" + ParameterMaxValue + "','" + ParameterEvaluationType + "','" + ((this.Active) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            else
            {
                x = Utilities.ExecuteNonQuery("update WorkFlowFieldValidations set DocumentType='" + DocumentType + "',ParameterField='" + ParameterField + "',ParameterDataType='" + ParameterDataType + "',ParameterFieldName='" + ParameterFieldName + "',ParameterValue='" + ParameterValue + "',ParameterMaxValue='" + ParameterMaxValue + "',ParameterEvaluationType='" + ParameterEvaluationType + "',Active='" + ((this.Active) ? "True" : "False") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);
                if (x == 0) x = -1;
                else x = this.Id;
            }
            return this.Id;
        }

        public long Id { get; set; }
        public string DocumentType { get; set; }
        public string ParameterField { get; set; }
        public string ParameterDataType { get; set; }
        public string ParameterFieldName { get; set; }
        public string ParameterValue { get; set; }
        public string ParameterMaxValue { get; set; }
        public string ParameterEvaluationType { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class WorkFlowStagesAutoDocuments
    {
        bool exists = false;
        public WorkFlowStagesAutoDocuments() { }

        public WorkFlowStagesAutoDocuments(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WorkFlowStagesAutoDocuments where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                this.Active = bool.Parse(reader.Reader["Active"].ToString());
                this.FK_AutoDocumentName = (reader.Reader["FK_AutoDocumentName"].ToString());
                this.SendEmail = int.Parse(reader.Reader["SendEmail"].ToString());
                this.SendSMS = int.Parse(reader.Reader["SendSMS"].ToString());
                Created = DateTime.Now;
                CreatedBy = (reader.Reader["CreatedBy"].ToString());
                LastModified = DateTime.Now;
                LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public WorkFlowStagesAutoDocuments(long workFlowStageId, string fK_AutoDocumentName, int sendEmail, int sendSMS, bool active)
        {
            //check if exists
            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from WorkFlowStagesAutoDocuments where FK_WorkFlowStageId=" + workFlowStageId + " and FK_AutoDocumentName='" + fK_AutoDocumentName + "'"));
            if (x > 0)
            {
                exists = true;
                this.Id = long.Parse(Utilities.ExecuteScalar("select Id from WorkFlowStagesAutoDocuments where FK_WorkFlowStageId=" + workFlowStageId + " and FK_AutoDocumentName='" + fK_AutoDocumentName + "'"));
            }
            this.Active = active;
            this.FK_AutoDocumentName = fK_AutoDocumentName;
            this.SendEmail = sendEmail;
            this.SendSMS = sendSMS;
            this.FK_WorkFlowStageId = workFlowStageId;
        }

        public long Save()
        {
            long x = 0;
            if (!exists)
                x = Utilities.ExecuteNewRecord("insert into WorkFlowStagesAutoDocuments(FK_WorkFlowStageId,FK_AutoDocumentName,SendEmail,SendSMS,Active,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_WorkFlowStageId + ",'" + this.FK_AutoDocumentName + "'," + this.SendEmail + "," + this.SendSMS + ",'" + ((this.Active) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            else
                x = this.Update();
            return x;
        }

        public long Update()
        {
            int x = Utilities.ExecuteNonQuery("update WorkFlowStagesAutoDocuments set Active='" + ((this.Active) ? "True" : "False") + "',SendEmail=" + this.SendEmail + ",SendSMS=" + this.SendSMS + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);
            if (((x > 0) ? true : false))
            {
                return this.Id;
            }
            else
                return 0;
        }

        public long Id { get; set; }
        public long FK_WorkFlowStageId { get; set; }
        public string FK_AutoDocumentName { get; set; }
        public int SendEmail { get; set; }
        public int SendSMS { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
}