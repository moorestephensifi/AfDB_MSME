﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SBFA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "Isbfa" in both code and config file together.
    [ServiceContract]
    public interface ISBFA
    {
        #region messaging
        [OperationContract]
        bool SendBasicEmail(string to, string subject, string message);

        [OperationContract]
        bool SendSMS(string to, string message);

        [OperationContract]
        long SendGroupEmail(string to, string subject, string message);

        [OperationContract]
        long SendGroupSMS(string to, string message);

        [OperationContract]
        List<Email> GetEmails(string filterText);

        [OperationContract]
        bool ClearEmails();

        [OperationContract]
        bool ClearSMSs();


        [OperationContract]
        List<SMS> GetSMSs(string filterText);

        [OperationContract]
        List<EmailMessageDesign> GetEmailMessageDesigns();

        [OperationContract]
        EmailMessageDesign GetEmailMessageDesign(string design);



        #endregion

        #region workflow
        [OperationContract]
        DocumentWorkflow SubmitWorkFlowDocument(long workFlowId, string documentId, string documentType);

        [OperationContract]
        string GetNextWorkFlowStage(long Id, string entityType);

        [OperationContract]
        string GetCurrentWorkFlowStage(long Id, string entityType);

        [OperationContract]
        DocumentWorkflow UpdateWorkFlowStage(long Id, string entityType);

        [OperationContract]
        DocumentWorkflow TerminateWorkFlowStage(long Id, string entityType);

        [OperationContract]
        bool AssignWorkFlowStage(string username, long Id, string entityType);

        [OperationContract]
        List<ApplicationUserSummary> GetAssigningUserList(long Id, string entityType);

        [OperationContract]
        List<WorkFlowStageDocuments> GetDocumentsRequiredList(long Id, string entityType);

        [OperationContract]
        string CheckCurrentStageDocumentRequirements(long Id, string entityType);

        [OperationContract]
        bool CheckCurrentStagePaymentRequirements(long Id, string entityType);

        [OperationContract]
        string CheckCurrentStageSiteVisitRequirements(long Id, string entityType);

        [OperationContract]
        string CheckCurrentStageRecommandationSiteVisitRequirements(long Id, string entityType, long recommendationId, int stakeholderId);

        [OperationContract]
        string CheckCurrentStageRecommendationsRequirements(long Id, string entityType);

        [OperationContract]
        bool UploadWorkFlowDocument(long Id, string entityType, string fileName, byte[] fileData, int documentTypeId, long documentFolderId, bool businessAssesment);

        [OperationContract]
        List<DocumentLibrary> GetWorkFlowDocuments(long Id, string entityType);

        [OperationContract]
        WorkFlows GetWorkFlow(long Id);

        [OperationContract]
        bool UpdateWorkFlow(WorkFlows wrkFlow);

        [OperationContract]
        long CreateWorkFlow(string workFlowName, string workFlowDescription, long startRoleGroupId, long endRoleGroupId);

        [OperationContract]
        List<WorkFlows> GetWorkFlows();

        [OperationContract]
        WorkFlowStages GetWorkFlowStage(long Id);

        [OperationContract]
        WorkFlowStages GetDocumentWorkFlowStage(long Id, string entityType);

        [OperationContract]
        bool UpdateWorkFlowStageRecord(WorkFlowStages wrkFlow);

        [OperationContract]
        long CreateWorkFlowStage(long workFlowId, int stagePosition, string stageName, string stageDescription, long roleGroupId, int stageAssignMode, bool stageOptional, bool requireDocuments, bool requirePayment, bool requireSiteVisit, bool requireRecommendations, string fK_AutoDocumentName, int sendEmail, int sendSMS);

        [OperationContract]
        List<WorkFlowStages> GetWorkFlowStages(long Id);

        [OperationContract]
        WorkFlowStageDocuments GetWorkFlowStageDocument(long Id);

        [OperationContract]
        bool UpdateWorkFlowStageDocument(WorkFlowStageDocuments wrkFlow);

        [OperationContract]
        bool CreateWorkFlowStageDocument(long stageId, int documentTypeId, bool documentRequired);

        [OperationContract]
        List<WorkFlowStageDocuments> GetWorkFlowStageDocuments(long Id);

        [OperationContract]
        List<DocumentWorkFlowProgress> GetWorkFlowProgress(long Id);

        [OperationContract]
        List<WorkFlowStageDocumentStatus> GetDocumentsRequiredStatus(long Id, string entityType);

        [OperationContract]
        bool CheckAccessToStage(long Id, string entityType);

        [OperationContract]
        List<WorkFlowStageDocumentStatus> GetAllRequiredDocuments(long Id, string entityType);

        [OperationContract]
        List<WorkFlowFieldValidations> GetValidationsList(string docType);

        [OperationContract]
        List<FeeRules> GetFeeRulesList(string docType);

        [OperationContract]
        bool SkipOptionalStage(long Id, string entityType);

        [OperationContract]
        bool ReverseStage(long Id, string entityType);

        [OperationContract]
        List<WorkFlowStagesAutoDocuments> GetWorkFlowStagesAutoDocuments(long Id);

        [OperationContract]
        long CreateWorkFlowStagesAutoDocument(long workFlowStageId, string fK_AutoDocumentName, int sendEmail, int sendSMS, bool active);

        [OperationContract]
        WorkFlowStagesAutoDocuments GetWorkFlowStagesAutoDocument(long Id);

        [OperationContract]
        bool SwitchStages(long IdUp, long IdDown);

        [OperationContract]
        bool DeleteStage(long workId, long delId);

        [OperationContract]
        long GetWorkFlowId(long Id, string entityType);
        #endregion

        #region documents
        [OperationContract]
        bool UploadDocument(long Id, string fileName, byte[] fileData, int documentTypeId, long documentFolderId);

        [OperationContract]
        List<DocumentLibrary> GetDocuments(long Id);

        [OperationContract]
        List<DocumentLibrary> GetFolderDocuments(long Id);

        [OperationContract]
        List<DocumentLibrary> GetRegistrationsFolderDocuments(long Id);

        [OperationContract]
        DocumentLibrary GetDocument(long Id);

        [OperationContract]
        List<DocumentFolders> GetFolders(long parentId);

        [OperationContract]
        long CreateFolder(string folderName, long parentId);

        [OperationContract]
        bool RenameFolder(long Id, string newName);

        [OperationContract]
        List<DocumentTypes> GetDocumentTypes();

        [OperationContract]
        List<DocumentLibrary> SearchDocuments(long Id, string filterText);

        [OperationContract]
        List<DocumentLibrary> SearchRegistrationDocuments(long Id,string filterText);

        [OperationContract]
        string GetFolderName(long Id);

        [OperationContract]
        string GetFolderPath(long Id);

        [OperationContract]
        long GetParentFolderId(long Id);

        [OperationContract]
        bool UploadTemplateDocument(string name, string fileName, byte[] fileData);

        [OperationContract]
        DocumentTemplateLibrary GetDocumentTemplate(string name);

        [OperationContract]
        List<DocumentTemplateLibrary> GetDocumentTemplates();
        
        #endregion

        #region sbfa
        [OperationContract]
        long SaveLoanRequest(LoanRequest loan);

        [OperationContract]
        bool RegisterLoan(long Id, string entityType);

        [OperationContract]
        bool RegisterDeclineLoan(long Id, string entityType);

        [OperationContract]
        List<LoanRequest> GetLoanRequests(string filterText);

        [OperationContract]
        LoanRequest GetLoanRequest(long Id);

        [OperationContract]
        long SaveDisbursementRequest(DisbursementRequest disbursement);

        [OperationContract]
        List<DisbursementRequest> GetDisbursementRequests(string filterText);

        [OperationContract]
        DisbursementRequest GetDisbursementRequest(long Id);

        [OperationContract]
        List<DisbursementRequest> GetLoanDisbursementRequests(long Id);

        [OperationContract]
        List<DisbursementRequest> GetActiveDisbursementRequests(string filterText);

        [OperationContract]
        List<AutoDocument> CheckAutoDocument(long Id, string entityType);

        [OperationContract]
        Byte[] GetAutoDocument(string docType, long Id);

        [OperationContract]
        Byte[] GetDisbursementDocument(long Id);

        [OperationContract]
        bool CreateLoanApproval(long Id);

        [OperationContract]
        LoanRequestApproval GetLoanApproval(long Id);

        [OperationContract]
        QuickStats GetQuickStats();

        [OperationContract]
        List<Notifications> CheckNotifications(string filterText, bool pending);

        [OperationContract]
        bool UpdateNotifications(long Id, bool status);

        [OperationContract]
        Guarantor GetGuarantor(string nin);

        [OperationContract]
        List<Guarantor> GetGuarantors(long Id);

        [OperationContract]
        long SaveLoanRequestGuarantor(Guarantor guarantor);

        [OperationContract]
        Guarantor GetLoanRequestGuarantor(string nin, long Id);

        [OperationContract]
        BusinessRegistration GetBusinessRegistration(string nin);

        [OperationContract]
        bool SaveLoanAssesment(LoanAssesment loanAss);

        [OperationContract]
        bool DeleteLoanAssesment(LoanAssesment loanAss);

        [OperationContract]
        LoanAssesment GetLoanAssesment(long requestId);

        [OperationContract]
        LoanAssesment GetDisbursementLoanAssesment(long requestId);

        [OperationContract]
        bool SaveRecommendation(long fK_LoanRequestId, string fK_Stage, bool approved, string recommendation);

        [OperationContract]
        List<LoanApprovalRecommendations> GetLoanApprovalRecommendations(long requestId);

        [OperationContract]
        List<Loan> GetLoans(string filterText);

        [OperationContract]
        Loan GetLoan(long Id);

        [OperationContract]
        bool UpdateDisbursementStatus(long Id);

        [OperationContract]
        Loan GetLoanByRequestId(long requestId);

        [OperationContract]
        bool CheckVoucher(long disId);

        [OperationContract]
        long SaveVoucher(PaymentVoucher voucher);

        [OperationContract]
        PaymentVoucher GetPaymentVoucher(long requestId);

        [OperationContract]
        List<BusinessAccount> GetBusinessAccounts(string filterText);

        [OperationContract]
        BusinessAccount GetBusinessAccount(string NIN);

        [OperationContract]
        float CalculateMonthlyRepayment(int months, long requestId);

        [OperationContract]
        bool DisburseDisbursement(long Id);

        [OperationContract]
        BusinessAccount GetBusinessAccountByAccount(string acc);

        [OperationContract]
        BusinessAccountOld GetOldBusinessAccountByAccount(string acc,string loan);        

        [OperationContract]
        List<RepaymentSchedule> GetRepaymentSchedules(string acc);

        [OperationContract]
        BusinessRegistration GetBusinessRegistrationByRegistration(string reg);

        [OperationContract]
        BusinessRegistration
        GetOldBusinessRegistrationByRegistration(string account,string loan);

        [OperationContract]
        float CalculateMonthlyRepaymentByBalance(int months, string account, float amount);

        [OperationContract]
        bool GenerateMonthlyRepayments(int months, string account, float amount, DateTime start);

        [OperationContract]
        bool CheckFullDisbursement(string account);

        [OperationContract]
        string ReceiptRepayment(string account, string currency, float balance, float amount, int fK_PayBranchId, int fK_PaymentMethodId, DateTime lastPaymentDate);

        [OperationContract]
        string OldReceiptRepayment(string account, string loan, string currency, float balance, float amount, int fK_PayBranchId, int fK_PaymentMethodId, DateTime lastPaymentDate);
        
        [OperationContract]
        string ReceiptFeeRepayment(string account, string currency, float amount, int fK_PayBranchId, int fK_PaymentMethodId);
        
        [OperationContract]
        string OldReceiptFeeRepayment(string account,string loan, string currency, float amount, int fK_PayBranchId, int fK_PaymentMethodId);
        
        [OperationContract]
        List<RepaymentSchedule> FindPendingRepaymentSchedules(string filterText);

        [OperationContract]
        WarningLetter GetWarningStage(long fK_RepaymentId);

        [OperationContract]
        bool SetWarningStage(long fK_RepaymentId, string warningStage, string remark, bool responded);

        [OperationContract]
        bool CheckDisbursementLetter(string docName, long requestId);

        [OperationContract]
        List<BusinessAccountOld> GetOldBusinessAccounts(string filterText);
        #endregion

        #region Administration
        [OperationContract]
        List<PickList> GetPickList(string type);

        [OperationContract]
        List<PickList> GetChildPickList(string type, int parentId);

        [OperationContract]
        List<PickList> GetUserPickList(string groupType);

        [OperationContract]
        string GetEntityName(long Id, string type);

        [OperationContract]
        string GetDocumentTypeName(long Id);

        [OperationContract]
        List<ReferenceTable> GetReferenceTableItems(string type);

        [OperationContract]
        bool SaveReferenceTable(string name, string description, bool active, string type, int fK_ParentId);

        [OperationContract]
        ReferenceTable GetReferenceTableItem(long Id, string type);

        [OperationContract]
        ReferenceTable GetReferenceTableItemByName(string name, string type);

        [OperationContract]
        List<Stakeholder> GetStakeholders();

        [OperationContract]
        long SaveStakeholder(string name, string description, string mobile, string email, bool active);

        [OperationContract]
        Stakeholder GetStakeholder(long Id);

        [OperationContract]
        List<Stakeholder> GetBusinessTypeStakeholders(int businessTypeId);

        [OperationContract]
        bool SaveBusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId, bool stakeholderRequired);

        [OperationContract]
        BusinessTypeStakeholder GetBusinessTypeStakeholder(long Id);

        [OperationContract]
        List<ReferenceTable> GetStakeholderBusinessTypes(int stakeholderId);

        [OperationContract]
        bool RemoveBusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId);
        
        [OperationContract]
        AutoDocumentsDesign GetAutoDocumentsDesign(string name);

        [OperationContract]
        List<AutoDocumentsDesign> GetAutoDocumentsDesigns();

        [OperationContract]
        bool SaveAutoDocumentsDesign(string documentName, string documentDesignSMS, string documentDesign, string emailSubject, bool sms, bool email);

        [OperationContract]
        WorkFlowFieldValidations GetValidation(long Id);

        [OperationContract]
        long SaveValidation(long id, string documentType, string parameterField, string parameterDataType, string parameterFieldName, string parameterValue, string parameterMaxValue, string parameterEvaluationType, bool active);

        [OperationContract]
        FeeRules GetFeeRule(long Id);

        [OperationContract]
        long SaveFeeRule(int id, string ruleName, string ruleType, string ruleField, string ruleExecutionType, string ruleExecutionValue, string ruleEvaluationField, string ruleEvaluationDataType, string ruleEvaluationType, string ruleEvaluationValue, string ruleEvaluationMaxValue, bool active);

        [OperationContract]
        bool RunEndOfPeriodLoanRecalculations();

        [OperationContract]
        string CountEndOfPeriodLoanRecalculations();
        #endregion

        #region security
        [OperationContract]
        SignoutResponse Signout(string username);

        [OperationContract]
        PasswordChangeResponse ChangePassword(string username, string oldPassword, string newPassword);

        [OperationContract]
        UserRoleActionResponse AddRole(string username, string userRole);

        [OperationContract]
        UserRoleActionResponse RemoveRole(string username, string userRole);

        [OperationContract]
        UserActionResponse AddUser(string username, string password,int stakeholderId, string roleGroup, string firstName, string surname, string emailAddress, string mobileNumber, bool passwordExpires, bool active, bool locked);

        [OperationContract]
        UserActionResponse UpdateUser(string username, string action);

        [OperationContract]
        List<ApplicationUsers> GetUsers(string filterText);

        [OperationContract]
        ApplicationUsers GetUser(string username);

        [OperationContract]
        List<ApplicationRoles> GetApplicationRoles(string username);

        [OperationContract]
        UserRoleActionResponse AddGroupRole(string username, string userRole);

        [OperationContract]
        UserRoleActionResponse RemoveGroupRole(string username, string userRole);

        [OperationContract]
        List<ApplicationRoleGroups> GetApplicationGroupRoles(string username);

        [OperationContract]
        UserRoleActionResponse AddUserGroup(string group, string description);

        [OperationContract]
        List<ApplicationRoles> GetApplicationUserGroupRoles(string group);

        [OperationContract]
        UserRoleActionResponse AddUserGroupRole(string group, string userRole);

        [OperationContract]
        UserRoleActionResponse RemoveUserGroupRole(string group, string userRole);

        [OperationContract]
        string DefaultPassword();
        #endregion

        #region site visit
        [OperationContract]
        List<SiteVisitReport> GetSiteVisitReports(long siteVisitId);

        [OperationContract]
        long SaveSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId,string comments);

        [OperationContract]
        SiteVisitReport GetSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId);

        [OperationContract]
        bool RemoveSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId);

        [OperationContract]
        bool ConfirmSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId);
        
        [OperationContract]
        long CreateWorkflowSiteVisit(long Id, string entityType);

        [OperationContract]
        long CreateWorkflowRecommendationSiteVisit(long Id, string entityType, long recommendationId);

        [OperationContract]
        SiteVisit GetCurrentWorkflowSiteVisit(long Id, string entityType);

        [OperationContract]
        SiteVisit GetSiteVisit(long Id);

        [OperationContract]
        long CreateSiteVisit(long Id);

        [OperationContract]
        SiteVisit GetCurrentWorkflowRecommendationSiteVisit(long recommendationId, long Id, string entityType);

        [OperationContract]
        bool UploadSiteVisitWorkFlowDocument(long siteVisitId, int stakeholderId,string comments, long Id, string entityType, string fileName, byte[] fileData, int documentTypeId, long documentFolderId);
        
        [OperationContract]
        bool SaveSiteVisit(SiteVisit site);

        [OperationContract]
        bool ScheduleSiteVisit(SiteVisit site);

        [OperationContract]
        bool NotifySiteVisit(long Id);

        [OperationContract]
        bool UpdateSiteVisitRequest(long siteId, bool require, string comment, bool officer, long Id, string entityType);

        [OperationContract]
        bool ConfirmSiteVisit(long Id);

        [OperationContract]
        bool UnConfirmSiteVisit(long Id);

        [OperationContract]
        List<SiteVisit> GetSiteVisits(long busId);
        #endregion

        #region invoices
        [OperationContract]
        List<Invoice> GetInvoices(string filterText);

        [OperationContract]
        Invoice GetInvoice(long Id);

        [OperationContract]
        string PayInvoice(long Id, string currency, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId);

        [OperationContract]
        List<InvoiceItem> GetInvoiceItems(long Id);
        #endregion

        #region recommendations
        [OperationContract]
        List<RecommendedAction> GetRecommendedActions(long fK_RecommendationId);

        [OperationContract]
        long SaveRecommendedAction(long fK_RecommendationId, int fK_StakeholderId, int fK_ActionId, string details, bool reminder, string status, string statusReason, bool active);

        [OperationContract]
        RecommendedAction GetRecommendedAction(long fK_RecommendationId, int fK_StakeholderId);

        [OperationContract]
        long CreateWorkflowRecommendations(long Id, string entityType);

        [OperationContract]
        Recommendations GetCurrentWorkflowRecommendations(long Id, string entityType);
        #endregion

        #region national residence
        [OperationContract]
        Resident GetResident(string nIN);

        [OperationContract]
        Business GetBusiness(string bRN);
        #endregion

        #region old db

        [OperationContract]
        List<oldLoanRequest> GetoldLoanRequests(string filterText);

        [OperationContract]
        List<oldRecovery> GetoldRecoverys(string filterText);

        [OperationContract]
        List<oldRepayments> GetoldRepayments(string filterText);

        #endregion
    }

}
