﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SBFA
{
    public partial class Utilities
    {
        public static List<PickList> GetPickList(string type)
        {
            List<PickList> response = new List<PickList>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Name from " + Utilities.GetEntityTable(type));
            while (reader.Reader.Read())
            {
                PickList list = new PickList();
                list.Id = long.Parse(reader.Reader["Id"].ToString());
                list.Text = (reader.Reader["Name"].ToString());

                response.Add(list);
            }
            reader.Close();
            return response;
        }

        public static List<PickList> GetPickList(string type, int parentId)
        {
            List<PickList> response = new List<PickList>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Name from " + Utilities.GetEntityTable(type) + " where FK_ParentId="+parentId);
            while (reader.Reader.Read())
            {
                PickList list = new PickList();
                list.Id = long.Parse(reader.Reader["Id"].ToString());
                list.Text = (reader.Reader["Name"].ToString());

                response.Add(list);
            }
            reader.Close();
            return response;
        }

        public static string GetEntityTable(string entityId)
        {
            string response = "";
            switch (entityId.ToLower())
            {
                case "loan":
                    response = "LoanRequest";
                    break;
                case "loaapp":
                    response = "LoanRequestApproval";
                    break;
                case "bustyp":
                    response = "BusinessType";
                    break;
                case "busregtyp":
                    response = "BusinessRegistrationType";
                    break;
                case "isl":
                    response = "Island";
                    break;
                case "dis":
                    response = "District";
                    break;
                case "edu":
                    response = "EducationLevel";
                    break;
                case "paymet":
                    response = "PaymentMethod";
                    break;
                case "finins":
                    response = "FinanceInstitution";
                    break;
                case "doctyp":
                    response = "DocumentTypes";
                    break;
                case "rolgro":
                    response = "ApplicationRoleGroups";
                    break;
                case "approl":
                    response = "ApplicationRoles";
                    break;
                case "stahol":
                    response = "Stakeholder";
                    break;
                case "sitvistyp":
                    response = "SiteVisitType";
                    break;
                case "bra":
                    response = "Branch";
                    break;
                case "cur":
                    response = "Currency";
                    break;
                case "act":
                    response = "Action";
                    break;
                case "sec":
                    response = "SecurityTypes";
                    break;
                case "ban":
                    response = "Bank";
                    break;
                default:
                    response = "LoanRequest";
                    break;
            }
            return response;
        }

        public static List<PickList> GetUserPickList(string groupType)
        {
            List<PickList> response = new List<PickList>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,(COALESCE(FirstName, '') + ' ' + COALESCE(Surname, '') ) as Name from ApplicationUsers where  Username in (select Username from ApplicationRoleGroupAssignedRoles where FK_RoleGroupId in (select Id from ApplicationRoleGroups where Name='" + groupType + "'))");
            while (reader.Reader.Read())
            {
                PickList list = new PickList();
                list.Id = long.Parse(reader.Reader["Id"].ToString());
                list.Text = (reader.Reader["Name"].ToString());

                response.Add(list);
            }
            reader.Close();
            return response;
        }
        
        public static string GetEntityName(long Id,string type)
        {
            try
            {
                return Utilities.ExecuteScalar("select Name from " + GetEntityTable(type) + " where Id=" + Id);
            }
            catch
            {
                return "";
            }
        }

        public static List<ReferenceTable> GetReferenceTableItems(string type)
        {
            List<ReferenceTable> response = new List<ReferenceTable>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from " + Utilities.GetEntityTable(type));
            while (reader.Reader.Read())
            {
                ReferenceTable refTbale = new ReferenceTable();
                refTbale.Id = int.Parse(reader.Reader["Id"].ToString());
                refTbale.FK_ParentId = int.Parse(reader.Reader["FK_ParentId"].ToString());
                refTbale.Name = (reader.Reader["Name"].ToString());
                refTbale.Description = (reader.Reader["Description"].ToString());
                refTbale.Active = bool.Parse(reader.Reader["Active"].ToString());
                refTbale.Created = DateTime.Now;
                refTbale.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                refTbale.LastModified = DateTime.Now;
                refTbale.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(refTbale);
            }
            reader.Close();
            return response;
        }

        public static bool SaveReferenceTable(string name, string description, bool active, string type, int fK_ParentId)
        {
            ReferenceTable refTable = new ReferenceTable(name, description, active, type, fK_ParentId);
            return refTable.Save();
        }

        public static ReferenceTable GetReferenceTableItem(long Id, string type)
        {
            ReferenceTable refTable = new ReferenceTable(Id, type);
            return refTable;
        }

        public static ReferenceTable GetReferenceTableItem(string name, string type)
        {
            ReferenceTable refTable = new ReferenceTable(name, type);
            return refTable;
        }

        public static List<Stakeholder> GetStakeholders()
        {
            List<Stakeholder> response = new List<Stakeholder>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Stakeholder");
            while (reader.Reader.Read())
            {
                Stakeholder stake = new Stakeholder();
                stake.Id = int.Parse(reader.Reader["Id"].ToString());
                stake.Name = (reader.Reader["Name"].ToString());
                stake.Description = (reader.Reader["Description"].ToString());
                stake.Email = (reader.Reader["Email"].ToString());
                stake.Mobile = (reader.Reader["Mobile"].ToString());
                stake.Active = bool.Parse(reader.Reader["Active"].ToString());
                stake.Created = DateTime.Now;
                stake.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                stake.LastModified = DateTime.Now;
                stake.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(stake);
            }
            reader.Close();
            return response;
        }

        public static long SaveStakeholder(string name, string description, string mobile, string email, bool active)
        {
            Stakeholder stake = new Stakeholder(name, description, mobile,  email, active);
            return stake.Save();
        }

        public static Stakeholder GetStakeholder(long Id)
        {
            Stakeholder stake = new Stakeholder(Id);
            return stake;
        }

        public static List<Stakeholder> GetBusinessTypeStakeholders(int businessTypeId)
        {
            List<Stakeholder> response = new List<Stakeholder>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Stakeholder where Id in (select FK_StakeholderId from BusinessTypeStakeholder where FK_BusinessTypeId=" + businessTypeId + ")");
            while (reader.Reader.Read())
            {
                Stakeholder stake = new Stakeholder();
                stake.Id = int.Parse(reader.Reader["Id"].ToString());
                stake.Name = (reader.Reader["Name"].ToString());
                stake.Description = (reader.Reader["Description"].ToString());
                stake.Email = (reader.Reader["Email"].ToString());
                stake.Mobile = (reader.Reader["Mobile"].ToString());
                stake.Active = bool.Parse(reader.Reader["Active"].ToString());
                stake.Created = DateTime.Now;
                stake.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                stake.LastModified = DateTime.Now;
                stake.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(stake);
            }
            reader.Close();
            return response;
        }

        public static bool SaveBusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId, bool stakeholderRequired)
        {
            BusinessTypeStakeholder stake = new BusinessTypeStakeholder(fK_BusinessTypeId, fK_StakeholderId, stakeholderRequired);
            return stake.Save();
        }

        public static BusinessTypeStakeholder GetBusinessTypeStakeholder(long Id)
        {
            BusinessTypeStakeholder stake = new BusinessTypeStakeholder(Id);
            return stake;
        }

        public static List<ReferenceTable> GetStakeholderBusinessTypes(int stakeholderId)
        {
            List<ReferenceTable> response = new List<ReferenceTable>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BusinessType where Id in (select FK_BusinessTypeId from BusinessTypeStakeholder where FK_StakeholderId=" + stakeholderId +")");
            while (reader.Reader.Read())
            {
                ReferenceTable refTbale = new ReferenceTable();
                refTbale.Id = int.Parse(reader.Reader["Id"].ToString());
                refTbale.Name = (reader.Reader["Name"].ToString());
                refTbale.Description = (reader.Reader["Description"].ToString());
                refTbale.Active = bool.Parse(reader.Reader["Active"].ToString());
                refTbale.Created = DateTime.Now;
                refTbale.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                refTbale.LastModified = DateTime.Now;
                refTbale.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(refTbale);
            }
            reader.Close();
            return response;
        }

        public static bool RemoveBusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId)
        {
            return BusinessTypeStakeholder.Remove(fK_BusinessTypeId, fK_StakeholderId);
        }

        public static AutoDocumentsDesign GetAutoDocumentsDesign(string name)
        {
            AutoDocumentsDesign desg = new AutoDocumentsDesign(name);
            return desg;
        }

        public static List<AutoDocumentsDesign> GetAutoDocumentsDesigns()
        {
            List<AutoDocumentsDesign> response = new List<AutoDocumentsDesign>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from AutoDocumentsDesign");
            while (reader.Reader.Read())
            {
                AutoDocumentsDesign desg = new AutoDocumentsDesign();
                desg.Id = long.Parse(reader.Reader["Id"].ToString());
                desg.DocumentName = (reader.Reader["DocumentName"].ToString());
                desg.DocumentDesign = (reader.Reader["DocumentDesign"].ToString());
                desg.DocumentDesignSMS = (reader.Reader["DocumentDesignSMS"].ToString());
                desg.EmailSubject = (reader.Reader["EmailSubject"].ToString());
                desg.SMS = bool.Parse(reader.Reader["SMS"].ToString());
                desg.Email = bool.Parse(reader.Reader["Email"].ToString());
                desg.Created = DateTime.Now;
                desg.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                desg.LastModified = DateTime.Now;
                desg.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(desg);
            }
            reader.Close();
            return response;
        }

        public static bool SaveAutoDocumentsDesign(string documentName, string documentDesignSMS, string documentDesign, string emailSubject, bool sms, bool email)
        {
            AutoDocumentsDesign desg = new AutoDocumentsDesign(documentName, documentDesignSMS, documentDesign, emailSubject, sms, email);
            return desg.Save();
        }

        public static bool RunEndOfPeriodLoanRecalculations()
        {
            List<BusinessAccount> accounts = Utilities.GetBusinessAccountsWithBalanceForPeriod();
            bool done = true;
            foreach (BusinessAccount acc in accounts)
            {
                DateTime tempDate = (acc.LastCalculationDate.AddMonths(1));
                if (acc.IntrestRate > 0 && (tempDate < DateTime.Now))
                {
                    double newBal = (double)TruncateDecimalPlaces((decimal)Utilities.CalculateBalance(acc.AccountBalance.ToString(), acc.IntrestRate.ToString(), acc.LastCalculationDate),2);

                    //intrest
                    if (newBal > acc.AccountBalance)
                    {
                        DateTime lDt = GetLastCalculationDate(acc.LastCalculationDate);

                        //reord account activity
                        AccountActivity act = new AccountActivity(acc.AccountNumber, 0, "Intrest", "Intrest at rate " + acc.IntrestRate.ToString(), float.Parse((newBal - acc.AccountBalance).ToString()), false);
                        long x = act.Save();
                        BusinessAccount.SetLastCalculationDate(acc.AccountNumber, float.Parse(newBal.ToString()), lDt);

                    }
                }
                    //check for defaulted payments
                    List<RepaymentSchedule> repayments = GetPendingDefaultedRepaymentSchedules(acc.AccountNumber);
                    foreach (RepaymentSchedule repay in repayments)
                    {
                        //fees
                        Fees stageFee = new Fees("penalty", 0);
                        float charge = stageFee.Amount;
                        List<FeeRules> calcFee = Utilities.GetFeeRulesList("penalty");
                        foreach (FeeRules rule in calcFee)
                        {
                            DateTime sd = DateTime.Parse(DateTime.Now.AddDays(-1 * int.Parse(rule.RuleExecutionValue)).ToString("yyyy-MM-dd 01:00:00.000"));
                            DateTime ed = DateTime.Parse(DateTime.Now.AddDays(1 + (-1 * int.Parse(rule.RuleExecutionValue))).ToString("yyyy-MM-dd 01:00:00.000"));
                            if (repay.ExpectedDate > sd && repay.ExpectedDate < ed)
                            {
                                charge += Utilities.CalculatePenaltyFee(rule, repay);
                            }
                        }
                        if (charge > 0)
                        {
                            if (BusinessAccount.AddPenaltyBalance(acc.AccountNumber, charge))
                            {
                                //reord account activity
                                AccountActivity act = new AccountActivity(acc.AccountNumber, repay.Id, "Penalty", "Repayment " + repay.ExpectedDate.ToString("yyyy-MM-dd"), charge, false);
                                act.Save();
                            }
                        }
                    }
                
            }

            //run for ld accounts
            //List<BusinessAccountOld> oldAccounts = Utilities.GetOldBusinessAccountsWithBalanceForPeriod();
            //foreach (BusinessAccountOld acc in oldAccounts)
            //{
            //    DateTime tempDate = (acc.LastCalculationDate.AddMonths(1));
            //    if (acc.IntrestRate > 0 && (tempDate < DateTime.Now))
            //    {
            //        double newBal = (double)TruncateDecimalPlaces((decimal)Utilities.CalculateBalance(acc.AccountBalance.ToString(), acc.IntrestRate.ToString(), acc.LastCalculationDate),2);

            //        //intrest
            //        if (newBal > (double)acc.AccountBalance)
            //        {
            //            DateTime lDt = GetLastCalculationDate(acc.LastCalculationDate);

            //            //reord account activity
            //            OldAccountActivity act = new OldAccountActivity(acc.AccountNumber, acc.LoanNumber, 0, "Intrest", "Intrest at rate " + acc.IntrestRate.ToString(), float.Parse((newBal - (double)acc.AccountBalance).ToString()), false);
            //            long x=act.Save();
            //            LoanIntrestActivity logActivity = new LoanIntrestActivity(acc.LoanNumber, x);
            //            logActivity.Save();
            //            BusinessAccountOld.SetLastCalculationDate(acc.AccountNumber, acc.LoanNumber, float.Parse(newBal.ToString()), lDt);

            //        }
            //    }
            //}
            return done;
        }

        public static string CountEndOfPeriodLoanRecalculations()
        {
            List<BusinessAccount> accounts = Utilities.GetBusinessAccountsWithBalanceForPeriod();
           
            //run for ld accounts
            List<BusinessAccountOld> oldAccounts = Utilities.GetOldBusinessAccountsWithBalanceForPeriod();
            
            return accounts.Count.ToString() + " New : " + oldAccounts.Count.ToString() + " Old";
        }

        public static decimal TruncateDecimalPlaces(decimal val, int places)
        {
            if (places < 0)
            {
                throw new ArgumentException("places");
            }
            return Math.Round(val - Convert.ToDecimal((0.5 / Math.Pow(10, places))), places);
        }


        public struct DateTimeSpan
        {
            private readonly int years;
            private readonly int months;
            private readonly int days;
            private readonly int hours;
            private readonly int minutes;
            private readonly int seconds;
            private readonly int milliseconds;

            public DateTimeSpan(int years, int months, int days, int hours, int minutes, int seconds, int milliseconds)
            {
                this.years = years;
                this.months = months;
                this.days = days;
                this.hours = hours;
                this.minutes = minutes;
                this.seconds = seconds;
                this.milliseconds = milliseconds;
            }

            public int Years { get { return years; } }
            public int Months { get { return months; } }
            public int Days { get { return days; } }
            public int Hours { get { return hours; } }
            public int Minutes { get { return minutes; } }
            public int Seconds { get { return seconds; } }
            public int Milliseconds { get { return milliseconds; } }

            enum Phase { Years, Months, Days, Done }

            public static DateTimeSpan CompareDates(DateTime date1, DateTime date2)
            {
                if (date2 < date1)
                {
                    var sub = date1;
                    date1 = date2;
                    date2 = sub;
                }

                DateTime current = date1;
                int years = 0;
                int months = 0;
                int days = 0;

                Phase phase = Phase.Years;
                DateTimeSpan span = new DateTimeSpan();
                int officialDay = current.Day;

                while (phase != Phase.Done)
                {
                    switch (phase)
                    {
                        case Phase.Years:
                            if (current.AddYears(years + 1) > date2)
                            {
                                phase = Phase.Months;
                                current = current.AddYears(years);
                            }
                            else
                            {
                                years++;
                            }
                            break;
                        case Phase.Months:
                            if (current.AddMonths(months + 1) > date2)
                            {
                                phase = Phase.Days;
                                current = current.AddMonths(months);
                                if (current.Day < officialDay && officialDay <= DateTime.DaysInMonth(current.Year, current.Month))
                                    current = current.AddDays(officialDay - current.Day);
                            }
                            else
                            {
                                months++;
                            }
                            break;
                        case Phase.Days:
                            if (current.AddDays(days + 1) > date2)
                            {
                                current = current.AddDays(days);
                                var timespan = date2 - current;
                                span = new DateTimeSpan(years, months, days, timespan.Hours, timespan.Minutes, timespan.Seconds, timespan.Milliseconds);
                                phase = Phase.Done;
                            }
                            else
                            {
                                days++;
                            }
                            break;
                    }
                }

                return span;
            }
        }

        static DateTime GetLastCalculationDate(DateTime lastPay)
        {
            DateTime compareTo = lastPay;
            DateTime now = DateTime.Now;
            var dateSpan = DateTimeSpan.CompareDates(compareTo, now);
            //Console.WriteLine("Years: " + dateSpan.Years);
            //Console.WriteLine("Months: " + dateSpan.Months);
            //Console.WriteLine("Days: " + dateSpan.Days);
            // Console.WriteLine("Hours: " + dateSpan.Hours);
            // Console.WriteLine("Minutes: " + dateSpan.Minutes);
            // Console.WriteLine("Seconds: " + dateSpan.Seconds);
            // Console.WriteLine("Milliseconds: " + dateSpan.Milliseconds);
            int months = ((dateSpan.Years * 12) + dateSpan.Months);
            return (lastPay.AddMonths(months));
        }

        static double CalculateBalance(string amount, string rate, DateTime lastPay)
        {           
            // Make sure we use types that hold decimal places
            double new_balance, ending_balance;
            double interest_paid, annual_rate, principle_paid, payment;
            ending_balance = (double)TruncateDecimalPlaces((decimal)(Convert.ToDouble(amount)),2);//Convert.ToDouble(amount);
            annual_rate = (double)TruncateDecimalPlaces((decimal)(Convert.ToDouble(rate)), 2);//Convert.ToDouble(rate);
            // Setup a counter to count payments
            int count = 1;
            //get months in between
            DateTime compareTo = lastPay;
            DateTime now = DateTime.Now;
            var dateSpan = DateTimeSpan.CompareDates(compareTo, now);
            //Console.WriteLine("Years: " + dateSpan.Years);
            //Console.WriteLine("Months: " + dateSpan.Months);
            //Console.WriteLine("Days: " + dateSpan.Days);
            // Console.WriteLine("Hours: " + dateSpan.Hours);
            // Console.WriteLine("Minutes: " + dateSpan.Minutes);
            // Console.WriteLine("Seconds: " + dateSpan.Seconds);
            // Console.WriteLine("Milliseconds: " + dateSpan.Milliseconds);          
            int months = ((dateSpan.Years * 12) + dateSpan.Months);          
            // Get our standard payment which is 1/months of loan
            //payment = (ending_balance / months);
            //payment = Convert.ToDouble(monthly);
            while (count <= months)
            {
                new_balance = ending_balance;
                // Calculate interest by multiplying rate against balance
                interest_paid = new_balance * (annual_rate / 100 / 12.0);
                // Subtract interest from your payment
                // principle_paid = payment - interest_paid;
                // Subtract final payment from running balance
                ending_balance = new_balance + interest_paid;
                // If the balance remaining plus its interest is less than payment amount
                // Then print out 0 balance, the interest paid and that balance minus the interest will tell us
                // how much principle you paid to get to zero.

                count++;
            }
            return ending_balance;
        }
    }

    public class ReferenceTable
    {
        public ReferenceTable() { }

        public ReferenceTable(long id, string type) {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from " + Utilities.GetEntityTable(type) + " where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Name = (reader.Reader["Name"].ToString());
                this.Description = (reader.Reader["Description"].ToString());
                this.Active = bool.Parse(reader.Reader["Active"].ToString());
                this.FK_ParentId= int.Parse(reader.Reader["FK_ParentId"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.Type = type;
            }
            reader.Close();
        }

        public ReferenceTable(string name, string type)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from " + Utilities.GetEntityTable(type) + " where Name='" + name + "'");
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Name = (reader.Reader["Name"].ToString());
                this.Description = (reader.Reader["Description"].ToString());
                this.Active = bool.Parse(reader.Reader["Active"].ToString());
                this.FK_ParentId = int.Parse(reader.Reader["FK_ParentId"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.Type = type;
            }
            reader.Close();
        }

        public ReferenceTable(string name,string description, bool active, string type, int fK_ParentId) {
            this.Name = name;
            this.Description = description;
            this.Active = active;
            this.Type = type;
            this.FK_ParentId = fK_ParentId;
        }

        public bool Save()
        {
            //check if exists
            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from " + Utilities.GetEntityTable(this.Type) + " where Name='" + this.Name + "'"));
            if (x < 1)
            {
                x = Utilities.ExecuteNonQuery("insert into " + Utilities.GetEntityTable(this.Type) + "(FK_ParentId,Name,Description,Active,Created,CreatedBy,LastModified,LastModifiedBy) values("+this.FK_ParentId + ",'" + this.Name + "','" + this.Description + "','" + ((this.Active) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            }
            else
            {
                x = Utilities.ExecuteNonQuery("update " + Utilities.GetEntityTable(this.Type) + " set Description='" + this.Description + "',Active='" + ((this.Active) ? "True" : "False") + "',FK_ParentId="+this.FK_ParentId+",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Name='" + this.Name + "'");
            }
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public int FK_ParentId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public string Type { get; set; }
    }

    public class Stakeholder
    {
        public Stakeholder() { }

        public Stakeholder(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Stakeholder where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Name = (reader.Reader["Name"].ToString());
                this.Description = (reader.Reader["Description"].ToString());
                this.Email = (reader.Reader["Email"].ToString());
                this.Mobile = (reader.Reader["Mobile"].ToString());
                this.Active = bool.Parse(reader.Reader["Active"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
               
            }
            reader.Close();
        }

        public Stakeholder(string name, string description,string mobile,string email, bool active) {
            this.Name = name;
            this.Description = description;
            this.Mobile = mobile;
            this.Email = email;
            this.Active = active;
        }

        public long Save()
        {
            //check if exists
            long y = -1;
            long x = int.Parse(Utilities.ExecuteScalar("select count(Id) from Stakeholder where Name='" + this.Name + "'"));
            if (x < 1)
            {
                y = Utilities.ExecuteNewRecord("insert into Stakeholder(Name,Description,Mobile,Email,Active,Created,CreatedBy,LastModified,LastModifiedBy) values('" + this.Name + "','" + this.Description + "','" + this.Mobile + "','" + this.Email + "','" + ((this.Active) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            }
            else
            {
                y = Utilities.ExecuteNonQuery("update Stakeholder set Description='" + this.Description + "',Active='" + ((this.Active) ? "True" : "False") + "',Email='" + this.Email + "',Mobile='" + this.Mobile + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Name='" + this.Name + "'");
                y = 0;
            }
            
            return y;
        }

        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class BusinessTypeStakeholder
    {
        public BusinessTypeStakeholder() { }

        public BusinessTypeStakeholder(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BusinessTypeStakeholder where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_BusinessTypeId = int.Parse(reader.Reader["FK_BusinessTypeId"].ToString());
                this.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                this.StakeholderRequired = bool.Parse(reader.Reader["StakeholderRequired"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public BusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId, bool stakeholderRequired)
        {
            this.FK_BusinessTypeId = fK_BusinessTypeId;
            this.FK_StakeholderId = fK_StakeholderId;
            this.StakeholderRequired = stakeholderRequired;
        }

        public bool Save()
        {
            //check if exists
            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from BusinessTypeStakeholder where FK_BusinessTypeId=" + this.FK_BusinessTypeId + " and FK_StakeholderId="+this.FK_StakeholderId));
            if (x < 1)
            {
                x = Utilities.ExecuteNonQuery("insert into BusinessTypeStakeholder(FK_BusinessTypeId,FK_StakeholderId,StakeholderRequired,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_BusinessTypeId + "," + this.FK_StakeholderId + ",'" + ((this.StakeholderRequired) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            }
            else
            {
                x = Utilities.ExecuteNonQuery("update BusinessTypeStakeholder set StakeholderRequired='" + ((this.StakeholderRequired) ? "True" : "False") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_BusinessTypeId=" + this.FK_BusinessTypeId + " and FK_StakeholderId=" + this.FK_StakeholderId);
            }
            return ((x > 0) ? true : false);
        }

        public static bool Remove(int fK_BusinessTypeId, int fK_StakeholderId)
        {
            //check if exists
            int x = Utilities.ExecuteNonQuery("delete from BusinessTypeStakeholder where FK_StakeholderId=" + fK_StakeholderId + " and FK_BusinessTypeId=" + fK_BusinessTypeId);
           
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public int FK_BusinessTypeId { get; set; }
        public int FK_StakeholderId { get; set; }
        public bool StakeholderRequired { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class AutoDocumentsDesign
    {
        public AutoDocumentsDesign() { }

        public AutoDocumentsDesign(string docType)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from AutoDocumentsDesign where DocumentName='" + docType + "'");
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.DocumentName = (reader.Reader["DocumentName"].ToString());
                this.DocumentDesign = (reader.Reader["DocumentDesign"].ToString());
                this.DocumentDesignSMS = (reader.Reader["DocumentDesignSMS"].ToString());
                this.EmailSubject = (reader.Reader["EmailSubject"].ToString());
                this.SMS = bool.Parse(reader.Reader["SMS"].ToString());
                this.Email = bool.Parse(reader.Reader["Email"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public AutoDocumentsDesign(string documentName, string documentDesignSMS, string documentDesign, string emailSubject, bool sms, bool email)
        {
            this.DocumentDesign = documentDesign;
            this.DocumentName = documentName;
            this.EmailSubject = emailSubject;
            this.DocumentDesignSMS = documentDesignSMS;
            this.SMS = sms;
            this.Email = email;
        }

        public bool Save()
        {
            int y = Utilities.ExecuteNonQuery("update AutoDocumentsDesign set DocumentDesignSMS='" + this.DocumentDesignSMS + "',DocumentDesign='" + this.DocumentDesign + "',EmailSubject='" + this.EmailSubject + "',SMS='" + ((this.SMS) ? "True" : "False") + "',Email='" + ((this.Email) ? "True" : "False") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where DocumentName='" + this.DocumentName + "'");
            return ((y > 0) ? true : false);
        }

        public long Id { get; set; }
        public string DocumentName { get; set; }
        public string DocumentDesignSMS { get; set; }
        public string DocumentDesign { get; set; }
        public string EmailSubject { get; set; }
        public bool SMS { get; set; }
        public bool Email { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
}