﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SBFA
{
    public partial class Utilities
    {
        public static List<Loan> GetLoans(string filterText)
        {
            List<Loan> response = new List<Loan>();
            //get loans
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top "+ FilterBatch() + " * from Loan where LoanNumber like '%"+filterText+ "%' or FK_BusinessRegistrationId in (select Id from BusinessRegistration where NIN like '%" + filterText + "%' or FirstNames like '%" + filterText + "%' or LastName like '%" + filterText + "%' or BusinessName like '%" + filterText + "%')");
            while (reader.Reader.Read())
            {
                Loan loan = new Loan();
                loan.Id = long.Parse(reader.Reader["Id"].ToString());
                loan.FK_BusinessRegistrationId = int.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                loan.FK_LoanRequestId = int.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                loan.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                loan.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                loan.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                loan.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                loan.LoanNumber = reader.Reader["LoanNumber"].ToString();
                loan.Currency = reader.Reader["Currency"].ToString();
                loan.ApprovalDate = DateTime.Parse(reader.Reader["ApprovalDate"].ToString());
                loan.Status = reader.Reader["Status"].ToString();
                loan.StatusReason = reader.Reader["StatusReason"].ToString();
                loan.Purpose = reader.Reader["Purpose"].ToString();
                loan.Amount = float.Parse(reader.Reader["Amount"].ToString());
                loan.AmountDisbursed = float.Parse(reader.Reader["AmountDisbursed"].ToString());
                response.Add(loan);
            }
            reader.Close();

            return response;
        }

        public static List<LoanAssesmentSupplier> GetLoanSuppliers(long Id)
        {
            List<LoanAssesmentSupplier> response = new List<LoanAssesmentSupplier>();
            //get loans
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from LoanAssesmentSupplier where FK_LoanRequestId="+ Id);
            while (reader.Reader.Read())
            {
                LoanAssesmentSupplier loan = new LoanAssesmentSupplier();
                loan.Id = long.Parse(reader.Reader["Id"].ToString());
                loan.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                loan.Supplier = reader.Reader["Supplier"].ToString();
                loan.Description = reader.Reader["Description"].ToString();
                loan.Quantity = float.Parse(reader.Reader["Quantity"].ToString());
                loan.Currency = reader.Reader["Currency"].ToString();
                loan.Price = float.Parse(reader.Reader["Price"].ToString());
                loan.PriceDisbursed = float.Parse(reader.Reader["PriceDisbursed"].ToString());
                response.Add(loan);
            }
            reader.Close();

            return response;
        }

        public static Loan GetLoan(long Id)
        {
            return new Loan(Id);
        }

        public static Loan GetLoanByRequestId(long requestId)
        {
            long Id = long.Parse(Utilities.ExecuteScalar("select Id from Loan where FK_LoanRequestId="+ requestId));
            return new Loan(Id);
        }

        public static long SaveDisbursementRequest(DisbursementRequest disbursement)
        {
            return disbursement.Save();
        }

        public static List<DisbursementRequestSupplier> GetDisbursementRequestSuppliers(long Id)
        {
            List<DisbursementRequestSupplier> response = new List<DisbursementRequestSupplier>();
            //get loans
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from DisbursementRequestSupplier where FK_DisbursementRequestId=" + Id);
            while (reader.Reader.Read())
            {
                DisbursementRequestSupplier loan = new DisbursementRequestSupplier();
                loan.Id = long.Parse(reader.Reader["Id"].ToString());
                loan.FK_DisbursementRequestId = long.Parse(reader.Reader["FK_DisbursementRequestId"].ToString());
                loan.Supplier = reader.Reader["Supplier"].ToString();              
                loan.Currency = reader.Reader["Currency"].ToString();
                loan.Price = float.Parse(reader.Reader["Amount"].ToString());
                response.Add(loan);
            }
            reader.Close();

            return response;
        }

        public static List<DisbursementRequest> GetDisbursementRequests(string filterText)
        {
            List<DisbursementRequest> response = new List<DisbursementRequest>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT top " + FilterBatch() + " * FROM DisbursementRequest where (ApprovalStatus='Signed' or ApprovalStatus='Voucher Raised') and FK_LoanRequestId in (select FK_LoanRequestId from BusinessRegistration where NIN like '%" + filterText + "%' or FirstNames like '%" + filterText + "%' or LastName like '%" + filterText + "%' or BusinessName like '%" + filterText + "%')");
            while (reader.Reader.Read())
            {
                DisbursementRequest disb = new DisbursementRequest();
                disb.Id = long.Parse(reader.Reader["Id"].ToString());
                disb.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                disb.DisbursementCurrency = (reader.Reader["DisbursementCurrency"].ToString());
                disb.DisbursementAmount = float.Parse(reader.Reader["DisbursementAmount"].ToString());
                disb.ProcessStartDate = DateTime.Parse(reader.Reader["ProcessStartDate"].ToString());
                disb.ProcessEndDate = DateTime.Parse(reader.Reader["ProcessEndDate"].ToString());
                disb.ApprovalStatus = (reader.Reader["ApprovalStatus"].ToString());
                disb.DeclineReason = (reader.Reader["DeclineReason"].ToString());
                disb.DeclinedApprovedBy = (reader.Reader["DeclinedApprovedBy"].ToString());
                disb.ChequeNo = (reader.Reader["ChequeNo"].ToString());
                response.Add(disb);
            }
            reader.Close();

            return response;

        }

        public static List<DisbursementRequest> GetActiveDisbursementRequests(string filterText)
        {
            List<DisbursementRequest> response = new List<DisbursementRequest>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT top " + FilterBatch() + " * FROM DisbursementRequest where ApprovalStatus <> 'Disbursed' and FK_LoanRequestId in (select FK_LoanRequestId from BusinessRegistration where NIN like '%" + filterText + "%' or FirstNames like '%" + filterText + "%' or LastName like '%" + filterText + "%' or BusinessName like '%" + filterText + "%')");
            while (reader.Reader.Read())
            {
                DisbursementRequest disb = new DisbursementRequest();
                disb.Id = long.Parse(reader.Reader["Id"].ToString());
                disb.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                disb.DisbursementCurrency = (reader.Reader["DisbursementCurrency"].ToString());
                disb.DisbursementAmount = float.Parse(reader.Reader["DisbursementAmount"].ToString());
                disb.ProcessStartDate = DateTime.Parse(reader.Reader["ProcessStartDate"].ToString());
                disb.ProcessEndDate = DateTime.Parse(reader.Reader["ProcessEndDate"].ToString());
                disb.ApprovalStatus = (reader.Reader["ApprovalStatus"].ToString());
                disb.DeclineReason = (reader.Reader["DeclineReason"].ToString());
                disb.DeclinedApprovedBy = (reader.Reader["DeclinedApprovedBy"].ToString());
                disb.ChequeNo = (reader.Reader["ChequeNo"].ToString());
                response.Add(disb);
            }
            reader.Close();

            return response;

        }

        public static DisbursementRequest GetDisbursementRequest(long Id)
        {
            DisbursementRequest disbursement = new DisbursementRequest(Id);
            return disbursement;
        }

        public static List<DisbursementRequest> GetDisbursementRequests(long loanId)
        {
            List<DisbursementRequest> response = new List<DisbursementRequest>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM DisbursementRequest where FK_LoanRequestId="+loanId+" order by Id desc");
            while (reader.Reader.Read())
            {
                DisbursementRequest disb = new DisbursementRequest();
                disb.Id = long.Parse(reader.Reader["Id"].ToString());
                disb.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                disb.DisbursementCurrency = (reader.Reader["DisbursementCurrency"].ToString());
                disb.DisbursementAmount = float.Parse(reader.Reader["DisbursementAmount"].ToString());
                disb.ProcessStartDate = DateTime.Parse(reader.Reader["ProcessStartDate"].ToString());
                disb.ProcessEndDate = DateTime.Parse(reader.Reader["ProcessEndDate"].ToString());
                disb.ApprovalStatus = (reader.Reader["ApprovalStatus"].ToString());
                disb.DeclineReason = (reader.Reader["DeclineReason"].ToString());
                disb.DeclinedApprovedBy = (reader.Reader["DeclinedApprovedBy"].ToString());
                disb.ChequeNo = (reader.Reader["ChequeNo"].ToString());

                response.Add(disb);
            }
            reader.Close();

            return response;

        }
        
        public static bool SaveLoanAssesment(LoanAssesment loanAss)
        {
            return loanAss.Save();
        }

        public static bool DeleteLoanAssesment(LoanAssesment loanAss)
        {
            return loanAss.Delete();
        }

        public static LoanAssesment GetLoanAssesment(long requestId)
        {
            return new LoanAssesment(requestId);
        }

        public static LoanAssesment GetDisbursementLoanAssesment(long requestId)
        {
            LoanAssesment response = new LoanAssesment();
            LoanAssesment ass= new LoanAssesment(requestId);
            response = ass;
            int cnt = 0;
            foreach(LoanAssesmentSupplier sup in ass.Supplier)
            {
                float disbursed = 0;
                try
                {
                    disbursed = float.Parse(Utilities.ExecuteScalar("select sum(Amount) from DisbursementRequestSupplier where Supplier='" + sup.Supplier + "' and FK_DisbursementRequestId in (select Id from DisbursementRequest where FK_LoanRequestId=" + requestId + ")"));
                }
                catch
                {
                    disbursed = 0;
                }
                    response.Supplier[cnt].Price = (response.Supplier[cnt].Price - disbursed);
                cnt++;
            }

            return response;
        }

        public static bool UpdateDisbursementStatus(long Id)
        {
            //set notification
            Notifications not = new Notifications("", "Prepare voucher for : " + Id.ToString(), "paymentVoucher",Id);

            return DisbursementRequest.UpdateSigned(Id);
        }

        public static bool DisburseDisbursement(long Id)
        {
            return DisbursementRequest.UpdateDisbursed(Id);
        }

        public static bool CheckVoucher(long disId)
        {
            return PaymentVoucher.CheckVoucher(disId);
        }

        public static long SaveVoucher(PaymentVoucher voucher)
        {
            return voucher.Save();
        }

        public static PaymentVoucher GetPaymentVoucher(long requestId)
        {
            return new PaymentVoucher(requestId);
        }

        public static List<BusinessAccount> GetBusinessAccounts(string filterText)
        {
            List<BusinessAccount> response = new List<BusinessAccount>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT top " + FilterBatch() + " * FROM BusinessAccount where AccountNumber like '%" + filterText + "%' or AccountNumber in (select RegistrationNumber from BusinessRegistration where NIN like '%" + filterText + "%' or FirstNames like '%" + filterText + "%' or LastName like '%" + filterText + "%' or BusinessName like '%" + filterText + "%')");
            while (reader.Reader.Read())
            {
                try
                {
                    BusinessAccount acc = new BusinessAccount();
                    acc.Id = long.Parse(reader.Reader["Id"].ToString());
                    acc.AccountNumber = (reader.Reader["AccountNumber"].ToString());
                    acc.AccountBalance = float.Parse(reader.Reader["AccountBalance"].ToString());
                    acc.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                    acc.CancellationFee = float.Parse(reader.Reader["CancellationFee"].ToString());
                    acc.Refund = float.Parse(reader.Reader["Refund"].ToString());
                    acc.Penalty = float.Parse(reader.Reader["Penalty"].ToString());
                    acc.IntrestRate = float.Parse(reader.Reader["IntrestRate"].ToString());
                    acc.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                    acc.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                    acc.LastPaymentDate = DateTime.Parse(reader.Reader["LastPaymentDate"].ToString());
                    acc.LastCalculationDate = DateTime.Parse(reader.Reader["LastCalculationDate"].ToString());

                    response.Add(acc);
                }catch(Exception ex)
                {

                }
                
            }
            reader.Close();

            return response;
        }

        public static List<BusinessAccount> GetBusinessAccountsWithBalance()
        {
            List<BusinessAccount> response = new List<BusinessAccount>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM BusinessAccount where AccountBalance>0 and StartDate<'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:000") + "'");
            while (reader.Reader.Read())
            {
                BusinessAccount acc = new BusinessAccount();
                acc.Id = long.Parse(reader.Reader["Id"].ToString());
                acc.AccountNumber = (reader.Reader["AccountNumber"].ToString());
                acc.AccountBalance = float.Parse(reader.Reader["AccountBalance"].ToString());
                acc.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                acc.CancellationFee = float.Parse(reader.Reader["CancellationFee"].ToString());
                acc.Refund = float.Parse(reader.Reader["Refund"].ToString());
                acc.Penalty = float.Parse(reader.Reader["Penalty"].ToString());
                acc.IntrestRate = float.Parse(reader.Reader["IntrestRate"].ToString());
                acc.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                acc.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                acc.LastPaymentDate = DateTime.Parse(reader.Reader["LastPaymentDate"].ToString());
                acc.LastCalculationDate = DateTime.Parse(reader.Reader["LastCalculationDate"].ToString());
               
                    response.Add(acc);
            }
            reader.Close();

            return response;
        }

        public static List<BusinessAccount> GetBusinessAccountsWithBalanceForPeriod()
        {
            List<BusinessAccount> response = new List<BusinessAccount>();
            //retrieve registrations details from database
            DateTime tempDate = (DateTime.Now.AddMonths(-1));
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM BusinessAccount where AccountBalance>0 and StartDate<'"+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:000")+ "' and LastCalculationDate <'" + tempDate.ToString("yyyy-MM-dd HH:mm:ss.fff") + "'");
            while (reader.Reader.Read())
            {
                BusinessAccount acc = new BusinessAccount();
                acc.Id = long.Parse(reader.Reader["Id"].ToString());
                acc.AccountNumber = (reader.Reader["AccountNumber"].ToString());
                acc.AccountBalance = float.Parse(reader.Reader["AccountBalance"].ToString());
                acc.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                acc.CancellationFee = float.Parse(reader.Reader["CancellationFee"].ToString());
                acc.Refund = float.Parse(reader.Reader["Refund"].ToString());
                acc.Penalty = float.Parse(reader.Reader["Penalty"].ToString());
                acc.IntrestRate = float.Parse(reader.Reader["IntrestRate"].ToString());
                acc.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                acc.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                acc.LastPaymentDate = DateTime.Parse(reader.Reader["LastPaymentDate"].ToString());
                acc.LastCalculationDate = DateTime.Parse(reader.Reader["LastCalculationDate"].ToString());               
                    response.Add(acc);
            }
            reader.Close();

            return response;
        }

        public static BusinessAccount GetBusinessAccount(string NIN)
        {
            BusinessRegistration bus = new BusinessRegistration(NIN);
            if (bus != null)
                return new BusinessAccount(bus.RegistrationNumber);
            else
                return null;
        }

        public static BusinessAccount GetBusinessAccountByAccount(string acc)
        {
            return new BusinessAccount(acc);
        }

        public static List<RepaymentSchedule> GetRepaymentSchedules(string acc)
        {
            List<RepaymentSchedule> response = new List<RepaymentSchedule>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM RepaymentSchedule where FK_AccountNumber='" + acc + "'");
            while (reader.Reader.Read())
            {
                RepaymentSchedule disb = new RepaymentSchedule();
                disb.Id = long.Parse(reader.Reader["Id"].ToString());
                disb.FK_AccountNumber = (reader.Reader["FK_AccountNumber"].ToString());
                disb.Currency = (reader.Reader["Currency"].ToString());
                disb.Amount = float.Parse(reader.Reader["Amount"].ToString());
                disb.AmountPaid = float.Parse(reader.Reader["AmountPaid"].ToString());
                disb.ExpectedDate = DateTime.Parse(reader.Reader["ExpectedDate"].ToString());
                disb.PaidDate = DateTime.Parse(reader.Reader["PaidDate"].ToString());


                response.Add(disb);
            }
            reader.Close();

            return response;

        }

        public static List<RepaymentSchedule> GetPendingRepaymentSchedules(string acc)
        {
            List<RepaymentSchedule> response = new List<RepaymentSchedule>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM RepaymentSchedule where FK_AccountNumber='" + acc + "' order by ExpectedDate asc");
            while (reader.Reader.Read())
            {
                RepaymentSchedule disb = new RepaymentSchedule();
                disb.Id = long.Parse(reader.Reader["Id"].ToString());
                disb.FK_AccountNumber = (reader.Reader["FK_AccountNumber"].ToString());
                disb.Currency = (reader.Reader["Currency"].ToString());
                disb.Amount = float.Parse(reader.Reader["Amount"].ToString());
                disb.AmountPaid = float.Parse(reader.Reader["AmountPaid"].ToString());
                disb.ExpectedDate = DateTime.Parse(reader.Reader["ExpectedDate"].ToString());
                disb.PaidDate = DateTime.Parse(reader.Reader["PaidDate"].ToString());

                if (disb.Amount > disb.AmountPaid)
                    response.Add(disb);
            }
            reader.Close();

            return response;

        }

        public static List<RepaymentSchedule> GetPendingDefaultedRepaymentSchedules(string acc)
        {
            List<RepaymentSchedule> response = new List<RepaymentSchedule>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM RepaymentSchedule where FK_AccountNumber='" + acc + "' and ExpectedDate<'" + DateTime.Now.ToString("yyyy-MM-dd 23:59:59.000") + "'");
            while (reader.Reader.Read())
            {
                RepaymentSchedule disb = new RepaymentSchedule();
                disb.Id = long.Parse(reader.Reader["Id"].ToString());
                disb.FK_AccountNumber = (reader.Reader["FK_AccountNumber"].ToString());
                disb.Currency = (reader.Reader["Currency"].ToString());
                disb.Amount = float.Parse(reader.Reader["Amount"].ToString());
                disb.AmountPaid = float.Parse(reader.Reader["AmountPaid"].ToString());
                disb.ExpectedDate = DateTime.Parse(reader.Reader["ExpectedDate"].ToString());
                disb.PaidDate = DateTime.Parse(reader.Reader["PaidDate"].ToString());

                if (disb.Amount > disb.AmountPaid)
                    response.Add(disb);
            }
            reader.Close();

            return response;
        }

        public static double PMT(double yearlyInterestRate, int totalNumberOfMonths, double loanAmount)
        {
            var rate = (double)yearlyInterestRate / 100 / 12;
            var denominator = Math.Pow((1 + rate), totalNumberOfMonths) - 1;
            return (rate + (rate / denominator)) * loanAmount;
        }

        public static float CalculateMonthlyRepayment(int months,long requestId)
        {
            //fees
           // Fees stageFee = new Fees("loanIntrest", 0);
            float rate = 0;
            LoanRequest loan = Utilities.GetLoanRequest(requestId);
            List<FeeRules> calcFee = Utilities.GetFeeRulesList("loanIntrest");
            foreach (FeeRules rule in calcFee)
            {
                rate += Utilities.CalculateLoanFee(rule, loan);
            }

            double x = PMT(rate, months, loan.LoanAmountRequested);

            return float.Parse(x.ToString());
        }

        public static float CalculateMonthlyRepayment(int months, string account, float amount)
        {
            //fees
            float rate = 0;
            //get last loan request
            BusinessRegistration br = new BusinessRegistration(account, true);
            long id = long.Parse(Utilities.ExecuteScalar("select top 1 Id from LoanRequest where NIN='"+br.NIN+"' order by Id desc"));
            LoanRequest loan = Utilities.GetLoanRequest(id);
            List<FeeRules> calcFee = Utilities.GetFeeRulesList("loanIntrest");
            foreach (FeeRules rule in calcFee)
            {
                rate += Utilities.CalculateLoanFee(rule, loan);
            }

            //update intrest rate in system
            BusinessAccount.SetRate(account, rate);

            double x = PMT(rate, months, amount);

            return float.Parse(x.ToString());
        }

        public static bool GenerateMonthlyRepayments(int months, string account, float amount, DateTime start)
        {
            //clear pending installs
            int x = Utilities.ExecuteNonQuery("delete from RepaymentSchedule where FK_AccountNumber='" + account + "' and AmountPaid=0");
            for (int a = 0; a < months; a++)
            {
                DateTime dt = start.AddMonths(a);
                RepaymentSchedule rep = new RepaymentSchedule(account, "SCR", amount, dt);
                rep.Save();
                if (a == (months - 1))
                {
                    BusinessAccount.SetDates(account, start, dt);
                }
            }

            return true;
        }

        public static string ReceiptRepayment(string account, string currency,float balance,float amount, int fK_PayBranchId, int fK_PaymentMethodId,DateTime lastPaymentDate)
        {
            string refNo = account+ "_"+ Utilities.ExecuteScalar("select count(FK_ReferenceNumber) from Invoice where FK_ReferenceNumber like '"+account+"%'");

            Invoice newInvoice = new Invoice(refNo, currency, amount, false, "repayment", 0, 0, 0, 0, 0);
            long invNum = newInvoice.Save();
            if (invNum > 0)
            {               
                    InvoiceItem temp = new InvoiceItem(invNum, currency, amount, "Loan Repayment for "+account);
                    temp.Save();

                //pay invoice
                return PayRepaymentInvoice(invNum, currency,balance, amount, 0, fK_PayBranchId, fK_PaymentMethodId,account,lastPaymentDate);
            }
            else
            {
                return "0";
            }
        }

        public static string ReceiptFeeRepayment(string account, string currency, float amount, int fK_PayBranchId, int fK_PaymentMethodId)
        {
            string refNo = account + "_" + Utilities.ExecuteScalar("select count(FK_ReferenceNumber) from Invoice where FK_ReferenceNumber like '" + account + "%'");

            Invoice newInvoice = new Invoice(refNo, currency, amount, false, "fee", 0, 0, 0, 0, 0);
            long invNum = newInvoice.Save();
            if (invNum > 0)
            {
                InvoiceItem temp = new InvoiceItem(invNum, currency, amount, "Loan Fee for " + account);
                temp.Save();

                //pay invoice
                return PayRepaymentInvoice(invNum, currency,  amount, 0, fK_PayBranchId, fK_PaymentMethodId, account);
            }
            else
            {
                return "0";
            }
        }

        public static string PayRepaymentInvoice(long Id, string currency, float balance, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId,string account, DateTime lastPaymentDate)
        {
            Invoice invoice = new Invoice(Id);
            string receipt = invoice.Pay(currency, amount, change, fK_PayBranchId, fK_PaymentMethodId);
            invoice.ReceiptNumber = receipt;
            if (receipt != "0")
            {
                //reord account activity
                AccountActivity act = new AccountActivity(account, Id, "Repayment", "Receipt " + receipt, amount, true);
                act.Save();

                //update last payment date
                BusinessAccount.SetLastCalculationDate(account, balance, lastPaymentDate);
                //process installment update
                List<RepaymentSchedule> schedules = Utilities.GetPendingRepaymentSchedules(account);
                float temp = amount;
                foreach (RepaymentSchedule schedule in schedules)
                {
                    float bal = schedule.Amount - schedule.AmountPaid;
                    if (bal <= temp)
                    {
                        schedule.UpdateBalance(bal);
                        temp -= bal;
                    }
                    else if (temp > 0)
                    {
                        schedule.UpdateBalance(temp);
                        temp = 0;
                    }
                    else
                    {
                        break;
                    }
                }

                try
                {
                    // Utilities.GenerateDocument("ackPayment", invoice, true, true);
                }
                catch { }
            }

            return receipt;
        }

        public static string PayRepaymentInvoice(long Id, string currency, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId, string account)
        {
            Invoice invoice = new Invoice(Id);
            string receipt = invoice.Pay(currency, amount, change, fK_PayBranchId, fK_PaymentMethodId);
            invoice.ReceiptNumber = receipt;
            if (receipt != "0")
            {
                //reord account activity
                AccountActivity act = new AccountActivity(account, Id, "Repayment Fee", "Receipt " + receipt, amount, true);
                act.Save();

                //update last payment date
                BusinessAccount bus = new BusinessAccount(account);
                double fee = bus.ProcessingFee;
                double fee2 = bus.CancellationFee;
                double pen = bus.Penalty;
                double temp = amount;

                if (fee > 0)
                {
                    if (temp >= fee)
                    {
                        if (BusinessAccount.AddProcessingBalance(account, float.Parse((-1 * fee).ToString())))
                            temp = temp - fee;
                    }
                    else
                    {
                        if (BusinessAccount.AddProcessingBalance(account, float.Parse((-1 * temp).ToString())))
                            temp = 0;
                    }
                }

                if (temp > 0 && fee2 > 0)
                {
                    if (temp >= fee2)
                    {
                        if(BusinessAccount.AddCancellationBalance(account, float.Parse((-1 * fee2).ToString())))
                            temp = temp - fee2;
                    }
                    else
                    {
                        if (BusinessAccount.AddCancellationBalance(account, float.Parse((-1 * temp).ToString())))
                            temp = 0;
                    }
                }

                if (temp > 0 && pen > 0)
                {
                    if (temp >= pen)
                    {
                        if (BusinessAccount.AddPenaltyBalance(account, float.Parse((-1 * pen).ToString())))
                            temp = temp - pen;
                    }
                    else
                    {
                        if (BusinessAccount.AddCancellationBalance(account, float.Parse((-1 * temp).ToString())))
                            temp = 0;
                    }
                }
                
                try
                {
                    // Utilities.GenerateDocument("ackPayment", invoice, true, true);
                }
                catch { }
            }

            return receipt;
        }
        
        public static List<RepaymentSchedule> FindPendingRepaymentSchedules(string filterText)
        {
            List<RepaymentSchedule> response = new List<RepaymentSchedule>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM RepaymentSchedule where FK_AccountNumber like '%" + filterText + "%' and ExpectedDate<'"+DateTime.Now.ToString("yyyy-MM-dd 01:00:00.000")+"' order by ExpectedDate desc");
            while (reader.Reader.Read())
            {
                RepaymentSchedule disb = new RepaymentSchedule();
                disb.Id = long.Parse(reader.Reader["Id"].ToString());
                disb.FK_AccountNumber = (reader.Reader["FK_AccountNumber"].ToString());
                disb.Currency = (reader.Reader["Currency"].ToString());
                disb.Amount = float.Parse(reader.Reader["Amount"].ToString());
                disb.AmountPaid = float.Parse(reader.Reader["AmountPaid"].ToString());
                disb.ExpectedDate = DateTime.Parse(reader.Reader["ExpectedDate"].ToString());
                disb.PaidDate = DateTime.Parse(reader.Reader["PaidDate"].ToString());

                if (disb.Amount > disb.AmountPaid)
                    response.Add(disb);
            }
            reader.Close();

            return response;

        }

        public static WarningLetter GetWarningStage(long fK_RepaymentId)
        {
            return new WarningLetter(fK_RepaymentId);
        }

        public static bool SetWarningStage(long fK_RepaymentId, string warningStage,string remark,bool responded)
        {
            WarningLetter letter = new WarningLetter(fK_RepaymentId, warningStage,remark,responded);
            return letter.SaveComment();
        }

        public static bool CheckDisbursementLetter(string docName, long requestId)
        {
            return DisbursementLetter.CheckDisbursementLetter(docName, requestId);
        }

        public static bool CheckFullDisbursement(string account)
        {
            return true;
        }
    }

    public class BusinessEntity
    {
        public BusinessEntity() { }

        public long Id { get; set; }
        public string BusinessRegistrationNumber { get; set; }
        public string BusinessName { get; set; }
        public int FK_BusinessTypeId { get; set; }
        public int FK_BusinessRegistrationTypeId { get; set; }
        public int FK_BusinessIslandLocationId { get; set; }
        public int FK_BusinessIslandDistrictId { get; set; }
        public string SEnPARegistrationNumber { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
    
    public class Loan
    {
        public Loan() { }

        public Loan(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Loan where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_BusinessRegistrationId = int.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                this.FK_LoanRequestId = int.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.LoanNumber = reader.Reader["LoanNumber"].ToString();
                this.Currency = reader.Reader["Currency"].ToString();
                this.ApprovalDate = DateTime.Parse(reader.Reader["ApprovalDate"].ToString());
                this.Status = reader.Reader["Status"].ToString();
                this.StatusReason = reader.Reader["StatusReason"].ToString();
                this.Purpose = reader.Reader["Purpose"].ToString();
                this.Amount = float.Parse(reader.Reader["Amount"].ToString()); 
                    this.AmountDisbursed = float.Parse(reader.Reader["AmountDisbursed"].ToString());
            }
            reader.Close();
        }

        public Loan(long requestId,bool isId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Loan where FK_LoanRequestId=" + requestId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_BusinessRegistrationId = int.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                this.FK_LoanRequestId = int.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.LoanNumber = reader.Reader["LoanNumber"].ToString();
                this.Currency = reader.Reader["Currency"].ToString();
                this.ApprovalDate = DateTime.Parse(reader.Reader["ApprovalDate"].ToString());
                this.Status = reader.Reader["Status"].ToString();
                this.StatusReason = reader.Reader["StatusReason"].ToString();
                this.Purpose = reader.Reader["Purpose"].ToString();
                this.Amount = float.Parse(reader.Reader["Amount"].ToString());
                this.AmountDisbursed = float.Parse(reader.Reader["AmountDisbursed"].ToString());
            }
            reader.Close();
        }

        public long Save()
        {
            try
            {
                SqlCommand command = new SqlCommand("insert into Loan(FK_BusinessRegistrationId,FK_LoanRequestId,LoanNumber,Currency,Amount,AmountDisbursed,Purpose,ApprovalDate,Status,StatusReason,Created,CreatedBy,LastModified,LastModifiedBy) values(@FK_BusinessRegistrationId,@FK_LoanRequestId,@LoanNumber,@Currency,@Amount,@AmountDisbursed,@Purpose,@ApprovalDate,@Status,@StatusReason,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");

                command.Parameters.Add(new SqlParameter("@FK_BusinessRegistrationId", this.FK_BusinessRegistrationId));
                command.Parameters.Add(new SqlParameter("@FK_LoanRequestId", this.FK_LoanRequestId));
                command.Parameters.Add(new SqlParameter("@LoanNumber", this.LoanNumber));
                command.Parameters.Add(new SqlParameter("@Currency", this.Currency));
                command.Parameters.Add(new SqlParameter("@Amount", this.Amount));
                command.Parameters.Add(new SqlParameter("@AmountDisbursed", this.AmountDisbursed));                
                command.Parameters.Add(new SqlParameter("@Purpose", this.Purpose));
                command.Parameters.Add(new SqlParameter("@ApprovalDate", this.ApprovalDate));
                command.Parameters.Add(new SqlParameter("@Status", this.Status));
                command.Parameters.Add(new SqlParameter("@StatusReason", this.StatusReason));
                command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
                command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));
                this.Id = Utilities.ExecuteNewRecord(command);
            }
            catch
            {

            }

            return this.Id;
        }

        public static bool Disbursed(long id, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update Loan set AmountDisbursed+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id='" + id + "'");

            return ((x > 0) ? true : false);
        }

        public static bool FullyDisbursed(long id)
        {
            long x = Utilities.ExecuteNonQuery("update Loan set [Status]='Disbursed' where Id='" + id + "'");

            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_BusinessRegistrationId { get; set; }
        public long FK_LoanRequestId { get; set; }
        public string LoanNumber { get; set; }
        public string Currency { get; set; }
        public float Amount { get; set; }
        public float AmountDisbursed { get; set; }
        public string Purpose { get; set; }
        public DateTime ApprovalDate { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }       
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        
    }

    public class LoanAssesment
    {
        public LoanAssesment() { }

        public LoanAssesment(long requestId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from LoanAssesment where FK_LoanRequestId=" + requestId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());                
                this.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                this.Total = float.Parse(reader.Reader["Total"].ToString());
                this.FinancialCommitment = reader.Reader["FinancialCommitment"].ToString();
                this.Condition = reader.Reader["Condition"].ToString();
                this.LoanAmount = float.Parse(reader.Reader["LoanAmount"].ToString());
                this.PaybackPeriod = int.Parse(reader.Reader["PaybackPeriod"].ToString());
                this.MonthlyRepayment = float.Parse(reader.Reader["MonthlyRepayment"].ToString());
                this.GracePeriod = int.Parse(reader.Reader["GracePeriod"].ToString());
                this.Analysis = reader.Reader["Analysis"].ToString();
                this.Supplier = Utilities.GetLoanSuppliers(this.FK_LoanRequestId);
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.ProposedLoanAmount = float.Parse(reader.Reader["ProposedLoanAmount"].ToString());
            }
            reader.Close();
        }
        
        public long Create()
        {
            //fees
            Fees stageFee = new Fees("loanAssesment", 0);
            float charge = stageFee.Amount;
            List<FeeRules> calcFee = Utilities.GetFeeRulesList("loanAssesment");
            foreach (FeeRules rule in calcFee)
            {
                charge += Utilities.CalculateLoanFee(rule, Utilities.GetLoanRequest(this.FK_LoanRequestId));
            }

            long x = Utilities.ExecuteNewRecord("insert into LoanAssesment(FK_LoanRequestId,ProcessingFee,Total,FinancialCommitment,Condition,LoanAmount,PaybackPeriod,MonthlyRepayment,GracePeriod,Analysis,Created,CreatedBy,LastModified,LastModifiedBy,ProposedLoanAmount) values(" + this.FK_LoanRequestId + ","+charge+", "+(this.LoanAmount-charge)+", '', '', " + this.LoanAmount + ", 12, "+Utilities.CalculateMonthlyRepayment(12, this.FK_LoanRequestId) +", 0, '', CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "'," + this.LoanAmount + ")");
            if (x > 0)
            {
                this.Id = x;
            }
            return x;
        }
         
        public bool Save()
        {
            long x = Utilities.ExecuteNonQuery("update LoanAssesment set ProposedLoanAmount="+ ProposedLoanAmount + ",ProcessingFee = " + ProcessingFee + ", Total = "+ Total + ", FinancialCommitment = '"+ FinancialCommitment + "', Condition = '"+ Condition + "', LoanAmount = "+ LoanAmount + ", PaybackPeriod = "+ PaybackPeriod + ", MonthlyRepayment = "+ MonthlyRepayment + ", GracePeriod = "+ GracePeriod + ", Analysis='"+ Analysis + "', LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_LoanRequestId=" + FK_LoanRequestId);
            //check current supplier total
            float ttl = 0;
            try
            {
                ttl = float.Parse(Utilities.ExecuteScalar("select sum(Price) from LoanAssesmentSupplier where FK_LoanRequestId=" + this.FK_LoanRequestId));
            }
            catch { }
            //save suppliers
            foreach (LoanAssesmentSupplier sup in this.Supplier)
            {
                //first check ass total
                if ((sup.Price + ttl) > this.Total)
                    x = 0;
                else
                    sup.Save();
            }
            return ((x > 0) ? true : false);
        }

        public bool Delete()
        {
            //save suppliers
            foreach (LoanAssesmentSupplier sup in this.Supplier)
            {
                sup.Delete();
            }
            return true;
        }

        public bool Update(double amount)
        {
            //fees
            Fees stageFee = new Fees("loanAssesment", 0);
            float charge = stageFee.Amount;
            List<FeeRules> calcFee = Utilities.GetFeeRulesList("loanAssesment");
            foreach (FeeRules rule in calcFee)
            {
                charge += Utilities.CalculateLoanFee(rule, Utilities.GetLoanRequest(this.FK_LoanRequestId));
            }

            long x = Utilities.ExecuteNonQuery("update LoanAssesment set ProcessingFee = " + charge + ", Total = " + (amount-charge) + ", LoanAmount = " + amount + ", PaybackPeriod = "+this.PaybackPeriod+", MonthlyRepayment = " + Utilities.CalculateMonthlyRepayment(int.Parse(this.PaybackPeriod.ToString()), this.FK_LoanRequestId) + ", GracePeriod = " + GracePeriod + ", Analysis='" + Analysis + "', LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_LoanRequestId=" + FK_LoanRequestId);
           
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_LoanRequestId { get; set; }
        public float ProcessingFee { get; set; }
        public float Total { get; set; }
        public string FinancialCommitment { get; set; }
        public string Condition { get; set; }
        public float LoanAmount { get; set; }
        public long PaybackPeriod { get; set; }
        public float MonthlyRepayment { get; set; }
        public int GracePeriod { get; set; }
        public string Analysis { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public List<LoanAssesmentSupplier> Supplier { get; set; }

        public float ProposedLoanAmount { get; set; }
    }

    public class LoanAssesmentSupplier
    {
        public LoanAssesmentSupplier() { }

        public LoanAssesmentSupplier(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from LoanAssesmentSupplier where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                this.Supplier = reader.Reader["Supplier"].ToString();
                this.Description = reader.Reader["Description"].ToString();
                this.Quantity = float.Parse(reader.Reader["Quantity"].ToString());
                this.Currency = reader.Reader["Currency"].ToString();
                this.Price = float.Parse(reader.Reader["Price"].ToString());
                this.PriceDisbursed = float.Parse(reader.Reader["PriceDisbursed"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public long Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into LoanAssesmentSupplier(FK_LoanRequestId,Supplier,Description,Quantity,Currency,Price,PriceDisbursed,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_LoanRequestId + ",'"+Supplier+"','"+Description+"',"+Quantity+",'"+Currency+"',"+Price+","+PriceDisbursed+", CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            if (x > 0)
            {
                this.Id = x;
            }
            return x;
        }

        public long Delete()
        {
            long x = Utilities.ExecuteNonQuery("delete from LoanAssesmentSupplier where FK_LoanRequestId=" + this.FK_LoanRequestId + " and Supplier='" + Supplier + "'");
            if (x > 0)
            {
                this.Id = x;
            }
            return x;
        }

        public bool Update()
        {
            long x = Utilities.ExecuteNonQuery("update LoanAssesmentSupplier set Supplier = '" + Supplier + "', Description = '" + Description + "', Quantity = " + Quantity + ", Currency = '" + Currency + "', Price = " + Price + ", LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_LoanRequestId { get; set; }
        public string Supplier { get; set; }
        public string Description { get; set; }
        public float Quantity { get; set; }
        public string Currency { get; set; }
        public float Price { get; set; }
        public float PriceDisbursed { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class LoanApprovalRecommendations
    {
        public LoanApprovalRecommendations() { }

        public LoanApprovalRecommendations(long fK_LoanRequestId , string fK_Stage,bool approved, string recommendation) {
            this.FK_LoanRequestId = fK_LoanRequestId;
            this.FK_Stage = fK_Stage;
            this.Approved = approved;
            this.Recommendation = recommendation;
        }

        public bool Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into LoanApprovalRecommendations(FK_LoanRequestId,FK_Stage,Approved,Recommendation,Created,CreatedBy) values(" + this.FK_LoanRequestId + ",'" + this.FK_Stage + "','"+((this.Approved)?"True":"False")+"','"+this.Recommendation + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

            return ((x>0)?true:false);
        }

        public long Id { get; set; }
        public long FK_LoanRequestId { get; set; }
        public string FK_Stage { get; set; }
        public bool Approved { get; set; }
        public string Recommendation { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
    }
    
    public class DisbursementRequest
    {
        public DisbursementRequest()
        {

        }

        public DisbursementRequest(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from DisbursementRequest where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                this.DisbursementCurrency = (reader.Reader["DisbursementCurrency"].ToString());
                this.DisbursementAmount = float.Parse(reader.Reader["DisbursementAmount"].ToString());
                this.ProcessStartDate = DateTime.Parse(reader.Reader["ProcessStartDate"].ToString());
                this.ProcessEndDate = DateTime.Parse(reader.Reader["ProcessEndDate"].ToString());
                this.ApprovalStatus = (reader.Reader["ApprovalStatus"].ToString());
                this.DeclineReason = (reader.Reader["DeclineReason"].ToString());
                this.DeclinedApprovedBy = (reader.Reader["DeclinedApprovedBy"].ToString());
                this.Supplier = Utilities.GetDisbursementRequestSuppliers(this.Id);
                this.ChequeNo = (reader.Reader["ChequeNo"].ToString());
            }
            reader.Close();
        }

        public float PreviousDisbursementAmount()
        {
            float amount = 0;
            bool there = false;

            List<DisbursementRequest> lstDisburse = Utilities.GetDisbursementRequests(this.FK_LoanRequestId);
            int cnt = lstDisburse.Count;
            for (int x = 0; x < cnt; x++)
            {
                if (there)
                {
                    amount += lstDisburse[x].DisbursementAmount;
                    break;
                }

                if ((lstDisburse[x].Id == this.Id))
                {
                    there=true;
                }
                
            }
            
            return amount;
        }

        public long Save()
        {

            SqlCommand command;
            
            if(this.Id==0)
           command = new SqlCommand("INSERT INTO DisbursementRequest(FK_LoanRequestId,DisbursementCurrency,DisbursementAmount,ProcessStartDate,ProcessEndDate,ApprovalStatus,DeclineReason,DeclinedApprovedBy,Created,CreatedBy,LastModified,LastModifiedBy,ChequeNo) values(@FK_LoanRequestId,@DisbursementCurrency,@DisbursementAmount,@ProcessStartDate,@ProcessEndDate,@ApprovalStatus,@DeclineReason,@DeclinedApprovedBy,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy,@ChequeNo)");
            else
                command = new SqlCommand("update DisbursementRequest set DisbursementCurrency='"+DisbursementCurrency+"',DisbursementAmount="+DisbursementAmount+ ",ChequeNo='"+ ChequeNo + "' where Id=" + this.Id);

            command.Parameters.Add(new SqlParameter("@FK_LoanRequestId", this.FK_LoanRequestId));
            command.Parameters.Add(new SqlParameter("@DisbursementCurrency", this.DisbursementCurrency));
            command.Parameters.Add(new SqlParameter("@DisbursementAmount", this.DisbursementAmount));
            command.Parameters.Add(new SqlParameter("@ProcessStartDate", this.ProcessStartDate));
            command.Parameters.Add(new SqlParameter("@ProcessEndDate", this.ProcessEndDate));
            command.Parameters.Add(new SqlParameter("@ApprovalStatus", this.ApprovalStatus));
            command.Parameters.Add(new SqlParameter("@DeclineReason", this.DeclineReason));
            command.Parameters.Add(new SqlParameter("@DeclinedApprovedBy", this.DeclinedApprovedBy));
            command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@ChequeNo", this.ChequeNo));

            if (this.Id == 0)
            {
                this.Id = Utilities.ExecuteNewRecord(command);
                if (this.Id > 0)
                {
                    //save suppliers
                    foreach (DisbursementRequestSupplier sup in this.Supplier)
                    {
                        sup.FK_DisbursementRequestId = this.Id;
                       sup.Save();
                    }
                }
            }
            else
            {
                int x = Utilities.ExecuteNonQuery(command);
                //save suppliers
                foreach (DisbursementRequestSupplier sup in this.Supplier)
                {                   
                    sup.Save();
                }
            }

            return this.Id;
        }

        public static bool UpdateSigned(long id)
        {
            int x = Utilities.ExecuteNonQuery("update DisbursementRequest set ApprovalStatus='Signed' where Id=" + id);
            return ((x > 0) ? true : false);
        }

        public static bool UpdateVoucherRaised(long id)
        {
            int x = Utilities.ExecuteNonQuery("update DisbursementRequest set ApprovalStatus='Voucher Raised' where Id=" + id);
            return ((x > 0) ? true : false);
        }

        public static bool UpdateDisbursed(long id)
        {
            int x = Utilities.ExecuteNonQuery("update DisbursementRequest set ApprovalStatus='Disbursed' where Id=" + id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_LoanRequestId { get; set; }
        public string DisbursementCurrency { get; set; }
        public float DisbursementAmount { get; set; }
        public DateTime ProcessStartDate { get; set; }
        public DateTime ProcessEndDate { get; set; }
        public string ApprovalStatus { get; set; }
        public string DeclineReason { get; set; }
        public string DeclinedApprovedBy { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
        public List<DisbursementRequestSupplier> Supplier { get; set; }
        
            public string ChequeNo { get; set; }
    }

    public class DisbursementRequestSupplier
    {
        public DisbursementRequestSupplier() { }

        public DisbursementRequestSupplier(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from DisbursementRequestSupplier where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_DisbursementRequestId = long.Parse(reader.Reader["FK_DisbursementRequestId"].ToString());
                this.Supplier = reader.Reader["Supplier"].ToString();
                this.Currency = reader.Reader["Currency"].ToString();
                this.Price = float.Parse(reader.Reader["Amount"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public long Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into DisbursementRequestSupplier(FK_DisbursementRequestId,Supplier,Currency,Amount,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_DisbursementRequestId + ",'" + Supplier + "','" + Currency + "'," + Price + ", CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

            if (x > 0)
            {
                this.Id = x;
            }
            else
            {
                 x = Utilities.ExecuteNewRecord("update DisbursementRequestSupplier set Currency='"+Currency+"',Amount="+ Price + " where Id="+this.Id);

            }
            return x;
        }

        public bool Update()
        {
            long x = Utilities.ExecuteNonQuery("update DisbursementRequestSupplier set Supplier = '" + Supplier + "', Currency = '" + Currency + "', Amount = " + Price + ", LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_DisbursementRequestId { get; set; }
        public string Supplier { get; set; }
        public string Currency { get; set; }
        public float Price { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class PaymentVoucher
    {
        public PaymentVoucher() { }

        public PaymentVoucher(long requestId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from PaymentVoucher where FK_DisbursementRequestId=" + requestId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_DisbursementRequestId = long.Parse(reader.Reader["FK_DisbursementRequestId"].ToString());
                this.ReferenceNumber = reader.Reader["ReferenceNumber"].ToString();
                this.PaymentMethod = reader.Reader["PaymentMethod"].ToString();
                this.CancellationFee = long.Parse(reader.Reader["CancellationFee"].ToString());
                this.Refund = long.Parse(reader.Reader["Refund"].ToString());
                this.VoucherDate = DateTime.Parse(reader.Reader["VoucherDate"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public static bool CheckVoucher(long disId)
        {
            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from PaymentVoucher where FK_DisbursementRequestId="+disId));
            return ((x>0)?true:false);
        }

        public long Save()
        {
            string refNo = Utilities.GenerateReferenceNumber("voucher", FK_DisbursementRequestId);
            long x = Utilities.ExecuteNewRecord("insert into PaymentVoucher(ReferenceNumber,FK_DisbursementRequestId,VoucherDate,PaymentMethod,CancellationFee,Refund,Created,CreatedBy,LastModified,LastModifiedBy) values('" + refNo + "'," + this.FK_DisbursementRequestId + ",'" + VoucherDate.ToString("yyyy-MM-dd HH:mm:ss.fff") + "','" + PaymentMethod + "'," + CancellationFee + "," + Refund + ", CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

            if (x > 0)
            {
                refNo = Utilities.GenerateReferenceNumber("voucher", x);
                Utilities.ExecuteNonQuery("update PaymentVoucher set ReferenceNumber='" + refNo + "' where Id=" + x);
                this.Id = x;
                //add balance to account
                DisbursementRequest dis = new DisbursementRequest(FK_DisbursementRequestId);
                DisbursementRequest.UpdateVoucherRaised(dis.Id);
                Loan loan = new Loan(dis.FK_LoanRequestId, false);
                BusinessRegistration bus = new BusinessRegistration(loan.FK_BusinessRegistrationId, false);
                //add disbursed to account
                BusinessAccount.AddBalance(bus.RegistrationNumber, dis.DisbursementAmount);
               
                //reord account activity
                AccountActivity act = new AccountActivity(bus.RegistrationNumber, dis.Id, "Disbursement", "Loan " + loan.LoanNumber, dis.DisbursementAmount, false);
                act.Save();
                //record disbursed against loan
                Loan.Disbursed(loan.Id, dis.DisbursementAmount);
                //if last disbursement then add processing fee to account
                loan = new Loan(dis.FK_LoanRequestId, false);
                if (loan.Amount <= loan.AmountDisbursed)
                {
                    //get processing fee
                    LoanAssesment ass = new LoanAssesment(loan.FK_LoanRequestId);
                    BusinessAccount.AddProcessingBalance(bus.RegistrationNumber, ass.ProcessingFee);
                   
                    //reord account activity
                    act = new AccountActivity(bus.RegistrationNumber, dis.Id, "Processing Fee", "Loan " + loan.LoanNumber, ass.ProcessingFee, false);
                    act.Save();
                    //update status to disbursed
                    Loan.FullyDisbursed(loan.Id);
                }
            }
            else
            {
                x = Utilities.ExecuteNewRecord("update PaymentVoucher set PaymentMethod='" + PaymentMethod + "',CancellationFee=" + CancellationFee + ",Refund=" + Refund + " where FK_DisbursementRequestId=" + this.FK_DisbursementRequestId);
            }
            return x;
        }

        public long Id { get; set; }
        public string ReferenceNumber { get; set; }
        public long FK_DisbursementRequestId { get; set; }
        public DateTime VoucherDate { get; set; }
        public string PaymentMethod { get; set; }
        public float CancellationFee { get; set; }
        public float Refund { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class BusinessAccount
    {
        public BusinessAccount() { }

        public BusinessAccount(string acc)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BusinessAccount where AccountNumber='"+acc+"'");
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.AccountNumber = (reader.Reader["AccountNumber"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.AccountBalance = float.Parse(reader.Reader["AccountBalance"].ToString());
                this.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                this.CancellationFee = float.Parse(reader.Reader["CancellationFee"].ToString());
                this.Refund = float.Parse(reader.Reader["Refund"].ToString());
                this.Penalty = float.Parse(reader.Reader["Penalty"].ToString());
                this.IntrestRate = float.Parse(reader.Reader["IntrestRate"].ToString());
                this.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                this.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                this.LastPaymentDate = DateTime.Parse(reader.Reader["LastPaymentDate"].ToString());
                this.LastCalculationDate = DateTime.Parse(reader.Reader["LastCalculationDate"].ToString());

            }
            reader.Close();
        }

        public long Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into BusinessAccount(AccountNumber,AccountBalance,ProcessingFee,CancellationFee,Penalty,Refund,IntrestRate,LastPaymentDate,LastCalculationDate,StartDate,EndDate,Created,CreatedBy,LastModified,LastModifiedBy) values('" + AccountNumber + "',0,0,0,0,0,0,'"+DateTime.Now.AddYears(100).ToString("yyyy-MM-dd HH:mm:ss.000")+ "','" + DateTime.Now.AddYears(100).ToString("yyyy-MM-dd HH:mm:ss.000") + "','" + DateTime.Now.AddYears(100).ToString("yyyy-MM-dd HH:mm:ss.000") + "','" + DateTime.Now.AddYears(100).ToString("yyyy-MM-dd HH:mm:ss.000") + "', CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
                       
            return x;
        }
     
        public static bool AddBalance(string account, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccount set AccountBalance+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool AddProcessingBalance(string account, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccount set AccountBalance+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool AddCancellationBalance(string account, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccount set CancellationFee+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool AddPenaltyBalance(string account, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccount set Penalty+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool SetRate(string account, float rate)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccount set IntrestRate=" + rate + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool SetDates(string account, DateTime sd, DateTime ed)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccount set LastCalculationDate='" + sd.AddMonths(-1).ToString("yyyy-MM-dd 06:00:00.000") + "',LastPaymentDate='" + sd.AddMonths(-1).ToString("yyyy-MM-dd 06:00:00.000") + "',StartDate='" + sd.ToString("yyyy-MM-dd 06:00:00.000") + "',EndDate='" + sd.ToString("yyyy-MM-dd 23:59:59.000") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool SetLastCalculationDate(string account, float balance, DateTime ld)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccount set AccountBalance="+balance+ ",LastCalculationDate='" + ld.ToString("yyyy-MM-dd 06:00:00.000") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }


        public float TotalBalance()
        {
            return (AccountBalance + ProcessingFee + CancellationFee - Refund + Penalty) - Refund;
        }

        public long Id { get; set; }
        public string AccountNumber { get; set; }
        public float AccountBalance { get; set; }
        public float ProcessingFee { get; set; }
        public float CancellationFee { get; set; }
        public float Refund { get; set; }
        public float Penalty { get; set; }
        public float IntrestRate { get; set; }
        public DateTime LastPaymentDate { get; set; }
        public DateTime LastCalculationDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class BankAccount
    {
        public BankAccount() { }

        public BankAccount(long requestId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BankAccount where FK_LoanRequestId=" + requestId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_LoanRequestId = int.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.AccountType = reader.Reader["AccountType"].ToString();
                this.AccountNumber = reader.Reader["AccountNumber"].ToString();
                this.FK_Bank = (reader.Reader["FK_Bank"].ToString());
            }
            reader.Close();
        }
        
        public long Save()
        {
            try
            {
                SqlCommand command = new SqlCommand("insert into BankAccount(FK_LoanRequestId,FK_Bank,AccountNumber,AccountType,Created,CreatedBy,LastModified,LastModifiedBy) values(@FK_LoanRequestId,@FK_Bank,@AccountNumber,@AccountType,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");

                command.Parameters.Add(new SqlParameter("@FK_LoanRequestId", this.FK_LoanRequestId));
                command.Parameters.Add(new SqlParameter("@FK_Bank", this.FK_Bank));
                command.Parameters.Add(new SqlParameter("@AccountNumber", this.AccountNumber));
                command.Parameters.Add(new SqlParameter("@AccountType", this.AccountType));
                command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
                command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));
                this.Id = Utilities.ExecuteNewRecord(command);
            }
            catch
            {

            }

            return this.Id;
        }

        public long Id { get; set; }
        public long FK_LoanRequestId { get; set; }
        public string FK_Bank { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class RepaymentSchedule
    {
        public RepaymentSchedule() { }

        public RepaymentSchedule(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM RepaymentSchedule where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_AccountNumber = (reader.Reader["FK_AccountNumber"].ToString());
                this.Currency = (reader.Reader["Currency"].ToString());
                this.Amount = float.Parse(reader.Reader["Amount"].ToString());
                this.AmountPaid = float.Parse(reader.Reader["AmountPaid"].ToString());
                this.ExpectedDate = DateTime.Parse(reader.Reader["ExpectedDate"].ToString());
                this.PaidDate = DateTime.Parse(reader.Reader["PaidDate"].ToString());
            }
            reader.Close();
        }

        public RepaymentSchedule(string acc, string curr, float amt, DateTime expDate)
        {
            this.FK_AccountNumber = acc;
            this.Currency = curr;
            this.Amount = amt;
            this.ExpectedDate = expDate;
        }

        public long Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into RepaymentSchedule(FK_AccountNumber,Currency,Amount,AmountPaid,ExpectedDate,PaidDate,Created,CreatedBy,LastModified,LastModifiedBy) values('" + this.FK_AccountNumber +"','" + this.Currency +"',"+this.Amount+",0,'"+this.ExpectedDate.ToString("yyyy-MM-dd 23:59:59.000")+"',CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

            return x;
        }

        public bool UpdateBalance(float bal)
        {
            long x = Utilities.ExecuteNewRecord("update RepaymentSchedule set AmountPaid+="+bal+",PaidDate=CURRENT_TIMESTAMP,LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);

            return ((x>0)?true:false);
        }

        public long Id { get; set; }
        public string FK_AccountNumber { get; set; }
        public string Currency { get; set; }
        public float Amount { get; set; }
        public float AmountPaid { get; set; }
        public DateTime ExpectedDate { get; set; }
        public DateTime PaidDate { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }

    }

    public class WarningLetter
    {
        public WarningLetter() { }

        public WarningLetter(long payId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WarningLetter where FK_RepaymentId=" + payId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.WarningStage = (reader.Reader["WarningStage"].ToString());
                this.FK_RepaymentId = long.Parse(reader.Reader["FK_RepaymentId"].ToString());
                this.Responded = bool.Parse(reader.Reader["Responded"].ToString());
                this.FirstRemark = (reader.Reader["FirstRemark"].ToString());
                this.SecondRemark = (reader.Reader["SecondRemark"].ToString());
                this.FinalRemark = (reader.Reader["FinalRemark"].ToString());

                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());

            }
            reader.Close();
        }

        public WarningLetter(long payId,string stage)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from WarningLetter where WarningStage='"+stage+"' and FK_RepaymentId=" + payId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.WarningStage = (reader.Reader["WarningStage"].ToString());
                this.FK_RepaymentId = long.Parse(reader.Reader["FK_RepaymentId"].ToString());
                this.Responded = bool.Parse(reader.Reader["Responded"].ToString());
                this.FirstRemark = (reader.Reader["FirstRemark"].ToString());
                this.SecondRemark = (reader.Reader["SecondRemark"].ToString());
                this.FinalRemark = (reader.Reader["FinalRemark"].ToString());

                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());

            }
            reader.Close();
        }

        public WarningLetter(long fK_RepaymentId, string warningStage, string remark, bool responded)
        {
            this.FK_RepaymentId = fK_RepaymentId;
            this.WarningStage = warningStage;
            this.Responded = responded;
            if (this.WarningStage.ToLower() == "first")
            {
                this.FirstRemark = remark;
            }
            else if (this.WarningStage.ToLower() == "second")
            {
                this.SecondRemark = remark;
            }
            else if (this.WarningStage.ToLower() == "final")
            {
                this.FinalRemark = remark;
            }
        }

        public bool Save()
        {
            //check payment period
            if (this.WarningStage.ToLower() == "first")
            {

            }
            else if (this.WarningStage.ToLower() == "second")
            {

            }
            else if (this.WarningStage.ToLower() == "final")
            {

            }
            else
            {
                return false;
            }
            //count first
            int a = int.Parse(Utilities.ExecuteScalar("select count(Id) from WarningLetter where FK_RepaymentId=" + this.FK_RepaymentId));
            long x = 0;
            if (a <1)
                x = Utilities.ExecuteNewRecord("insert into WarningLetter(FK_RepaymentId,WarningStage,Responded,FirstRemark,SecondRemark,FinalRemark,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_RepaymentId + ",'" + this.WarningStage + "','False','','','', CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            else
                x = Utilities.ExecuteNonQuery("update WarningLetter set WarningStage='" + this.WarningStage + "',Responded='" + ((this.Responded) ? "True" : "False") + "'," + ((this.WarningStage.ToLower() == "first") ? "FirstRemark='" + this.FirstRemark + "'" : ((this.WarningStage.ToLower() == "second") ? "SecondRemark='" + this.SecondRemark + "'" : "FinalRemark='" + this.FinalRemark + "'")) + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_RepaymentId=" + this.FK_RepaymentId);

            return ((x > 0) ? true : false);
        }

        public bool SaveComment()
        {
            //check payment period
            if (this.WarningStage.ToLower() == "first")
            {

            }
            else if (this.WarningStage.ToLower() == "second")
            {

            }
            else if (this.WarningStage.ToLower() == "final")
            {

            }
            else
            {
                return false;
            }
            //count first
            int a = int.Parse(Utilities.ExecuteScalar("select count(Id) from WarningLetter where FK_RepaymentId=" + this.FK_RepaymentId));
            long x = 0;
            if (a < 1)
                x = Utilities.ExecuteNewRecord("insert into WarningLetter(FK_RepaymentId,WarningStage,Responded,FirstRemark,SecondRemark,FinalRemark,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_RepaymentId + ",'" + this.WarningStage + "','False','','','', CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            else
                x = Utilities.ExecuteNonQuery("update WarningLetter set Responded='" + ((this.Responded) ? "True" : "False") + "'," + ((this.WarningStage.ToLower() == "first") ? "FirstRemark='" + this.FirstRemark + "'" : ((this.WarningStage.ToLower() == "second") ? "SecondRemark='" + this.SecondRemark + "'" : "FinalRemark='" + this.FinalRemark + "'")) + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_RepaymentId=" + this.FK_RepaymentId);

            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_RepaymentId { get; set; }
        public string WarningStage { get; set; }
        public bool Responded { get; set; }
        public string FirstRemark { get; set; }
        public string SecondRemark { get; set; }
        public string FinalRemark { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class DisbursementLetter
    {
        public DisbursementLetter() { }

        public DisbursementLetter(string docName,long requestId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from DisbursementLetter where DocumentName='"+docName+"' and FK_LoanRequestId=" + requestId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.DocumentName = (reader.Reader["DocumentName"].ToString());
                this.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                this.FK_DocumentLibraryId = long.Parse(reader.Reader["FK_DocumentLibraryId"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());

            }
            reader.Close();
        }

        public DisbursementLetter(string docName, long requestId,long docId)
        {
            this.DocumentName = docName;
            this.FK_LoanRequestId = requestId;
            this.FK_DocumentLibraryId = docId;
        }

        public void Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into DisbursementLetter(FK_LoanRequestId,FK_DocumentLibraryId,DocumentName,Created,CreatedBy) values(" + this.FK_LoanRequestId+ ","+ this.FK_DocumentLibraryId + ",'" + this.DocumentName + "',CURRENT_TIMESTAMP, '" + Security.actingUser + "')");
           
        }

        public static bool CheckDisbursementLetter(string docName, long requestId)
        {
            int x = int.Parse(Utilities.ExecuteScalar("select count(Id) from DisbursementLetter where DocumentName='" + docName + "' and FK_LoanRequestId=" + requestId));
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_LoanRequestId { get; set; }
        public long FK_DocumentLibraryId { get; set; }
        public string DocumentName { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
    }

    public class AccountActivity
    {
        public AccountActivity() { }

        public AccountActivity(string fK_AccountNumber, long fK_Id, string transactionType, string description, float amount, bool drCr)
        {
            FK_AccountNumber = fK_AccountNumber;
            FK_Id = fK_Id;
            TransactionType = transactionType;
            Description = description;
            BusinessAccount bus = new BusinessAccount(fK_AccountNumber);
            Balance = bus.TotalBalance();
            Amount = amount;
            DrCr = drCr;
        }

        public long Save()
        {
            Amount = float.Parse(Math.Round(Amount, 2).ToString());
            if (Amount == 0)
            {
                return 0;
            }
            else
            {
                long x = Utilities.ExecuteNewRecord("insert into AccountActivity(FK_AccountNumber,FK_Id,TransactionType,Description,Balance,Amount,DrCr,Created,CreatedBy) values('" + FK_AccountNumber + "'," + FK_Id + ",'" + TransactionType + "','" + Description + "'," + Balance + "," + Amount + ",'" + ((DrCr) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

                return x;
            }
        } 

        public long Id { get; set; }
        public string FK_AccountNumber { get; set; }
        public long FK_Id { get; set; }
        public string TransactionType { get; set; }
        public string Description { get; set; }
        public float Balance { get; set; }
        public float Amount { get; set; }
        public bool DrCr { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
    }

    public class OldAccountActivity
    {
        public OldAccountActivity() { }

        public OldAccountActivity(string fK_AccountNumber,string loan, long fK_Id, string transactionType, string description, float amount, bool drCr)
        {
            FK_AccountNumber = fK_AccountNumber;
            FK_Id = fK_Id;
            TransactionType = transactionType;
            Description = description;
            BusinessAccountOld bus = new BusinessAccountOld(fK_AccountNumber,loan);
            Balance = bus.TotalBalance();
            Amount = amount;
            DrCr = drCr;
        }

        public long Save()
        {
            Amount = float.Parse(Math.Round(Amount, 2).ToString());
            if (Amount == 0)
            {
                return 0;
            }
            else
            {
                long x = Utilities.ExecuteNewRecord("insert into AccountActivity(FK_AccountNumber,FK_Id,TransactionType,Description,Balance,Amount,DrCr,Created,CreatedBy) values('" + FK_AccountNumber + "'," + FK_Id + ",'" + TransactionType + "','" + Description + "'," + Balance + "," + Amount + ",'" + ((DrCr) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

                return x;
            }
        }

        public long Id { get; set; }
        public string FK_AccountNumber { get; set; }
        public long FK_Id { get; set; }
        public string TransactionType { get; set; }
        public string Description { get; set; }
        public float Balance { get; set; }
        public float Amount { get; set; }
        public bool DrCr { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
    }

    public class LoanIntrestActivity
    {
        public LoanIntrestActivity() { }

        public LoanIntrestActivity(string fK_LoanNumber, long fK_ActivityId)
        {
            FK_LoanNumber = fK_LoanNumber;
            FK_ActivityId = fK_ActivityId;
        }

        public bool Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into LoanIntrestActivity(FK_LoanNumber,FK_ActivityId,Created,CreatedBy) values('" + FK_LoanNumber + "'," + FK_ActivityId + ",CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public string FK_LoanNumber { get; set; }
        public long FK_ActivityId { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
    }
}