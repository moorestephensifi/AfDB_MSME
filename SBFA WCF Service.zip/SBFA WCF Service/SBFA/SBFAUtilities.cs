﻿using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;

namespace SBFA
{
    public partial class Utilities
    {
        public static int FilterBatch()
        {
            return 100;
        }

        public static long SaveLoanRequest(LoanRequest loan)
        {
            return loan.Save();
        }

        public static bool RegisterLoan(long Id, string entityType)
        {
            bool done = true;
            LoanRequest loan = new LoanRequest(Id);

            BusinessRegistration br = new BusinessRegistration();
            br.FK_LoanRequestId = loan.Id;
            br.Id = 0;
            br.RegistrationNumber = GenerateReferenceNumber("businessregistration", loan.Id);
            br.BusinessRegistrationNumber = loan.BusinessRegistrationNumber;
            br.BusinessName = loan.BusinessName;
            br.FK_BusinessTypeId = loan.FK_BusinessTypeId;
            br.FK_BusinessRegistrationTypeId = loan.FK_BusinessRegistrationTypeId;
            br.FK_BusinessIslandLocationId = loan.FK_BusinessIslandLocationId;
            br.FK_BusinessIslandDistrictId = loan.FK_BusinessIslandDistrictId;
            br.NIN = loan.NIN;
            br.FirstNames = loan.FirstNames;
            br.LastName = loan.LastName;
            br.Salutation = loan.Salutation;
            br.Citizenship = "";
            br.Gender = loan.Gender;
            br.DOB = loan.DOB;
            br.FK_ResidenceIslandLocationId = loan.FK_ResidenceIslandLocationId;
            br.FK_ResidenceDistrictLocationId = loan.FK_ResidenceDistrictLocationId;
            br.Mobile = loan.Mobile;
            br.HomeTelephone = loan.HomeTelephone;
            br.WorkTelephone = loan.WorkTelephone;
            br.Email = loan.Email;
            br.SEnPARegistrationNo = loan.SEnPARegistrationNo;
            br.NoOfEmployees = loan.NoOfEmployees;
            br.Status = loan.Status;
            br.StatusReason = loan.StatusReason;
            br.Created = loan.Created;
            br.CreatedBy = loan.CreatedBy;
            br.LastModified = loan.LastModified;
            br.LastModifiedBy = loan.LastModifiedBy;
            long brId = br.Save();

            Guarantor gr = new Guarantor();
            gr.FK_BusinessRegistrationId = brId;
            gr.Id = 0;
            gr.Created = DateTime.Now;
            gr.CreatedBy = Security.actingUser;
            gr.LastModified = DateTime.Now;
            gr.LastModifiedBy = Security.actingUser;

            //Guarantor details
            gr.GuarantorNIN = loan.GuarantorNIN;
            gr.GuarantorName = loan.GuarantorName;
            gr.GuarantorSurname = loan.GuarantorSurname;
            gr.GuarantorDOB = loan.GuarantorDOB;
            gr.GuarantorAddress = loan.GuarantorAddress;
            gr.GuarantorContactNo = loan.GuarantorContactNo;
            gr.GuarantorMaritalStatus = loan.GuarantorMaritalStatus;
            gr.GuarantorNoOfDependents = loan.GuarantorNoOfDependents;
            gr.GuarantorEmploymentStatus = loan.GuarantorEmploymentStatus;
            gr.GuarantorEmployersAddress = loan.GuarantorEmployersAddress;
            gr.GuarantorEmployersName = loan.GuarantorEmployersName;
            gr.GuarantorCurrentPosition = loan.GuarantorCurrentPosition;
            gr.GuarantorNoOfYears = loan.GuarantorNoOfYears;
            gr.GuarantorTotalMonthlyIncome = loan.GuarantorTotalMonthlyIncome;
            gr.GuarantorTotalMonthlyExpenditure = loan.GuarantorTotalMonthlyExpenditure;
            gr.Save();

            BusinessAccount acc = new BusinessAccount();
            acc.AccountBalance = 0;
            acc.AccountNumber = br.RegistrationNumber;
            acc.Save();

            BankAccount bank = new BankAccount();
            bank.AccountNumber = loan.AccountNo;
            bank.FK_Bank = loan.NameOfBank;
            bank.AccountType = loan.TypeOfAccount;
            bank.FK_LoanRequestId = br.FK_LoanRequestId;
            bank.Save();

            Loan ln = new Loan();
            ln.FK_BusinessRegistrationId = brId;
            ln.FK_LoanRequestId = br.FK_LoanRequestId;
            ln.Id = 0;
            ln.Created = DateTime.Now;
            ln.CreatedBy = Security.actingUser;
            ln.LastModified = DateTime.Now;
            ln.LastModifiedBy = Security.actingUser;

            ln.LoanNumber = GenerateReferenceNumber("loannumber", loan.Id);
            ln.Currency = "SCR";
            ln.ApprovalDate = DateTime.Now;
            ln.Status = "Approved";
            ln.StatusReason = "Loan Assesment";
            ln.Purpose = loan.PurposeOfLoan;
            ln.Amount = loan.LoanAmountRequested;
            ln.AmountDisbursed = 0;
            ln.Save();

            return done;
        }

        public static bool RegisterDeclineLoan(long Id, string entityType)
        {
            bool done = true;
            LoanRequest loan = new LoanRequest(Id);

            BusinessRegistration br = new BusinessRegistration();
            br.FK_LoanRequestId = loan.Id;
            br.Id = 0;
            br.RegistrationNumber = GenerateReferenceNumber("businessregistration", loan.Id);
            br.BusinessRegistrationNumber = loan.BusinessRegistrationNumber;
            br.BusinessName = loan.BusinessName;
            br.FK_BusinessTypeId = loan.FK_BusinessTypeId;
            br.FK_BusinessRegistrationTypeId = loan.FK_BusinessRegistrationTypeId;
            br.FK_BusinessIslandLocationId = loan.FK_BusinessIslandLocationId;
            br.FK_BusinessIslandDistrictId = loan.FK_BusinessIslandDistrictId;
            br.NIN = loan.NIN;
            br.FirstNames = loan.FirstNames;
            br.LastName = loan.LastName;
            br.Salutation = loan.Salutation;
            br.Citizenship = "";
            br.Gender = loan.Gender;
            br.DOB = loan.DOB;
            br.FK_ResidenceIslandLocationId = loan.FK_ResidenceIslandLocationId;
            br.FK_ResidenceDistrictLocationId = loan.FK_ResidenceDistrictLocationId;
            br.Mobile = loan.Mobile;
            br.HomeTelephone = loan.HomeTelephone;
            br.WorkTelephone = loan.WorkTelephone;
            br.Email = loan.Email;
            br.SEnPARegistrationNo = loan.SEnPARegistrationNo;
            br.NoOfEmployees = loan.NoOfEmployees;
            br.Status = loan.Status;
            br.StatusReason = loan.StatusReason;
            br.Created = loan.Created;
            br.CreatedBy = loan.CreatedBy;
            br.LastModified = loan.LastModified;
            br.LastModifiedBy = loan.LastModifiedBy;
            long brId = br.Save();

            Guarantor gr = new Guarantor();
            gr.FK_BusinessRegistrationId = brId;
            gr.Id = 0;
            gr.Created = DateTime.Now;
            gr.CreatedBy = Security.actingUser;
            gr.LastModified = DateTime.Now;
            gr.LastModifiedBy = Security.actingUser;

            //Guarantor details
            gr.GuarantorNIN = loan.GuarantorNIN;
            gr.GuarantorName = loan.GuarantorName;
            gr.GuarantorSurname = loan.GuarantorSurname;
            gr.GuarantorDOB = loan.GuarantorDOB;
            gr.GuarantorAddress = loan.GuarantorAddress;
            gr.GuarantorContactNo = loan.GuarantorContactNo;
            gr.GuarantorMaritalStatus = loan.GuarantorMaritalStatus;
            gr.GuarantorNoOfDependents = loan.GuarantorNoOfDependents;
            gr.GuarantorEmploymentStatus = loan.GuarantorEmploymentStatus;
            gr.GuarantorEmployersAddress = loan.GuarantorEmployersAddress;
            gr.GuarantorEmployersName = loan.GuarantorEmployersName;
            gr.GuarantorCurrentPosition = loan.GuarantorCurrentPosition;
            gr.GuarantorNoOfYears = loan.GuarantorNoOfYears;
            gr.GuarantorTotalMonthlyIncome = loan.GuarantorTotalMonthlyIncome;
            gr.GuarantorTotalMonthlyExpenditure = loan.GuarantorTotalMonthlyExpenditure;
            gr.Save();

            BusinessAccount acc = new BusinessAccount();
            acc.AccountBalance = 0;
            acc.AccountNumber = br.RegistrationNumber;
            acc.Save();

            BankAccount bank = new BankAccount();
            bank.AccountNumber = loan.AccountNo;
            bank.FK_Bank = loan.NameOfBank;
            bank.AccountType = loan.TypeOfAccount;
            bank.FK_LoanRequestId = br.FK_LoanRequestId;
            bank.Save();
            
            return done;
        }

        //get registrations list
        public static List<LoanRequest> GetLoanRequests(string filterText)
        {
            List<LoanRequest> response = new List<LoanRequest>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " Id,ReferenceNumber,BusinessRegistrationNumber,BusinessName,NIN,FirstNames,LastName,Status from LoanRequest where NIN like '%" + filterText + "%' or ReferenceNumber like '%" + filterText + "%' or FirstNames like '%" + filterText + "' or LastName like '%" + filterText + "%' order by Created Desc");
            while (reader.Reader.Read())
            {
                LoanRequest reg = new LoanRequest();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.ReferenceNumber = (reader.Reader["ReferenceNumber"].ToString());
                reg.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                reg.BusinessName = (reader.Reader["BusinessName"].ToString());
                reg.NIN = (reader.Reader["NIN"].ToString());
                reg.FirstNames = (reader.Reader["FirstNames"].ToString());
                reg.LastName = (reader.Reader["LastName"].ToString());
                reg.Status = (reader.Reader["Status"].ToString());

                response.Add(reg);
            }
            reader.Close();

            return response;

        }

        public static LoanRequest GetLoanRequest(long Id)
        {
            LoanRequest registration = new LoanRequest(Id);
            return registration;
        }

        public static long SaveBusinessRegistration(BusinessRegistration registration)
        {
            return registration.Save();
        }

        public static long SaveGuarantor(Guarantor guarantor)
        {
            return guarantor.Save();
        }

        public static Guarantor GetGuarantor(string nin)
        {
            return new Guarantor(nin);
        }

        public static List<Guarantor> GetGuarantors(long Id)
        {
            List<Guarantor> response = new List<Guarantor>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from LoanRequestGuarantor where FK_LoanRequestId=" + Id);
            while (reader.Reader.Read())
            {
                Guarantor reg = new Guarantor();
                reg.GuarantorNIN = reader.Reader["GuarantorNIN"].ToString();
                reg.GuarantorName = reader.Reader["GuarantorName"].ToString();
                reg.GuarantorSurname = reader.Reader["GuarantorSurname"].ToString();
                reg.GuarantorDOB = DateTime.Parse(reader.Reader["GuarantorDOB"].ToString());
                reg.GuarantorAddress = reader.Reader["GuarantorAddress"].ToString();
                reg.GuarantorContactNo = reader.Reader["GuarantorContactNo"].ToString();
                reg.GuarantorMaritalStatus = reader.Reader["GuarantorMaritalStatus"].ToString();
                reg.GuarantorNoOfDependents = reader.Reader["GuarantorNoOfDependents"].ToString();
                reg.GuarantorEmploymentStatus = reader.Reader["GuarantorEmploymentStatus"].ToString();
                reg.GuarantorEmployersAddress = reader.Reader["GuarantorEmployersAddress"].ToString();
                reg.GuarantorEmployersName = reader.Reader["GuarantorEmployersName"].ToString();
                reg.GuarantorCurrentPosition = reader.Reader["GuarantorCurrentPosition"].ToString();
                reg.GuarantorNoOfYears = long.Parse(reader.Reader["GuarantorNoOfYears"].ToString());
                reg.GuarantorTotalMonthlyIncome = float.Parse(reader.Reader["GuarantorTotalMonthlyIncome"].ToString());
                reg.GuarantorTotalMonthlyExpenditure = float.Parse(reader.Reader["GuarantorTotalMonthlyExpenditure"].ToString());

                response.Add(reg);
            }
            reader.Close();

            return response;

        }

        public static long SaveLoanRequestGuarantor(Guarantor guarantor)
        {
            return guarantor.SaveRequest();
        }

        public static Guarantor GetLoanRequestGuarantor(string nin,long Id)
        {
            return new Guarantor(nin,Id);
        }

        public static BusinessRegistration GetBusinessRegistration(string nin)
        {
            return new BusinessRegistration(nin);
        }

        public static BusinessRegistration GetBusinessRegistrationByRegistration(string reg)
        {
            return new BusinessRegistration(reg, true);
        }

        public static bool SaveRecommendation(long fK_LoanRequestId, string fK_Stage, bool approved, string recommendation)
        {
            LoanApprovalRecommendations lreco = new LoanApprovalRecommendations(fK_LoanRequestId, fK_Stage, approved, recommendation);
            return lreco.Save();
        }

        public static List<LoanApprovalRecommendations> GetLoanApprovalRecommendations(long requestId)
        {
            List<LoanApprovalRecommendations> response = new List<LoanApprovalRecommendations>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM LoanApprovalRecommendations where FK_LoanRequestId=" + requestId + " order by Created desc");
            while (reader.Reader.Read())
            {
                LoanApprovalRecommendations rec = new LoanApprovalRecommendations();
                rec.Id = long.Parse(reader.Reader["Id"].ToString());
                rec.FK_LoanRequestId = long.Parse(reader.Reader["FK_LoanRequestId"].ToString());
                rec.FK_Stage = (reader.Reader["FK_Stage"].ToString());
                rec.Approved = bool.Parse(reader.Reader["Approved"].ToString());
                rec.Recommendation = (reader.Reader["Recommendation"].ToString());

                response.Add(rec);
            }
            reader.Close();

            return response;

        }

        private static string GenerateLoanNumber(string refNo)
        {
            return refNo;
        }

        private static string GenerateReferenceNumber()
        {

            return DateTime.Now.ToString("yyMMddHHmmss");
        }

        public static string GenerateReferenceNumber(string area, long index)
        {
            int digits = 10;
            string prefix = "REF";

            if (area.Equals("loanapplication"))
            {
                prefix = "LA";
            }
            if (area.Equals("disbursementrequest"))
            {
                prefix = "DR";
            }
            if (area.Equals("businessregistration"))
            {
                prefix = "BR";
            }
            if (area.Equals("loannumber"))
            {
                prefix = "LN";
            }
            if (area.Equals("voucher"))
            {
                prefix = "PV";
            }

            string referenceNumber = string.Format(prefix + "{0}", index.ToString().PadLeft(digits, '0'));

            return referenceNumber;
        }

        public static bool SendDocument(string docType, long docWorkFlowId, long workFlowStageId, bool email, bool sms)
        {
            string response = "";
            //break if not email or sms is required
            if (!email && !sms)
                return true;
            long inv = 0;
            switch (docType)
            {
                case "loanSubmit":
                    long id = long.Parse(Utilities.ExecuteScalar("select FK_DocumentId from DocumentWorkflow where Id=" + docWorkFlowId));
                    LoanRequest reg = new LoanRequest(id);
                    response = GenerateDocument(docType, reg, email, sms);
                    break;
                case "invoice":
                    //get invoice id
                    inv = long.Parse(Utilities.ExecuteScalar("select Id from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Invoice invoice = new Invoice(inv);
                    response = GenerateDocument(docType, invoice, email, sms);
                    break;
                case "ackPayment":
                    //get invoice id
                    long invId = long.Parse(Utilities.ExecuteScalar("select Id from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Invoice invoicePaid = new Invoice(invId);
                    response = GenerateDocument(docType, invoicePaid, email, sms);
                    break;
                case "receipt":
                    long recId = long.Parse(Utilities.ExecuteScalar("select ReceiptNumber from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Receipt receipt = new Receipt(recId);
                    response = GenerateDocument(docType, receipt, email, sms);
                    break;
                case "receiptLoan":
                    long recIdReg = long.Parse(Utilities.ExecuteScalar("select ReceiptNumber from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Receipt receiptReg = new Receipt(recIdReg);
                    response = GenerateDocument(docType, receiptReg, email, sms);
                    break;
                default:
                    break;
            }
            //just continue
            return true;
        }

        public static bool SendDocument(string docType, long Id, bool email, bool sms)
        {
            string response = "";
            //break if not email or sms is required
            if (!email && !sms)
                return true;

            switch (docType)
            {
                case "sitevisit":
                    SiteVisit site = new SiteVisit(Id);
                    response = GenerateDocument(docType, site, site.Email, site.SMS);
                    break;
                default:
                    break;
            }
            //just continue
            return true;
        }

        public static string GenerateDocument(string docType, Object data, bool email = false, bool sms = false)
        {
            string response = "", responseSMS = "", emailSubject = "";
            string mobileNumber = "", emailAddress = "";
            AutoDocumentsDesign desg = new AutoDocumentsDesign(docType);
            response = desg.DocumentDesign;
            responseSMS = desg.DocumentDesignSMS;
            emailSubject = desg.EmailSubject;
            try
            {
                if (docType == "LoanSubmit")
                {
                    #region registration
                    LoanRequest registration = data as LoanRequest;
                    response = response.Replace("<registration>", registration.ReferenceNumber);
                    response = response.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    response = response.Replace("<nin>", registration.NIN);
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", registration.ReferenceNumber);
                    responseSMS = responseSMS.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    responseSMS = responseSMS.Replace("<nin>", registration.NIN);
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", registration.ReferenceNumber);
                    emailSubject = emailSubject.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    emailSubject = emailSubject.Replace("<nin>", registration.NIN);

                    mobileNumber = registration.Mobile;
                    emailAddress = registration.Email;
                    #endregion
                }
                else if (docType == "ackPayment")
                {
                    #region ackpay
                    Invoice invoice = data as Invoice;
                    LoanRequest registration = new LoanRequest(invoice.FK_DocumentId);
                    response = response.Replace("<receipt>", invoice.ReceiptNumber);
                    response = response.Replace("<reference>", invoice.FK_ReferenceNumber);
                    response = response.Replace("<amount>", invoice.Currency + invoice.AmountTotal.ToString());
                    response = response.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    response = response.Replace("<nin>", registration.NIN);

                    response = response.Replace("<location>", Utilities.GetEntityName(registration.FK_BusinessIslandLocationId, "isl"));
                    response = response.Replace("<payment>", registration.DocumentType.ToUpper());
                    response = response.Replace("<invoice>", invoice.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<subtotal>", invoice.AmountTotal.ToString());
                    response = response.Replace("<total>", invoice.AmountTotal.ToString());
                    response = response.Replace("<paid>", invoice.AmountPaid.ToString());
                    response = response.Replace("<due>", (invoice.AmountTotal - invoice.AmountPaid).ToString());
                    List<InvoiceItem> items = Utilities.GetInvoiceItems(invoice.Id);
                    StringBuilder sb = new StringBuilder();
                    foreach (InvoiceItem item in items)
                    {
                        sb.Append("<table width=\"100%\" style=\"max-width:300px;\" cellspacing=\"0\" cellpadding=\"0\"><tr><td width=\"10%\">" + item.Id + "</td><td>" + item.Description + "</td><td width=\"40%\">" + item.Amount + "</td><tr></table>");
                    }
                    response = response.Replace("<items>", sb.ToString());
                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", invoice.ReceiptNumber);
                    responseSMS = responseSMS.Replace("<reference>", invoice.FK_ReferenceNumber);
                    responseSMS = responseSMS.Replace("<amount>", invoice.Currency + invoice.AmountTotal.ToString());
                    responseSMS = responseSMS.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    responseSMS = responseSMS.Replace("<nin>", registration.NIN);
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", invoice.ReceiptNumber);
                    emailSubject = emailSubject.Replace("<reference>", invoice.FK_ReferenceNumber);
                    emailSubject = emailSubject.Replace("<amount>", invoice.Currency + invoice.AmountTotal.ToString());
                    emailSubject = emailSubject.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    emailSubject = emailSubject.Replace("<nin>", registration.NIN);

                    mobileNumber = registration.Mobile;
                    emailAddress = registration.Email;
                    #endregion
                }
                else if (docType == "receipt")
                {
                    #region receipt
                    Receipt receipt = data as Receipt;

                    //try to get loan number
                    response = response.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<paid>", receipt.AmountTendered.ToString());
                    response = response.Replace("<amount>", receipt.Amount.ToString());
                    response = response.Replace("<words>", ConvertToWords(receipt.Amount.ToString()));

                    response = response.Replace("<change>",  receipt.Change.ToString());
                    ApplicationUsers user = new ApplicationUsers(receipt.ReceiptedBy);
                    response = response.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    response = response.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    Invoice invoice = new Invoice(receipt.FK_InvoiceId);
                   
                    response = response.Replace("<invoice>", invoice.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<subtotal>", invoice.AmountTotal.ToString());
                    response = response.Replace("<total>", invoice.AmountTotal.ToString());
                    response = response.Replace("<paid>", invoice.AmountPaid.ToString());
                    response = response.Replace("<due>", (invoice.AmountTotal - invoice.AmountPaid).ToString());
                    response = response.Replace("<loannumber>", invoice.FK_ReferenceNumber.ToString().Split('_')[0]);
                    response = response.Replace("<paymode>", Utilities.GetEntityName(invoice.FK_PaymentMethodId, "paymet"));


                    long docId = long.Parse(Utilities.ExecuteScalar("select FK_DocumentId from Invoice where ReceiptNumber='" + receipt.Id.ToString().PadLeft(10, '0') + "'"));
                    if (docId > 0)
                    {
                        LoanRequest registrationreceipt = new LoanRequest(docId);

                        response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        response = response.Replace("<nin>", registrationreceipt.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", "Loan Processing Payment for" + invoice.FK_ReferenceNumber.ToString().Split('_')[0]);
                        responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);
                        emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);
                        mobileNumber = registrationreceipt.Mobile;
                        emailAddress = registrationreceipt.Email;
                    }
                    else
                    {
                        string refNumber = Utilities.ExecuteScalar("select FK_ReferenceNumber from Invoice where ReceiptNumber='" + receipt.Id.ToString().PadLeft(10, '0') + "'");
                        if (refNumber.IndexOf("SBFA") > -1)
                        {
                            BusinessRegistration registrationreceipt = Utilities.GetOldBusinessRegistrationByRegistration(refNumber.Split('_')[0]);
                            response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                            response = response.Replace("<nin>", registrationreceipt.NIN);
                            response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                            response = response.Replace("<payment>", "Loan Repayment (Old Accounts) for " + invoice.FK_ReferenceNumber.ToString().Split('_')[0]);
                            responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                            responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);
                            emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                            emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);
                            mobileNumber = registrationreceipt.Mobile;
                            emailAddress = registrationreceipt.Email;
                        }
                        else
                        {

                            BusinessRegistration registrationreceipt = Utilities.GetBusinessRegistrationByRegistration(refNumber.Split('_')[0]);
                            response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                            response = response.Replace("<nin>", registrationreceipt.NIN);
                            response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                            response = response.Replace("<payment>", "Loan Repayment for " + invoice.FK_ReferenceNumber.ToString().Split('_')[0]);
                            responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                            responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);
                            emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                            emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);
                            mobileNumber = registrationreceipt.Mobile;
                            emailAddress = registrationreceipt.Email;
                        }
                    }

                    List<InvoiceItem> items = Utilities.GetInvoiceItems(invoice.Id);
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<table style=\"margin:15px 0 0 0;\" cellspacing=\"0\" cellpadding=\"0\" border=\"1\" width=\"70%\"><tr><td>Item</td><td>Description</td><td>Cost</td></tr>");
                    foreach (InvoiceItem item in items)
                    {
                        sb.Append("<tr><td>" + item.Id + "</td><td>" + item.Description + "</td><td>" + item.Amount + "</td></tr>");
                    }
                    sb.Append("</table>");
                    response = response.Replace("<items>", sb.ToString());

                    if (receipt.Printed > 0)
                    {
                        response = response.Replace("<copy>", "COPY");
                    }
                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    responseSMS = responseSMS.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    responseSMS = responseSMS.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    
                    responseSMS = responseSMS.Replace("<change>", receipt.Currency + receipt.Change.ToString());

                    responseSMS = responseSMS.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    responseSMS = responseSMS.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    emailSubject = emailSubject.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    emailSubject = emailSubject.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                   
                    emailSubject = emailSubject.Replace("<change>", receipt.Currency + receipt.Change.ToString());

                    emailSubject = emailSubject.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    emailSubject = emailSubject.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }

                   
                    #endregion
                }
                else if (docType == "receiptLoan")
                {
                    #region receipt Registration
                    Receipt receipt = data as Receipt;
                    long docId = long.Parse(Utilities.ExecuteScalar("select FK_DocumentId from Invoice where ReceiptNumber='" + receipt.Id.ToString().PadLeft(10, '0') + "'"));
                    LoanRequest registrationreceipt = new LoanRequest(docId);
                    //set notification
                    ApplicationUsers userOwner = new ApplicationUsers(registrationreceipt.FK_LoansOfficerId);
                    Notifications not = new Notifications(userOwner.Username, "Receipt for " + registrationreceipt.ReferenceNumber + " paid for Loan Application", "loan", registrationreceipt.Id);

                    response = response.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    response = response.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    response = response.Replace("<nin>", registrationreceipt.NIN);
                    response = response.Replace("<change>", receipt.Currency + receipt.Change.ToString());
                    ApplicationUsers user = new ApplicationUsers(receipt.ReceiptedBy);
                    response = response.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    response = response.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        response = response.Replace("<copy>", "COPY");
                    }
                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    responseSMS = responseSMS.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    responseSMS = responseSMS.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);
                    responseSMS = responseSMS.Replace("<change>", receipt.Currency + receipt.Change.ToString());

                    responseSMS = responseSMS.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    responseSMS = responseSMS.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    emailSubject = emailSubject.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    emailSubject = emailSubject.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);
                    emailSubject = emailSubject.Replace("<change>", receipt.Currency + receipt.Change.ToString());

                    emailSubject = emailSubject.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    emailSubject = emailSubject.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }

                    mobileNumber = registrationreceipt.Mobile;
                    emailAddress = registrationreceipt.Email;
                    #endregion
                }
                else if (docType == "invoice")
                {
                    #region invoice
                    Invoice invoice = data as Invoice;
                    
                    //set notification
                    Notifications not = new Notifications("", "Invoice : " + invoice.FK_ReferenceNumber, "invoice", invoice.Id);
                    response = response.Replace("<receipt>", invoice.ReceiptNumber);
                    response = response.Replace("<reference>", invoice.FK_ReferenceNumber);
                    response = response.Replace("<amount>", invoice.AmountTotal.ToString());
                    if (invoice.FK_DocumentId == 0)
                    {
                        BusinessRegistration registration = new BusinessRegistration(invoice.FK_ReferenceNumber.Split('_')[0], true);
                        response = response.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                        response = response.Replace("<nin>", registration.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registration.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", invoice.DocumentType.ToUpper());

                        responseSMS = responseSMS.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registration.NIN);

                        emailSubject = emailSubject.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registration.NIN);

                        mobileNumber = registration.Mobile;
                        emailAddress = registration.Email;
                    }
                    else
                    {
                        LoanRequest registration = new LoanRequest(invoice.FK_DocumentId);
                        response = response.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                        response = response.Replace("<nin>", registration.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registration.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", registration.DocumentType.ToUpper());

                        responseSMS = responseSMS.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registration.NIN);

                        emailSubject = emailSubject.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registration.NIN);

                        mobileNumber = registration.Mobile;
                        emailAddress = registration.Email;
                    }
                    response = response.Replace("<invoice>", invoice.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<subtotal>", invoice.AmountTotal.ToString());
                    response = response.Replace("<total>", invoice.AmountTotal.ToString());
                    response = response.Replace("<paid>", invoice.AmountPaid.ToString());
                    response = response.Replace("<due>", (invoice.AmountTotal - invoice.AmountPaid).ToString());
                    List<InvoiceItem> items = Utilities.GetInvoiceItems(invoice.Id);
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<table style=\"margin:15px 0 0 0;\" cellspacing=\"0\" cellpadding=\"0\" border=\"1\" width=\"70%\"><tr><td>Item</td><td>Description</td><td>Cost</td></tr>");
                    foreach (InvoiceItem item in items)
                    {
                        sb.Append("<tr><td>" + item.Id + "</td><td>" + item.Description + "</td><td>" + item.Amount + "</td></tr>");
                    }
                    sb.Append("</table>");
                    response = response.Replace("<items>", sb.ToString());
                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", invoice.ReceiptNumber);
                    responseSMS = responseSMS.Replace("<reference>", invoice.FK_ReferenceNumber);
                    responseSMS = responseSMS.Replace("<amount>",  invoice.AmountTotal.ToString());
                   
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", invoice.ReceiptNumber);
                    emailSubject = emailSubject.Replace("<reference>", invoice.FK_ReferenceNumber);
                    emailSubject = emailSubject.Replace("<amount>", invoice.AmountTotal.ToString());
                   
                    #endregion
                }
                else if (docType == "First" || docType == "Second" || docType == "Final")
                {
                    RepaymentSchedule rep = data as RepaymentSchedule;
                    WarningLetter lt = new WarningLetter(rep.Id, ((docType == "First") ? "Second" : "Final"),"",false);
                    lt.Save();
                    BusinessRegistration registration = new BusinessRegistration(rep.FK_AccountNumber, true);
                    Loan loan = new Loan(registration.FK_LoanRequestId, false);

                    List<Guarantor> gua = Utilities.GetGuarantors(registration.FK_LoanRequestId);
                    response = response.Replace("<nameGuarantor>", gua[0].GuarantorName + " " + gua[0].GuarantorSurname);
                    response = response.Replace("<islandGuarantor>", gua[0].GuarantorAddress);

                    if(docType == "Second")
                    {
                        WarningLetter ltFirst = new WarningLetter(rep.Id, "First");
                        response = response.Replace("<lastdate>", ltFirst.Created.ToLongDateString());
                    }
                    else if (docType == "Final")
                    {
                        WarningLetter ltFirst = new WarningLetter(rep.Id, "Second");
                        response = response.Replace("<lastdate>", ltFirst.Created.ToLongDateString());
                    }

                    response = response.Replace("<loannumber>", loan.LoanNumber);
                    response = response.Replace("<salutation>", registration.Salutation);
                    response = response.Replace("<amount>", rep.Currency + (rep.Amount - rep.AmountPaid).ToString());
                    response = response.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    response = response.Replace("<nin>", registration.NIN);
                    response = response.Replace("<district>", Utilities.GetEntityName(registration.FK_ResidenceDistrictLocationId, "dis"));
                    response = response.Replace("<island>", Utilities.GetEntityName(registration.FK_ResidenceIslandLocationId, "isl"));
                    response = response.Replace("<date>", DateTime.Now.AddDays(20).ToLongDateString());
                    response = response.Replace("<currentdate>", DateTime.Now.ToLongDateString());

                    responseSMS = responseSMS.Replace("<amount>", rep.Currency + (rep.Amount - rep.AmountPaid).ToString());
                    responseSMS = responseSMS.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    responseSMS = responseSMS.Replace("<nin>", registration.NIN);
                    responseSMS = responseSMS.Replace("<district>", Utilities.GetEntityName(registration.FK_ResidenceDistrictLocationId, "dis"));
                    responseSMS = responseSMS.Replace("<island>", Utilities.GetEntityName(registration.FK_ResidenceIslandLocationId, "isl"));
                    responseSMS = responseSMS.Replace("<date>", DateTime.Now.AddDays(20).ToLongDateString());

                    emailSubject = emailSubject.Replace("<amount>", rep.Currency + (rep.Amount - rep.AmountPaid).ToString());
                    emailSubject = emailSubject.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    emailSubject = emailSubject.Replace("<nin>", registration.NIN);
                    emailSubject = emailSubject.Replace("<district>", Utilities.GetEntityName(registration.FK_ResidenceDistrictLocationId, "dis"));
                    emailSubject = emailSubject.Replace("<island>", Utilities.GetEntityName(registration.FK_ResidenceIslandLocationId, "isl"));
                    emailSubject = emailSubject.Replace("<date>", DateTime.Now.AddDays(20).ToLongDateString());

                    mobileNumber = registration.Mobile;
                    emailAddress = registration.Email;
                }
                else if (docType == "disbursementForm")
                {
                    #region Disbursement
                    DisbursementRequest disburse = data as DisbursementRequest;
                    LoanRequest registration = new LoanRequest(disburse.FK_LoanRequestId);
                    Loan loan = new Loan(disburse.FK_LoanRequestId, false);
                    LoanAssesment ass = new LoanAssesment(disburse.FK_LoanRequestId);
                    BusinessRegistration reg = new BusinessRegistration(registration.NIN);
                    BusinessAccount bus = new BusinessAccount(reg.RegistrationNumber);
                    //if (disburse.ApprovalStatus.ToLower() == "disbursed")
                       // response = response.Replace("<amount>", (loan.AmountDisbursed).ToString());
                   // else
                        response = response.Replace("<amount>", (loan.AmountDisbursed + disburse.DisbursementAmount).ToString());

                    response = response.Replace("<balance>", (loan.Amount - (loan.AmountDisbursed+ass.ProcessingFee+ disburse.DisbursementAmount)).ToString());
                    response = response.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    response = response.Replace("<nin>", registration.NIN);
                    response = response.Replace("<business>", Utilities.GetEntityName(registration.FK_BusinessTypeId, "bustyp"));
                    response = response.Replace("<district>", Utilities.GetEntityName(registration.FK_ResidenceDistrictLocationId, "dis"));
                    response = response.Replace("<island>", Utilities.GetEntityName(registration.FK_ResidenceIslandLocationId, "isl"));
                    response = response.Replace("<loanamount>", loan.Amount.ToString());
                    response = response.Replace("<loannumber>", loan.LoanNumber.ToString());
                    response = response.Replace("<processingfee>", ass.ProcessingFee.ToString());
                    response = response.Replace("<cancellationfee>", bus.CancellationFee.ToString());
                    response = response.Replace("<repaymentperiod>", ass.PaybackPeriod.ToString());
                    response = response.Replace("<repaymentamount>", ass.MonthlyRepayment.ToString());
                    response = response.Replace("<interest>", bus.IntrestRate.ToString());
                    response = response.Replace("<interestamount>", ((ass.MonthlyRepayment * ass.PaybackPeriod) - loan.Amount).ToString());
                    response = response.Replace("<preparedby>", Security.actingUser);
                    response = response.Replace("<date>", DateTime.Now.ToShortDateString());
                    response = response.Replace("<accountnumber>", reg.RegistrationNumber);
                    response = response.Replace("<disbursementnumber>", disburse.Id.ToString().PadLeft(7,'0'));

                    List<DisbursementRequestSupplier> sups = Utilities.GetDisbursementRequestSuppliers(disburse.Id);
                    string temp = "";
                    temp = temp + "<table style=\"margin:15px 0 0 0;\" cellspacing=\"0\" cellpadding=\"0\" border=\"1\" width=\"100%\">";
                    temp = temp + "<tr>";
                    temp = temp + "<td>Disbursement Detail</td>";
                    temp = temp + "<td>Supplier Detail</td>";
                    temp = temp + "<td>Amount SR</td>";
                    temp = temp + "</tr>";
                    foreach (DisbursementRequestSupplier sup in sups)
                    {
                        temp = temp + "<tr>";
                        temp = temp + "<td>Against Invoice</td>";
                        temp = temp + "<td>" + sup.Supplier + "</td>";
                        temp = temp + "<td>" + sup.Price + "</td>";
                        temp = temp + "</tr>";
                    }
                    temp = temp + "</table>";
                    response = response.Replace("<suppliers>", temp);
                    mobileNumber = "";
                    emailAddress = "";
                    #endregion
                }
                else if (docType == "voucher")
                {
                    #region voucher
                    PaymentVoucher pv= data as PaymentVoucher;
                    DisbursementRequest disburse = new DisbursementRequest(pv.FK_DisbursementRequestId);
                    LoanRequest registration = new LoanRequest(disburse.FK_LoanRequestId);
                    Loan loan = new Loan(disburse.FK_LoanRequestId, false);
                    LoanAssesment ass = new LoanAssesment(disburse.FK_LoanRequestId);
                    BusinessRegistration reg = new BusinessRegistration(registration.NIN);
                    BusinessAccount bus = new BusinessAccount(reg.RegistrationNumber);

                    response = response.Replace("<amount>", disburse.DisbursementAmount.ToString());
                    response = response.Replace("<bank>", registration.NameOfBank);
                    response = response.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    response = response.Replace("<nin>", registration.NIN);
                    response = response.Replace("<reference>", pv.Id.ToString());
                    response = response.Replace("<credit>", loan.Amount.ToString());
                    response = response.Replace("<loan>", (loan.LoanNumber).ToString());
                    response = response.Replace("<fee>", ass.ProcessingFee.ToString());
                    response = response.Replace("<words>", ConvertToWords(disburse.DisbursementAmount.ToString()));

                    response = response.Replace("<disbursement>", disburse.PreviousDisbursementAmount().ToString());
                    float bal = loan.Amount - ass.ProcessingFee-loan.AmountDisbursed;

                    response = response.Replace("<balance>", (bal).ToString());
                   
                    response = response.Replace("<total>", (ass.ProcessingFee+ disburse.PreviousDisbursementAmount()+(bal)).ToString());

                    response = response.Replace("<net>", (disburse.DisbursementAmount).ToString());
                    response = response.Replace("<interest>", bus.IntrestRate.ToString());
                    response = response.Replace("<interestamount>", ((ass.MonthlyRepayment * ass.PaybackPeriod) - loan.Amount).ToString());
                    response = response.Replace("<preparedby>", Security.actingUser);
                    response = response.Replace("<date>", DateTime.Now.ToShortDateString());
                    response = response.Replace("<accountnumber>", reg.RegistrationNumber);
                    response = response.Replace("<disbursementnumber>", disburse.Id.ToString().PadLeft(7, '0'));
                    
                    mobileNumber = "";
                    emailAddress = "";
                    #endregion
                }
                else
                {
                    #region loan documents
                    Loan loan = data as Loan;
                    LoanRequest loanRequest = new LoanRequest(loan.FK_LoanRequestId);

                    response = response.Replace("<registration>", loanRequest.ReferenceNumber);
                    response = response.Replace("<name>", loanRequest.FirstNames + " " + loanRequest.LastName);
                    response = response.Replace("<nin>", loanRequest.NIN);
                    response = response.Replace("<amount>", loan.Amount.ToString());
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", loanRequest.ReferenceNumber);
                    responseSMS = responseSMS.Replace("<name>", loanRequest.FirstNames + " " + loanRequest.LastName);
                    responseSMS = responseSMS.Replace("<nin>", loanRequest.NIN);
                    responseSMS = responseSMS.Replace("<amount>", loan.Amount.ToString());
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", loanRequest.ReferenceNumber);
                    emailSubject = emailSubject.Replace("<name>", loanRequest.FirstNames + " " + loanRequest.LastName);
                    emailSubject = emailSubject.Replace("<nin>", loanRequest.NIN);
                    emailSubject = emailSubject.Replace("<amount>", loan.Amount.ToString());

                    mobileNumber = loanRequest.Mobile;
                    emailAddress = loanRequest.Email;
                    #endregion
                }
            }
            catch (Exception ex)
            {
                //error log
            }

            if (docType == "sitevisit")
            {
                desg = new AutoDocumentsDesign("sitevisitClient");
                response = desg.DocumentDesign;
                responseSMS = desg.DocumentDesignSMS;
                emailSubject = desg.EmailSubject;
                SiteVisit site = data as SiteVisit;
                DocumentWorkflow doc = new DocumentWorkflow(site.FK_DocumentWorkFlowId);
                LoanRequest reg = new LoanRequest();

                #region sitevisit client notification

                //check if registered first                    
                if (doc.DocumentType == "loan")
                {
                    reg = new LoanRequest(long.Parse(doc.FK_DocumentId));
                    //set notification
                    Notifications not = new Notifications("", "Site Visit scheduled for " + site.VisitDate.ToLongDateString(), "loanSite", site.FK_DocumentId);

                    response = response.Replace("<registration>", reg.ReferenceNumber);
                    response = response.Replace("<name>", reg.FirstNames + " " + reg.LastName);
                    response = response.Replace("<nin>", reg.NIN);

                    response = response.Replace("<date>", site.VisitDate.ToLongTimeString());
                    response = response.Replace("<address>", site.VisitAddress);
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", reg.ReferenceNumber);
                    responseSMS = responseSMS.Replace("<name>", reg.FirstNames + " " + reg.LastName);
                    responseSMS = responseSMS.Replace("<nin>", reg.NIN);

                    responseSMS = responseSMS.Replace("<date>", site.VisitDate.ToLongTimeString());
                    responseSMS = responseSMS.Replace("<address>", site.VisitAddress);
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", reg.ReferenceNumber);
                    emailSubject = emailSubject.Replace("<name>", reg.FirstNames + " " + reg.LastName);
                    emailSubject = emailSubject.Replace("<nin>", reg.NIN);

                    emailSubject = emailSubject.Replace("<date>", site.VisitDate.ToLongTimeString());
                    emailSubject = emailSubject.Replace("<address>", site.VisitAddress);

                    mobileNumber = reg.Mobile;
                    emailAddress = reg.Email;
                }


                #endregion

                if (email && emailAddress != "")
                {
                    Utilities.SendEmail(emailAddress, emailSubject, response, "blank");
                }

                if (sms && mobileNumber != "")
                {
                    Utilities.SendSMS(mobileNumber, responseSMS);
                }

                desg = new AutoDocumentsDesign("sitevisitStakeholder");
                response = desg.DocumentDesign;
                responseSMS = desg.DocumentDesignSMS;
                emailSubject = desg.EmailSubject;

                //get list of stakeholders
                List<SiteVisitReport> stakeReports = GetSiteVisitReports(site.Id);
                foreach (SiteVisitReport rep in stakeReports)
                {
                    Stakeholder stake = new Stakeholder(rep.FK_StakeholderId);
                    #region sitevisit client notification

                    //check if registered first                    
                    if (doc.DocumentType == "loan")
                    {
                        response = response.Replace("<registration>", reg.ReferenceNumber);
                        response = response.Replace("<client>", reg.FirstNames + " " + reg.LastName);
                        response = response.Replace("<nin>", reg.NIN);
                        response = response.Replace("<name>", stake.Name);

                        response = response.Replace("<date>", site.VisitDate.ToLongTimeString());
                        response = response.Replace("<address>", site.VisitAddress);
                        //sms version
                        responseSMS = responseSMS.Replace("<registration>", reg.ReferenceNumber);
                        responseSMS = responseSMS.Replace("<name>", stake.Name);
                        responseSMS = responseSMS.Replace("<nin>", reg.NIN);
                        responseSMS = responseSMS.Replace("<client>", reg.FirstNames + " " + reg.LastName);

                        responseSMS = responseSMS.Replace("<date>", site.VisitDate.ToLongTimeString());
                        responseSMS = responseSMS.Replace("<address>", site.VisitAddress);
                        //subject email version
                        emailSubject = emailSubject.Replace("<registration>", reg.ReferenceNumber);
                        emailSubject = emailSubject.Replace("<name>", stake.Name);
                        emailSubject = emailSubject.Replace("<nin>", reg.NIN);
                        emailSubject = emailSubject.Replace("<client>", reg.FirstNames + " " + reg.LastName);

                        emailSubject = emailSubject.Replace("<date>", site.VisitDate.ToLongTimeString());
                        emailSubject = emailSubject.Replace("<address>", site.VisitAddress);
                    }


                    #endregion

                    mobileNumber = stake.Mobile;
                    emailAddress = stake.Email;

                    if (email && emailAddress != "")
                    {
                        Utilities.SendEmail(emailAddress, emailSubject, response, "blank");
                    }

                    if (sms && mobileNumber != "")
                    {
                        Utilities.SendSMS(mobileNumber, responseSMS);
                    }
                }
            }
            else
            {
                if (email && emailAddress != "")
                {
                    Utilities.SendEmail(emailAddress, emailSubject, response, "blank");
                }

                if (sms && mobileNumber != "")
                {
                    Utilities.SendSMS(mobileNumber, responseSMS);
                }
            }

            return response;
        }

        public static List<AutoDocument> CheckAutoDocument(long Id, string entityType)
        {
            List<AutoDocument> response = new List<AutoDocument>();
            //get invoices ack first
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Invoice where ReceiptNumber<>'' and DocumentType='" + entityType + "' and FK_DocumentId=" + Id);
            while (reader.Reader.Read())
            {
                AutoDocument reg = new AutoDocument();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.DocumentType = "ackPayment";
                reg.DocumentTypeName = "Payment Acknowledgement";
                response.Add(reg);
            }
            reader.Close();
            //get receipts
            Utilities.DatabaseReader readerReceipt = new Utilities.DatabaseReader("select * from Receipt where FK_InvoiceId in (select Id from Invoice where DocumentType='" + entityType + "' and FK_DocumentId=" + Id + ")");
            while (readerReceipt.Reader.Read())
            {
                AutoDocument reg = new AutoDocument();
                reg.Id = long.Parse(readerReceipt.Reader["Id"].ToString());
                reg.DocumentType = "receipt";
                reg.DocumentTypeName = "Receipt (" + (readerReceipt.Reader["Id"].ToString()).PadLeft(10, '0') + ")";
                response.Add(reg);
            }
            readerReceipt.Close();

            return response;
        }

        public static List<AutoDocument> CheckTrainingAutoDocument(long Id, string entityType)
        {
            List<AutoDocument> response = new List<AutoDocument>();
            //get invoices ack first
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from TrainingRegistration where Attended='True' and FK_BusinessRegistrationId=" + Id);
            while (reader.Reader.Read())
            {
                AutoDocument reg = new AutoDocument();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.DocumentType = "training";
                reg.DocumentTypeName = "Cert" + reg.Id.ToString().PadLeft(6, '0');
                response.Add(reg);
            }
            reader.Close();

            return response;
        }

        //get auto document
        public static Byte[] GetAutoDocument(string docType, long Id)
        {
            string html = "<html><head><title>Blank</title></head><body>Blank</body></html>";

            switch (docType)
            {
                case "ackPayment":
                    Invoice invoice = new Invoice(Id);
                    html = GenerateDocument(docType, invoice, false, false);
                    break;
                case "receipt":
                    Receipt receipt = new Receipt(Id);
                    html = GenerateDocument(docType, receipt, false, false);
                    break;
                case "First":
                    RepaymentSchedule rep = new RepaymentSchedule(Id);
                    AutoDocumentsDesign desg = new AutoDocumentsDesign(docType);
                    html = GenerateDocument(docType, rep, desg.Email, desg.SMS);
                    break;
                case "Second":
                    RepaymentSchedule rep1 = new RepaymentSchedule(Id);
                    AutoDocumentsDesign desg1 = new AutoDocumentsDesign(docType);
                    html = GenerateDocument(docType, rep1, desg1.Email, desg1.SMS);
                    break;
                case "Final":
                    RepaymentSchedule rep2 = new RepaymentSchedule(Id);
                    AutoDocumentsDesign desg2 = new AutoDocumentsDesign(docType);
                    html = GenerateDocument(docType, rep2, desg2.Email, desg2.SMS);
                    break;
                case "voucher":
                    PaymentVoucher pv = new PaymentVoucher(Id);
                    html = GenerateDocument(docType, pv, false, false);
                    break;
                default:
                    Loan loan = new Loan(Id);
                    html = GenerateDocument(docType, loan, false, false);
                    break;
            }

            byte[] data = PdfSharpConvert(html);
            if (docType != "receipt")
            {
                //document.Save(@"F:\papa.pdf");
                string tmp = DateTime.Now.ToString("yyMMddHHmmssfff");
                File.WriteAllBytes(@"C:\docs\" + tmp + ".pdf", data);
                PdfDocument document = PdfSharp.Pdf.IO.PdfReader.Open(@"C:\docs\" + tmp + ".pdf");
                // Get an XGraphics object for drawing
                XGraphics gfx = XGraphics.FromPdfPage(document.Pages[0]);
                DrawImage(gfx, @"C:\docs\sbfa\logo.png", 20, 30, 100, 100);

                byte[] pdfData;
                using (var ms = new MemoryStream())
                {
                    document.Save(ms);
                    pdfData = ms.ToArray();
                }

                try
                {
                    File.Delete(@"C:\docs\" + tmp + ".pdf");
                }
                catch { }

                return pdfData;
            }
            else
                return data;
        }

        static void DrawImage(XGraphics gfx, string jpegSamplePath, int x, int y, int width, int height)
        {
            XImage image = XImage.FromFile(jpegSamplePath);
            gfx.DrawImage(image, x, y, width, height);
        }

        public static Byte[] GetDisbursementDocument(long Id)
        {
            string html = "<html><head><title>Blank</title></head><body>Blank</body></html>";
            DisbursementRequest dis = new DisbursementRequest(Id);
            AutoDocumentsDesign desg = new AutoDocumentsDesign("disbursementForm");
            html = GenerateDocument("disbursementForm", dis, desg.Email, desg.SMS);

            return PdfSharpConvert(html);
        }

        public static List<LoanApprovalCriteria> GetLoanApprovalList()
        {
            List<LoanApprovalCriteria> response = new List<LoanApprovalCriteria>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from LoanApprovalCriteria");
            while (reader.Reader.Read())
            {
                LoanApprovalCriteria doc = new LoanApprovalCriteria();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.FK_WorkFlowId = int.Parse(reader.Reader["FK_WorkFlowId"].ToString());
                doc.ParameterField = (reader.Reader["ParameterField"].ToString());
                doc.ParameterDataType = (reader.Reader["ParameterDataType"].ToString());
                doc.ParameterFieldName = (reader.Reader["ParameterFieldName"].ToString());
                doc.ParameterValue = (reader.Reader["ParameterValue"].ToString());
                doc.ParameterMaxValue = (reader.Reader["ParameterMaxValue"].ToString());
                doc.ParameterEvaluationType = (reader.Reader["ParameterEvaluationType"].ToString());
                doc.Active = bool.Parse(reader.Reader["Active"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();

            return response;
        }

        public static LoanRequestApproval GetLoanApproval(long Id)
        {
            LoanRequestApproval approve = new LoanRequestApproval(Id);
            return approve;
        }

        public static bool CreateLoanApproval(long Id)
        {
            LoanRequestApproval approve = new LoanRequestApproval();
            LoanRequest loan = new LoanRequest(Id);
            approve.Id = Id;
            approve.Status = "";
            approve.StatusReason = "";
            List<LoanApprovalCriteria> criteria = Utilities.GetLoanApprovalList();
            foreach (LoanApprovalCriteria crit in criteria)
            {
                if (ValidateLoanField(crit, loan))
                {
                    approve.WorkFlowId = crit.FK_WorkFlowId;
                    break;
                }
            }

            return approve.Save();

        }

        public static bool ValidateLoanField(LoanApprovalCriteria aVal, LoanRequest classObject)
        {
            object val = null;
            bool found = false;
            FieldInfo[] fields = classObject.GetType().GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (FieldInfo f in fields)
            {
                if (f.Name.Split('<')[1].Split('>')[0] == aVal.ParameterField)
                {
                    val = f.GetValue(classObject);
                    found = true;
                    break;
                }
                else
                {

                }

            }

            if (found)
                return ValidateField(aVal, val);
            else
                return false;
        }

        static bool ValidateField(LoanApprovalCriteria aVal, object val)
        {
            bool allValidated = true;

            if (aVal.ParameterDataType == "quantity")
            {
                if (aVal.ParameterEvaluationType == "less")
                {
                    if (float.Parse(val.ToString()) < float.Parse(aVal.ParameterValue))
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "greater")
                {
                    if (float.Parse(val.ToString()) > float.Parse(aVal.ParameterValue))
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "equal")
                {
                    if (float.Parse(val.ToString()) == float.Parse(aVal.ParameterValue))
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "not")
                {
                    if (float.Parse(val.ToString()) != float.Parse(aVal.ParameterValue))
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "in")
                {
                    if ((float.Parse(val.ToString()) >= float.Parse(aVal.ParameterValue)) && (float.Parse(val.ToString()) <= float.Parse(aVal.ParameterMaxValue)))
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "between")
                {
                    if ((float.Parse(val.ToString()) > float.Parse(aVal.ParameterValue)) && (float.Parse(val.ToString()) < float.Parse(aVal.ParameterMaxValue)))
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "out")
                {
                    if ((float.Parse(val.ToString()) < float.Parse(aVal.ParameterValue)) || (float.Parse(val.ToString()) > float.Parse(aVal.ParameterMaxValue)))
                        allValidated = true;
                    else
                        allValidated = false;
                }
            }
            else
            {
                if (aVal.ParameterEvaluationType == "equal")
                {
                    if (val.ToString() == aVal.ParameterValue)
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "not")
                {
                    if (val.ToString() != aVal.ParameterValue)
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "like")
                {
                    if (val.ToString().IndexOf(aVal.ParameterValue) > -1)
                        allValidated = true;
                    else
                        allValidated = false;
                }
                else if (aVal.ParameterEvaluationType == "not like")
                {
                    if (val.ToString().IndexOf(aVal.ParameterValue) < 0)
                        allValidated = true;
                    else
                        allValidated = false;
                }

            }

            return allValidated;
        }

        public static QuickStats GetQuickStats()
        {
            return new QuickStats();
        }

        public static List<Notifications> CheckNotifications(string filterText, bool pending)
        {
            List<Notifications> response = new List<Notifications>();
            ReferenceTable usrAcc = GetReferenceTableItem("AccountsOfficer", "rolgro");
            ReferenceTable usrHr = GetReferenceTableItem("HumanResources", "rolgro");

            //get invoices ack first
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " * from Notifications where ((FK_Username='" + Security.actingUser + "') or (FK_Username='' and DocumentType='paymentVoucher' and ('" + ((Security.CheckUserRolegroupAccess(Security.actingUser, usrAcc.Id)) ? "True" : "False") + "'='True')) or (FK_Username='' and DocumentType='invoice' and ('" + ((Security.CheckUserRolegroupAccess(Security.actingUser, usrAcc.Id)) ? "True" : "False") + "'='True')) or (FK_Username='' and DocumentType='loanSite' and ('" + ((Security.CheckUserRolegroupAccess(Security.actingUser, usrHr.Id)) ? "True" : "False") + "'='True'))) and Status='" + ((pending) ? "False" : "True") + "' and Title like '%" + filterText + "%'");
            while (reader.Reader.Read())
            {
                Notifications not = new Notifications();
                not.Id = long.Parse(reader.Reader["Id"].ToString());
                not.FK_Username = (reader.Reader["FK_Username"].ToString());
                not.Title = (reader.Reader["Title"].ToString());
                not.DocumentType = (reader.Reader["DocumentType"].ToString());
                not.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                not.Status = bool.Parse(reader.Reader["Status"].ToString());
                not.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                not.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                not.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                not.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                response.Add(not);
            }
            reader.Close();

            return response;
        }

        public static bool UpdateNotifications(long Id, bool status)
        {
            return Notifications.Update(Id, status);
        }
    }
}