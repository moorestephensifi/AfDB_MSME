﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SBFA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "sbfaSecurity" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select sbfaSecurity.svc or sbfaSecurity.svc.cs at the Solution Explorer and start debugging.
    public class SBFASecurity : ISBFASecurity
    {
        public AuthenticationResponse Authenticate(string username, string password)
        {
           return Security.Authenticate(username, password);
        }

        public PasswordChangeResponse ChangePassword(string username, string oldpassword, string newpassword)
        {
            return Security.ChangePassword(username,oldpassword,newpassword);
            
        }
        public bool UpdateUserDetails(string userName, string FirstName, string Surname, string EmailAddress, string MobileNumber)
        {
            return ApplicationUsers.UpdateUserDetails(userName, FirstName, Surname, EmailAddress, MobileNumber);
        }
    }
}
