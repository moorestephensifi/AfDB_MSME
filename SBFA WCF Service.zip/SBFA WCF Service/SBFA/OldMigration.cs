﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SBFA
{
    public partial class Utilities
    {
        public static List<oldLoanRequest> GetoldLoanRequests(string filterText)
        {
            List<oldLoanRequest> response = new List<oldLoanRequest>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT top " + FilterBatch() + " * FROM oldLoanRequest where AccounNo like '%" + filterText + "%' or  LoanType like '%" + filterText + "%' or  Description like '%" + filterText + "%' or LoanNo like '%" + filterText + "%' or Applicants like '%" + filterText + "%' or Guarantor like '%" + filterText + "%'");
            while (reader.Reader.Read())
            {
                try
                {
                    oldLoanRequest acc = new oldLoanRequest();
                    acc.LoanType = (reader.Reader["LoanType"].ToString());
                    acc.Description = (reader.Reader["Description"].ToString());
                    acc.TotalCost = float.Parse(reader.Reader["TotalCost"].ToString());
                    acc.TotalRequested = float.Parse(reader.Reader["TotalRequested"].ToString());
                    acc.DateApplied = DateTime.Parse(reader.Reader["DateApplied"].ToString());
                    acc.HasApplicantSigned = float.Parse(reader.Reader["HasApplicantSigned"].ToString());
                    acc.IsApplicationComplete = float.Parse(reader.Reader["IsApplicationComplete"].ToString());
                    acc.DateApplicationReceived = DateTime.Parse(reader.Reader["DateApplicationReceived"].ToString());
                    acc.LoanNo = (reader.Reader["LoanNo"].ToString());
                    acc.MaxValue = float.Parse(reader.Reader["MaxValue"].ToString());
                    acc.InterestRate = float.Parse(reader.Reader["InterestRate"].ToString());
                    acc.MaxRepayment = float.Parse(reader.Reader["MaxRepayment"].ToString());
                    acc.LoanTypeDescription = (reader.Reader["LoanTypeDescription"].ToString());
                    acc.Id = float.Parse(reader.Reader["Id"].ToString());
                    acc.Applicants = (reader.Reader["Applicants"].ToString());
                    acc.Guarantor = (reader.Reader["Guarantor"].ToString());
                    acc.LoanStatus = (reader.Reader["LoanStatus"].ToString());
                    acc.Remarks = (reader.Reader["Remarks"].ToString());
                    acc.ApprovedDate = DateTime.Parse(reader.Reader["ApprovedDate"].ToString());
                    acc.EffectiveDate = DateTime.Parse(reader.Reader["EffectiveDate"].ToString());
                    acc.GracePeriod = float.Parse(reader.Reader["GracePeriod"].ToString());
                    acc.RepaymentPeriod = float.Parse(reader.Reader["RepaymentPeriod"].ToString());
                    acc.RepaymentAmount = float.Parse(reader.Reader["RepaymentAmount"].ToString());
                    acc.AccounNo = (reader.Reader["AccounNo"].ToString());

                    response.Add(acc);
                }
                catch (Exception ex)
                {

                }

            }
            reader.Close();

            return response;
        }

        public static List<oldRecovery> GetoldRecoverys(string filterText)
        {
            List<oldRecovery> response = new List<oldRecovery>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT top " + FilterBatch() + " * FROM oldRecovery where AccounNo  like '%" + filterText + "%' or Surname like '%" + filterText + "%' or NIN like '%" + filterText + "%' or FirstName like '%" + filterText + "%' or LoanNo like '%" + filterText + "%'");
            while (reader.Reader.Read())
            {
                try
                {
                    oldRecovery acc = new oldRecovery();

                    acc.FK_APPLICANTID = float.Parse(reader.Reader["FK_APPLICANTID"].ToString());
                    acc.FK_LOANREQUESTID = float.Parse(reader.Reader["FK_LOANREQUESTID"].ToString());
                    acc.TotalPaid = float.Parse(reader.Reader["TotalPaid"].ToString());
                    acc.TotalDue = float.Parse(reader.Reader["TotalDue"].ToString());
                    acc.Surname = (reader.Reader["Surname"].ToString());
                    acc.FirstName = (reader.Reader["FirstName"].ToString());
                    acc.Address = (reader.Reader["Address"].ToString());
                    acc.Island = (reader.Reader["Island"].ToString());
                    acc.HomePhone = (reader.Reader["HomePhone"].ToString());
                    acc.NIN = (reader.Reader["NIN"].ToString());
                    acc.OtherPhone = (reader.Reader["OtherPhone"].ToString());
                    acc.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                    acc.Country = (reader.Reader["Country"].ToString());
                    acc.Name = (reader.Reader["Name"].ToString());
                    acc.TotalCost = float.Parse(reader.Reader["TotalCost"].ToString());
                    acc.TotalRequested = float.Parse(reader.Reader["TotalRequested"].ToString());
                    acc.DateApplied = DateTime.Parse(reader.Reader["DateApplied"].ToString());
                    acc.LoanNo = (reader.Reader["LoanNo"].ToString());
                    acc.AccounNo = (reader.Reader["AccounNo"].ToString());
                    acc.Gender = (reader.Reader["Gender"].ToString());

                    response.Add(acc);
                }
                catch (Exception ex)
                {

                }

            }
            reader.Close();

            return response;
        }

        public static List<oldRepayments> GetoldRepayments(string filterText)
        {
            List<oldRepayments> response = new List<oldRepayments>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT top " + FilterBatch() + " * FROM oldRepayments where NIN like '%" + filterText + "%' or FirstName like '%" + filterText + "%' or Surname like '%" + filterText + "%' or AccounNo like '%" + filterText + "%' or LoanNo like '%" + filterText + "%'");
            while (reader.Reader.Read())
            {
                try
                {
                    oldRepayments acc = new oldRepayments();

                    acc.PaymentType = (reader.Reader["PaymentType"].ToString());
                    acc.PaymentMode = (reader.Reader["PaymentMode"].ToString());
                    acc.PayPoint = (reader.Reader["PayPoint"].ToString());
                    acc.NIN = (reader.Reader["NIN"].ToString());
                    acc.FirstName = (reader.Reader["FirstName"].ToString());
                    acc.Surname = (reader.Reader["Surname"].ToString());
                    acc.LoanNo = (reader.Reader["LoanNo"].ToString());
                    acc.AppMonth = (reader.Reader["AppMonth"].ToString());
                    acc.APPLYEAR = float.Parse(reader.Reader["APPLYEAR"].ToString());
                    acc.PAYMENTDATE = DateTime.Parse(reader.Reader["PAYMENTDATE"].ToString());
                    acc.AMOUNT = float.Parse(reader.Reader["AMOUNT"].ToString());
                    acc.PAYDESCRIPTION = (reader.Reader["PAYDESCRIPTION"].ToString());
                    acc.RECEIPTNO = float.Parse(reader.Reader["RECEIPTNO"].ToString());
                    acc.RECEIPTYEAR = float.Parse(reader.Reader["RECEIPTYEAR"].ToString());
                    acc.PRINTSTATUS = (reader.Reader["PRINTSTATUS"].ToString());
                    acc.PRINTEDDATE = DateTime.Parse(reader.Reader["PRINTEDDATE"].ToString());
                    acc.REFERENCENO = (reader.Reader["REFERENCENO"].ToString());
                    acc.MANUALRECEIPTNO = float.Parse(reader.Reader["MANUALRECEIPTNO"].ToString());
                    acc.PAYMENTID = float.Parse(reader.Reader["PAYMENTID"].ToString());
                    acc.Address = (reader.Reader["Address"].ToString());
                    acc.CRNO = (reader.Reader["CRNO"].ToString());
                    acc.FK_LOANREQUESTID = float.Parse(reader.Reader["FK_LOANREQUESTID"].ToString());
                    acc.ApplicantId = float.Parse(reader.Reader["ApplicantId"].ToString());
                    acc.AppMonthId = float.Parse(reader.Reader["AppMonthId"].ToString());
                    acc.Cashier = (reader.Reader["Cashier"].ToString());
                    acc.RECEIVEDDATE = DateTime.Parse(reader.Reader["RECEIVEDDATE"].ToString());
                    acc.AccounNo = (reader.Reader["AccounNo"].ToString());
                    acc.REMARKS = (reader.Reader["REMARKS"].ToString());
                    acc.LoanType = (reader.Reader["LoanType"].ToString());
                    acc.Category = (reader.Reader["Category"].ToString());
                    acc.F31 = (reader.Reader["F31"].ToString());
                    acc.F32 = (reader.Reader["F32"].ToString());


                    response.Add(acc);
                }
                catch (Exception ex)
                {

                }

            }
            reader.Close();

            return response;
        }

        public static List<BusinessAccountOld> GetOldBusinessAccounts(string filterText)
        {
            List<BusinessAccountOld> response = new List<BusinessAccountOld>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT top " + FilterBatch() + " * FROM BusinessAccountOld where LoanNumber like '%" + filterText + "%' or AccountNumber like '%" + filterText + "%' or AccountNumber in (select AccounNo from oldRecovery where NIN like '%" + filterText + "%' or FirstName like '%" + filterText + "%' or Surname like '%" + filterText + "%' or LoanNo like '%" + filterText + "%')");
            while (reader.Reader.Read())
            {
                try
                {
                    BusinessAccountOld acc = new BusinessAccountOld();
                    acc.Id = long.Parse(reader.Reader["Id"].ToString());
                    acc.AccountNumber = (reader.Reader["AccountNumber"].ToString());
                    acc.LoanNumber = (reader.Reader["LoanNumber"].ToString());
                    acc.AccountBalance = float.Parse(reader.Reader["AccountBalance"].ToString());
                    acc.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                    acc.CancellationFee = float.Parse(reader.Reader["CancellationFee"].ToString());
                    acc.Refund = float.Parse(reader.Reader["Refund"].ToString());
                    acc.Penalty = float.Parse(reader.Reader["Penalty"].ToString());
                    acc.IntrestRate = float.Parse(reader.Reader["IntrestRate"].ToString());
                    acc.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                    acc.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                    acc.LastPaymentDate = DateTime.Parse(reader.Reader["LastPaymentDate"].ToString());
                    acc.LastCalculationDate = DateTime.Parse(reader.Reader["LastCalculationDate"].ToString());

                    response.Add(acc);
                }
                catch (Exception ex)
                {

                }

            }
            reader.Close();

            return response;
        }

        public static BusinessRegistration GetOldBusinessRegistrationByRegistration(string account, string loan)
        {
            return new BusinessRegistration( account, loan);
        }

        public static BusinessRegistration GetOldBusinessRegistrationByRegistration(string account)
        {
            return new BusinessRegistration(account,1);
        }

        public static BusinessAccountOld GetOldBusinessAccountByAccount(string acc,string loan)
        {
            return new BusinessAccountOld(acc,loan);
        }

        public static string OldReceiptRepayment(string account,string loan, string currency, float balance, float amount, int fK_PayBranchId, int fK_PaymentMethodId, DateTime lastPaymentDate)
        {
            string refNo = account + "_" + Utilities.ExecuteScalar("select count(FK_ReferenceNumber) from Invoice where FK_ReferenceNumber like '" + account + "%'");

            Invoice newInvoice = new Invoice(refNo, currency, amount, false, "repayment", 0, 0, 0, 0, 0);
            long invNum = newInvoice.Save();
            if (invNum > 0)
            {
                InvoiceItem temp = new InvoiceItem(invNum, currency, amount, "Old Loan Repayment for " + account);
                temp.Save();

                //pay invoice
                return OldPayRepaymentInvoice(invNum, currency, balance, amount, 0, fK_PayBranchId, fK_PaymentMethodId, account,loan, lastPaymentDate);
            }
            else
            {
                return "0";
            }
        }

        public static string OldPayRepaymentInvoice(long Id, string currency, float balance, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId, string account,string loan, DateTime lastPaymentDate)
        {
            Invoice invoice = new Invoice(Id);
            string receipt = invoice.Pay(currency, amount, change, fK_PayBranchId, fK_PaymentMethodId);
            invoice.ReceiptNumber = receipt;
            if (receipt != "0")
            {
                //reord account activity
                OldAccountActivity act = new OldAccountActivity(account,loan, Id, "Repayment", "Receipt " + receipt, amount, true);
                long x=act.Save();
                LoanIntrestActivity logActivity = new LoanIntrestActivity(loan, x);
                logActivity.Save();
                //update last payment date
                BusinessAccountOld.SetLastCalculationDate(account,loan, balance, lastPaymentDate);
                
                try
                {
                    // Utilities.GenerateDocument("ackPayment", invoice, true, true);
                }
                catch { }
            }

            return receipt;
        }

        public static string OldReceiptFeeRepayment(string account,string loan, string currency, float amount, int fK_PayBranchId, int fK_PaymentMethodId)
        {
            string refNo = account + "_" + Utilities.ExecuteScalar("select count(FK_ReferenceNumber) from Invoice where FK_ReferenceNumber like '" + account + "%'");

            Invoice newInvoice = new Invoice(refNo, currency, amount, false, "fee", 0, 0, 0, 0, 0);
            long invNum = newInvoice.Save();
            if (invNum > 0)
            {
                InvoiceItem temp = new InvoiceItem(invNum, currency, amount, "Loan Fee for " + account);
                temp.Save();

                //pay invoice
                return OldPayRepaymentInvoice(invNum, currency, amount, 0, fK_PayBranchId, fK_PaymentMethodId, account,loan);
            }
            else
            {
                return "0";
            }
        }

        public static string OldPayRepaymentInvoice(long Id, string currency, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId, string account,string loan)
        {
            Invoice invoice = new Invoice(Id);
            string receipt = invoice.Pay(currency, amount, change, fK_PayBranchId, fK_PaymentMethodId);
            invoice.ReceiptNumber = receipt;
            if (receipt != "0")
            {
                //reord account activity
                AccountActivity act = new AccountActivity(account, Id, "Old Repayment Fee", "Receipt " + receipt, amount, true);
                act.Save();

                //update last payment date
                BusinessAccountOld bus = new BusinessAccountOld(account,loan);
                double fee = bus.ProcessingFee;
                double fee2 = bus.CancellationFee;
                double pen = bus.Penalty;
                double temp = amount;

                if (fee > 0)
                {
                    if (temp >= fee)
                    {
                        if (BusinessAccountOld.AddProcessingBalance(account,loan, float.Parse((-1 * fee).ToString())))
                            temp = temp - fee;
                    }
                    else
                    {
                        if (BusinessAccountOld.AddProcessingBalance(account, loan, float.Parse((-1 * temp).ToString())))
                            temp = 0;
                    }
                }

                if (temp > 0 && fee2 > 0)
                {
                    if (temp >= fee2)
                    {
                        if (BusinessAccountOld.AddCancellationBalance(account, loan, float.Parse((-1 * fee2).ToString())))
                            temp = temp - fee2;
                    }
                    else
                    {
                        if (BusinessAccountOld.AddCancellationBalance(account, loan, float.Parse((-1 * temp).ToString())))
                            temp = 0;
                    }
                }

                if (temp > 0 && pen > 0)
                {
                    if (temp >= pen)
                    {
                        if (BusinessAccountOld.AddPenaltyBalance(account, loan, float.Parse((-1 * pen).ToString())))
                            temp = temp - pen;
                    }
                    else
                    {
                        if (BusinessAccountOld.AddCancellationBalance(account, loan, float.Parse((-1 * temp).ToString())))
                            temp = 0;
                    }
                }

                try
                {
                    // Utilities.GenerateDocument("ackPayment", invoice, true, true);
                }
                catch { }
            }

            return receipt;
        }

        public static List<BusinessAccountOld> GetOldBusinessAccountsWithBalanceForPeriod()
        {
            List<BusinessAccountOld> response = new List<BusinessAccountOld>();
            //retrieve registrations details from database
            DateTime tempDate = (DateTime.Now.AddMonths(-1));
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM BusinessAccountOld where AccountBalance>0 and StartDate<'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:000") + "' and LastCalculationDate <'"+tempDate.ToString("yyyy-MM-dd HH:mm:ss.fff")+ "' and IntrestRate>0 order by LastCalculationDate asc");
            while (reader.Reader.Read())
            {
                BusinessAccountOld acc = new BusinessAccountOld();
                acc.Id = long.Parse(reader.Reader["Id"].ToString());
                acc.AccountNumber = (reader.Reader["AccountNumber"].ToString());
                acc.LoanNumber = (reader.Reader["LoanNumber"].ToString());
                acc.AccountBalance = float.Parse(reader.Reader["AccountBalance"].ToString());
                acc.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                acc.CancellationFee = float.Parse(reader.Reader["CancellationFee"].ToString());
                acc.Refund = float.Parse(reader.Reader["Refund"].ToString());
                acc.Penalty = float.Parse(reader.Reader["Penalty"].ToString());
                acc.IntrestRate = float.Parse(reader.Reader["IntrestRate"].ToString());
                acc.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                acc.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                acc.LastPaymentDate = DateTime.Parse(reader.Reader["LastPaymentDate"].ToString());
                acc.LastCalculationDate = DateTime.Parse(reader.Reader["LastCalculationDate"].ToString());
                response.Add(acc);
            }
            reader.Close();

            return response;
        }

        public static List<BusinessAccountOld> GetOldBusinessAccountsWithBalance()
        {
            List<BusinessAccountOld> response = new List<BusinessAccountOld>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("SELECT * FROM BusinessAccountOld where AccountBalance>0 and StartDate<'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:000") + "'");
            while (reader.Reader.Read())
            {
                BusinessAccountOld acc = new BusinessAccountOld();
                acc.Id = long.Parse(reader.Reader["Id"].ToString());
                acc.AccountNumber = (reader.Reader["AccountNumber"].ToString());
                acc.LoanNumber = (reader.Reader["LoanNumber"].ToString());
                acc.AccountBalance = float.Parse(reader.Reader["AccountBalance"].ToString());
                acc.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                acc.CancellationFee = float.Parse(reader.Reader["CancellationFee"].ToString());
                acc.Refund = float.Parse(reader.Reader["Refund"].ToString());
                acc.Penalty = float.Parse(reader.Reader["Penalty"].ToString());
                acc.IntrestRate = float.Parse(reader.Reader["IntrestRate"].ToString());
                acc.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                acc.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                acc.LastPaymentDate = DateTime.Parse(reader.Reader["LastPaymentDate"].ToString());
                acc.LastCalculationDate = DateTime.Parse(reader.Reader["LastCalculationDate"].ToString());
               
                    response.Add(acc);
            }
            reader.Close();

            return response;
        }
    }

    public class oldLoanRequest
    {
        public oldLoanRequest() { }

        public string LoanType { get; set; }
        public string Description { get; set; }
        public float TotalCost { get; set; }
        public float TotalRequested { get; set; }
        public DateTime DateApplied { get; set; }
        public float HasApplicantSigned { get; set; }
        public float IsApplicationComplete { get; set; }
        public DateTime DateApplicationReceived { get; set; }
        public string LoanNo { get; set; }
        public float MaxValue { get; set; }
        public float InterestRate { get; set; }
        public float MaxRepayment { get; set; }
        public string LoanTypeDescription { get; set; }
        public float Id { get; set; }
        public string Applicants { get; set; }
        public string Guarantor { get; set; }
        public string LoanStatus { get; set; }
        public string Remarks { get; set; }
        public DateTime ApprovedDate { get; set; }
        public DateTime EffectiveDate { get; set; }
        public float GracePeriod { get; set; }
        public float RepaymentPeriod { get; set; }
        public float RepaymentAmount { get; set; }
        public string AccounNo { get; set; }
    }

    public class oldRecovery
    {
        public oldRecovery() { }

        public float FK_APPLICANTID { get; set; }
        public float FK_LOANREQUESTID { get; set; }
        public float TotalPaid { get; set; }
        public float TotalDue { get; set; }
        public string Surname { get; set; }
        public string FirstName { get; set; }
        public string Address { get; set; }
        public string Island { get; set; }
        public string HomePhone { get; set; }
        public string NIN { get; set; }
        public string OtherPhone { get; set; }
        public DateTime DOB { get; set; }
        public string Country { get; set; }
        public string Name { get; set; }
        public float TotalCost { get; set; }
        public float TotalRequested { get; set; }
        public DateTime DateApplied { get; set; }
        public string LoanNo { get; set; }
        public string AccounNo { get; set; }
        public string Gender { get; set; }
    }

    public class oldRepayments
    {
        public oldRepayments() { }

        public string PaymentType { get; set; }
        public string PaymentMode { get; set; }
        public string PayPoint { get; set; }
        public string NIN { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string LoanNo { get; set; }
        public string AppMonth { get; set; }
        public float APPLYEAR { get; set; }
        public DateTime PAYMENTDATE { get; set; }
        public float AMOUNT { get; set; }
        public string PAYDESCRIPTION { get; set; }
        public float RECEIPTNO { get; set; }
        public float RECEIPTYEAR { get; set; }
        public string PRINTSTATUS { get; set; }
        public DateTime PRINTEDDATE { get; set; }
        public string REFERENCENO { get; set; }
        public float MANUALRECEIPTNO { get; set; }
        public float PAYMENTID { get; set; }
        public string Address { get; set; }
        public string CRNO { get; set; }
        public float FK_LOANREQUESTID { get; set; }
        public float ApplicantId { get; set; }
        public float AppMonthId { get; set; }
        public string Cashier { get; set; }
        public DateTime RECEIVEDDATE { get; set; }
        public string AccounNo { get; set; }
        public string REMARKS { get; set; }
        public string LoanType { get; set; }
        public string Category { get; set; }
        public string F31 { get; set; }
        public string F32 { get; set; }
    }

    public class BusinessAccountOld
    {
        public BusinessAccountOld() { }

        public BusinessAccountOld(string acc, string loan)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BusinessAccountOld where LoanNumber='" + loan + "' and AccountNumber='" + acc + "'");
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.AccountNumber = (reader.Reader["AccountNumber"].ToString());
                this.LoanNumber = (reader.Reader["LoanNumber"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.AccountBalance = float.Parse(reader.Reader["AccountBalance"].ToString());
                this.ProcessingFee = float.Parse(reader.Reader["ProcessingFee"].ToString());
                this.CancellationFee = float.Parse(reader.Reader["CancellationFee"].ToString());
                this.Refund = float.Parse(reader.Reader["Refund"].ToString());
                this.Penalty = float.Parse(reader.Reader["Penalty"].ToString());
                this.IntrestRate = float.Parse(reader.Reader["IntrestRate"].ToString());
                this.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                this.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                this.LastPaymentDate = DateTime.Parse(reader.Reader["LastPaymentDate"].ToString());
                this.LastCalculationDate = DateTime.Parse(reader.Reader["LastCalculationDate"].ToString());

            }
            reader.Close();
        }

        public long Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into BusinessAccountOld(AccountNumber,LoanNumber,AccountBalance,ProcessingFee,CancellationFee,Penalty,Refund,IntrestRate,LastPaymentDate,LastCalculationDate,StartDate,EndDate,Created,CreatedBy,LastModified,LastModifiedBy) values('" + AccountNumber + "','" + LoanNumber + "',0,0,0,0,0,0,'" + DateTime.Now.AddYears(100).ToString("yyyy-MM-dd HH:mm:ss.000") + "','" + DateTime.Now.AddYears(100).ToString("yyyy-MM-dd HH:mm:ss.000") + "','" + DateTime.Now.AddYears(100).ToString("yyyy-MM-dd HH:mm:ss.000") + "','" + DateTime.Now.AddYears(100).ToString("yyyy-MM-dd HH:mm:ss.000") + "', CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

            return x;
        }

        public static bool AddBalance(string account, string loan, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccountOld set AccountBalance+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where LoanNumber='" + loan + "' and  AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool AddProcessingBalance(string account, string loan, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccountOld set ProcessingFee+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where LoanNumber='" + loan + "' and  AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool AddCancellationBalance(string account, string loan, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccountOld set CancellationFee+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where LoanNumber='" + loan + "' and  AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool AddPenaltyBalance(string account, string loan, float amount)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccountOld set Penalty+=" + amount + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where LoanNumber='" + loan + "' and  AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool SetRate(string account, string loan, float rate)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccountOld set IntrestRate=" + rate + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where LoanNumber='" + loan + "' and  AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool SetDates(string account, string loan, DateTime sd, DateTime ed)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccountOld set LastCalculationDate='" + sd.AddMonths(-1).ToString("yyyy-MM-dd 06:00:00.000") + "',LastPaymentDate='" + sd.AddMonths(-1).ToString("yyyy-MM-dd 06:00:00.000") + "',StartDate='" + sd.ToString("yyyy-MM-dd 06:00:00.000") + "',EndDate='" + sd.ToString("yyyy-MM-dd 23:59:59.000") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where LoanNumber='" + loan + "' and  AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public static bool SetLastCalculationDate(string account, string loan, float balance, DateTime ld)
        {
            long x = Utilities.ExecuteNonQuery("update BusinessAccountOld set AccountBalance=" + balance + ",LastCalculationDate='" + ld.ToString("yyyy-MM-dd 06:00:00.000") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where LoanNumber='" + loan + "' and  AccountNumber='" + account + "'");

            return ((x > 0) ? true : false);
        }

        public float TotalBalance()
        {
            return (AccountBalance + ProcessingFee + CancellationFee - Refund + Penalty) - Refund;
        }

        public long Id { get; set; }
        public string AccountNumber { get; set; }
        public string LoanNumber { get; set; }
        public float AccountBalance { get; set; }
        public float ProcessingFee { get; set; }
        public float CancellationFee { get; set; }
        public float Refund { get; set; }
        public float Penalty { get; set; }
        public float IntrestRate { get; set; }
        public DateTime LastPaymentDate { get; set; }
        public DateTime LastCalculationDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
}