﻿using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace SEnPA
{
    public partial class Utilities
    {
        public static int daysToExpiryAllowRenew = 90;

        public static int FilterBatch()
        {
            return 100;
        }

        public static long SaveRegistrationRequest(RegistrationRequest registration)
        {
            return registration.Save();
        }             

        //get registrations list
        public static List<RegistrationRequest> GetRegistrationRequests(string filterText)
        {
            List<RegistrationRequest> response = new List<RegistrationRequest>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " Id,ReferenceNumber,BusinessRegistrationNumber,BusinessName,NIN,FirstNames,LastName,Citizenship,Status from RegistrationRequest where NIN  like '%" + filterText + "%' or ReferenceNumber like '%" + filterText + "%' or FirstNames like '%" + filterText + "' or LastName like '%" + filterText + "%' order by Created Desc");
            while (reader.Reader.Read())
            {
                RegistrationRequest reg = new RegistrationRequest();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.ReferenceNumber = (reader.Reader["ReferenceNumber"].ToString());
                reg.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                reg.BusinessName = (reader.Reader["BusinessName"].ToString());
                reg.NIN = (reader.Reader["NIN"].ToString());
                reg.FirstNames = (reader.Reader["FirstNames"].ToString());
                reg.LastName = (reader.Reader["LastName"].ToString());
                reg.Citizenship = (reader.Reader["Citizenship"].ToString());
                reg.Status = (reader.Reader["Status"].ToString());

                response.Add(reg);
            }
            reader.Close();

            return response;

        }

        public static RegistrationRequest GetRegistrationRequest(long Id)
        {
            RegistrationRequest registration = new RegistrationRequest(Id);
            return registration;
        }

        private static string GenerateRegistrationNumber(string refNo)
        {
            return refNo;
        }

        private static string GenerateReferenceNumber()
        {
            return DateTime.Now.ToString("yyMMddHHmmss");
        }

        public static long RegisterBusiness(long registrationRequestId)
        {
            RegistrationRequest registration = new RegistrationRequest(registrationRequestId);
            BusinessRegistration busRegistration = new BusinessRegistration();
            busRegistration.Id = 0;
            busRegistration.RegistrationNumber = GenerateRegistrationNumber(registration.ReferenceNumber);
            busRegistration.BusinessRegistrationNumber = registration.BusinessRegistrationNumber;
            busRegistration.BusinessName = registration.BusinessName;
            busRegistration.FK_BusinessTypeId = registration.FK_BusinessTypeId;
            busRegistration.FK_BusinessRegistrationTypeId = registration.FK_BusinessRegistrationTypeId;
            busRegistration.FK_BusinessIslandLocationId = registration.FK_BusinessIslandLocationId;
            busRegistration.FK_BusinessIslandDistrictId = registration.FK_BusinessIslandDistrictId;
            busRegistration.NIN = registration.NIN;
            busRegistration.FirstNames = registration.FirstNames;
            busRegistration.LastName = registration.LastName;
            busRegistration.Salutation = registration.Salutation;
            busRegistration.Citizenship = registration.Citizenship;
            busRegistration.Gender = registration.Gender;
            busRegistration.DOB = registration.DOB;
            busRegistration.FK_ResidenceIslandLocationId = registration.FK_ResidenceIslandLocationId;
            busRegistration.FK_ResidenceDistrictLocationId = registration.FK_ResidenceDistrictLocationId;
            busRegistration.Mobile = registration.Mobile;
            busRegistration.HomeTelephone = registration.HomeTelephone;
            busRegistration.WorkTelephone = registration.WorkTelephone;
            busRegistration.Email = registration.Email;
            busRegistration.FK_EducationLevelId = registration.FK_EducationLevelId;
            busRegistration.TermsAndConditionsAccepted = registration.TermsAndConditionsAccepted;
            busRegistration.Status = registration.Status;
            busRegistration.StatusReason = registration.StatusReason;
            busRegistration.CertificateIssueDate = DateTime.Now;
            busRegistration.CertificateNumber = "";
            busRegistration.FK_RegistrationRequestId = registration.Id;
            busRegistration.Created = registration.Created;
            busRegistration.CreatedBy = registration.CreatedBy;
            busRegistration.LastModified = registration.LastModified;
            busRegistration.LastModifiedBy = registration.LastModifiedBy;
            long x = busRegistration.Save();
            //initialize certificate
            if(x>0)
            {
                CottageCertificate cert = new CottageCertificate();
                cert.InitializeCertificate(registration.Id);
            }
            return x;
        }

        public static long SaveBusinessRegistration(BusinessRegistration registration)
        {
            return registration.Save();
        }

        //get business list
        public static List<BusinessRegistration> GetBusinessRegistrations(string filterText)
        {
            List<BusinessRegistration> response = new List<BusinessRegistration>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select  top " + FilterBatch() + " Id,RegistrationNumber,BusinessRegistrationNumber,BusinessName,NIN,FirstNames,LastName,Citizenship,Status,CertificateNumber,FK_RegistrationRequestId from BusinessRegistration where CertificateNumber like '%" + filterText + "%' or RegistrationNumber like '%" + filterText + "%' or FirstNames like '%" + filterText + "' or LastName like '%" + filterText + "%' or NIN like '%" + filterText + "%' order by Created desc");
            while (reader.Reader.Read())
            {
                BusinessRegistration reg = new BusinessRegistration();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.RegistrationNumber = (reader.Reader["RegistrationNumber"].ToString());
                reg.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                reg.BusinessName = (reader.Reader["BusinessName"].ToString());
                reg.NIN = (reader.Reader["NIN"].ToString());
                reg.FirstNames = (reader.Reader["FirstNames"].ToString());
                reg.LastName = (reader.Reader["LastName"].ToString());
                reg.Citizenship = (reader.Reader["Citizenship"].ToString());
                reg.Status = (reader.Reader["Status"].ToString());
                reg.CertificateNumber = (reader.Reader["CertificateNumber"].ToString());
                reg.FK_RegistrationRequestId = long.Parse(reader.Reader["FK_RegistrationRequestId"].ToString());
                response.Add(reg);
            }
            reader.Close();

            return response;

        }

        public static BusinessRegistration GetBusinessRegistration(long Id, bool regNo)
        {
            BusinessRegistration registration = new BusinessRegistration(Id,regNo);
            return registration;
        }

        public static long SaveRenewalRequest(RenewalRequest registration)
        {
            return registration.Save();
        }

        //get renewal registrations list
        public static List<RenewalRequest> GetRenewalRequests(string filterText)
        {
            List<RenewalRequest> response = new List<RenewalRequest>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " Id,ReferenceNumber,FK_BusinessRegistrationId,Status from RenewalRequest where ReferenceNumber like '%" + filterText + "%' or BusinessDescription like '%" + filterText + "' or RawMaterials like '%" + filterText + "%' order by Created desc");
            while (reader.Reader.Read())
            {
                RenewalRequest reg = new RenewalRequest();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.ReferenceNumber = (reader.Reader["ReferenceNumber"].ToString());
                reg.FK_BusinessRegistrationId = long.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                reg.Status = (reader.Reader["Status"].ToString());

                response.Add(reg);
            }
            reader.Close();

            return response;

        }

        public static RenewalRequest GetRenewalRequest(long Id)
        {
            RenewalRequest registration = new RenewalRequest(Id);
            return registration;
        }

        public static long GetCurrentRenewalID(long Id)
        {

            long x = int.Parse(Utilities.ExecuteScalar("select count(Id) from RenewalRequest where FK_BusinessRegistrationId=" + Id +" and Status<>'Complete'"));
            if(x>0)
            {
                 x = int.Parse(Utilities.ExecuteScalar("select Id from RenewalRequest where FK_BusinessRegistrationId=" + Id + " and Status<>'Complete'"));
                
            }
            else
            {
                //create one
                RenewalRequest request = new RenewalRequest();
                request.Id = 0;
                request.BusinessAdvantages = "";
                request.BusinessDescription = "";
                request.BusinessDisadvantages = "";
                request.CertificateRenewalDate = DateTime.Now;
                request.DocumentType = "renewal";
                request.Equipment = "";
                request.FK_BusinessDevelopmentOfficerId = 0;
                request.FK_BusinessRegistrationId = Id;
                request.GoalsAndObjectives = "";
                request.Funding = "";
                request.MarketingPlan = "";
                request.OperationsForecast = "";
                request.RawMaterials = "";
                request.ReferenceNumber = GenerateReferenceNumber();
                request.RequireWorkFlow = true;
                request.SalesTarget = "";
                request.Status = "";
                request.StatusReason = "";
                request.SubmissionType = "O";
                request.WorkFlowId = 2;
                request.WorkFlowStatus = "";
                request.WorkingPremises = "";
                x = request.Save();
            }

            return x;
        }

        public static bool SendDocument(string docType, long docWorkFlowId,long workFlowStageId, bool email, bool sms)
        {
            string response = "";
            //break if not email or sms is required
            if (!email && !sms)
                return true;
            long inv = 0;
            switch (docType)
            {
                case "registrationSubmit":
                    long id = long.Parse(Utilities.ExecuteScalar("select FK_DocumentId from DocumentWorkflow where Id=" + docWorkFlowId));
                    RegistrationRequest reg = new RegistrationRequest(id);
                    response = GenerateDocument(docType, reg, email, sms);
                    break;
                case "invoice":
                    //get invoice id
                     inv = long.Parse(Utilities.ExecuteScalar("select Id from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Invoice invoice = new Invoice(inv);
                    response = GenerateDocument(docType, invoice, email, sms);
                    break;
                case "ackPayment":
                    //get invoice id
                    long invId = long.Parse(Utilities.ExecuteScalar("select Id from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Invoice invoicePaid = new Invoice(invId);
                    response = GenerateDocument(docType, invoicePaid, email, sms);
                    break;
                case "receipt":
                    long recId = long.Parse(Utilities.ExecuteScalar("select ReceiptNumber from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Receipt receipt = new Receipt(recId);                   
                    response = GenerateDocument(docType, receipt, email, sms);
                    break;
                case "receiptRegistration":
                    long recIdReg = long.Parse(Utilities.ExecuteScalar("select ReceiptNumber from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Receipt receiptReg = new Receipt(recIdReg);                   
                    response = GenerateDocument(docType, receiptReg, email, sms);
                    break;
                case "receiptRenewal":
                    long recIdRen = long.Parse(Utilities.ExecuteScalar("select ReceiptNumber from Invoice where FK_DocumentWorkFlowId=" + docWorkFlowId + " and FK_WorkFlowStageId=" + workFlowStageId));
                    Receipt receiptRen = new Receipt(recIdRen);
                    response = GenerateDocument(docType, receiptRen, email, sms);
                    break;
                default:
                    break;
            }
            //just continue
            return true;
        }

        public static bool SendDocument(string docType, long Id, bool email, bool sms)
        {
            string response = "";
            //break if not email or sms is required
            if (!email && !sms)
                return true;

            switch (docType)
            {               
                case "training":
                    TrainingRegistration training = new TrainingRegistration(Id);
                    response = GenerateDocument(docType, training, email, sms);
                    break;
                case "sitevisit":
                    SiteVisit site = new SiteVisit(Id);
                    response = GenerateDocument(docType, site, site.Email, site.SMS);
                    break;
                default:
                    break;
            }
            //just continue
            return true;
        }

        public static bool SendDocument(string docType, long Id)
        {
            string response = "";
            AutoDocumentsDesign desg = new AutoDocumentsDesign(docType);
            bool sms = desg.SMS, email = desg.Email;
            //break if not email or sms is required
            if (!email && !sms)
                return true;

            switch (docType)
            {
                case "certificateIssued":
                    CottageCertificate cert = new CottageCertificate(Id);
                    response = GenerateDocument(docType, cert, email, sms);
                    break;
                case "certificateRenewed":
                    CottageCertificate certRenewed = new CottageCertificate(Id);
                    response = GenerateDocument(docType, certRenewed, email, sms);
                    break;
                default:
                    break;
            }
            //just continue
            return true;
        }

        public static string GenerateDocument(string docType, Object data, bool email = false, bool sms = false)
        {
            string response = "", responseSMS = "", emailSubject = "";
            string mobileNumber = "", emailAddress = "";
            AutoDocumentsDesign desg = new AutoDocumentsDesign(docType);
            response = desg.DocumentDesign;
            responseSMS = desg.DocumentDesignSMS;
            emailSubject = desg.EmailSubject;
            try
            {
                if (docType == "registrationSubmit")
                {
                    #region registration
                    RegistrationRequest registration = data as RegistrationRequest;
                    response = response.Replace("<registration>", registration.ReferenceNumber);
                    response = response.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    response = response.Replace("<nin>", registration.NIN);
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", registration.ReferenceNumber);
                    responseSMS = responseSMS.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    responseSMS = responseSMS.Replace("<nin>", registration.NIN);
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", registration.ReferenceNumber);
                    emailSubject = emailSubject.Replace("<name>", registration.FirstNames + " " + registration.LastName);
                    emailSubject = emailSubject.Replace("<nin>", registration.NIN);

                    mobileNumber = registration.Mobile;
                    emailAddress = registration.Email;
                    #endregion
                }
                else if (docType == "ackPayment")
                {
                    #region ackpay
                    Invoice invoice = data as Invoice;
                    response = response.Replace("<receipt>", invoice.ReceiptNumber);
                    response = response.Replace("<reference>", invoice.FK_ReferenceNumber);
                    response = response.Replace("<amount>", invoice.AmountTotal.ToString());
                    if (invoice.DocumentType == "registration")
                    {
                        RegistrationRequest registrationreceipt = new RegistrationRequest(invoice.FK_DocumentId);
                        response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        response = response.Replace("<nin>", registrationreceipt.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", registrationreceipt.DocumentType.ToUpper());

                        responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);

                        emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);

                        mobileNumber = registrationreceipt.Mobile;
                        emailAddress = registrationreceipt.Email;
                    }
                    else if (invoice.DocumentType == "renewal")
                    {
                        RenewalRequest ren = new RenewalRequest(invoice.FK_DocumentId);
                        BusinessRegistration registrationreceipt = new BusinessRegistration(ren.FK_BusinessRegistrationId);
                        response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        response = response.Replace("<nin>", registrationreceipt.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", ren.DocumentType.ToUpper());

                        responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);

                        emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);

                        mobileNumber = registrationreceipt.Mobile;
                        emailAddress = registrationreceipt.Email;
                    }
                    response = response.Replace("<invoice>", invoice.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<subtotal>", invoice.AmountTotal.ToString());
                    response = response.Replace("<total>", invoice.AmountTotal.ToString());
                    response = response.Replace("<paid>", invoice.AmountPaid.ToString());
                    response = response.Replace("<due>", (invoice.AmountTotal - invoice.AmountPaid).ToString());
                    List<InvoiceItem> items = Utilities.GetInvoiceItems(invoice.Id);
                    StringBuilder sb = new StringBuilder();
                    foreach (InvoiceItem item in items)
                    {
                        sb.Append("<table width=\"100%\" style=\"max-width:300px;\" cellspacing=\"0\" cellpadding=\"0\"><tr><td width=\"10%\">" + item.Id + "</td><td>" + item.Description + "</td><td width=\"40%\">" + item.Amount + "</td><tr></table>");
                    }
                    response = response.Replace("<items>", sb.ToString());
                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", invoice.ReceiptNumber);
                    responseSMS = responseSMS.Replace("<reference>", invoice.FK_ReferenceNumber);
                    responseSMS = responseSMS.Replace("<amount>",  invoice.AmountTotal.ToString());
                    
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", invoice.ReceiptNumber);
                    emailSubject = emailSubject.Replace("<reference>", invoice.FK_ReferenceNumber);
                    emailSubject = emailSubject.Replace("<amount>",  invoice.AmountTotal.ToString());
                    
                    #endregion
                }
                else if (docType == "receipt")
                {
                    #region receipt
                    Receipt receipt = data as Receipt;
                    long docId = long.Parse(Utilities.ExecuteScalar("select FK_DocumentId from Invoice where ReceiptNumber='" + receipt.Id.ToString().PadLeft(10, '0') + "'"));
                                      
                    response = response.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<paid>",  receipt.AmountTendered.ToString());
                    response = response.Replace("<amount>",  receipt.Amount.ToString());
                   
                    response = response.Replace("<change>", receipt.Currency + receipt.Change.ToString());
                    ApplicationUsers user = new ApplicationUsers(receipt.ReceiptedBy);
                    response = response.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    response = response.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    Invoice invoice = new Invoice(receipt.FK_InvoiceId);
                    if (invoice.DocumentType == "registration")
                    {
                        RegistrationRequest registrationreceipt = new RegistrationRequest(docId);
                        response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        response = response.Replace("<nin>", registrationreceipt.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", registrationreceipt.DocumentType.ToUpper());

                        responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);

                        emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);

                        mobileNumber = registrationreceipt.Mobile;
                        emailAddress = registrationreceipt.Email;
                    }
                    else if (invoice.DocumentType == "renewal")
                    {
                        RenewalRequest ren = new RenewalRequest(docId);
                        BusinessRegistration registrationreceipt = new BusinessRegistration(ren.FK_BusinessRegistrationId);
                        response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        response = response.Replace("<nin>", registrationreceipt.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", ren.DocumentType.ToUpper());

                        responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);

                        emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);

                        mobileNumber = registrationreceipt.Mobile;
                        emailAddress = registrationreceipt.Email;
                    }
                   
                    response = response.Replace("<invoice>", invoice.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<subtotal>", invoice.AmountTotal.ToString());
                    response = response.Replace("<total>", invoice.AmountTotal.ToString());
                    response = response.Replace("<paid>", invoice.AmountPaid.ToString());
                    response = response.Replace("<due>", (invoice.AmountTotal - invoice.AmountPaid).ToString());
                    List<InvoiceItem> items = Utilities.GetInvoiceItems(invoice.Id);
                    StringBuilder sb = new StringBuilder();
                    foreach (InvoiceItem item in items)
                    {
                        sb.Append("<table width=\"100%\" style=\"max-width:300px;\" cellspacing=\"0\" cellpadding=\"0\"><tr><td width=\"10%\">" + item.Id + "</td><td>" + item.Description + "</td><td width=\"40%\">" + item.Amount + "</td><tr></table>");
                    }
                    response = response.Replace("<items>", sb.ToString());

                    if (receipt.Printed > 0)
                    {
                        response = response.Replace("<copy>", "COPY");
                    }
                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    responseSMS = responseSMS.Replace("<paid>",  receipt.AmountTendered.ToString());
                    responseSMS = responseSMS.Replace("<amount>",  receipt.Amount.ToString());
                    //responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                   // responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);
                    responseSMS = responseSMS.Replace("<change>", receipt.Change.ToString());

                    responseSMS = responseSMS.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    responseSMS = responseSMS.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    emailSubject = emailSubject.Replace("<paid>",  receipt.AmountTendered.ToString());
                    emailSubject = emailSubject.Replace("<amount>", receipt.Amount.ToString());
                  //  emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                  //  emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);
                    emailSubject = emailSubject.Replace("<change>",  receipt.Change.ToString());

                    emailSubject = emailSubject.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    emailSubject = emailSubject.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }

                  //  mobileNumber = registrationreceipt.Mobile;
                   // emailAddress = registrationreceipt.Email;
                    #endregion
                }
                else if (docType == "receiptRenewal")
                {
                    #region receipt Renewal
                    Receipt receipt = data as Receipt;
                    long docId = long.Parse(Utilities.ExecuteScalar("select FK_DocumentId from Invoice where ReceiptNumber='" + receipt.Id.ToString().PadLeft(10, '0') + "'"));
                    RenewalRequest renew = new RenewalRequest(docId);
                    BusinessRegistration registrationreceipt = new BusinessRegistration(renew.FK_BusinessRegistrationId,false);
                    //set notification
                    ApplicationUsers userOwner = new ApplicationUsers(renew.FK_BusinessDevelopmentOfficerId);
                    Notifications not = new Notifications(userOwner.Username, "Receipt for "+ renew.ReferenceNumber+" paid for Renewal", "renewal", registrationreceipt.Id);
                    response = response.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    response = response.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    response = response.Replace("<nin>", registrationreceipt.NIN);
                    response = response.Replace("<change>", receipt.Currency + receipt.Change.ToString());
                    ApplicationUsers user = new ApplicationUsers(receipt.ReceiptedBy);
                    response = response.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    response = response.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        response = response.Replace("<copy>", "COPY");
                    }
                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    responseSMS = responseSMS.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    responseSMS = responseSMS.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);
                    responseSMS = responseSMS.Replace("<change>", receipt.Currency + receipt.Change.ToString());

                    responseSMS = responseSMS.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    responseSMS = responseSMS.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    emailSubject = emailSubject.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    emailSubject = emailSubject.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);
                    emailSubject = emailSubject.Replace("<change>", receipt.Currency + receipt.Change.ToString());

                    emailSubject = emailSubject.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    emailSubject = emailSubject.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }

                    mobileNumber = registrationreceipt.Mobile;
                    emailAddress = registrationreceipt.Email;
                    #endregion
                }
                else if (docType == "receiptRegistration")
                {
                    #region receipt Registration
                    Receipt receipt = data as Receipt;
                    long docId = long.Parse(Utilities.ExecuteScalar("select FK_DocumentId from Invoice where ReceiptNumber='" + receipt.Id.ToString().PadLeft(10, '0') + "'"));
                    RegistrationRequest registrationreceipt = new RegistrationRequest(docId);
                    //set notification
                    ApplicationUsers userOwner = new ApplicationUsers(registrationreceipt.FK_BusinessDevelopmentOfficerId);
                    Notifications not = new Notifications(userOwner.Username, "Receipt for " + registrationreceipt.ReferenceNumber + " paid for Registration", "registration", registrationreceipt.Id);
                    response = response.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    response = response.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    response = response.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    response = response.Replace("<nin>", registrationreceipt.NIN);
                    response = response.Replace("<change>", receipt.Currency + receipt.Change.ToString());
                    ApplicationUsers user = new ApplicationUsers(receipt.ReceiptedBy);
                    response = response.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    response = response.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        response = response.Replace("<copy>", "COPY");
                    }
                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    responseSMS = responseSMS.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    responseSMS = responseSMS.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);
                    responseSMS = responseSMS.Replace("<change>", receipt.Currency + receipt.Change.ToString());

                    responseSMS = responseSMS.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    responseSMS = responseSMS.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", receipt.Id.ToString().PadLeft(10, '0'));
                    emailSubject = emailSubject.Replace("<paid>", receipt.CurrencyTendered + receipt.AmountTendered.ToString());
                    emailSubject = emailSubject.Replace("<amount>", receipt.Currency + receipt.Amount.ToString());
                    emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                    emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);
                    emailSubject = emailSubject.Replace("<change>", receipt.Currency + receipt.Change.ToString());

                    emailSubject = emailSubject.Replace("<cashier>", user.FirstName + " " + user.Surname);
                    emailSubject = emailSubject.Replace("<date>", receipt.Receipted.ToString("yyyy-MM-dd HH:mm"));
                    if (receipt.Printed > 0)
                    {
                        responseSMS = responseSMS.Replace("<copy>", "COPY");
                    }

                    mobileNumber = registrationreceipt.Mobile;
                    emailAddress = registrationreceipt.Email;
                    #endregion
                }
                else if (docType == "invoice")
                {
                    #region invoice
                    Invoice invoice = data as Invoice;
                    //set notification
                    Notifications not = new Notifications("", "Invoice : " + invoice.FK_ReferenceNumber, "invoice", invoice.Id);
                    if (invoice.DocumentType == "registration")
                    {
                        RegistrationRequest registrationreceipt = new RegistrationRequest(invoice.FK_DocumentId);
                        response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        response = response.Replace("<nin>", registrationreceipt.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", registrationreceipt.DocumentType.ToUpper());

                        responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);

                        emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);

                        mobileNumber = registrationreceipt.Mobile;
                        emailAddress = registrationreceipt.Email;
                    }
                    else if (invoice.DocumentType == "renewal")
                    {
                        RenewalRequest ren = new RenewalRequest(invoice.FK_DocumentId);
                        BusinessRegistration registrationreceipt = new BusinessRegistration(ren.FK_BusinessRegistrationId);
                        response = response.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        response = response.Replace("<nin>", registrationreceipt.NIN);
                        response = response.Replace("<location>", Utilities.GetEntityName(registrationreceipt.FK_BusinessIslandLocationId, "isl"));
                        response = response.Replace("<payment>", ren.DocumentType.ToUpper());

                        responseSMS = responseSMS.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        responseSMS = responseSMS.Replace("<nin>", registrationreceipt.NIN);

                        emailSubject = emailSubject.Replace("<name>", registrationreceipt.FirstNames + " " + registrationreceipt.LastName);
                        emailSubject = emailSubject.Replace("<nin>", registrationreceipt.NIN);

                        mobileNumber = registrationreceipt.Mobile;
                        emailAddress = registrationreceipt.Email;
                    }

                    response = response.Replace("<receipt>", invoice.ReceiptNumber);
                    response = response.Replace("<reference>", invoice.FK_ReferenceNumber);
                    response = response.Replace("<amount>", invoice.Currency + invoice.AmountTotal.ToString());
                    
                    response = response.Replace("<invoice>", invoice.Id.ToString().PadLeft(10,'0'));
                    response = response.Replace("<subtotal>", invoice.AmountTotal.ToString());
                    response = response.Replace("<total>", invoice.AmountTotal.ToString());
                    response = response.Replace("<paid>", invoice.AmountPaid.ToString());
                    response = response.Replace("<due>", (invoice.AmountTotal-invoice.AmountPaid).ToString());
                    List<InvoiceItem> items = Utilities.GetInvoiceItems(invoice.Id);
                    StringBuilder sb = new StringBuilder();
                    foreach(InvoiceItem item in items)
                    {
                        sb.Append("<table width=\"100%\" style=\"max-width:300px;\" cellspacing=\"0\" cellpadding=\"0\"><tr><td width=\"10%\">" + item.Id + "</td><td>" + item.Description + "</td><td width=\"40%\">" + item.Amount + "</td><tr></table>");
                    }
                    response = response.Replace("<items>", sb.ToString());

                    //sms version
                    responseSMS = responseSMS.Replace("<receipt>", invoice.ReceiptNumber);
                    responseSMS = responseSMS.Replace("<reference>", invoice.FK_ReferenceNumber);
                    responseSMS = responseSMS.Replace("<amount>", invoice.Currency + invoice.AmountTotal.ToString());
                    //subject email version
                    emailSubject = emailSubject.Replace("<receipt>", invoice.ReceiptNumber);
                    emailSubject = emailSubject.Replace("<reference>", invoice.FK_ReferenceNumber);
                    emailSubject = emailSubject.Replace("<amount>", invoice.Currency + invoice.AmountTotal.ToString());
                    
                    #endregion
                }
                else if (docType == "certificate" || docType == "certificateR")
                {
                    #region certificate
                    CottageCertificate cert = data as CottageCertificate;
                    long Id = long.Parse(Utilities.ExecuteScalar("select Id from BusinessRegistration where FK_RegistrationRequestId=" + cert.FK_BusinessRegistrationId));
                    BusinessRegistration certReg = new BusinessRegistration(Id, false);
                    response = response.Replace("<registration>", certReg.RegistrationNumber);
                    response = response.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    response = response.Replace("<nin>", certReg.NIN);
                    response = response.Replace("<business>", certReg.BusinessName);
                    response = response.Replace("<category>", Utilities.GetEntityName(certReg.FK_BusinessTypeId, "bustyp"));
                    response = response.Replace("<resdistrict>", Utilities.GetEntityName(certReg.FK_ResidenceDistrictLocationId, "dis"));
                    response = response.Replace("<busdistrict>", Utilities.GetEntityName(certReg.FK_BusinessIslandDistrictId, "dis"));

                    response = response.Replace("<issuedate>", cert.CertificateIssueDate.ToShortDateString());
                    response = response.Replace("<validfrom>", cert.LastRenewalDate.ToShortDateString());
                    response = response.Replace("<validto>", cert.NextRenewalDate.ToShortDateString());

                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", certReg.RegistrationNumber);
                    responseSMS = responseSMS.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    responseSMS = responseSMS.Replace("<nin>", certReg.NIN);
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", certReg.RegistrationNumber);
                    emailSubject = emailSubject.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    emailSubject = emailSubject.Replace("<nin>", certReg.NIN);

                    mobileNumber = certReg.Mobile;
                    emailAddress = certReg.Email;
                    #endregion
                }
                else if (docType == "training")
                {
                    #region training
                    TrainingRegistration training = data as TrainingRegistration;
                    long Id = long.Parse(Utilities.ExecuteScalar("select Id from BusinessRegistration where FK_RegistrationRequestId=" + training.FK_BusinessRegistrationId));
                    BusinessRegistration certReg = new BusinessRegistration(Id, false);
                    response = response.Replace("<registration>", certReg.RegistrationNumber);
                    response = response.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    response = response.Replace("<nin>", certReg.NIN);
                    TrainingSession sess = new TrainingSession(training.FK_TrainingSessionId);
                    response = response.Replace("<category>", GetEntityName(sess.FK_TrainingCategoryId, "tracat"));
                    response = response.Replace("<course>", GetEntityName(sess.FK_TrainingCourseId, "tracou"));
                    response = response.Replace("<type>", GetEntityName(sess.FK_TrainingTypeId, "tratyp"));
                    response = response.Replace("<date>", sess.EndDate.ToShortDateString());
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", certReg.RegistrationNumber);
                    responseSMS = responseSMS.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    responseSMS = responseSMS.Replace("<nin>", certReg.NIN);
                    responseSMS = responseSMS.Replace("<category>", GetEntityName(sess.FK_TrainingCategoryId, "tracat"));
                    responseSMS = responseSMS.Replace("<course>", GetEntityName(sess.FK_TrainingCourseId, "tracou"));
                    responseSMS = responseSMS.Replace("<type>", GetEntityName(sess.FK_TrainingTypeId, "tratyp"));
                    responseSMS = responseSMS.Replace("<date>", sess.EndDate.ToShortDateString());
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", certReg.RegistrationNumber);
                    emailSubject = emailSubject.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    emailSubject = emailSubject.Replace("<nin>", certReg.NIN);
                    emailSubject = emailSubject.Replace("<category>", GetEntityName(sess.FK_TrainingCategoryId, "tracat"));
                    emailSubject = emailSubject.Replace("<course>", GetEntityName(sess.FK_TrainingCourseId, "tracou"));
                    emailSubject = emailSubject.Replace("<type>", GetEntityName(sess.FK_TrainingTypeId, "tratyp"));
                    emailSubject = emailSubject.Replace("<date>", sess.EndDate.ToShortDateString());

                    mobileNumber = certReg.Mobile;
                    emailAddress = certReg.Email;
                    #endregion
                }               
                else if (docType == "certificateIssued")
                {
                    #region certificateIssued
                    CottageCertificate certIssued = data as CottageCertificate;
                    long Id = long.Parse(Utilities.ExecuteScalar("select Id from BusinessRegistration where FK_RegistrationRequestId=" + certIssued.FK_BusinessRegistrationId));
                    BusinessRegistration certReg = new BusinessRegistration(Id, false);
                    response = response.Replace("<registration>", certReg.RegistrationNumber);
                    response = response.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    response = response.Replace("<nin>", certReg.NIN);
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", certReg.RegistrationNumber);
                    responseSMS = responseSMS.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    responseSMS = responseSMS.Replace("<nin>", certReg.NIN);
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", certReg.RegistrationNumber);
                    emailSubject = emailSubject.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    emailSubject = emailSubject.Replace("<nin>", certReg.NIN);

                    mobileNumber = certReg.Mobile;
                    emailAddress = certReg.Email;
                    #endregion
                }
                else if (docType == "certificateRenewed")
                {
                    #region certificateIssued
                    CottageCertificate certIssued = data as CottageCertificate;
                    long Id = long.Parse(Utilities.ExecuteScalar("select Id from BusinessRegistration where FK_RegistrationRequestId=" + certIssued.FK_BusinessRegistrationId));
                    BusinessRegistration certReg = new BusinessRegistration(Id, false);
                    response = response.Replace("<registration>", certReg.RegistrationNumber);
                    response = response.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    response = response.Replace("<nin>", certReg.NIN);
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", certReg.RegistrationNumber);
                    responseSMS = responseSMS.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    responseSMS = responseSMS.Replace("<nin>", certReg.NIN);
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", certReg.RegistrationNumber);
                    emailSubject = emailSubject.Replace("<name>", certReg.FirstNames + " " + certReg.LastName);
                    emailSubject = emailSubject.Replace("<nin>", certReg.NIN);

                    mobileNumber = certReg.Mobile;
                    emailAddress = certReg.Email;
                    #endregion
                }
            }catch(Exception ex)
            {
               //error log
            }

            if (docType == "sitevisit")
            {
                desg = new AutoDocumentsDesign("sitevisitClient");
                response = desg.DocumentDesign;
                responseSMS = desg.DocumentDesignSMS;
                emailSubject = desg.EmailSubject;
                SiteVisit site = data as SiteVisit;
                DocumentWorkflow doc = new DocumentWorkflow(site.FK_DocumentWorkFlowId);
                RegistrationRequest reg = new RegistrationRequest();
                BusinessRegistration regBus = new BusinessRegistration();
                #region sitevisit client notification

                long Id = 0;
                //check if registered first                    
                if (doc.DocumentType == "registration")
                {
                    reg = new RegistrationRequest(long.Parse(doc.FK_DocumentId));

                    //set notification
                    Notifications not = new Notifications("", "Site Visit scheduled for " + site.VisitDate.ToLongDateString(), "registrationSite", site.FK_DocumentId);

                    response = response.Replace("<registration>", reg.ReferenceNumber);
                    response = response.Replace("<name>", reg.FirstNames + " " + reg.LastName);
                    response = response.Replace("<nin>", reg.NIN);

                    response = response.Replace("<date>", site.VisitDate.ToLongTimeString());
                    response = response.Replace("<address>", site.VisitAddress);
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", reg.ReferenceNumber);
                    responseSMS = responseSMS.Replace("<name>", reg.FirstNames + " " + reg.LastName);
                    responseSMS = responseSMS.Replace("<nin>", reg.NIN);

                    responseSMS = responseSMS.Replace("<date>", site.VisitDate.ToLongTimeString());
                    responseSMS = responseSMS.Replace("<address>", site.VisitAddress);
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", reg.ReferenceNumber);
                    emailSubject = emailSubject.Replace("<name>", reg.FirstNames + " " + reg.LastName);
                    emailSubject = emailSubject.Replace("<nin>", reg.NIN);

                    emailSubject = emailSubject.Replace("<date>", site.VisitDate.ToLongTimeString());
                    emailSubject = emailSubject.Replace("<address>", site.VisitAddress);

                    mobileNumber = reg.Mobile;
                    emailAddress = reg.Email;
                }
                else if (doc.DocumentType == "renewal")
                {
                    Id = long.Parse(Utilities.ExecuteScalar("select FK_BusinessRegistrationId from RenewalRequest where Id=" + doc.FK_DocumentId));
                     regBus = new BusinessRegistration(Id, false);

                    //set notification
                    Notifications not = new Notifications("", "Site Visit scheduled for " + site.VisitDate.ToLongDateString(), "renewalSite", site.FK_DocumentId);

                    response = response.Replace("<registration>", regBus.RegistrationNumber);
                    response = response.Replace("<name>", regBus.FirstNames + " " + regBus.LastName);
                    response = response.Replace("<nin>", regBus.NIN);

                    response = response.Replace("<date>", site.VisitDate.ToLongTimeString());
                    response = response.Replace("<address>", site.VisitAddress);
                    //sms version
                    responseSMS = responseSMS.Replace("<registration>", regBus.RegistrationNumber);
                    responseSMS = responseSMS.Replace("<name>", regBus.FirstNames + " " + regBus.LastName);
                    responseSMS = responseSMS.Replace("<nin>", regBus.NIN);

                    responseSMS = responseSMS.Replace("<date>", site.VisitDate.ToLongTimeString());
                    responseSMS = responseSMS.Replace("<address>", site.VisitAddress);
                    //subject email version
                    emailSubject = emailSubject.Replace("<registration>", regBus.RegistrationNumber);
                    emailSubject = emailSubject.Replace("<name>", regBus.FirstNames + " " + regBus.LastName);
                    emailSubject = emailSubject.Replace("<nin>", regBus.NIN);

                    emailSubject = emailSubject.Replace("<date>", site.VisitDate.ToLongTimeString());
                    emailSubject = emailSubject.Replace("<address>", site.VisitAddress);

                    mobileNumber = reg.Mobile;
                    emailAddress = reg.Email;
                }

                #endregion

                if (email && emailAddress != "")
                {
                    Utilities.SendEmail(emailAddress, emailSubject, response, "blank");
                }

                if (sms && mobileNumber != "")
                {
                    Utilities.SendSMS(mobileNumber, responseSMS);
                }

                desg = new AutoDocumentsDesign("sitevisitStakeholder");
                response = desg.DocumentDesign;
                responseSMS = desg.DocumentDesignSMS;
                emailSubject = desg.EmailSubject;

                //get list of stakeholders
                List<SiteVisitReport> stakeReports = GetSiteVisitReports(site.Id);
                foreach (SiteVisitReport rep in stakeReports)
                {
                    Stakeholder stake = new Stakeholder(rep.FK_StakeholderId);
                    #region sitevisit client notification
                    
                    //check if registered first                    
                    if (doc.DocumentType == "registration")
                    {
                        response = response.Replace("<registration>", reg.ReferenceNumber);
                        response = response.Replace("<client>", reg.FirstNames + " " + reg.LastName);
                        response = response.Replace("<nin>", reg.NIN);
                        response = response.Replace("<name>", stake.Name);

                        response = response.Replace("<date>", site.VisitDate.ToLongTimeString());
                        response = response.Replace("<address>", site.VisitAddress);
                        //sms version
                        responseSMS = responseSMS.Replace("<registration>", reg.ReferenceNumber);
                        responseSMS = responseSMS.Replace("<name>", stake.Name);
                        responseSMS = responseSMS.Replace("<nin>", reg.NIN);
                        responseSMS = responseSMS.Replace("<client>", reg.FirstNames + " " + reg.LastName);

                        responseSMS = responseSMS.Replace("<date>", site.VisitDate.ToLongTimeString());
                        responseSMS = responseSMS.Replace("<address>", site.VisitAddress);
                        //subject email version
                        emailSubject = emailSubject.Replace("<registration>", reg.ReferenceNumber);
                        emailSubject = emailSubject.Replace("<name>", stake.Name);
                        emailSubject = emailSubject.Replace("<nin>", reg.NIN);
                        emailSubject = emailSubject.Replace("<client>", reg.FirstNames + " " + reg.LastName);

                        emailSubject = emailSubject.Replace("<date>", site.VisitDate.ToLongTimeString());
                        emailSubject = emailSubject.Replace("<address>", site.VisitAddress);                        
                    }
                    else if (doc.DocumentType == "renewal")
                    {
                        Id = long.Parse(Utilities.ExecuteScalar("select FK_BusinessRegistrationId from RenewalRequest where Id=" + doc.FK_DocumentId));                      
                        response = response.Replace("<registration>", regBus.RegistrationNumber);
                        response = response.Replace("<name>", stake.Name);
                        response = response.Replace("<nin>", regBus.NIN);
                        response = response.Replace("<client>", regBus.FirstNames + " " + regBus.LastName);

                        response = response.Replace("<date>", site.VisitDate.ToLongTimeString());
                        response = response.Replace("<address>", site.VisitAddress);
                        //sms version
                        responseSMS = responseSMS.Replace("<registration>", regBus.RegistrationNumber);
                        responseSMS = responseSMS.Replace("<name>", stake.Name);
                        responseSMS = responseSMS.Replace("<nin>", regBus.NIN);
                        responseSMS = responseSMS.Replace("<client>", regBus.FirstNames + " " + regBus.LastName);

                        responseSMS = responseSMS.Replace("<date>", site.VisitDate.ToLongTimeString());
                        responseSMS = responseSMS.Replace("<address>", site.VisitAddress);
                        //subject email version
                        emailSubject = emailSubject.Replace("<registration>", regBus.RegistrationNumber);
                        emailSubject = emailSubject.Replace("<name>", stake.Name);
                        emailSubject = emailSubject.Replace("<nin>", regBus.NIN);
                        emailSubject = emailSubject.Replace("<client>", regBus.FirstNames + " " + regBus.LastName);

                        emailSubject = emailSubject.Replace("<date>", site.VisitDate.ToLongTimeString());
                        emailSubject = emailSubject.Replace("<address>", site.VisitAddress);                        
                    }

                    #endregion

                    mobileNumber = stake.Mobile;
                    emailAddress = stake.Email;

                    if (email && emailAddress != "")
                    {
                        Utilities.SendEmail(emailAddress, emailSubject, response, "blank");
                    }

                    if (sms && mobileNumber != "")
                    {
                        Utilities.SendSMS(mobileNumber, responseSMS);
                    }
                }
            }
            else
            {
                if (email && emailAddress != "")
                {
                    Utilities.SendEmail(emailAddress, emailSubject, response, "blank");
                }

                if (sms && mobileNumber != "")
                {
                    Utilities.SendSMS(mobileNumber, responseSMS);
                }
            }

            return response;
        }

        public static List<AutoDocument> CheckAutoDocument(long Id, string entityType)
        {
            List<AutoDocument> response = new List<AutoDocument>();
            //get invoices ack first
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Invoice where DocumentType='" + entityType + "' and FK_DocumentId=" + Id);
            while (reader.Reader.Read())
            {
                AutoDocument reg = new AutoDocument();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.DocumentType = "ackPayment";
                reg.DocumentTypeName = "Payment Acknowledgement";
                response.Add(reg);
            }
            reader.Close();
            //get receipts
            Utilities.DatabaseReader readerReceipt = new Utilities.DatabaseReader("select * from Receipt where FK_InvoiceId in (select Id from Invoice where DocumentType='" + entityType + "' and FK_DocumentId=" + Id + ")");
            while (readerReceipt.Reader.Read())
            {
                AutoDocument reg = new AutoDocument();
                reg.Id = long.Parse(readerReceipt.Reader["Id"].ToString());
                reg.DocumentType = "receipt";
                reg.DocumentTypeName = "Receipt (" + (readerReceipt.Reader["Id"].ToString()).PadLeft(10, '0') + ")";
                response.Add(reg);
            }
            readerReceipt.Close();

            return response;
        }

        public static List<AutoDocument> CheckTrainingAutoDocument(long Id, string entityType)
        {
            List<AutoDocument> response = new List<AutoDocument>();
            //get invoices ack first
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from TrainingRegistration where Attended='True' and FK_BusinessRegistrationId=" + Id);
            while (reader.Reader.Read())
            {
                AutoDocument reg = new AutoDocument();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.DocumentType = "training";
                reg.DocumentTypeName = "Cert" + reg.Id.ToString().PadLeft(6,'0');
                response.Add(reg);
            }
            reader.Close();
           
            return response;
        }

        //get auto document
        public static Byte[] GetAutoDocument(string docType, long Id)
        {
            string html = "<html><head><title>Blank</title></head><body>Blank</body></html>";

            switch (docType)
            {
                case "ackPayment":
                    Invoice invoice = new Invoice(Id);
                    html = GenerateDocument(docType, invoice, false, false);
                    break;
                case "receipt":
                    Receipt receipt = new Receipt(Id);
                    html = GenerateDocument(docType, receipt, false, false);
                    break;
                case "invoice":
                    Invoice invoice1 = new Invoice(Id);
                    html = GenerateDocument(docType, invoice1, false, false);
                    break;
                case "certificate":
                    CottageCertificate cert = new CottageCertificate(Id);
                    if (cert.FK_LastRenewedById != 0) docType = "certificateR";
                    html = GenerateDocument(docType, cert, false, false);
                    break;
                case "training":
                    TrainingRegistration training = new TrainingRegistration(Id);
                    html = GenerateDocument(docType, training, false, false);
                    break;
                default:
                    break;
            }

            byte[] data = PdfSharpConvert(html);

            //document.Save(@"F:\papa.pdf");
            string tmp = DateTime.Now.ToString("yyMMddHHmmssfff");
            File.WriteAllBytes(@"C:\docs\" + tmp + ".pdf", data);
            PdfDocument document = PdfSharp.Pdf.IO.PdfReader.Open(@"C:\docs\" + tmp + ".pdf");
            // Get an XGraphics object for drawing
            XGraphics gfx = XGraphics.FromPdfPage(document.Pages[0]);
            DrawImage(gfx, @"C:\docs\senpa\logo.png", 20, 30, 100, 100);

            byte[] pdfData;
            using (var ms = new MemoryStream())
            {
                document.Save(ms);
                pdfData = ms.ToArray();
            }

            try
            {
                File.Delete(@"C:\docs\" + tmp + ".pdf");
            }
            catch { }

            return pdfData;
        }

        static void DrawImage(XGraphics gfx, string jpegSamplePath, int x, int y, int width, int height)
        {
            XImage image = XImage.FromFile(jpegSamplePath);
            gfx.DrawImage(image, x, y, width, height);
        }

        public static int CheckCertificate(long Id)
        {
            CottageCertificate cert = new CottageCertificate(Id);
            if(cert==null)//not registered
            {
                return -2;
            }
            else
            {
                if (cert.CertificateNumber == "")//pending certificate issuing
                {
                    return 0;
                }
                else
                {
                    if (cert.Status.ToLower() == "pending" && cert.CertificateNumber != "")//pending renewal issuing
                    {
                        return 1;
                    }
                    else if (cert.NextRenewalDate < DateTime.Now)//expired
                    {
                        return -1;
                    }
                    else if (cert.NextRenewalDate < DateTime.Now.AddDays(Utilities.daysToExpiryAllowRenew))//expiring in comming period
                    {
                        return 2;
                    }
                    else
                    {
                        return 3;
                    }
                }
            }
        }

        public static CottageCertificate GetCertificateDetails(long Id)
        {
            CottageCertificate cert = new CottageCertificate(Id);
            return cert;
        }

        public static bool IssueCertificate(long Id, long renewalId = 0)
        {
            CottageCertificate cert = new CottageCertificate(Id);
            bool done= cert.Issue(renewalId);
            if(done)
            {
                SendDocument(((renewalId == 0) ? "certificateIssued" : "certificateRenewed"), cert.Id, false, false);               
            }
            return done;
        }

        public static long LastRenewalId(long Id)
        {
            try
            {
                long x = long.Parse(Utilities.ExecuteScalar("select top 1 Id from RenewalRequest where FK_BusinessRegistrationId=" + Id + " order by Created desc"));
                return x;
            }
            catch(Exception ex)
            {
                Utilities.LogError("err", ex);
                return 0;
            }
        }

        public static bool SetRenewal(long Id)
        {
            CottageCertificate cert = new CottageCertificate();
            return cert.InitializeCertificate(Id);
        }

        public static string GenerateCertificateNumber(long Id)
        {
            return Id.ToString().PadLeft(8,'0');
        }

        public static List<CottageCertificate> GetCertificates(string filterText)
        {
            List<CottageCertificate> response = new List<CottageCertificate>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " * from CottageCertificate where CertificateNumber like '%" + filterText + "%' order by Created desc");
            while (reader.Reader.Read())
            {
                CottageCertificate cert = new CottageCertificate();
                cert.Id = long.Parse(reader.Reader["Id"].ToString());
                cert.CertificateIssueDate = DateTime.Parse(reader.Reader["CertificateIssueDate"].ToString());
                cert.LastRenewalDate = DateTime.Parse(reader.Reader["LastRenewalDate"].ToString());
                cert.NextRenewalDate = DateTime.Parse(reader.Reader["NextRenewalDate"].ToString());
                cert.FK_LastRenewedById = long.Parse(reader.Reader["FK_LastRenewedById"].ToString());
                cert.FK_IssuedById = (reader.Reader["FK_IssuedById"].ToString());
                cert.CertificateNumber = (reader.Reader["CertificateNumber"].ToString());
                cert.FK_BusinessRegistrationId = long.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                cert.Status = (reader.Reader["Status"].ToString());

                response.Add(cert);
            }
            reader.Close();

            return response;

        }

        public static bool UpdatePeriod(long id, DateTime lastRenewalDate, DateTime nextRenewalDate)
        {
            return CottageCertificate.UpdatePeriod(id, lastRenewalDate, nextRenewalDate);
        }

        //get business list
        public static List<ActiveRenewalRequest> GetActiveBusinessRenewals(string filterText)
        {
            List<ActiveRenewalRequest> response = new List<ActiveRenewalRequest>();
            //retrieve registrations details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,RegistrationNumber,BusinessName,NIN,FirstNames,LastName,CertificateNumber,Mobile,Email,Status from BusinessRegistration where (CertificateNumber like '%" + filterText + "%' or RegistrationNumber like '%" + filterText + "%' or FirstNames like '%" + filterText + "' or LastName like '%" + filterText + "%') and Id in (select FK_BusinessRegistrationId from RenewalRequest where WorkFlowStatus<>'Complete') order by Created desc");
            while (reader.Reader.Read())
            { 
                ActiveRenewalRequest reg = new ActiveRenewalRequest();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.RegistrationNumber = (reader.Reader["RegistrationNumber"].ToString());
                reg.BusinessName = (reader.Reader["BusinessName"].ToString());
                reg.NIN = (reader.Reader["NIN"].ToString());
                reg.FirstNames = (reader.Reader["FirstNames"].ToString());
                reg.LastName = (reader.Reader["LastName"].ToString());
                reg.Mobile = (reader.Reader["Mobile"].ToString());
                reg.Email = (reader.Reader["Email"].ToString());
                reg.CertificateNumber = (reader.Reader["CertificateNumber"].ToString());
                reg.Status = Utilities.ExecuteScalar("select Status from RenewalRequest where FK_BusinessRegistrationId=" + reg.Id);
                response.Add(reg);
            }
            reader.Close();

            return response;

        }

        public static QuickStats GetQuickStats()
        {
            return new QuickStats();
        }

        public static List<Notifications> CheckNotifications(string filterText,bool pending)
        {
            List<Notifications> response = new List<Notifications>();
            ReferenceTable usrAcc = GetReferenceTableItem("AccountsOfficer", "rolgro");
            ReferenceTable usrHr = GetReferenceTableItem("HumanResources", "rolgro");

            //get invoices ack first
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " * from Notifications where ((FK_Username='" + Security.actingUser + "') or (FK_Username='' and DocumentType='invoice' and ('"+((Security.CheckUserRolegroupAccess(Security.actingUser,usrAcc.Id))?"True":"False")+ "'='True')) or (FK_Username='' and DocumentType='registrationSite' and ('" + ((Security.CheckUserRolegroupAccess(Security.actingUser, usrHr.Id)) ? "True" : "False") + "'='True'))) and Status='" + ((pending) ? "False" : "True") + "' and Title like '%" + filterText+"%' order by Created desc");
            while (reader.Reader.Read())
            {
                Notifications not = new Notifications();
                not.Id = long.Parse(reader.Reader["Id"].ToString());
                not.FK_Username = (reader.Reader["FK_Username"].ToString());
                not.Title = (reader.Reader["Title"].ToString());
                not.DocumentType = (reader.Reader["DocumentType"].ToString());
                not.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                not.Status = bool.Parse(reader.Reader["Status"].ToString());
                not.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                not.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                not.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                not.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                response.Add(not);
            }
            reader.Close();

            return response;
        }

        public static bool UpdateNotifications(long Id,bool status)
        {
            return Notifications.Update(Id, status);
        }
    }
}