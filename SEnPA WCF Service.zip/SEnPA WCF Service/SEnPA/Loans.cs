﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEnPA
{
    public partial class Utilities
    {
    }

    public class Loan
    {
        public Loan() { }


        public long Id { get; set; }
        public string ReceiptNumber { get; set; }
        public bool RegistrationFee { get; set; }
        public long FK_RenewalId { get; set; }
        public int FK_FinanceInstitutionId { get; set; }
        public string Purpose { get; set; }
        public float Amount { get; set; }
        public int Year { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
}