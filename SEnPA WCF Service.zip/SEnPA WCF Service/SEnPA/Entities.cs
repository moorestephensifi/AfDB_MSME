﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SEnPA
{
    public class PickList
    {
        public long Id { get; set; }
        public string Text { get; set; }
    }

    public class RegistrationRequest
    {
        public RegistrationRequest() { }

        public RegistrationRequest(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from RegistrationRequest where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.ReferenceNumber = (reader.Reader["ReferenceNumber"].ToString());
                this.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                this.BusinessName = (reader.Reader["BusinessName"].ToString());
                this.FK_BusinessTypeId = int.Parse(reader.Reader["FK_BusinessTypeId"].ToString());
                this.FK_BusinessRegistrationTypeId = int.Parse(reader.Reader["FK_BusinessRegistrationTypeId"].ToString());
                this.FK_BusinessIslandLocationId = int.Parse(reader.Reader["FK_BusinessIslandLocationId"].ToString());
                this.FK_BusinessIslandDistrictId = int.Parse(reader.Reader["FK_BusinessIslandDistrictId"].ToString());
                this.NIN = (reader.Reader["NIN"].ToString());
                this.FirstNames = (reader.Reader["FirstNames"].ToString());
                this.LastName = (reader.Reader["LastName"].ToString());
                this.Salutation = (reader.Reader["Salutation"].ToString());
                this.Citizenship = (reader.Reader["Citizenship"].ToString());
                this.Gender = (reader.Reader["Gender"].ToString());
                this.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                this.FK_ResidenceIslandLocationId = int.Parse(reader.Reader["FK_ResidenceIslandLocationId"].ToString());
                this.FK_ResidenceDistrictLocationId = int.Parse(reader.Reader["FK_ResidenceDistrictLocationId"].ToString());
                this.Mobile = (reader.Reader["Mobile"].ToString());
                this.HomeTelephone = (reader.Reader["HomeTelephone"].ToString());
                this.WorkTelephone = (reader.Reader["WorkTelephone"].ToString());
                this.Email = (reader.Reader["Email"].ToString());
                this.FK_EducationLevelId = int.Parse(reader.Reader["FK_EducationLevelId"].ToString());
                this.TermsAndConditionsAccepted = bool.Parse(reader.Reader["TermsAndConditionsAccepted"].ToString());
                this.FK_BusinessDevelopmentOfficerId = int.Parse(reader.Reader["FK_BusinessDevelopmentOfficerId"].ToString());
                this.SubmissionType = (reader.Reader["SubmissionType"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.CertificateIssueDate = DateTime.Parse(reader.Reader["CertificateIssueDate"].ToString());
                this.DocumentType = (reader.Reader["DocumentType"].ToString());
                this.RequireWorkFlow = bool.Parse(reader.Reader["RequireWorkFlow"].ToString());
                this.WorkFlowId = long.Parse(reader.Reader["WorkFlowId"].ToString());
                this.WorkFlowStatus = (reader.Reader["WorkFlowStatus"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public long Save()
        {
            this.DocumentType = "registration";
            this.RequireWorkFlow = true;
            this.WorkFlowId = Utilities.GetEntityWorkFlow(this.DocumentType);
            this.WorkFlowStatus = "";

            int c = int.Parse(Utilities.ExecuteScalar("select count(Id) from RegistrationRequest where ReferenceNumber='" + this.ReferenceNumber + "'"));

            SqlCommand command;
            
            if(c<1)
                command= new SqlCommand("insert into RegistrationRequest(ReferenceNumber,BusinessRegistrationNumber,BusinessName,FK_BusinessTypeId,FK_BusinessRegistrationTypeId,FK_BusinessIslandLocationId,FK_BusinessIslandDistrictId,NIN,FirstNames,LastName,Salutation,Citizenship,Gender,DOB,FK_ResidenceIslandLocationId,FK_ResidenceDistrictLocationId,Mobile,HomeTelephone,WorkTelephone,Email,FK_EducationLevelId,TermsAndConditionsAccepted,FK_BusinessDevelopmentOfficerId,SubmissionType,Status,StatusReason,CertificateIssueDate,DocumentType,RequireWorkFlow,WorkFlowId,WorkFlowStatus,Created,CreatedBy,LastModified,LastModifiedBy) values(@ReferenceNumber,@BusinessRegistrationNumber,@BusinessName,@FK_BusinessTypeId,@FK_BusinessRegistrationTypeId,@FK_BusinessIslandLocationId,@FK_BusinessIslandDistrictId,@NIN,@FirstNames,@LastName,@Salutation,@Citizenship,@Gender,@DOB,@FK_ResidenceIslandLocationId,@FK_ResidenceDistrictLocationId,@Mobile,@HomeTelephone,@WorkTelephone,@Email,@FK_EducationLevelId,@TermsAndConditionsAccepted,@FK_BusinessDevelopmentOfficerId,@SubmissionType,@Status,@StatusReason,@CertificateIssueDate,@DocumentType,@RequireWorkFlow,@WorkFlowId,@WorkFlowStatus,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");
            else
                command = new SqlCommand("update RegistrationRequest set BusinessRegistrationNumber=@BusinessRegistrationNumber,BusinessName=@BusinessName,FK_BusinessTypeId=@FK_BusinessTypeId,FK_BusinessRegistrationTypeId=@FK_BusinessRegistrationTypeId,FK_BusinessIslandLocationId=@FK_BusinessIslandLocationId,FK_BusinessIslandDistrictId=@FK_BusinessIslandDistrictId,FirstNames=@FirstNames,LastName=@LastName,Salutation=@Salutation,Citizenship=@Citizenship,Gender=@Gender,DOB=@DOB,FK_ResidenceIslandLocationId=@FK_ResidenceIslandLocationId,FK_ResidenceDistrictLocationId=@FK_ResidenceDistrictLocationId,Mobile=@Mobile,HomeTelephone=@HomeTelephone,WorkTelephone=@WorkTelephone,Email=@Email,FK_EducationLevelId=@FK_EducationLevelId,FK_BusinessDevelopmentOfficerId=@FK_BusinessDevelopmentOfficerId,LastModified=CURRENT_TIMESTAMP,LastModifiedBy=@LastModifiedBy where ReferenceNumber=@ReferenceNumber");

            command.Parameters.Add(new SqlParameter("@ReferenceNumber", this.ReferenceNumber));
            command.Parameters.Add(new SqlParameter("@BusinessRegistrationNumber", this.BusinessRegistrationNumber));
            command.Parameters.Add(new SqlParameter("@BusinessName", this.BusinessName));
            command.Parameters.Add(new SqlParameter("@FK_BusinessTypeId", this.FK_BusinessTypeId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessRegistrationTypeId", this.FK_BusinessRegistrationTypeId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessIslandLocationId", this.FK_BusinessIslandLocationId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessIslandDistrictId", this.FK_BusinessIslandDistrictId));
            command.Parameters.Add(new SqlParameter("@NIN", this.NIN));
            command.Parameters.Add(new SqlParameter("@FirstNames", this.FirstNames));
            command.Parameters.Add(new SqlParameter("@LastName", this.LastName));
            command.Parameters.Add(new SqlParameter("@Salutation", this.Salutation));
            command.Parameters.Add(new SqlParameter("@Citizenship", this.Citizenship));
            command.Parameters.Add(new SqlParameter("@Gender", this.Gender));
            command.Parameters.Add(new SqlParameter("@DOB", this.DOB));
            command.Parameters.Add(new SqlParameter("@FK_ResidenceIslandLocationId", this.FK_ResidenceIslandLocationId));
            command.Parameters.Add(new SqlParameter("@FK_ResidenceDistrictLocationId", this.FK_ResidenceDistrictLocationId));
            command.Parameters.Add(new SqlParameter("@Mobile", this.Mobile));
            command.Parameters.Add(new SqlParameter("@HomeTelephone", this.HomeTelephone));
            command.Parameters.Add(new SqlParameter("@WorkTelephone", this.WorkTelephone));
            command.Parameters.Add(new SqlParameter("@Email", this.Email));
            command.Parameters.Add(new SqlParameter("@FK_EducationLevelId", this.FK_EducationLevelId));
            command.Parameters.Add(new SqlParameter("@TermsAndConditionsAccepted", this.TermsAndConditionsAccepted));
            command.Parameters.Add(new SqlParameter("@FK_BusinessDevelopmentOfficerId", this.FK_BusinessDevelopmentOfficerId));
            command.Parameters.Add(new SqlParameter("@SubmissionType", this.SubmissionType));
            command.Parameters.Add(new SqlParameter("@Status", this.Status));
            command.Parameters.Add(new SqlParameter("@StatusReason", this.StatusReason));
            command.Parameters.Add(new SqlParameter("@CertificateIssueDate", this.CertificateIssueDate));
            command.Parameters.Add(new SqlParameter("@DocumentType", this.DocumentType));
            command.Parameters.Add(new SqlParameter("@RequireWorkFlow", this.RequireWorkFlow));
            command.Parameters.Add(new SqlParameter("@WorkFlowId", this.WorkFlowId));
            command.Parameters.Add(new SqlParameter("@WorkFlowStatus", this.WorkFlowStatus));
            command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));

            if (c < 1)
            {
                this.Id = Utilities.ExecuteNewRecord(command);
                if (this.Id > 0)
                {
                    if (this.RequireWorkFlow)
                    {
                        //submit to workflow
                        DocumentWorkflow wrkDoc = Utilities.SubmitWorkFlowDocument(this.WorkFlowId, this.Id.ToString(), this.DocumentType);
                        this.WorkFlowStatus = wrkDoc.WorkFlowStatus;
                        UpdateWorkFlowStatus();

                    }
                }
                else
                {

                   
                }
            }
            else
            {
                int x = Utilities.ExecuteNonQuery(command);
                if (x > 0)
                    this.Id = long.Parse(Utilities.ExecuteScalar("select Id from RegistrationRequest where ReferenceNumber='" + this.ReferenceNumber + "'"));
                else
                    this.Id = x;
            }
           
            return this.Id;
        }

        public bool UpdateWorkFlowStatus()
        {
            int x = Utilities.ExecuteNonQuery("update RegistrationRequest set WorkFlowStatus='" + this.WorkFlowStatus + "',Status='" + this.WorkFlowStatus + "' where Id=" + this.Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public string ReferenceNumber { get; set; }
        public string BusinessRegistrationNumber { get; set; }
        public string BusinessName { get; set; }
        public int FK_BusinessTypeId { get; set; }
        public int FK_BusinessRegistrationTypeId { get; set; }
        public int FK_BusinessIslandLocationId { get; set; }
        public int FK_BusinessIslandDistrictId { get; set; }
        public string NIN { get; set; }
        public string FirstNames { get; set; }
        public string LastName { get; set; }
        public string Salutation { get; set; }
        public string Citizenship { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public int FK_ResidenceIslandLocationId { get; set; }
        public int FK_ResidenceDistrictLocationId { get; set; }
        public string Mobile { get; set; }
        public string HomeTelephone { get; set; }
        public string WorkTelephone { get; set; }
        public string Email { get; set; }
        public int FK_EducationLevelId { get; set; }
        public bool TermsAndConditionsAccepted { get; set; }
        public int FK_BusinessDevelopmentOfficerId { get; set; }
        public string SubmissionType { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public DateTime CertificateIssueDate { get; set; }
        public string DocumentType { get; set; }
        public bool RequireWorkFlow { get; set; }
        public long WorkFlowId { get; set; }
        public string WorkFlowStatus { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class BusinessRegistration
    {
        public BusinessRegistration() { }

        public BusinessRegistration(long Id, bool regNo=true)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from BusinessRegistration where " + ((regNo) ? "RegistrationNumber='" + Id + "'" : "Id=" + Id));
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.RegistrationNumber = (reader.Reader["RegistrationNumber"].ToString());
                this.BusinessRegistrationNumber = (reader.Reader["BusinessRegistrationNumber"].ToString());
                this.BusinessName = (reader.Reader["BusinessName"].ToString());
                this.FK_BusinessTypeId = int.Parse(reader.Reader["FK_BusinessTypeId"].ToString());
                this.FK_BusinessRegistrationTypeId = int.Parse(reader.Reader["FK_BusinessRegistrationTypeId"].ToString());
                this.FK_BusinessIslandLocationId = int.Parse(reader.Reader["FK_BusinessIslandLocationId"].ToString());
                this.FK_BusinessIslandDistrictId = int.Parse(reader.Reader["FK_BusinessIslandDistrictId"].ToString());
                this.NIN = (reader.Reader["NIN"].ToString());
                this.FirstNames = (reader.Reader["FirstNames"].ToString());
                this.LastName = (reader.Reader["LastName"].ToString());
                this.Salutation = (reader.Reader["Salutation"].ToString());
                this.Citizenship = (reader.Reader["Citizenship"].ToString());
                this.Gender = (reader.Reader["Gender"].ToString());
                this.DOB = DateTime.Parse(reader.Reader["DOB"].ToString());
                this.FK_ResidenceIslandLocationId = int.Parse(reader.Reader["FK_ResidenceIslandLocationId"].ToString());
                this.FK_ResidenceDistrictLocationId = int.Parse(reader.Reader["FK_ResidenceDistrictLocationId"].ToString());
                this.Mobile = (reader.Reader["Mobile"].ToString());
                this.HomeTelephone = (reader.Reader["HomeTelephone"].ToString());
                this.WorkTelephone = (reader.Reader["WorkTelephone"].ToString());
                this.Email = (reader.Reader["Email"].ToString());
                this.FK_EducationLevelId = int.Parse(reader.Reader["FK_EducationLevelId"].ToString());
                this.TermsAndConditionsAccepted = bool.Parse(reader.Reader["TermsAndConditionsAccepted"].ToString());
                this.CertificateNumber = (reader.Reader["CertificateNumber"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.CertificateIssueDate = DateTime.Parse(reader.Reader["CertificateIssueDate"].ToString());               
                this.FK_RegistrationRequestId = long.Parse(reader.Reader["FK_RegistrationRequestId"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }
        
        public long Save()
        {           
            int c = int.Parse(Utilities.ExecuteScalar("select count(Id) from BusinessRegistration where RegistrationNumber='" + this.RegistrationNumber + "'"));

            SqlCommand command;

            if (c < 1)
                command = new SqlCommand("insert into BusinessRegistration(RegistrationNumber,BusinessRegistrationNumber,BusinessName,FK_BusinessTypeId,FK_BusinessRegistrationTypeId,FK_BusinessIslandLocationId,FK_BusinessIslandDistrictId,NIN,FirstNames,LastName,Salutation,Citizenship,Gender,DOB,FK_ResidenceIslandLocationId,FK_ResidenceDistrictLocationId,Mobile,HomeTelephone,WorkTelephone,Email,FK_EducationLevelId,TermsAndConditionsAccepted,Status,StatusReason,CertificateIssueDate,CertificateNumber,FK_RegistrationRequestId,Created,CreatedBy,LastModified,LastModifiedBy) values(@RegistrationNumber,@BusinessRegistrationNumber,@BusinessName,@FK_BusinessTypeId,@FK_BusinessRegistrationTypeId,@FK_BusinessIslandLocationId,@FK_BusinessIslandDistrictId,@NIN,@FirstNames,@LastName,@Salutation,@Citizenship,@Gender,@DOB,@FK_ResidenceIslandLocationId,@FK_ResidenceDistrictLocationId,@Mobile,@HomeTelephone,@WorkTelephone,@Email,@FK_EducationLevelId,@TermsAndConditionsAccepted,@Status,@StatusReason,@CertificateIssueDate,@CertificateNumber,@FK_RegistrationRequestId,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");
            else
                command = new SqlCommand("update BusinessRegistration set FK_BusinessIslandLocationId=@FK_BusinessIslandLocationId,FK_BusinessIslandDistrictId=@FK_BusinessIslandDistrictId,FirstNames=@FirstNames,LastName=@LastName,Salutation=@Salutation,FK_ResidenceIslandLocationId=@FK_ResidenceIslandLocationId,FK_ResidenceDistrictLocationId=@FK_ResidenceDistrictLocationId,Mobile=@Mobile,HomeTelephone=@HomeTelephone,WorkTelephone=@WorkTelephone,Email=@Email,FK_EducationLevelId=@FK_EducationLevelId,LastModified=CURRENT_TIMESTAMP,LastModifiedBy=@LastModifiedBy where RegistrationNumber=@RegistrationNumber");

            command.Parameters.Add(new SqlParameter("@RegistrationNumber", this.RegistrationNumber));
            command.Parameters.Add(new SqlParameter("@BusinessRegistrationNumber", this.BusinessRegistrationNumber));
            command.Parameters.Add(new SqlParameter("@BusinessName", this.BusinessName));
            command.Parameters.Add(new SqlParameter("@FK_BusinessTypeId", this.FK_BusinessTypeId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessRegistrationTypeId", this.FK_BusinessRegistrationTypeId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessIslandLocationId", this.FK_BusinessIslandLocationId));
            command.Parameters.Add(new SqlParameter("@FK_BusinessIslandDistrictId", this.FK_BusinessIslandDistrictId));
            command.Parameters.Add(new SqlParameter("@NIN", this.NIN));
            command.Parameters.Add(new SqlParameter("@FirstNames", this.FirstNames));
            command.Parameters.Add(new SqlParameter("@LastName", this.LastName));
            command.Parameters.Add(new SqlParameter("@Salutation", this.Salutation));
            command.Parameters.Add(new SqlParameter("@Citizenship", this.Citizenship));
            command.Parameters.Add(new SqlParameter("@Gender", this.Gender));
            command.Parameters.Add(new SqlParameter("@DOB", this.DOB));
            command.Parameters.Add(new SqlParameter("@FK_ResidenceIslandLocationId", this.FK_ResidenceIslandLocationId));
            command.Parameters.Add(new SqlParameter("@FK_ResidenceDistrictLocationId", this.FK_ResidenceDistrictLocationId));
            command.Parameters.Add(new SqlParameter("@Mobile", this.Mobile));
            command.Parameters.Add(new SqlParameter("@HomeTelephone", this.HomeTelephone));
            command.Parameters.Add(new SqlParameter("@WorkTelephone", this.WorkTelephone));
            command.Parameters.Add(new SqlParameter("@Email", this.Email));
            command.Parameters.Add(new SqlParameter("@FK_EducationLevelId", this.FK_EducationLevelId));
            command.Parameters.Add(new SqlParameter("@TermsAndConditionsAccepted", this.TermsAndConditionsAccepted));
            command.Parameters.Add(new SqlParameter("@CertificateNumber", this.CertificateNumber));
            command.Parameters.Add(new SqlParameter("@Status", this.Status));
            command.Parameters.Add(new SqlParameter("@StatusReason", this.StatusReason));
            command.Parameters.Add(new SqlParameter("@CertificateIssueDate", this.CertificateIssueDate));
            command.Parameters.Add(new SqlParameter("@FK_RegistrationRequestId", this.FK_RegistrationRequestId));
            command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));

            if (c < 1)
            {
                this.Id = Utilities.ExecuteNewRecord(command);                
            }
            else
            {
                int x = Utilities.ExecuteNonQuery(command);
                if (x > 0)
                    this.Id = long.Parse(Utilities.ExecuteScalar("select Id from BusinessRegistration where RegistrationNumber='" + this.RegistrationNumber + "'"));
                else
                    this.Id = x;
            }

            return this.Id;
        }

        public long Id { get; set; }
        public string RegistrationNumber { get; set; }
        public string BusinessRegistrationNumber { get; set; }
        public string BusinessName { get; set; }
        public int FK_BusinessTypeId { get; set; }
        public int FK_BusinessRegistrationTypeId { get; set; }
        public int FK_BusinessIslandLocationId { get; set; }
        public int FK_BusinessIslandDistrictId { get; set; }
        public string NIN { get; set; }
        public string FirstNames { get; set; }
        public string LastName { get; set; }
        public string Salutation { get; set; }
        public string Citizenship { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public int FK_ResidenceIslandLocationId { get; set; }
        public int FK_ResidenceDistrictLocationId { get; set; }
        public string Mobile { get; set; }
        public string HomeTelephone { get; set; }
        public string WorkTelephone { get; set; }
        public string Email { get; set; }        
        public int FK_EducationLevelId { get; set; }
        public bool TermsAndConditionsAccepted { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public DateTime CertificateIssueDate { get; set; }
        public string CertificateNumber { get; set; }
        public long FK_RegistrationRequestId { get; set; }       
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
      
    }

    public class RenewalRequest
    {
        public RenewalRequest() { }

        public RenewalRequest(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from RenewalRequest where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.ReferenceNumber = (reader.Reader["ReferenceNumber"].ToString());
                this.FK_BusinessRegistrationId = long.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                this.BusinessDescription = (reader.Reader["BusinessDescription"].ToString());
                this.WorkingPremises = (reader.Reader["WorkingPremises"].ToString());
                this.MarketingPlan = (reader.Reader["MarketingPlan"].ToString());
                this.Funding = (reader.Reader["Funding"].ToString());
                this.GoalsAndObjectives = (reader.Reader["GoalsAndObjectives"].ToString());
                this.Equipment = (reader.Reader["Equipment"].ToString());
                this.RawMaterials = (reader.Reader["RawMaterials"].ToString());
                this.OperationsForecast = (reader.Reader["OperationsForecast"].ToString());
                this.SalesTarget = (reader.Reader["SalesTarget"].ToString());
                this.BusinessAdvantages = (reader.Reader["BusinessAdvantages"].ToString());
                this.BusinessDisadvantages = (reader.Reader["BusinessDisadvantages"].ToString());
                this.FK_BusinessDevelopmentOfficerId = int.Parse(reader.Reader["FK_BusinessDevelopmentOfficerId"].ToString());
                this.SubmissionType = (reader.Reader["SubmissionType"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.CertificateRenewalDate = DateTime.Parse(reader.Reader["CertificateRenewalDate"].ToString());
                this.DocumentType = (reader.Reader["DocumentType"].ToString());
                this.RequireWorkFlow = bool.Parse(reader.Reader["RequireWorkFlow"].ToString());
                this.WorkFlowId = long.Parse(reader.Reader["WorkFlowId"].ToString());
                this.WorkFlowStatus = (reader.Reader["WorkFlowStatus"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public long Save()
        {
            this.DocumentType = "renewal";
            this.RequireWorkFlow = true;
            this.WorkFlowId = Utilities.GetEntityWorkFlow(this.DocumentType);
            this.WorkFlowStatus = "";

            int c = int.Parse(Utilities.ExecuteScalar("select count(Id) from RenewalRequest where ReferenceNumber='" + this.ReferenceNumber + "'"));

            SqlCommand command;

            if (c < 1)
                command = new SqlCommand("insert into RenewalRequest(ReferenceNumber,FK_BusinessRegistrationId,BusinessDescription,WorkingPremises,MarketingPlan,Funding,GoalsAndObjectives,Equipment,RawMaterials,OperationsForecast,SalesTarget,BusinessAdvantages,BusinessDisadvantages,FK_BusinessDevelopmentOfficerId,SubmissionType,Status,StatusReason,CertificateRenewalDate,DocumentType,RequireWorkFlow,WorkFlowId,WorkFlowStatus,Created,CreatedBy,LastModified,LastModifiedBy) values(@ReferenceNumber,@FK_BusinessRegistrationId,@BusinessDescription,@WorkingPremises,@MarketingPlan,@Funding,@GoalsAndObjectives,@Equipment,@RawMaterials,@OperationsForecast,@SalesTarget,@BusinessAdvantages,@BusinessDisadvantages,@FK_BusinessDevelopmentOfficerId,@SubmissionType,@Status,@StatusReason,@CertificateRenewalDate,@DocumentType,@RequireWorkFlow,@WorkFlowId,@WorkFlowStatus,CURRENT_TIMESTAMP,@CreatedBy,CURRENT_TIMESTAMP,@LastModifiedBy)");
            else
                command = new SqlCommand("update RenewalRequest set FK_BusinessRegistrationId=@FK_BusinessRegistrationId,BusinessDescription=@BusinessDescription,WorkingPremises=@WorkingPremises,MarketingPlan=@MarketingPlan,Funding=@Funding,GoalsAndObjectives=@GoalsAndObjectives,Equipment=@Equipment,RawMaterials=@RawMaterials,OperationsForecast=@OperationsForecast,SalesTarget=@SalesTarget,BusinessAdvantages=@BusinessAdvantages,BusinessDisadvantages=@BusinessDisadvantages,FK_BusinessDevelopmentOfficerId=@FK_BusinessDevelopmentOfficerId,LastModified=CURRENT_TIMESTAMP,LastModifiedBy=@LastModifiedBy where ReferenceNumber=@ReferenceNumber");
           
            command.Parameters.Add(new SqlParameter("@ReferenceNumber", this.ReferenceNumber));
            command.Parameters.Add(new SqlParameter("@FK_BusinessRegistrationId", this.FK_BusinessRegistrationId));
            command.Parameters.Add(new SqlParameter("@BusinessDescription", this.BusinessDescription));
            command.Parameters.Add(new SqlParameter("@WorkingPremises", this.WorkingPremises));
            command.Parameters.Add(new SqlParameter("@MarketingPlan", this.MarketingPlan));
            command.Parameters.Add(new SqlParameter("@Funding", this.Funding));
            command.Parameters.Add(new SqlParameter("@GoalsAndObjectives", this.GoalsAndObjectives));
            command.Parameters.Add(new SqlParameter("@Equipment", this.Equipment));
            command.Parameters.Add(new SqlParameter("@RawMaterials", this.RawMaterials));
            command.Parameters.Add(new SqlParameter("@OperationsForecast", this.OperationsForecast));
            command.Parameters.Add(new SqlParameter("@SalesTarget", this.SalesTarget));
            command.Parameters.Add(new SqlParameter("@BusinessAdvantages", this.BusinessAdvantages));
            command.Parameters.Add(new SqlParameter("@BusinessDisadvantages", this.BusinessDisadvantages));
            command.Parameters.Add(new SqlParameter("@FK_BusinessDevelopmentOfficerId", this.FK_BusinessDevelopmentOfficerId));
            command.Parameters.Add(new SqlParameter("@SubmissionType", this.SubmissionType));
            command.Parameters.Add(new SqlParameter("@Status", this.Status));
            command.Parameters.Add(new SqlParameter("@StatusReason", this.StatusReason));
            command.Parameters.Add(new SqlParameter("@CertificateRenewalDate", this.CertificateRenewalDate));
            command.Parameters.Add(new SqlParameter("@DocumentType", this.DocumentType));
            command.Parameters.Add(new SqlParameter("@RequireWorkFlow", this.RequireWorkFlow));
            command.Parameters.Add(new SqlParameter("@WorkFlowId", this.WorkFlowId));
            command.Parameters.Add(new SqlParameter("@WorkFlowStatus", this.WorkFlowStatus));
            command.Parameters.Add(new SqlParameter("@CreatedBy", Security.actingUser));
            command.Parameters.Add(new SqlParameter("@LastModifiedBy", Security.actingUser));

            if (c < 1)
            {
                this.Id = Utilities.ExecuteNewRecord(command);
                if (this.Id > 0)
                {
                    if (this.RequireWorkFlow)
                    {
                        //submit to workflow
                        DocumentWorkflow wrkDoc = Utilities.SubmitWorkFlowDocument(this.WorkFlowId, this.Id.ToString(), this.DocumentType);
                        this.WorkFlowStatus = wrkDoc.WorkFlowStatus;
                        UpdateWorkFlowStatus();

                    }
                }
                else
                {


                }
            }
            else
            {
                int x = Utilities.ExecuteNonQuery(command);
                if (x > 0)
                    this.Id = long.Parse(Utilities.ExecuteScalar("select Id from RenewalRequest where ReferenceNumber='" + this.ReferenceNumber + "'"));
                else
                    this.Id = x;
            }

            return this.Id;
        }

        public bool UpdateWorkFlowStatus()
        {
            int x = Utilities.ExecuteNonQuery("update RenewalRequest set WorkFlowStatus='" + this.WorkFlowStatus + "',Status='" + this.WorkFlowStatus + "' where Id=" + this.Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public string ReferenceNumber { get; set; }
        public long FK_BusinessRegistrationId { get; set; }
        public string BusinessDescription { get; set; }
        public string WorkingPremises { get; set; }
        public string MarketingPlan { get; set; }
        public string Funding { get; set; }
        public string GoalsAndObjectives { get; set; }
        public string Equipment { get; set; }
        public string RawMaterials { get; set; }
        public string OperationsForecast { get; set; }
        public string SalesTarget { get; set; }
        public string BusinessAdvantages { get; set; }
        public string BusinessDisadvantages { get; set; }
        public int FK_BusinessDevelopmentOfficerId { get; set; }
        public string SubmissionType { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public DateTime CertificateRenewalDate { get; set; }
        public string DocumentType { get; set; }
        public bool RequireWorkFlow { get; set; }
        public long WorkFlowId { get; set; }
        public string WorkFlowStatus { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
    
    public class AutoDocument
    {
        public AutoDocument() { }
        public long Id { get; set; }
        public string DocumentType { get; set; }
        public string DocumentTypeName { get; set; }
    }

    public class CottageCertificate
    {
        public CottageCertificate() { }

        public CottageCertificate(long Id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from CottageCertificate where FK_BusinessRegistrationId=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_BusinessRegistrationId = long.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                this.CertificateNumber = (reader.Reader["CertificateNumber"].ToString());
                this.CertificateIssueDate = DateTime.Parse(reader.Reader["CertificateIssueDate"].ToString());
                this.LastRenewalDate = DateTime.Parse(reader.Reader["LastRenewalDate"].ToString());
                this.NextRenewalDate = DateTime.Parse(reader.Reader["NextRenewalDate"].ToString());
                this.FK_LastRenewedById = long.Parse(reader.Reader["FK_LastRenewedById"].ToString());
                this.FK_IssuedById = (reader.Reader["FK_IssuedById"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.DocumentType = (reader.Reader["DocumentType"].ToString());
                this.RequireWorkFlow = bool.Parse(reader.Reader["RequireWorkFlow"].ToString());
                this.WorkFlowId = long.Parse(reader.Reader["WorkFlowId"].ToString());
                this.WorkFlowStatus = (reader.Reader["WorkFlowStatus"].ToString());
                this.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }
        
        public bool InitializeCertificate(long fK_BusinessRegistrationId)
        {
            this.DocumentType = "certificate";
            this.RequireWorkFlow = true;
            this.WorkFlowId = Utilities.GetEntityWorkFlow(this.DocumentType);
            this.WorkFlowStatus = "";
            this.FK_BusinessRegistrationId = fK_BusinessRegistrationId;
            bool done = false;
            //check if already exists
            int y = int.Parse(Utilities.ExecuteScalar("select count(Id) from CottageCertificate where FK_BusinessRegistrationId="+fK_BusinessRegistrationId));
            if (y < 1)
            {
                long x = (Utilities.ExecuteNewRecord("insert into CottageCertificate(FK_BusinessRegistrationId,CertificateNumber,CertificateIssueDate,LastRenewalDate,NextRenewalDate,FK_LastRenewedById,FK_IssuedById,Status,StatusReason,DocumentType,RequireWorkFlow,WorkFlowId,WorkFlowStatus,Created,CreatedBy,LastModified,LastModifiedBy) values(" + fK_BusinessRegistrationId + ",'',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,0,'','Pending','Registration','"+this.DocumentType+"','True',"+this.WorkFlowId+",'',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')"));               
                 done= ((x > 0) ? true : false);
                if (done)
                {
                    //submit to workflow
                    DocumentWorkflow wrkDoc = Utilities.SubmitWorkFlowDocument(this.WorkFlowId, x.ToString(), this.DocumentType);
                    this.WorkFlowStatus = wrkDoc.WorkFlowStatus;
                    UpdateWorkFlowStatus();
                }
               
            }
            else
            {
                long x = Utilities.ExecuteNonQuery("update CottageCertificate set Status='Pending',StatusReason='Renewal',WorkFlowStatus='Saved',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_BusinessRegistrationId=" + fK_BusinessRegistrationId);
                 done= ((x > 0) ? true : false);
                if(done)
                {
                    //get id
                    long z = long.Parse(Utilities.ExecuteScalar("select Id from CottageCertificate where FK_BusinessRegistrationId=" + fK_BusinessRegistrationId));
                    //submit to workflow
                    DocumentWorkflow newDocument = new DocumentWorkflow(this.WorkFlowId, z.ToString(), this.DocumentType,true);
                    newDocument.SaveDocument();
                    //this.WorkFlowStatus = newDocument.WorkFlowStatus;
                    //UpdateWorkFlowStatus();
                }
            }

            return done;
        }

        public bool Issue(long renewalId = 0)
        {
            int x = 0;
            if (renewalId == 0)
            {
                x = Utilities.ExecuteNonQuery("update CottageCertificate set CertificateIssueDate=CURRENT_TIMESTAMP,Status='Issued',StatusReason='Registration',FK_IssuedById='" + Security.actingUser + "',CertificateNumber='" + Utilities.GenerateCertificateNumber(this.FK_BusinessRegistrationId) + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where CertificateNumber='' and FK_BusinessRegistrationId=" + this.FK_BusinessRegistrationId);
            }
            else
            {              
                x = Utilities.ExecuteNonQuery("update CottageCertificate set FK_LastRenewedById=" + renewalId + ",Status='Issued',StatusReason='Renewal',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_BusinessRegistrationId=" + this.FK_BusinessRegistrationId);
            }
            
            return ((x > 0) ? true : false);
        }
        
        public bool UpdateWorkFlowStatus()
        {
            int x = Utilities.ExecuteNonQuery("update CottageCertificate set WorkFlowStatus='" + this.WorkFlowStatus + "',Status='" + this.WorkFlowStatus + "' where FK_BusinessRegistrationId=" + this.FK_BusinessRegistrationId);
            return ((x > 0) ? true : false);
        }

        public static bool UpdatePeriod(long id, DateTime lastRenewalDate, DateTime nextRenewalDate)
        {
            int x = Utilities.ExecuteNonQuery("update CottageCertificate set LastRenewalDate='"+ lastRenewalDate.ToString("yyyy-MM-dd HH:mm:ss.000") + "',NextRenewalDate='" + nextRenewalDate.ToString("yyyy-MM-dd HH:mm:ss.000") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_BusinessRegistrationId=" + id);
            
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_BusinessRegistrationId { get; set; }
        public string CertificateNumber { get; set; }
        public DateTime CertificateIssueDate { get; set; }
        public DateTime LastRenewalDate { get; set; }
        public DateTime NextRenewalDate { get; set; }
        public long FK_LastRenewedById { get; set; }
        public string FK_IssuedById { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public string DocumentType { get; set; }
        public bool RequireWorkFlow { get; set; }
        public long WorkFlowId { get; set; }
        public string WorkFlowStatus { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class ActiveRenewalRequest
    {
        public ActiveRenewalRequest() { }
        
        public long Id { get; set; }
        public string RegistrationNumber { get; set; }
        public string BusinessName { get; set; }
        public string NIN { get; set; }
        public string FirstNames { get; set; }
        public string LastName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string Status { get; set; }
        public string CertificateNumber { get; set; }
    }

    public class QuickStats
    {
        public QuickStats() {
            this.RegisteredBusinessCount = long.Parse(Utilities.ExecuteScalar("select count(Id) from BusinessRegistration"));
            this.PendingRenewalsCount = long.Parse(Utilities.ExecuteScalar("select count(Id) from RenewalRequest where Status<>'Complete'"));
            this.PendingBusinessRegistrationsCount = long.Parse(Utilities.ExecuteScalar("select count(Id) from RegistrationRequest where Status<>'Complete'"));
            this.PendingSiteVisitsCount = long.Parse(Utilities.ExecuteScalar("select count(Id) from SiteVisit where VisitDate >CURRENT_TIMESTAMP"));
        }
        
        public long RegisteredBusinessCount { get; set; }
        public long PendingRenewalsCount { get; set; }
        public long PendingBusinessRegistrationsCount { get; set; }
        public long PendingSiteVisitsCount { get; set; }
    }

    public class Notifications
    {
        public Notifications() { }

        public Notifications(string fK_Username, string title, string documentType, long fK_DocumentId) {
            this.FK_Username = fK_Username;
            this.Title = title;
            this.DocumentType = documentType;
            this.FK_DocumentId = fK_DocumentId;
            this.Status = false;
            Save();
    }

        public bool Save()
        {
            long x = (Utilities.ExecuteNewRecord("insert into Notifications(FK_Username,Title,DocumentType,FK_DocumentId,Status,Created,CreatedBy,LastModified,LastModifiedBy) values('" + this.FK_Username + "','" + this.Title + "','" + this.DocumentType + "'," + this.FK_DocumentId + ",'" + ((this.Status) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')"));
            return ((x > 0) ? true : false);
        }

        public static bool Update(long id,bool status)
        {
            long x = (Utilities.ExecuteNewRecord("update Notifications set Status='"+((status)?"True":"False")+"' where Id=" + id));
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public string FK_Username { get; set; }
        public string Title { get; set; }
        public string DocumentType { get; set; }
        public long FK_DocumentId { get; set; }
        public bool Status { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

}