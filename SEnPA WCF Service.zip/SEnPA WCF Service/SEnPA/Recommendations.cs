﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEnPA
{
    public partial class Utilities
    {
        public static List<RecommendedAction> GetRecommendedActions(long fK_RecommendationId)
        {
            List<RecommendedAction> response = new List<RecommendedAction>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from RecommendedAction where FK_RecommendationId=" + fK_RecommendationId);
            while (reader.Reader.Read())
            {
                RecommendedAction report = new RecommendedAction();
                report.Id = long.Parse(reader.Reader["Id"].ToString());
                report.FK_RecommendationId = int.Parse(reader.Reader["FK_RecommendationId"].ToString());
                report.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                report.FK_ActionId = int.Parse(reader.Reader["FK_ActionId"].ToString());
                report.Details = (reader.Reader["Details"].ToString());
                report.Reminder = bool.Parse(reader.Reader["Reminder"].ToString());
                report.Status = (reader.Reader["Status"].ToString());
                report.StatusReason = (reader.Reader["StatusReason"].ToString());
                report.Active = bool.Parse(reader.Reader["Active"].ToString());
                report.Created = DateTime.Now;
                report.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                report.LastModified = DateTime.Now;
                report.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(report);
            }
            reader.Close();
            return response;
        }

        public static long SaveRecommendedAction(long fK_RecommendationId, int fK_StakeholderId, int fK_ActionId, string details, bool reminder, string status, string statusReason, bool active)
        {
            RecommendedAction report = new RecommendedAction(fK_RecommendationId, fK_StakeholderId, fK_ActionId, details, reminder, status, statusReason, active);
            return report.Save();
        }

        public static RecommendedAction GetRecommendedAction(long fK_RecommendationId, int fK_StakeholderId)
        {
            RecommendedAction report = new RecommendedAction(fK_RecommendationId, fK_StakeholderId);
            return report;
        }
        
        public static long CreateWorkflowRecommendations(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return 0;
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                Recommendations reco = new Recommendations();
                return reco.Generate(long.Parse(wrkIdentity.DocumentId), wrkDoc.Id, wrkStage.Id);
            }
        }

        public static Recommendations GetCurrentWorkflowRecommendations(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return new Recommendations();
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                Recommendations reco = new Recommendations(long.Parse(wrkIdentity.DocumentId), wrkDoc.Id, wrkStage.Id);
                return reco;
            }
        }
    }

    public class RecommendedAction
    {
        public RecommendedAction() { }
        public RecommendedAction(long fK_RecommendationId, int fK_StakeholderId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from RecommendedAction where FK_RecommendationId=" + fK_RecommendationId + " and FK_StakeholderId=" + fK_StakeholderId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_RecommendationId = int.Parse(reader.Reader["FK_RecommendationId"].ToString());
                this.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                this.FK_ActionId = int.Parse(reader.Reader["FK_ActionId"].ToString());
                this.Details = (reader.Reader["Details"].ToString());
                this.Reminder = bool.Parse(reader.Reader["Reminder"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.Active = bool.Parse(reader.Reader["Active"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public RecommendedAction(long fK_RecommendationId, int fK_StakeholderId, int fK_ActionId, string details, bool reminder, string status, string statusReason, bool active)
        {
            this.FK_RecommendationId = fK_RecommendationId;
            this.FK_StakeholderId = fK_StakeholderId;
            this.FK_ActionId = fK_ActionId;
            this.Details = details;
            this.Reminder = reminder;
            this.Status = status;
            this.StatusReason = statusReason;
            this.Active = active;
        }

        public long Save()
        {
            long x = int.Parse(Utilities.ExecuteScalar("select count(Id) from RecommendedAction where FK_RecommendationId=" + this.FK_RecommendationId + " and FK_StakeholderId=" + this.FK_StakeholderId));
            if (x < 1)
                x = Utilities.ExecuteNewRecord("insert into RecommendedAction(FK_RecommendationId,FK_StakeholderId,FK_ActionId,Details,Reminder,Active,Status,StatusReason,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_RecommendationId + "," + this.FK_StakeholderId + "," + this.FK_ActionId + ",'" + this.Details + "','" + ((this.Reminder) ? "True" : "False") + "','" + ((this.Active) ? "True" : "False") + "','" + this.Status + "','" + this.StatusReason + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            else
            {
                x = Utilities.ExecuteNonQuery("update RecommendedAction set FK_ActionId=" + this.FK_ActionId + ",Details='" + this.Details + "',Reminder='" + ((this.Reminder) ? "True" : "False") + "',Active='" + ((this.Active) ? "True" : "False") + "',Status='" + this.Status + "',StatusReason='" + this.StatusReason + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "'  where FK_RecommendationId=" + this.FK_RecommendationId + " and FK_StakeholderId=" + this.FK_StakeholderId);
                
            }
                return x;
        }

        public long Id { get; set; }
        public long FK_RecommendationId { get; set; }
        public int FK_StakeholderId { get; set; }
        public int FK_ActionId { get; set; }
        public string Details { get; set; }
        public bool Reminder { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class Recommendations
    {
        public Recommendations() { }
        
        public Recommendations(long fK_DocumentId, long fK_DocumentWorkFlowId, long fK_WorkFlowStageId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from Recommendations where FK_DocumentId=" + fK_DocumentId + " and FK_DocumentWorkFlowId=" + fK_DocumentWorkFlowId + " and FK_WorkFlowStageId=" + fK_WorkFlowStageId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                this.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                this.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                this.FK_BusinessDevelopmentOfficer = int.Parse(reader.Reader["FK_BusinessDevelopmentOfficer"].ToString());
                this.DeadlineDate = DateTime.Parse(reader.Reader["DeadlineDate"].ToString());
                this.Comments = (reader.Reader["Comments"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public Recommendations(long fK_DocumentId, long fK_DocumentWorkFlowId, long fK_WorkFlowStageId, int fK_BusinessDevelopmentOfficer, DateTime deadlineDate, string comments, string status, string statusReason)
        {
            this.FK_DocumentId = fK_DocumentId;
            this.FK_DocumentWorkFlowId = fK_DocumentWorkFlowId;
            this.FK_WorkFlowStageId = fK_WorkFlowStageId;
            this.FK_BusinessDevelopmentOfficer = fK_BusinessDevelopmentOfficer;
            this.DeadlineDate = deadlineDate;
            this.Comments = comments;
            this.Status = status;
            this.StatusReason = statusReason;
        }

        public long Generate(long fK_DocumentId, long fK_DocumentWorkFlowId, long fK_WorkFlowStageId)
        {
            long x = Utilities.ExecuteNewRecord("insert into Recommendations(FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,FK_BusinessDevelopmentOfficer,DeadlineDate,Comments,Status,StatusReason,Created,CreatedBy,LastModified,LastModifiedBy) values(" + fK_DocumentId + "," + fK_DocumentWorkFlowId + "," + fK_WorkFlowStageId + ",0,'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.00") + "','','','',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            if (x > 0)
            {
                this.Id = x;
            }
            return x;
        }

        public long Create()
        {
            long x = Utilities.ExecuteNewRecord("insert into Recommendations(FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,FK_BusinessDevelopmentOfficer,DeadlineDate,Comments,Status,StatusReason,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_DocumentId + "," + this.FK_DocumentWorkFlowId + "," + this.FK_WorkFlowStageId + "," + this.FK_BusinessDevelopmentOfficer + ",'" + this.DeadlineDate.ToString("yyyy-MM-dd HH:mm:ss.00") + "','" + this.Comments + "','" + this.Status +"','" + this.StatusReason+"',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            if (x > 0)
            {
                this.Id = x;
            }
            return x;
        }

        public long Id { get; set; }
        public long FK_DocumentId { get; set; }
        public long FK_DocumentWorkFlowId { get; set; }
        public long FK_WorkFlowStageId { get; set; }
        public int FK_BusinessDevelopmentOfficer { get; set; }
        public DateTime DeadlineDate { get; set; }
        public string Comments { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
}