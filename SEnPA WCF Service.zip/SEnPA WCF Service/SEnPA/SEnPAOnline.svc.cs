﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SEnPA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "SEnPAOnline" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select SEnPAOnline.svc or SEnPAOnline.svc.cs at the Solution Explorer and start debugging.
    public class SEnPAOnline : ISEnPAOnline
    {
        public string DoWork(string ID)
        {
            return "";// SystemUtilities.DoWork(ID);
        }
    }
}
