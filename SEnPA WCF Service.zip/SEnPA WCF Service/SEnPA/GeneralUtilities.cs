﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace SEnPA
{
    public partial class Utilities
    {
        //Log error
        public static void LogError(string source, Exception exception)
        {
            try
            {
                EventLog eventLog = new EventLog("SEnPA");
                eventLog.Source = source + "_PlatformService";
                eventLog.WriteEntry(exception.ToString(), EventLogEntryType.Error);
            }
            catch (Exception ex)
            {
                ; //Do nothing
            }
        }

        //Trace to file
        public static void WriteTrace(string filename, string data)
        {
            System.IO.File.WriteAllText(@"c:\Musvo\" + filename, data);
        }

        //Convert string to base 64 string
        public static string ConvertToBase64(string inputString)
        {
            byte[] bytes = System.Text.ASCIIEncoding.ASCII.GetBytes(inputString);
            return Convert.ToBase64String(bytes, Base64FormattingOptions.None);
        }
        
    }
}