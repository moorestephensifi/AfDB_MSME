﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SEnPA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ISEnPASecurity" in both code and config file together.
    [ServiceContract]
    public interface ISEnPASecurity
    {
        [OperationContract]
        AuthenticationResponse Authenticate(string username, string password);

        [OperationContract]
        PasswordChangeResponse ChangePassword(string username, string oldpassword, string newpassword);

        [OperationContract]
        bool UpdateUserDetails(string userName, string FirstName, string Surname, string EmailAddress, string MobileNumber);


    }
}
