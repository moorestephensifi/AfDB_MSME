﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace SEnPA
{
    public class Security
    {
        public static int sessionHours = 24;
        public static int passwordExpiryDays = 180;
        public static string defaultPassword = "Password2017";
        public static string actingUser = "System";

        public static AuthenticationResponse Authenticate(string username, string password)
        {
            AuthenticationResponse response= new AuthenticationResponse { username = username, accessToken = "", authenticationStatus = false, responseCode = -1, responseMessage = "failed" };

            ApplicationUsers user = new ApplicationUsers(username);
            string userAuthToken = Security.GeneratePasswordToken(username, password);

            if (user.Passcode == "")
            {
                response.responseCode = -1;
                response.responseMessage = "Invalid username";
            }
            else if (user.Passcode != userAuthToken)
            {
                response.responseCode = -2;
                response.responseMessage = "Invalid username and password";
            }
            else if (!user.Active)
            {
                response.responseCode = -3;
                response.responseMessage = "Account is disabled";
            }
            else if (user.Locked)
            {
                response.responseCode = -4;
                response.responseMessage = "Account is locked";
            }
            else if (user.PasswordExpires && user.PasswordExpiryDate < DateTime.Now)
            {
                response.responseCode = -5;
                response.responseMessage = "Account password has expired";
            }
            else
            {
                //log user in, create session token for user
                string getToken = GenerateSessionToken(user.Username);
                if(getToken!="")
                {
                    response.accessToken = getToken;
                    response.authenticationStatus = true;
                    response.responseCode = 1;
                    response.responseMessage = "";
                }
                else
                {
                    //failed token generation
                    response.responseCode = 0;
                    response.responseMessage = "Error creating session";
                }
            }

            return response;
        }

        public static SignoutResponse Signout(string username)
        {
            return new SignoutResponse { signoutStatus = true };
        }

        public static PasswordChangeResponse ChangePassword(string username,string oldPassword,string newPassword)
        {
            PasswordChangeResponse response= new PasswordChangeResponse { changeStatus = false, responseMessage = "" };
            if (CheckStrength(newPassword) > PasswordScore.Weak)
            {
                ApplicationUsers user = new ApplicationUsers(username);
                string userAuthToken = Security.GeneratePasswordToken(username, oldPassword);

                if (user.Passcode == "")
                {
                    response.responseMessage = "Invalid user";
                }
                else if (user.Passcode != userAuthToken)
                {
                    response.responseMessage = "Invalid old password";
                }
                else
                {
                    if (user.UpdatePassword(newPassword))
                    {
                        response.changeStatus = true;
                        response.responseMessage = "Successful";
                    }
                    else
                    {
                        response.responseMessage = "Error updating password";
                    }
                }
            }
            else
            {
                response.responseMessage = "Your password is weak!";
            }

            return response;
        }

        public static List<ApplicationUsers> GetUsers(string filterText)
        {
            List<ApplicationUsers> response = new List<ApplicationUsers>();
            //retrieve user details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Username,Passcode,FK_StakeholderId,FK_RoleGroup,Active,Locked,PasswordExpires,PasswordExpiryDate,PasswordLastChanged,Created,CreatedBy,LastModified,LastModifiedBy,FirstName,Surname,EmailAddress,MobileNumber from ApplicationUsers where Username like '%" + filterText + "%'");
            while (reader.Reader.Read())
            {
                ApplicationUsers user = new ApplicationUsers();
                user.Id = int.Parse(reader.Reader["Id"].ToString());
                user.Username = (reader.Reader["Username"].ToString());
                user.Passcode = "";
                user.FK_RoleGroup = (reader.Reader["FK_RoleGroup"].ToString());
                user.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                user.Active = reader.Reader.GetBoolean(5);
                user.Locked = reader.Reader.GetBoolean(6);
                user.PasswordExpires = reader.Reader.GetBoolean(7);
                user.PasswordExpiryDate = reader.Reader.GetDateTime(8);
                user.PasswordLastChanged = reader.Reader.GetDateTime(9);
                user.Created = reader.Reader.GetDateTime(10);
                user.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                user.LastModified = reader.Reader.GetDateTime(12);
                user.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                user.FirstName = (reader.Reader["FirstName"].ToString());
                user.Surname = (reader.Reader["Surname"].ToString());
                user.EmailAddress = (reader.Reader["EmailAddress"].ToString());
                user.MobileNumber = (reader.Reader["MobileNumber"].ToString());

                response.Add(user);
            }
            reader.Close();
            return response;
        }

        public static ApplicationUsers GetUser(string username)
        {
           ApplicationUsers response = new ApplicationUsers(username);
            response.Passcode = "";
            return response;
        }
       
        public static List<ApplicationRoles> GetApplicationRoles(string username)
        {
            List<ApplicationRoles> response = new List<ApplicationRoles>();
            //retrieve user details from database
            string query = ((username.ToLower() == "default") ? "select Id,Name,Description from ApplicationRoles" : "select Id,Name,Description from ApplicationRoles where Id in (select FK_RoleId from ApplicationUserAssignedRoles where Username='" + username + "')");
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader(query);
            while (reader.Reader.Read())
            {
                ApplicationRoles userRole = new ApplicationRoles();
                userRole.Id = int.Parse(reader.Reader["Id"].ToString());
                userRole.Name = (reader.Reader["Name"].ToString());
                userRole.Description = (reader.Reader["Description"].ToString());

                response.Add(userRole);
            }
            reader.Close();

            List<ApplicationRoleGroups> groups = Security.GetApplicationRoleGroups(username);
            foreach (ApplicationRoleGroups grp in groups)
            {
                List<ApplicationRoles> roles = Security.GetApplicationUserGroupRoles(grp.Name);
                foreach (ApplicationRoles role in roles)
                {
                    response.Add(role);
                }
            }
            //get group user roles

            return response;
        }       

        public static UserRoleActionResponse AddRole(string username, string userRole)
        {
            UserRoleActionResponse response = new UserRoleActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationUserAssignedRoles usrRole = new ApplicationUserAssignedRoles(username, userRole);
            if(usrRole.AddRole())
            {
                response.actionStatus = true;
                response.responseMessage = "";
            }
            else
            {
                response.responseMessage = "Failed to add role";
            }

            return response;
        }

        public static UserRoleActionResponse RemoveRole(string username, string userRole)
        {
            UserRoleActionResponse response = new UserRoleActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationUserAssignedRoles usrRole = new ApplicationUserAssignedRoles(username, userRole);
            if (usrRole.RemoveRole())
            {
                response.actionStatus = true;
                response.responseMessage = "";
            }
            else
            {
                response.responseMessage = "Failed to remove role";
            }

            return response;
        }

        public static List<ApplicationRoleGroups> GetApplicationRoleGroups(string username)
        {
            List<ApplicationRoleGroups> response = new List<ApplicationRoleGroups>();
            if (username.ToLower() != "default")
            {
                ApplicationUsers user = new ApplicationUsers(username);
                ApplicationRoleGroups userRol = new ApplicationRoleGroups();
                userRol.Name = user.FK_RoleGroup;
                userRol.Id = 0;
                response.Add(userRol);
            }
            //retrieve user details from database
            string query = ((username.ToLower() == "default") ? "select Id,Name,Description from ApplicationRoleGroups" : "select Id,Name,Description from ApplicationRoleGroups where Id in (select FK_RoleGroupId from ApplicationRoleGroupAssignedRoles where Username='" + username + "')");
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader(query);
            while (reader.Reader.Read())
            {
                ApplicationRoleGroups userRole = new ApplicationRoleGroups();
                userRole.Id = int.Parse(reader.Reader["Id"].ToString());
                userRole.Name = (reader.Reader["Name"].ToString());
                userRole.Description = (reader.Reader["Description"].ToString());

                response.Add(userRole);
            }
            reader.Close();
            return response;
        }

        public static UserRoleActionResponse AddGroupRole(string username, string userRole)
        {
            UserRoleActionResponse response = new UserRoleActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationRoleGroupAssignedRoles usrRole = new ApplicationRoleGroupAssignedRoles(username, userRole);
            if (usrRole.AddRole())
            {
                response.actionStatus = true;
                response.responseMessage = "";
            }
            else
            {
                response.responseMessage = "Failed to add role";
            }

            return response;
        }

        public static UserRoleActionResponse RemoveGroupRole(string username, string userRole)
        {
            UserRoleActionResponse response = new UserRoleActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationRoleGroupAssignedRoles usrRole = new ApplicationRoleGroupAssignedRoles(username, userRole);
            if (usrRole.RemoveRole())
            {
                response.actionStatus = true;
                response.responseMessage = "";
            }
            else
            {
                response.responseMessage = "Failed to remove role";
            }

            return response;
        }

        public static UserActionResponse AddUser(string username, string password, int fK_StakeholderId, string roleGroup, string firstName, string surname, string emailAddress, string mobileNumber, bool passwordExpires, bool active, bool locked)
        {
            UserActionResponse response = new UserActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationUsers user = new ApplicationUsers(username, password,fK_StakeholderId, roleGroup, firstName, surname, emailAddress, mobileNumber, passwordExpires, active, locked);
            if (user.SaveUser())
            {
                response.actionStatus = true;
            }
            else
            {
                response.responseMessage = "Error";
            }

            return response;
        }

        public static UserActionResponse UpdateUser(string username, string action)
        {
            UserActionResponse response = new UserActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationUsers user = new ApplicationUsers(username);
            switch (action) {
                case "disable":
                    if (user.DisableUser())
                        response.actionStatus = true;
                    else
                        response.responseMessage = "Error";
                    break;
                case "enable":
                    if (user.EnableUser())
                        response.actionStatus = true;
                    else
                        response.responseMessage = "Error";
                    break;
                case "lock":
                    if (user.LockUser())
                        response.actionStatus = true;
                    else
                        response.responseMessage = "Error";
                    break;
                case "unlock":
                    if (user.UnlockUser())
                        response.actionStatus = true;
                    else
                        response.responseMessage = "Error";
                    break;

                case "expire":
                    if (user.ExpireUserPassword())
                        response.actionStatus = true;
                    else
                        response.responseMessage = "Error";
                    break;
                case "notexpire":
                    if (user.NotExpireUserPassword())
                        response.actionStatus = true;
                    else
                        response.responseMessage = "Error";
                    break;
                default:
                    response.responseMessage = "Error";
                    break;
            }            

            return response;
        }

        public static UserRoleActionResponse AddUserGroup(string group, string description)
        {
            UserRoleActionResponse response = new UserRoleActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationRoleGroups usrRole = new ApplicationRoleGroups(group, description);
            if (usrRole.SaveGroup())
            {
                response.actionStatus = true;
                response.responseMessage = "";
            }
            else
            {
                response.responseMessage = "Failed to add group";
            }

            return response;
        }

        public static List<ApplicationRoles> GetApplicationUserGroupRoles(string group)
        {
            List<ApplicationRoles> response = new List<ApplicationRoles>();
            //retrieve user details from database
            string query = "select Id,Name,Description from ApplicationRoles where Id in (select FK_RoleId from ApplicationUserAssingedRoleGroups where FK_RoleGroup='" + group + "')";
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader(query);
            while (reader.Reader.Read())
            {
                ApplicationRoles userRole = new ApplicationRoles();
                userRole.Id = int.Parse(reader.Reader["Id"].ToString());
                userRole.Name = (reader.Reader["Name"].ToString());
                userRole.Description = (reader.Reader["Description"].ToString());

                response.Add(userRole);
            }
            reader.Close();

            return response;
        }

        public static UserRoleActionResponse AddUserGroupRole(string group, string userRole)
        {
            UserRoleActionResponse response = new UserRoleActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationUserAssingedRoleGroups usrRole = new ApplicationUserAssingedRoleGroups(group, userRole);
            if (usrRole.AddRole())
            {
                response.actionStatus = true;
                response.responseMessage = "";
            }
            else
            {
                response.responseMessage = "Failed to add role";
            }

            return response;
        }

        public static UserRoleActionResponse RemoveUserGroupRole(string group, string userRole)
        {
            UserRoleActionResponse response = new UserRoleActionResponse { actionStatus = false, responseMessage = "" };
            ApplicationUserAssingedRoleGroups usrRole = new ApplicationUserAssingedRoleGroups(group, userRole);
            if (usrRole.RemoveRole())
            {
                response.actionStatus = true;
                response.responseMessage = "";
            }
            else
            {
                response.responseMessage = "Failed to remove role";
            }

            return response;
        }

        //security utilities
        public static bool CheckUserRolegroupAccess(string username, long groupId)
        {
            int x = int.Parse(Utilities.ExecuteScalar("select count(FK_RoleGroupId) from ApplicationRoleGroupAssignedRoles where Username='" + username + "' and FK_RoleGroupId=" + groupId));
            return ((x > 0) ? true : false);
        }

        //utilities
        static string GetMd5Hash(MD5 md5Hash, string input)
        {

            // Convert the input string to a byte array and compute the hash.
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Create a new Stringbuilder to collect the bytes
            // and create a string.
            StringBuilder sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data 
            // and format each one as a hexadecimal string.
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }

        public static string GeneratePasswordToken(string account, string password)
        {
            try
            {
                string token = password + account.ToLower();
                MD5 md5Hash = MD5.Create();
                string hash = GetMd5Hash(md5Hash, token);
                return hash;
            }
            catch
            {
                return "Error";
            }
        }

        public static string GenerateSessionToken(string username)
        {
            try
            {
                string currentTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                string expiryTime = DateTime.Now.AddHours(sessionHours).ToString("yyyy-MM-dd HH:mm:ss.fff");
                string token = Utilities.ConvertToBase64(username.ToLower() + currentTime + expiryTime);
                int response = Utilities.ExecuteNonQuery("insert into UserSessions(Username,SessionToken,SessionExpiryTime,LoggedInTime,LoggedOutTime) values('" + username + "','" + token + "','" + expiryTime + "','" + currentTime + "','" + currentTime + "')");
                if (response < 1)
                    return "";
                else
                    return Utilities.ConvertToBase64(username + ":" + Utilities.ConvertToBase64(currentTime) + ":" + Utilities.ConvertToBase64(expiryTime) + ":" + token);
            }
            catch
            {
                return "";
            }
        }

        public static PasswordScore CheckStrength(string password)
        {
            int score = 0;

            // using three requirements here:  min length and two types of characters (numbers and letters)
            bool blnMinLengthRequirementMet = false;
            bool blnRequirement1Met = false;
            bool blnRequirement2Met = false;

            // check for chars in password
            if (password.Length < 1)
                return PasswordScore.Blank;

            // if less than 6 chars, return as too short, else, plus one
            if (password.Length < 6)
            {
                return PasswordScore.TooShort;
            }
            else
            {
                score++;
                blnMinLengthRequirementMet = true;
            }

            // if 8 or more chars, plus one
            if (password.Length >= 8)
                score++;

            // if 10 or more chars, plus one
            if (password.Length >= 10)
                score++;

            // if password has a number, plus one
            if (Regex.IsMatch(password, @"[\d]", RegexOptions.ECMAScript))
            {
                score++;
                blnRequirement1Met = true;
            }

            // if password has lower case letter, plus one
            if (Regex.IsMatch(password, @"[a-z]", RegexOptions.ECMAScript))
            {
                score++;
                blnRequirement2Met = true;
            }

            // if password has upper case letter, plus one
            if (Regex.IsMatch(password, @"[A-Z]", RegexOptions.ECMAScript))
            {
                score++;
                blnRequirement2Met = true;
            }

            // if password has a special character, plus one
            if (Regex.IsMatch(password, @"[~`!@#$%\^\&\*\(\)\-_\+=\[\{\]\}\|\\;:'\""<\,>\.\?\/£]", RegexOptions.ECMAScript))
                score++;

            // if password is longer than 2 characters and has 3 repeating characters, minus one (to minimum of score of 3)
            List<char> lstPass = password.ToList();
            if (lstPass.Count >= 3)
            {
                for (int i = 2; i < lstPass.Count; i++)
                {
                    char charCurrent = lstPass[i];
                    if (charCurrent == lstPass[i - 1] && charCurrent == lstPass[i - 2] && score >= 4)
                    {
                        score++;
                    }
                }
            }

            if (!blnMinLengthRequirementMet || !blnRequirement1Met || !blnRequirement2Met)
            {
                return PasswordScore.RequirementsNotMet;
            }

            return (PasswordScore)score;
        }
    }
    public class ApplicationUserSummary
    {
        public ApplicationUserSummary() { }
        public long Id { get; set; }
        public string Username { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string EmailAddress { get; set; }
        public string MobileNumber { get; set; }
    }

    public class ApplicationUsers
    {
        public ApplicationUsers() { }

        public ApplicationUsers(string username)
        {
            //retrieve user details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Username,Passcode,FK_StakeholderId,FK_RoleGroup,Active,Locked,PasswordExpires,PasswordExpiryDate,PasswordLastChanged,Created,CreatedBy,LastModified,LastModifiedBy,FirstName,Surname,EmailAddress,MobileNumber from ApplicationUsers where Username='" + username + "'");
           while(reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Username = (reader.Reader["Username"].ToString());
                this.Passcode = (reader.Reader["Passcode"].ToString());
                this.FK_RoleGroup = (reader.Reader["FK_RoleGroup"].ToString());
                this.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                this.Active = reader.Reader.GetBoolean(5);
                this.Locked = reader.Reader.GetBoolean(6);
                this.PasswordExpires = reader.Reader.GetBoolean(7);
                this.PasswordExpiryDate = reader.Reader.GetDateTime(8);
                this.PasswordLastChanged = reader.Reader.GetDateTime(9);
                this.Created = reader.Reader.GetDateTime(10);
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = reader.Reader.GetDateTime(12);
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.FirstName = (reader.Reader["FirstName"].ToString());
                this.Surname = (reader.Reader["Surname"].ToString());
                this.MobileNumber = (reader.Reader["MobileNumber"].ToString());
                this.EmailAddress = (reader.Reader["EmailAddress"].ToString());
            }
            reader.Close();
        }

        public ApplicationUsers(long id)
        {
            //retrieve user details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Username,Passcode,FK_StakeholderId,FK_RoleGroup,Active,Locked,PasswordExpires,PasswordExpiryDate,PasswordLastChanged,Created,CreatedBy,LastModified,LastModifiedBy,FirstName,Surname,EmailAddress,MobileNumber from ApplicationUsers where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Username = (reader.Reader["Username"].ToString());
                this.Passcode = (reader.Reader["Passcode"].ToString());
                this.FK_RoleGroup = (reader.Reader["FK_RoleGroup"].ToString());
                this.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                this.Active = reader.Reader.GetBoolean(5);
                this.Locked = reader.Reader.GetBoolean(6);
                this.PasswordExpires = reader.Reader.GetBoolean(7);
                this.PasswordExpiryDate = reader.Reader.GetDateTime(8);
                this.PasswordLastChanged = reader.Reader.GetDateTime(9);
                this.Created = reader.Reader.GetDateTime(10);
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = reader.Reader.GetDateTime(12);
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.FirstName = (reader.Reader["FirstName"].ToString());
                this.Surname = (reader.Reader["Surname"].ToString());
                this.MobileNumber = (reader.Reader["MobileNumber"].ToString());
                this.EmailAddress = (reader.Reader["EmailAddress"].ToString());
            }
            reader.Close();
        }

        public ApplicationUsers(string username, string password,int fK_StakeholderId, string roleGroup,string firstName, string surname, string emailAddress, string mobileNumber, bool passwordExpires, bool active, bool locked)
        {
            //set new user details for saving database
            this.Username = username;
            this.FK_RoleGroup = roleGroup;
            this.PasswordExpires = passwordExpires;
            this.Passcode = Security.GeneratePasswordToken(username, password);
            this.FirstName = firstName;
            this.Surname = surname;
            this.EmailAddress = emailAddress;
            this.MobileNumber = mobileNumber;
            this.Locked = locked;
            this.Active = active;
            this.FK_StakeholderId = fK_StakeholderId;
        }

        public static bool UpdateUserDetails(string userName, string FirstName, string Surname, string EmailAddress, string MobileNumber)
        {
            int response = Utilities.ExecuteNonQuery("UPDATE ApplicationUsers set FirstName='" + FirstName + "', Surname='" + Surname + "', EmailAddress='" + EmailAddress + "', MobileNumber='" + MobileNumber + "' WHERE Username = '" + userName + "'");
            return ((response > 0) ? true : false);
        }

        public bool SaveUser()
        {
            int response = Utilities.ExecuteNonQuery("insert into ApplicationUsers(Username,Passcode,FK_StakeholderId,FK_RoleGroup,FirstName,Surname,EmailAddress,MobileNumber,Active,Locked,PasswordExpires,PasswordExpiryDate,PasswordLastChanged,Created,CreatedBy,LastModified,LastModifiedBy) values('" + this.Username + "','" + this.Passcode + "'," + FK_StakeholderId + ",'" + FK_RoleGroup + "','" + this.FirstName + "','" + this.Surname + "','" + this.EmailAddress + "','" + this.MobileNumber + "','" + ((this.Active) ? "True" : "False") + "','" + ((this.Locked) ? "True" : "False") + "','" + ((this.PasswordExpires) ? "True" : "False") + "','" + ((this.PasswordExpires) ? DateTime.Now.AddDays(Security.passwordExpiryDays).ToString("yyyy-MM-dd HH:mm:ss.fff") : DateTime.Now.AddYears(1000).ToString("yyyy-MM-dd HH:mm:ss.fff")) + "',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            if (response < 1)
                return false;
            else
                return true;
        }

        public bool UpdatePassword(string newPassword)
        {
            string userAuthToken = Security.GeneratePasswordToken(this.Username, newPassword);
            int response = Utilities.ExecuteNonQuery("update ApplicationUsers set Passcode='" + userAuthToken + "'" + ((this.PasswordExpires)? ",PasswordExpiryDate='" + DateTime.Now.AddDays(Security.passwordExpiryDays).ToString("yyyy-MM-dd HH:mm:ss.fff") + "'" : "") + ",PasswordLastChanged=CURRENT_TIMESTAMP where Username='" + this.Username + "'");
            return ((response > 0) ? true : false);
        }

        public bool DisableUser()
        {
            int response = Utilities.ExecuteNonQuery("update ApplicationUsers set Active='False' where Username='" + this.Username + "'");
            return ((response > 0) ? true : false);
        }

        public bool EnableUser()
        {
            int response = Utilities.ExecuteNonQuery("update ApplicationUsers set Active='True' where Username='" + this.Username + "'");
            return ((response > 0) ? true : false);
        }

        public bool LockUser()
        {
            int response = Utilities.ExecuteNonQuery("update ApplicationUsers set Locked='True' where Username='" + this.Username + "'");
            return ((response > 0) ? true : false);
        }

        public bool UnlockUser()
        {
            int response = Utilities.ExecuteNonQuery("update ApplicationUsers set Locked='False' where Username='" + this.Username + "'");
            return ((response > 0) ? true : false);
        }

        public bool ExpireUserPassword()
        {
            int response = Utilities.ExecuteNonQuery("update ApplicationUsers set PasswordExpires='True',PasswordExpiryDate='" + DateTime.Now.AddDays(Security.passwordExpiryDays).ToString("yyyy-MM-dd HH:mm:ss.fff") + "' where Username='" + this.Username + "'");
            return ((response > 0) ? true : false);
        }

        public bool NotExpireUserPassword()
        {
            int response = Utilities.ExecuteNonQuery("update ApplicationUsers set PasswordExpires='False',PasswordExpiryDate='" + DateTime.Now.AddDays(1000).ToString("yyyy-MM-dd HH:mm:ss.fff") + "' where Username='" + this.Username + "'");
            return ((response > 0) ? true : false);
        }

        public int Id { get; set; }
        public string Username { get; set; }
        public string Passcode { get; set; }
        public string FK_RoleGroup { get; set; }
        public int FK_StakeholderId { get; set; }
        public bool Active { get; set; }
        public bool Locked { get; set; }
        public bool PasswordExpires { get; set; }
        public DateTime PasswordExpiryDate { get; set; }
        public DateTime PasswordLastChanged { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }

        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string EmailAddress { get; set; }
        public string MobileNumber { get; set; }
    }

    public class UserSessions {

        public UserSessions() { }

        public UserSessions(string sessionToken)
        {
            //retrive user session details
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Username,SessionToken,SessionExpiryTime,LoggedInTime,LoggedOutTime from UserSessions where SessionToken='" + sessionToken + "'");
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Username = (reader.Reader["Username"].ToString());
                this.SessionToken=(reader.Reader["SessionToken"].ToString());
                this.SessionExpiryTime = reader.Reader.GetDateTime(3);
                this.LoggedInTime = reader.Reader.GetDateTime(4);
                this.LoggedOutTime = reader.Reader.GetDateTime(5);                
            }
            reader.Close();
        }
        
        public int Id { get; set; }
        public string Username { get; set; }
        public string SessionToken { get; set; }
        public DateTime SessionExpiryTime { get; set; }
        public DateTime LoggedInTime { get; set; }
        public DateTime LoggedOutTime { get; set; }

}

    public class ApplicationRoles
    {
        public ApplicationRoles() { }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }

    public class ApplicationUserAssignedRoles
    {
        public ApplicationUserAssignedRoles() { }

        public ApplicationUserAssignedRoles(string username, string userRole) {
            this.FK_RoleId = int.Parse(Utilities.ExecuteScalar("select Id from ApplicationRoles where Name='" + userRole + "'"));
            this.Username = username;
        }

        public bool AddRole()
        {
            int response = Utilities.ExecuteNonQuery("insert into ApplicationUserAssignedRoles values(" + this.FK_RoleId + ",'" + this.Username + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            return ((response > 0) ? true : false);
        }

        public bool RemoveRole()
        {
            int response = Utilities.ExecuteNonQuery("delete from ApplicationUserAssignedRoles where FK_RoleId=" + this.FK_RoleId + " and Username='" + this.Username + "'");
            return ((response > 0) ? true : false);
        }

        public int FK_RoleId { get; set; }
        public string Username { get; set; }
    }

    public class ApplicationRoleGroups
    {
        public ApplicationRoleGroups() { }

        public ApplicationRoleGroups(string group, string description) {
            this.Name = group;
            this.Description = description;
        }

        public bool SaveGroup()
        {
            int response = Utilities.ExecuteNonQuery("insert into ApplicationRoleGroups(FK_ParentId,Name,Description,Active,Created,CreatedBy,LastModified,LastModifiedBy) values(0,'" + this.Name + "','" + this.Description + "','True',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            if (response < 1)
                return false;
            else
                return true;
        }

        public static bool GroupIsModified(long roleGroupId)
        {
            int response = Utilities.ExecuteNonQuery("update ApplicationRoleGroups set LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + roleGroupId);
            if (response < 1)
                return false;
            else
                return true;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }

    public class ApplicationRoleGroupAssignedRoles
    {
        public ApplicationRoleGroupAssignedRoles() { }

        public ApplicationRoleGroupAssignedRoles(string username, string userRole)
        {
            this.FK_RoleGroupId = int.Parse(Utilities.ExecuteScalar("select Id from ApplicationRoleGroups where Name='" + userRole + "'"));
            this.Username = username;
        }

        public bool AddRole()
        {
            int response = Utilities.ExecuteNonQuery("insert into ApplicationRoleGroupAssignedRoles values(" + this.FK_RoleGroupId + ",'" + this.Username + "',CURRENT_TIMESTAMP,'" + Security.actingUser +"')");
            bool done = ((response > 0) ? true : false);
            if (done)
                ApplicationRoleGroups.GroupIsModified(this.FK_RoleGroupId);
            return done;
        }

        public bool RemoveRole()
        {
            int response = Utilities.ExecuteNonQuery("delete from ApplicationRoleGroupAssignedRoles where FK_RoleGroupId=" + this.FK_RoleGroupId + " and Username='" + this.Username + "'");
            bool done = ((response > 0) ? true : false);
            if (done)
                ApplicationRoleGroups.GroupIsModified(this.FK_RoleGroupId);
            return done;
        }

        public int FK_RoleGroupId { get; set; }
        public string Username { get; set; }
    }

    public class ApplicationUserAssingedRoleGroups
    {
        public ApplicationUserAssingedRoleGroups() { }

        public ApplicationUserAssingedRoleGroups(string group, string userRole)
        {
            this.FK_RoleId = int.Parse(Utilities.ExecuteScalar("select Id from ApplicationRoles where Name='" + userRole + "'"));
            this.FK_RoleGroup = group;
        }

        public bool AddRole()
        {
            int response = Utilities.ExecuteNonQuery("insert into ApplicationUserAssingedRoleGroups values(" + this.FK_RoleId + ",'" + this.FK_RoleGroup + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            return ((response > 0) ? true : false);
        }

        public bool RemoveRole()
        {
            int response = Utilities.ExecuteNonQuery("delete from ApplicationUserAssingedRoleGroups where FK_RoleId=" + this.FK_RoleId + " and FK_RoleGroup='" + this.FK_RoleGroup + "'");
            return ((response > 0) ? true : false);
        }

        public int FK_RoleId { get; set; }
        public string FK_RoleGroup { get; set; }
    }

    public class AuthenticationResponse
    {
        public string username { get; set; }
        public string accessToken { get; set; }
        public bool authenticationStatus { get; set; }
        public int responseCode { get; set; }
        public string responseMessage { get; set; }
    }

    public class SignoutResponse
    {
        public bool signoutStatus { get; set; }
    }

    public class PasswordChangeResponse
    {
        public bool changeStatus { get; set; }
        public string responseMessage { get; set; }
    }

    public class UserRoleActionResponse
    {
        public bool actionStatus { get; set; }
        public string responseMessage { get; set; }
    }

    public class UserActionResponse
    {
        public bool actionStatus { get; set; }
        public string responseMessage { get; set; }
    }

    public enum PasswordScore
    {
        Blank = 0,
        TooShort = 1,
        RequirementsNotMet = 2,
        VeryWeak = 3,
        Weak = 4,
        Fair = 5,
        Medium = 6,
        Strong = 7,
        VeryStrong = 8
    }

    public class SystemAuthorizationManager : ServiceAuthorizationManager
    {
        protected override bool CheckAccessCore(OperationContext operationContext)
        {
            //Extract the Authorization header, and parse out the credentials converting the Base64 string:  
            var authHeader = WebOperationContext.Current.IncomingRequest.Headers["Authorization"];
            if ((authHeader != null) && (authHeader != string.Empty))
            {
                var svcCredentials = System.Text.ASCIIEncoding.ASCII
                    .GetString(Convert.FromBase64String(authHeader.Substring(0)))
                    .Split(':');
                var user = new
                {
                    Name = svcCredentials[0],
                    Time = svcCredentials[1],
                    ExpiryTime = svcCredentials[2],
                    Token = svcCredentials[3]
                };
                UserSessions userSession = new UserSessions(user.Token);
                if (userSession.Username.ToLower() == user.Name.ToLower())
                {
                    if (userSession.LoggedOutTime > userSession.LoggedInTime)
                        return false;
                    else if (userSession.SessionExpiryTime < DateTime.Now)
                        return false;
                    else
                    {
                        //User is authorized and originating call will proceed  
                        Security.actingUser = user.Name;
                        return true;
                    }
                }
                else
                {
                    //not authorized  
                    return false;
                }
            }
            else
            {
                //No authorization header was provided, so challenge the client to provide before proceeding:  
                WebOperationContext.Current.OutgoingResponse.Headers.Add("WWW-Authenticate: Basic realm=\"SEnPA\"");
                //Throw an exception with the associated HTTP status code equivalent to HTTP status 401  
                throw new WebFaultException(HttpStatusCode.Unauthorized);
            }
        }
    }

    public class AccessAuthorizationManager : ServiceAuthorizationManager
    {
        protected override bool CheckAccessCore(OperationContext operationContext)
        {
            //Extract the Authorization header, and parse out the credentials converting the Base64 string:  
            var authHeader = WebOperationContext.Current.IncomingRequest.Headers["Authorization"];
            if ((authHeader != null) && (authHeader != string.Empty))
            {
                var svcCredentials = System.Text.ASCIIEncoding.ASCII
                    .GetString(Convert.FromBase64String(authHeader.Substring(6)))
                    .Split(':');
                var user = new
                {
                    Name = svcCredentials[0],
                    Password = svcCredentials[1]
                };

                string userDbToken = Utilities.ExecuteScalar("select PasswordKey from AuthorizationUsers where AuthorizationName='" + user.Name + "' and IsEnabled='True'");
                string userAuthToken = Utilities.ConvertToBase64(user.Name + ":" + user.Password);
                
                if ((userAuthToken == userDbToken))
                {
                    //User is authorized and originating call will proceed  
                    return true;
                }
                else
                {
                    //not authorized  
                    return false;
                }
            }
            else
            {
                //No authorization header was provided, so challenge the client to provide before proceeding:  
                WebOperationContext.Current.OutgoingResponse.Headers.Add("WWW-Authenticate: Basic realm=\"SEnPA\"");
                //Throw an exception with the associated HTTP status code equivalent to HTTP status 401  
                throw new WebFaultException(HttpStatusCode.Unauthorized);
            }
        }        
    }
}