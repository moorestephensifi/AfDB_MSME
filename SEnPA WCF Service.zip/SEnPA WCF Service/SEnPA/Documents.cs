﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace SEnPA
{
    public partial class Utilities
    {       
        public static string GetDocumentTypeName(long Id)
        {
            return Utilities.ExecuteScalar("select Name from DocumentTypes where Id=" + Id);
        }

        public static long UploadWorkFlowDocument(long Id, string entityType, string fileName, byte[] fileData, int documentTypeId, long documentFolderId, bool businessAssesment)
        {
            documentFolderId = 3;
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
            string ext = Path.GetExtension(fileName);
            string contenttype = String.Empty;

            //Set the contenttype based on File Extension
            switch (ext.ToLower())
            {
                case ".doc":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype = "image/jpg";
                    break;
                case ".png":
                    contenttype = "image/png";
                    break;
                case ".gif":
                    contenttype = "image/gif";
                    break;
                case ".pdf":
                    contenttype = "application/pdf";
                    break;
            }

            if (contenttype != String.Empty)
            {
                try
                {
                    string strQuery = "insert into DocumentLibrary(FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,BusinessAssesment,Created,CreatedBy,LastModified,LastModifiedBy) values(" + documentFolderId + "," + documentTypeId + ",'" + fileName + "'," + "0x" + BitConverter.ToString(fileData).Replace("-", "") + ",'" + contenttype + "'," + Id + "," + wrkDoc.Id + "," + wrkStage.Id + ",'" + ((businessAssesment)?"True":"False") + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')";
                    long y = Utilities.ExecuteNewRecord(strQuery);
                    return ((y > 0) ? y : 0);
                }
                catch (Exception ex)
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }

        }

        //get document list for a workflow, without the actual document
        public static List<DocumentLibrary> GetWorkFlowDocuments(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
            List<DocumentLibrary> response = new List<DocumentLibrary>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,BusinessAssesment,Created,CreatedBy,LastModified,LastModifiedBy from DocumentLibrary where FK_DocumentId=" + Id + " and FK_WorkFlowStageId=" + wrkDoc.Id);
            while (reader.Reader.Read())
            {
                DocumentLibrary doc = new DocumentLibrary();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.FK_DocumentFolderId = int.Parse(reader.Reader["FK_DocumentFolderId"].ToString());
                doc.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                doc.DocumentName = (reader.Reader["DocumentName"].ToString());
                doc.DocumentContentType = (reader.Reader["DocumentContentType"].ToString());
                doc.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                doc.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                doc.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                doc.BusinessAssesment = bool.Parse(reader.Reader["BusinessAssesment"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();

            return response;

        }

        public static bool UploadDocument(long Id, string fileName, byte[] fileData, int documentTypeId, long documentFolderId)
        {

            string ext = Path.GetExtension(fileName);
            string contenttype = String.Empty;

            //Set the contenttype based on File Extension
            switch (ext.ToLower())
            {
                case ".doc":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".docx":
                    contenttype = "application/vnd.ms-word";
                    break;
                case ".xls":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".xlsx":
                    contenttype = "application/vnd.ms-excel";
                    break;
                case ".jpg":
                    contenttype = "image/jpg";
                    break;
                case ".png":
                    contenttype = "image/png";
                    break;
                case ".gif":
                    contenttype = "image/gif";
                    break;
                case ".pdf":
                    contenttype = "application/pdf";
                    break;
            }

            if (contenttype != String.Empty)
            {
                try
                {
                    string strQuery = "insert into DocumentLibrary(FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,BusinessAssesment,Created,CreatedBy,LastModified,LastModifiedBy) values(" + documentFolderId + "," + documentTypeId + ",'" + fileName + "'," + "0x" + BitConverter.ToString(fileData).Replace("-", "") + ",'" + contenttype + "'," + Id + ",0,0,'False',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')";

                    int y = Utilities.ExecuteNonQuery(strQuery);
                    return ((y > 0) ? true : false);
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

        }

        //get document list of documents without the actual document
        public static List<DocumentLibrary> GetDocuments(long Id)
        {
            List<DocumentLibrary> response = new List<DocumentLibrary>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,BusinessAssesment,Created,CreatedBy,LastModified,LastModifiedBy from DocumentLibrary where DocumentId=" + Id);
            while (reader.Reader.Read())
            {
                DocumentLibrary doc = new DocumentLibrary();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.FK_DocumentFolderId = int.Parse(reader.Reader["FK_DocumentFolderId"].ToString());
                doc.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                doc.DocumentName = (reader.Reader["DocumentName"].ToString());
                doc.DocumentContentType = (reader.Reader["DocumentContentType"].ToString());
                doc.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                doc.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                doc.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                doc.BusinessAssesment = bool.Parse(reader.Reader["BusinessAssesment"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();

            return response;

        }

        //get document list of documents without the actual document
        public static List<DocumentLibrary> GetDocuments(long Id, string filterText)
        {
            List<DocumentLibrary> response = new List<DocumentLibrary>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,BusinessAssesment,Created,CreatedBy,LastModified,LastModifiedBy from DocumentLibrary where ((DocumentName like '%" + filterText + "%') or (DocumentTypeId in (select Id from DocumentTypes where Name like '%" + filterText + "%' or Description like '%" + filterText + "%'))) and DocumentFolderId in (select Id from DocumentFolders where ParentId=" + Id + " or Id=" + Id + ")");
            while (reader.Reader.Read())
            {
                DocumentLibrary doc = new DocumentLibrary();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.FK_DocumentFolderId = int.Parse(reader.Reader["FK_DocumentFolderId"].ToString());
                doc.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                doc.DocumentName = (reader.Reader["DocumentName"].ToString());
                doc.DocumentContentType = (reader.Reader["DocumentContentType"].ToString());
                doc.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                doc.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                doc.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                doc.BusinessAssesment = bool.Parse(reader.Reader["BusinessAssesment"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();

            return response;

        }

        //get registration document list of documents without the actual document
        public static List<DocumentLibrary> GetRegistrationDocuments(long Id,string filterText)
        {
            List<DocumentLibrary> response = new List<DocumentLibrary>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,BusinessAssesment,Created,CreatedBy,LastModified,LastModifiedBy from DocumentLibrary where DocumentName like '%" + filterText + "%' and FK_DocumentFolderId=3 and FK_DocumentTypeId=" + Id);
            while (reader.Reader.Read())
            {
                DocumentLibrary doc = new DocumentLibrary();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.FK_DocumentFolderId = int.Parse(reader.Reader["FK_DocumentFolderId"].ToString());
                doc.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                doc.DocumentName = (reader.Reader["DocumentName"].ToString());
                doc.DocumentContentType = (reader.Reader["DocumentContentType"].ToString());
                doc.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                doc.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                doc.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                doc.BusinessAssesment = bool.Parse(reader.Reader["BusinessAssesment"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();

            return response;

        }

        //get document list of documents without the actual document
        public static List<DocumentTypes> GetDocumentTypes()
        {
            List<DocumentTypes> response = new List<DocumentTypes>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Name,Description, Created,CreatedBy,LastModified,LastModifiedBy from DocumentTypes");
            while (reader.Reader.Read())
            {
                DocumentTypes doc = new DocumentTypes();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.Name =(reader.Reader["Name"].ToString());
                doc.Description = (reader.Reader["Description"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();
            return response;

        }

        //get document list of documents without the actual document
        public static List<DocumentLibrary> GetFolderDocuments(long Id)
        {
            List<DocumentLibrary> response = new List<DocumentLibrary>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,Created,CreatedBy,LastModified,LastModifiedBy from DocumentLibrary where FK_DocumentFolderId=" + Id);
            while (reader.Reader.Read())
            {
                DocumentLibrary doc = new DocumentLibrary();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.FK_DocumentFolderId = int.Parse(reader.Reader["FK_DocumentFolderId"].ToString());
                doc.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                doc.DocumentName = (reader.Reader["DocumentName"].ToString());
                doc.DocumentContentType = (reader.Reader["DocumentContentType"].ToString());
                doc.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                doc.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                doc.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();
            return response;

        }

        
        //get registration document list of documents without the actual document
        public static List<DocumentLibrary> GetRegistrationsFolderDocuments(long Id)
        {
            List<DocumentLibrary> response = new List<DocumentLibrary>();
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,Created,CreatedBy,LastModified,LastModifiedBy from DocumentLibrary where FK_DocumentFolderId=3 and FK_DocumentTypeId=" + Id);
            while (reader.Reader.Read())
            {
                DocumentLibrary doc = new DocumentLibrary();
                doc.Id = long.Parse(reader.Reader["Id"].ToString());
                doc.FK_DocumentFolderId = int.Parse(reader.Reader["FK_DocumentFolderId"].ToString());
                doc.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                doc.DocumentName = (reader.Reader["DocumentName"].ToString());
                doc.DocumentContentType = (reader.Reader["DocumentContentType"].ToString());
                doc.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                doc.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                doc.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                doc.Created = DateTime.Now;
                doc.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                doc.LastModified = DateTime.Now;
                doc.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(doc);
            }
            reader.Close();
            return response;

        }

        //get actual file
        public static DocumentLibrary GetDocument(long Id)
        {
            DocumentLibrary doc = new DocumentLibrary(Id);
            return doc;

        }

        //get folder list
        public static List<DocumentFolders> GetFolders(long parentId)
        {
            List<DocumentFolders> response = new List<DocumentFolders>();
            //retrieve documents folder from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FolderName,ParentId,Created,CreatedBy,LastModified,LastModifiedBy from DocumentFolders where ParentId=" + parentId);
            while (reader.Reader.Read())
            {
                DocumentFolders folder = new DocumentFolders();
                folder.Id = long.Parse(reader.Reader["Id"].ToString());
                folder.FolderName = (reader.Reader["FolderName"].ToString());
                folder.ParentId = int.Parse(reader.Reader["ParentId"].ToString());
                folder.Created = DateTime.Parse(reader.Reader["Created"].ToString());
                folder.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                folder.LastModified = DateTime.Parse(reader.Reader["LastModified"].ToString());
                folder.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                response.Add(folder);
            }
            reader.Close();
            return response;
        }

        //get folder name
        public static string GetFolderName(long Id)
        {
            DocumentFolders folder = new DocumentFolders(Id);
            return folder.FolderName;
        }

        //get folder path
        public static string GetFolderPath(long Id)
        {
            DocumentFolders folder = new DocumentFolders(Id);
            string response = folder.FolderName;
            long parentId = folder.ParentId;
            //terminator counter
            int terminator = 50;
            while (parentId != 0 && terminator > 0)
            {
                DocumentFolders outerFolder = new DocumentFolders(parentId);
                response = outerFolder.FolderName + "," + response;
                parentId = outerFolder.ParentId;
                terminator--;
            }
            return response;
        }

        //create new folder
        public static long CreateFolder(string folderName, long parentId)
        {
            DocumentFolders newFolder = new DocumentFolders(folderName, parentId);
            return newFolder.Create();
        }

        //rename folder
        public static bool RenameFolder(long Id, string newName)
        {
            DocumentFolders newFolder = new DocumentFolders(Id);
            return newFolder.Rename(newName);
        }

        //get parent folder
        public static long GetParentFolderId(long Id)
        {
            DocumentFolders folder = new DocumentFolders(Id);
            return folder.ParentId;
        }

        public static Byte[] PdfSharpConvert(String html)
        {
            Byte[] res = null;
            using (MemoryStream ms = new MemoryStream())
            {
                var pdf = TheArtOfDev.HtmlRenderer.PdfSharp.PdfGenerator.GeneratePdf(html, PdfSharp.PageSize.A4);
                pdf.Save(ms);
                res = ms.ToArray();
            }
            return res;
        }
    }

    public class DocumentLibrary
    {
        public DocumentLibrary() { }
        public DocumentLibrary(long Id)
        {
            //retrieve documents details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FK_DocumentFolderId,FK_DocumentTypeId,DocumentName,DocumentData,DocumentContentType,FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,BusinessAssesment,Created,CreatedBy,LastModified,LastModifiedBy from DocumentLibrary where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_DocumentFolderId = int.Parse(reader.Reader["FK_DocumentFolderId"].ToString());
                this.FK_DocumentTypeId = int.Parse(reader.Reader["FK_DocumentTypeId"].ToString());
                this.DocumentName = (reader.Reader["DocumentName"].ToString());
                this.DocumentData = (byte[])(reader.Reader.GetValue(4));
                this.DocumentContentType = (reader.Reader["DocumentContentType"].ToString());
                this.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                this.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                this.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                this.BusinessAssesment = bool.Parse(reader.Reader["BusinessAssesment"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public long Id { get; set; }
        public long FK_DocumentFolderId { get; set; }
        public int FK_DocumentTypeId { get; set; }
        public string DocumentName { get; set; }
        public byte[] DocumentData { get; set; }
        public string DocumentContentType { get; set; }
        public long FK_DocumentId { get; set; }
        public long FK_DocumentWorkFlowId { get; set; }
        public long FK_WorkFlowStageId { get; set; }
        public bool BusinessAssesment { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class DocumentFolders
    {
        public DocumentFolders() { }

        public DocumentFolders(string folderName, long parentId) {
            this.FolderName = folderName;
            this.ParentId = parentId;
        }

        public DocumentFolders(long Id)
        {
            //retrieve documents folder from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,FolderName,ParentId,Created,CreatedBy,LastModified,LastModifiedBy from DocumentFolders where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FolderName = (reader.Reader["FolderName"].ToString());
                this.ParentId = int.Parse(reader.Reader["ParentId"].ToString());               
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
            }
            reader.Close();
        }

        public long Create()
        {
            this.Id = Utilities.ExecuteNewRecord("insert into DocumentFolders(FolderName,ParentId,Created,CreatedBy,LastModified,LastModifiedBy) values('"+this.FolderName+"',"+this.ParentId+ ",CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            return this.Id;
        }

        public bool Rename(string newName)
        {
            this.FolderName = newName;
            this.Id = Utilities.ExecuteNonQuery("update DocumentFolders set FolderName='" + this.FolderName + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id );
            if (this.Id > 0) return true;
            else return false;
        }

        public long Id { get; set; }
        public string FolderName { get; set; }
        public long ParentId { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }

    }

    public class DocumentTypes
    {
        public DocumentTypes() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
}