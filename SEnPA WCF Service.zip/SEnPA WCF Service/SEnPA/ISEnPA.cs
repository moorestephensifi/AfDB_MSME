﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SEnPA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ISEnPA" in both code and config file together.
    [ServiceContract]
    public interface ISEnPA
    {
        #region messaging
        [OperationContract]
        bool SendBasicEmail(string to, string subject, string message);

        [OperationContract]
        bool SendSMS(string to, string message);

        [OperationContract]
        List<Email> GetEmails(string filterText);

        [OperationContract]
        List<SMS> GetSMSs(string filterText);

        [OperationContract]
        bool ClearEmails();

        [OperationContract]
        bool ClearSMSs();

        [OperationContract]
        List<EmailMessageDesign> GetEmailMessageDesigns();

        [OperationContract]
        EmailMessageDesign GetEmailMessageDesign(string design);

        #endregion

        #region workflow
        [OperationContract]
        DocumentWorkflow SubmitWorkFlowDocument(long workFlowId, string documentId, string documentType);
        
        [OperationContract]
        string GetNextWorkFlowStage(long Id, string entityType);

        [OperationContract]
        string GetCurrentWorkFlowStage(long Id, string entityType);

        [OperationContract]
        DocumentWorkflow UpdateWorkFlowStage(long Id, string entityType);

        [OperationContract]
        bool AssignWorkFlowStage(string username, long Id, string entityType);

        [OperationContract]
        List<ApplicationUserSummary> GetAssigningUserList(long Id, string entityType);

        [OperationContract]
        List<WorkFlowStageDocuments> GetDocumentsRequiredList(long Id, string entityType);

        [OperationContract]
        string CheckCurrentStageDocumentRequirements(long Id, string entityType);

        [OperationContract]
        bool CheckCurrentStagePaymentRequirements(long Id, string entityType);

        [OperationContract]
        string CheckCurrentStageSiteVisitRequirements(long Id, string entityType);

        [OperationContract]
        string CheckCurrentStageRecommandationSiteVisitRequirements(long Id, string entityType, long recommendationId, int stakeholderId);

        [OperationContract]
        string CheckCurrentStageRecommendationsRequirements(long Id, string entityType);

        [OperationContract]
        bool UploadWorkFlowDocument(long Id, string entityType, string fileName, byte[] fileData, int documentTypeId, long documentFolderId, bool businessAssesment);

        [OperationContract]
        List<DocumentLibrary> GetWorkFlowDocuments(long Id, string entityType);

        [OperationContract]
        WorkFlows GetWorkFlow(long Id);

        [OperationContract]
        bool UpdateWorkFlow(WorkFlows wrkFlow);

        [OperationContract]
        long CreateWorkFlow(string workFlowName, string workFlowDescription, long startRoleGroupId, long endRoleGroupId);

        [OperationContract]
        List<WorkFlows> GetWorkFlows();

        [OperationContract]
        WorkFlowStages GetWorkFlowStage(long Id);

        [OperationContract]
        WorkFlowStages GetDocumentWorkFlowStage(long Id, string entityType);

        [OperationContract]
        bool UpdateWorkFlowStageRecord(WorkFlowStages wrkFlow);

        [OperationContract]
        long CreateWorkFlowStage(long workFlowId, int stagePosition, string stageName, string stageDescription, long roleGroupId, int stageAssignMode, bool stageOptional, bool requireDocuments, bool requirePayment, bool requireSiteVisit, bool requireRecommendations, string fK_AutoDocumentName, int sendEmail, int sendSMS);

        [OperationContract]
        List<WorkFlowStages> GetWorkFlowStages(long Id);

        [OperationContract]
        WorkFlowStageDocuments GetWorkFlowStageDocument(long Id);

        [OperationContract]
        bool UpdateWorkFlowStageDocument(WorkFlowStageDocuments wrkFlow);

        [OperationContract]
        bool CreateWorkFlowStageDocument(long stageId, int documentTypeId, bool documentRequired);

        [OperationContract]
        List<WorkFlowStageDocuments> GetWorkFlowStageDocuments(long Id);

        [OperationContract]
        List<DocumentWorkFlowProgress> GetWorkFlowProgress(long Id);

        [OperationContract]
        List<WorkFlowStageDocumentStatus> GetDocumentsRequiredStatus(long Id, string entityType);

        [OperationContract]
        bool CheckAccessToStage(long Id, string entityType);

        [OperationContract]
        List<WorkFlowStageDocumentStatus> GetAllRequiredDocuments(long Id, string entityType);

        [OperationContract]
        List<WorkFlowFieldValidations> GetValidationsList(string docType);

        [OperationContract]
        List<FeeRules> GetFeeRulesList(string docType);

        [OperationContract]
        bool SkipOptionalStage(long Id, string entityType);

        [OperationContract]
        bool ReverseStage(long Id, string entityType);

        [OperationContract]
        List<WorkFlowStagesAutoDocuments> GetWorkFlowStagesAutoDocuments(long Id);

        [OperationContract]
        long CreateWorkFlowStagesAutoDocument(long workFlowStageId, string fK_AutoDocumentName, int sendEmail, int sendSMS, bool active);

        [OperationContract]
        WorkFlowStagesAutoDocuments GetWorkFlowStagesAutoDocument(long Id);

        [OperationContract]
        bool SwitchStages(long IdUp, long IdDown);

        [OperationContract]
        bool DeleteStage(long workId, long delId);
        #endregion

        #region documents
        [OperationContract]
        bool UploadDocument(long Id, string fileName, byte[] fileData, int documentTypeId, long documentFolderId);

        [OperationContract]
        List<DocumentLibrary> GetDocuments(long Id);

        [OperationContract]
        List<DocumentLibrary> GetFolderDocuments(long Id);

        [OperationContract]
        List<DocumentLibrary> GetRegistrationsFolderDocuments(long Id);

        [OperationContract]
        DocumentLibrary GetDocument(long Id);

        [OperationContract]
        List<DocumentFolders> GetFolders(long parentId);

        [OperationContract]
        long CreateFolder(string folderName, long parentId);

        [OperationContract]
        bool RenameFolder(long Id, string newName);

        [OperationContract]
        List<DocumentTypes> GetDocumentTypes();

        [OperationContract]
        List<DocumentLibrary> SearchDocuments(long Id, string filterText);

        [OperationContract]
        List<DocumentLibrary> SearchRegistrationDocuments(long Id,string filterText);

        [OperationContract]
        string GetFolderName(long Id);

        [OperationContract]
        string GetFolderPath(long Id);

        [OperationContract]
        long GetParentFolderId(long Id);


        #endregion

        #region senpa
        [OperationContract]
        long SaveRegistrationRequest(RegistrationRequest registration);               

        [OperationContract]
        List<RegistrationRequest> GetRegistrationRequests(string filterText);

        [OperationContract]
        RegistrationRequest GetRegistrationRequest(long Id);

        [OperationContract]
        long RegisterBusiness(long registrationRequestId);

        [OperationContract]
        List<BusinessRegistration> GetBusinessRegistrations(string filterText);

        [OperationContract]
        BusinessRegistration GetBusinessRegistration(long Id, bool regNo);

        [OperationContract]
        long SaveRenewalRequest(RenewalRequest registration);

        [OperationContract]
        List<RenewalRequest> GetRenewalRequests(string filterText);

        [OperationContract]
        RenewalRequest GetRenewalRequest(long Id);

        [OperationContract]
        long GetCurrentRenewalID(long Id);

        [OperationContract]
        List<AutoDocument> CheckAutoDocument(long Id, string entityType);

        [OperationContract]
        Byte[] GetAutoDocument(string docType, long Id);

        [OperationContract]
        int CheckCertificate(long Id);

        [OperationContract]
        bool IssueCertificate(long Id, long renewalId);

        [OperationContract]
        CottageCertificate GetCertificateDetails(long Id);

        [OperationContract]
        long LastRenewalId(long Id);

        [OperationContract]
        bool SetRenewal(long Id);

        [OperationContract]
        List<CottageCertificate> GetCertificates(string filterText);

        [OperationContract]
        bool UpdatePeriod(long id, DateTime lastRenewalDate, DateTime nextRenewalDate);

        [OperationContract]
        List<AutoDocument> CheckTrainingAutoDocument(long Id, string entityType);

        [OperationContract]
        List<ActiveRenewalRequest> GetActiveBusinessRenewals(string filterText);

        [OperationContract]
        QuickStats GetQuickStats();

        [OperationContract]
        List<Notifications> CheckNotifications(string filterText,bool pending);

        [OperationContract]
        bool UpdateNotifications(long Id, bool status);
        #endregion

        #region Administration
        [OperationContract]
        List<PickList> GetPickList(string type);

        [OperationContract]
        List<PickList> GetChildPickList(string type, int parentId);

        [OperationContract]
        List<PickList> GetUserPickList(string groupType);

        [OperationContract]
        string GetEntityName(long Id, string type);

        [OperationContract]
        string GetDocumentTypeName(long Id);

        [OperationContract]
        List<ReferenceTable> GetReferenceTableItems(string type);

        [OperationContract]
        bool SaveReferenceTable(string name, string description, bool active, string type, int fK_ParentId);

        [OperationContract]
        ReferenceTable GetReferenceTableItem(long Id, string type);

        [OperationContract]
        ReferenceTable GetReferenceTableItemByName(string name, string type);

        [OperationContract]
        List<Stakeholder> GetStakeholders();

        [OperationContract]
        long SaveStakeholder(string name, string description, string mobile, string email, bool active);

        [OperationContract]
        Stakeholder GetStakeholder(long Id);

        [OperationContract]
        List<Stakeholder> GetBusinessTypeStakeholders(int businessTypeId);

        [OperationContract]
        bool SaveBusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId, bool stakeholderRequired);

        [OperationContract]
        BusinessTypeStakeholder GetBusinessTypeStakeholder(long Id);

        [OperationContract]
        List<ReferenceTable> GetStakeholderBusinessTypes(int stakeholderId);

        [OperationContract]
        bool RemoveBusinessTypeStakeholder(int fK_BusinessTypeId, int fK_StakeholderId);

        [OperationContract]
        AutoDocumentsDesign GetAutoDocumentsDesign(string name);

        [OperationContract]
        List<AutoDocumentsDesign> GetAutoDocumentsDesigns();

        [OperationContract]
        bool SaveAutoDocumentsDesign(string documentName, string documentDesignSMS, string documentDesign, string emailSubject,bool sms,bool email);

        [OperationContract]
        WorkFlowFieldValidations GetValidation(long Id);

        [OperationContract]
        long SaveValidation(long id, string documentType, string parameterField, string parameterDataType, string parameterFieldName, string parameterValue, string parameterMaxValue, string parameterEvaluationType, bool active);

        [OperationContract]
        FeeRules GetFeeRule(long Id);

        [OperationContract]
        long SaveFeeRule(int id, string ruleName, string ruleType, string ruleField, string ruleExecutionType, string ruleExecutionValue, string ruleEvaluationField, string ruleEvaluationDataType, string ruleEvaluationType, string ruleEvaluationValue, string ruleEvaluationMaxValue, bool active);

        #endregion

        #region security
        [OperationContract]
        SignoutResponse Signout(string username);

        [OperationContract]
        PasswordChangeResponse ChangePassword(string username, string oldPassword, string newPassword);

        [OperationContract]
        UserRoleActionResponse AddRole(string username, string userRole);

        [OperationContract]
        UserRoleActionResponse RemoveRole(string username, string userRole);

        [OperationContract]
        UserActionResponse AddUser(string username, string password,int stakeholderId, string roleGroup, string firstName, string surname, string emailAddress, string mobileNumber, bool passwordExpires, bool active, bool locked);

        [OperationContract]
        UserActionResponse UpdateUser(string username, string action);

        [OperationContract]
        List<ApplicationUsers> GetUsers(string filterText);

        [OperationContract]
        ApplicationUsers GetUser(string username);

        [OperationContract]
        List<ApplicationRoles> GetApplicationRoles(string username);

        [OperationContract]
        UserRoleActionResponse AddGroupRole(string username, string userRole);

        [OperationContract]
        UserRoleActionResponse RemoveGroupRole(string username, string userRole);

        [OperationContract]
        List<ApplicationRoleGroups> GetApplicationGroupRoles(string username);

        [OperationContract]
        UserRoleActionResponse AddUserGroup(string group, string description);

        [OperationContract]
        List<ApplicationRoles> GetApplicationUserGroupRoles(string group);

        [OperationContract]
        UserRoleActionResponse AddUserGroupRole(string group, string userRole);

        [OperationContract]
        UserRoleActionResponse RemoveUserGroupRole(string group, string userRole);

        [OperationContract]
        string DefaultPassword();
        #endregion

        #region site visit
        [OperationContract]
        List<SiteVisitReport> GetSiteVisitReports(long siteVisitId);

        [OperationContract]
        long SaveSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId,string comments);

        [OperationContract]
        SiteVisitReport GetSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId);

        [OperationContract]
        bool RemoveSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId);

        [OperationContract]
        bool ConfirmSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId);
        
        [OperationContract]
        long CreateWorkflowSiteVisit(long Id, string entityType);

        [OperationContract]
        long CreateWorkflowRecommendationSiteVisit(long Id, string entityType, long recommendationId);

        [OperationContract]
        SiteVisit GetCurrentWorkflowSiteVisit(long Id, string entityType);

        [OperationContract]
        SiteVisit GetCurrentWorkflowRecommendationSiteVisit(long recommendationId, long Id, string entityType);

        [OperationContract]
        bool UploadSiteVisitWorkFlowDocument(long siteVisitId, int stakeholderId,string comments, long Id, string entityType, string fileName, byte[] fileData, int documentTypeId, long documentFolderId);

        [OperationContract]
        bool SaveSiteVisit(SiteVisit site);

        [OperationContract]
        bool ScheduleSiteVisit(SiteVisit site);

        [OperationContract]
        bool NotifySiteVisit(long Id);

        [OperationContract]
        bool ConfirmSiteVisit(long Id);

        #endregion

        #region invoices
        [OperationContract]
        List<Invoice> GetInvoices(string filterText);

        [OperationContract]
        Invoice GetInvoice(long Id);

        [OperationContract]
        string PayInvoice(long Id, string currency, float amount, float change, int fK_PayBranchId, int fK_PaymentMethodId);

        [OperationContract]
        List<InvoiceItem> GetInvoiceItems(long Id);
        #endregion

        #region recommendations
        [OperationContract]
        List<RecommendedAction> GetRecommendedActions(long fK_RecommendationId);

        [OperationContract]
        long SaveRecommendedAction(long fK_RecommendationId, int fK_StakeholderId, int fK_ActionId, string details, bool reminder, string status, string statusReason, bool active);

        [OperationContract]
        RecommendedAction GetRecommendedAction(long fK_RecommendationId, int fK_StakeholderId);

        [OperationContract]
        long CreateWorkflowRecommendations(long Id, string entityType);

        [OperationContract]
        Recommendations GetCurrentWorkflowRecommendations(long Id, string entityType);
        #endregion

        #region national residence
        [OperationContract]
        Resident GetResident(string nIN);

        [OperationContract]
        Business GetBusiness(string bRN);
        #endregion

        #region training
        [OperationContract]
        List<TrainingSessionReport> GetTrainingSessions(string filterText);

        [OperationContract]
        TrainingSession GetTrainingSession(long Id);

        [OperationContract]
        long SaveTrainingRegistration(long fK_TrainingSessionId, long fK_BusinessRegistrationId);

        [OperationContract]
        List<TrainingRegistrationReport> GetTrainingRegistrationReport(long Id);

        [OperationContract]
        bool UpdateAttendance(long fK_TrainingSessionId, long fK_BusinessRegistrationId, bool attended);

        [OperationContract]
        long SaveTrainingSession(TrainingSession training);

        [OperationContract]
        List<TrainingRegistrationReport> GetAttendedTrainingRegistrationReport(long Id);

        [OperationContract]
        bool CloseTraining(long Id);

        #endregion
    }

}
