﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEnPA
{
    public partial class Utilities
    {
        public static List<TrainingSessionReport> GetTrainingSessions(string filterText)
        {
            List<TrainingSessionReport> response = new List<TrainingSessionReport>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " * from TrainingSession where TrainingBy like '%" + filterText + "%'");
            while (reader.Reader.Read())
            {
                TrainingSessionReport course = new TrainingSessionReport();
                course.Id = long.Parse(reader.Reader["Id"].ToString());
                course.TrainingCourse = Utilities.GetEntityName(long.Parse(reader.Reader["FK_TrainingCourseId"].ToString()),"tracou");
                course.TrainingCategory = Utilities.GetEntityName(long.Parse(reader.Reader["FK_TrainingCategoryId"].ToString()), "tracat");
                course.TrainingType = Utilities.GetEntityName(long.Parse(reader.Reader["FK_TrainingTypeId"].ToString()), "tratyp");
                course.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                course.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                course.LocationAddress = (reader.Reader["LocationAddress"].ToString());
                course.TrainingBy = (reader.Reader["TrainingBy"].ToString());
                course.Status = (reader.Reader["Status"].ToString());
                course.StatusReason = (reader.Reader["StatusReason"].ToString());
                course.Created = DateTime.Now;
                course.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                course.LastModified = DateTime.Now;
                course.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(course);
            }
            reader.Close();
            return response;
        }

        public static TrainingSession GetTrainingSession(long Id)
        {
            return new TrainingSession(Id);
        }

        public static long SaveTrainingRegistration(long fK_TrainingSessionId, long fK_BusinessRegistrationId)
        {
            TrainingRegistration training = new TrainingRegistration(fK_TrainingSessionId, fK_BusinessRegistrationId);
            return training.Save();
        }

        public static List<TrainingRegistrationReport> GetTrainingRegistrationReport(long Id)
        {
            List<TrainingRegistrationReport> response = new List<TrainingRegistrationReport>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select  FK_RegistrationRequestId,BusinessName,FK_BusinessTypeId,FK_BusinessRegistrationTypeId,FirstNames,LastName,NIN,FK_BusinessIslandLocationId from BusinessRegistration where FK_RegistrationRequestId in (select FK_BusinessRegistrationId from TrainingRegistration where FK_TrainingSessionId=" + Id+")");
            while (reader.Reader.Read())
            {
                TrainingRegistrationReport reg = new TrainingRegistrationReport();               

                 reg.BusinessRegistrationId = long.Parse(reader.Reader["FK_RegistrationRequestId"].ToString());
                reg.BusinessType=Utilities.GetEntityName(long.Parse(reader.Reader["FK_BusinessTypeId"].ToString()), "bustyp");
                reg.BusinessName = (reader.Reader["BusinessName"].ToString());
                reg.FirstNames = (reader.Reader["FirstNames"].ToString());
                reg.LastName = (reader.Reader["LastName"].ToString());
                reg.BusinessRegistrationType= Utilities.GetEntityName(long.Parse(reader.Reader["FK_BusinessRegistrationTypeId"].ToString()), "busregtyp");
                reg.Island = Utilities.GetEntityName(long.Parse(reader.Reader["FK_BusinessIslandLocationId"].ToString()), "isl");
                reg.NIN = (reader.Reader["NIN"].ToString());

                response.Add(reg);
            }
            reader.Close();
            return response;
        }

        public static bool UpdateAttendance(long fK_TrainingSessionId, long fK_BusinessRegistrationId, bool attended)
        {
            return TrainingRegistration.UpdateAttendance(fK_TrainingSessionId, fK_BusinessRegistrationId, attended);
        }

        public static long SaveTrainingSession(TrainingSession training)
        {
            return training.Save();
        }

        public static List<TrainingRegistrationReport> GetAttendedTrainingRegistrationReport(long Id)
        {
            List<TrainingRegistrationReport> response = new List<TrainingRegistrationReport>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select  FK_RegistrationRequestId,BusinessName,FK_BusinessTypeId,FK_BusinessRegistrationTypeId,FirstNames,LastName,NIN,FK_BusinessIslandLocationId from BusinessRegistration where FK_RegistrationRequestId in (select FK_BusinessRegistrationId from TrainingRegistration where Attended='True' and FK_TrainingSessionId=" + Id + ")");
            while (reader.Reader.Read())
            {
                TrainingRegistrationReport reg = new TrainingRegistrationReport();

                reg.BusinessRegistrationId = long.Parse(reader.Reader["FK_RegistrationRequestId"].ToString());
                reg.BusinessType = Utilities.GetEntityName(long.Parse(reader.Reader["FK_BusinessTypeId"].ToString()), "bustyp");
                reg.BusinessName = (reader.Reader["BusinessName"].ToString());
                reg.FirstNames = (reader.Reader["FirstNames"].ToString());
                reg.LastName = (reader.Reader["LastName"].ToString());
                reg.BusinessRegistrationType = Utilities.GetEntityName(long.Parse(reader.Reader["FK_BusinessRegistrationTypeId"].ToString()), "busregtyp");
                reg.Island = Utilities.GetEntityName(long.Parse(reader.Reader["FK_BusinessIslandLocationId"].ToString()), "isl");
                reg.NIN = (reader.Reader["NIN"].ToString());

                response.Add(reg);
            }
            reader.Close();
            return response;
        }

        public static bool CloseTraining(long Id)
        {
            List<TrainingRegistration> regs = GetAttendedTrainingRegistrations(Id);
            foreach(TrainingRegistration reg in regs)
            {
                SendDocument("training", reg.Id, true, true);
            }

            return TrainingSession.Close(Id);
        }

        public static List<TrainingRegistration> GetAttendedTrainingRegistrations(long Id)
        {
            List<TrainingRegistration> response = new List<TrainingRegistration>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select  * from TrainingRegistration where Attended='True' and FK_TrainingSessionId=" + Id);
            while (reader.Reader.Read())
            {
                TrainingRegistration reg = new TrainingRegistration();
                reg.Id = long.Parse(reader.Reader["Id"].ToString());
                reg.FK_TrainingSessionId = long.Parse(reader.Reader["FK_TrainingSessionId"].ToString());
                reg.FK_BusinessRegistrationId = long.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                reg.Attended = bool.Parse(reader.Reader["Attended"].ToString());
                reg.ReasonsForNotAttending = (reader.Reader["ReasonsForNotAttending"].ToString());
                reg.Created = DateTime.Now;
                reg.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                reg.LastModified = DateTime.Now;
                reg.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(reg);
            }
            reader.Close();
            return response;
        }
    }

    public class TrainingRegistration
    {
        public TrainingRegistration() { }

        public TrainingRegistration(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from TrainingRegistration where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_TrainingSessionId = long.Parse(reader.Reader["FK_TrainingSessionId"].ToString());
                this.FK_BusinessRegistrationId = long.Parse(reader.Reader["FK_BusinessRegistrationId"].ToString());
                this.Attended = bool.Parse(reader.Reader["Attended"].ToString());
                this.ReasonsForNotAttending = (reader.Reader["ReasonsForNotAttending"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public TrainingRegistration(long fK_TrainingSessionId, long fK_BusinessRegistrationId) {
            this.FK_TrainingSessionId = fK_TrainingSessionId;
            this.FK_BusinessRegistrationId = fK_BusinessRegistrationId;
            this.Attended = false;
            this.ReasonsForNotAttending = "";
        }

        public long Save()
        {
            long x = Utilities.ExecuteNewRecord("insert into TrainingRegistration(FK_TrainingSessionId,FK_BusinessRegistrationId,Attended,ReasonsForNotAttending,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_TrainingSessionId + "," + this.FK_BusinessRegistrationId + ",'" + ((this.Attended) ? "True" : "False") + "','" + this.ReasonsForNotAttending + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            this.Id = x;
            return x;
        }

        public static bool UpdateAttendance(long fK_TrainingSessionId, long fK_BusinessRegistrationId, bool attended)
        {
            int x = Utilities.ExecuteNonQuery("update TrainingRegistration set Attended='" + ((attended) ? "True" : "False") + "' where FK_TrainingSessionId=" + fK_TrainingSessionId + " and FK_BusinessRegistrationId=" + fK_BusinessRegistrationId);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_TrainingSessionId { get; set; }
        public long FK_BusinessRegistrationId { get; set; }
        public bool Attended { get; set; }
        public string ReasonsForNotAttending { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class TrainingSession
    {
        public TrainingSession() { }

        public TrainingSession(long id) {
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from TrainingSession where Id=" + id);
            while (reader.Reader.Read())
            {               
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_TrainingCourseId = int.Parse(reader.Reader["FK_TrainingCourseId"].ToString());
                this.FK_TrainingCategoryId = int.Parse(reader.Reader["FK_TrainingCategoryId"].ToString());
                this.FK_TrainingTypeId = int.Parse(reader.Reader["FK_TrainingTypeId"].ToString());
                this.StartDate = DateTime.Parse(reader.Reader["StartDate"].ToString());
                this.EndDate = DateTime.Parse(reader.Reader["EndDate"].ToString());
                this.LocationAddress = (reader.Reader["LocationAddress"].ToString());
                this.TrainingBy = (reader.Reader["TrainingBy"].ToString());
                this.Status = (reader.Reader["Status"].ToString());
                this.StatusReason = (reader.Reader["StatusReason"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                
            }
            reader.Close();
        }

        public long Save()
        {
            if (this.Id == 0)
            {
                long x = Utilities.ExecuteNewRecord("insert into TrainingSession(FK_TrainingCourseId,FK_TrainingCategoryId,FK_TrainingTypeId,StartDate,EndDate,LocationAddress,TrainingBy,Status,StatusReason,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_TrainingCourseId + "," + this.FK_TrainingCategoryId + "," + this.FK_TrainingTypeId + ",'" + this.StartDate.ToString("yyyy-MM-dd HH:mm:ss.000") + "','" + this.EndDate.ToString("yyyy-MM-dd HH:mm:ss.000") + "','" + this.LocationAddress + "','" + this.TrainingBy + "','" + this.Status + "','" + this.StatusReason + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
                return x;
            }
            else
            {
                int x = Utilities.ExecuteNonQuery("update TrainingSession set FK_TrainingCourseId=" + this.FK_TrainingCourseId + ",FK_TrainingCategoryId=" + this.FK_TrainingCategoryId + ",FK_TrainingTypeId=" + this.FK_TrainingTypeId + ",StartDate='" + this.StartDate.ToString("yyyy-MM-dd HH:mm:ss.000") + "',EndDate='" + this.EndDate.ToString("yyyy-MM-dd HH:mm:ss.000") + "',LocationAddress='" + this.LocationAddress + "',TrainingBy='" + this.TrainingBy + "',Status='" + this.Status + "',StatusReason='" + this.StatusReason + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + this.Id);
                if (x > 0)
                    return this.Id;
                else return x;
            }
        }

        public static bool Close(long id)
        {
            int x = Utilities.ExecuteNonQuery("update TrainingSession set Status='Closed',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public int FK_TrainingCourseId { get; set; }
        public int FK_TrainingCategoryId { get; set; }
        public int FK_TrainingTypeId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string LocationAddress { get; set; }
        public string TrainingBy { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class TrainingSessionReport
    {
        public TrainingSessionReport() { }

        public long Id { get; set; }
        public string TrainingCourse { get; set; }
        public string TrainingCategory { get; set; }
        public string TrainingType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string LocationAddress { get; set; }
        public string TrainingBy { get; set; }
        public string Status { get; set; }
        public string StatusReason { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class TrainingRegistrationReport
    {
        public TrainingRegistrationReport() { }

        public long BusinessRegistrationId { get; set; }
        public string BusinessType { get; set; }
        public string BusinessName { get; set; }
        public string FirstNames { get; set; }
        public string LastName { get; set; }
        public string BusinessRegistrationType { get; set; }
        public string Island { get; set; }
        public string NIN { get; set; }
    }
}