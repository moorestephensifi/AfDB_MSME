﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SEnPA
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "SEnPASecurity" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select SEnPASecurity.svc or SEnPASecurity.svc.cs at the Solution Explorer and start debugging.
    public class SEnPASecurity : ISEnPASecurity
    {
        public AuthenticationResponse Authenticate(string username, string password)
        {
            return Security.Authenticate(username, password);
        }

        public PasswordChangeResponse ChangePassword(string username, string oldpassword, string newpassword)
        {
            return Security.ChangePassword(username, oldpassword, newpassword);

        }
        public bool UpdateUserDetails(string userName, string FirstName, string Surname, string EmailAddress, string MobileNumber)
        {
            return ApplicationUsers.UpdateUserDetails(userName, FirstName, Surname, EmailAddress, MobileNumber);
        }
    }
}
