﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Xml;

namespace SEnPA
{
    public partial class Utilities
    {
        //Send e-mail message      
        public static bool SendEmail(string to, string subject, string message, string design = "default")
        {
            try
            {
                Email newMail = new Email(to, subject, message, design);
                newMail.LogEmail();
                Thread email = new Thread(delegate ()
                {
                    newMail.SendEmail();
                });

                email.IsBackground = true;
                email.Start();
               
               //newMail.SendEmail().ContinueWith(t => Utilities.LogError("Send Email",t.Exception),TaskContinuationOptions.OnlyOnFaulted);
                return true;
            }
            catch (Exception ex)
            {
                Utilities.LogError("SendEmail", ex);
                return false;
            }
        }

        //Send SMS message
        public static bool SendSMS(string to, string message)
        {
            try
            {
                SMS newSMS = new SMS(to, message);
                newSMS.LogSMS();
                Thread sms = new Thread(delegate ()
                {
                    newSMS.SendSMS();
                });

                sms.IsBackground = true;
                sms.Start();
                
                return true;
            }
            catch (Exception ex)
            {
                Utilities.LogError("SendSMS", ex);
                return false;
            }
        }

        //get emails
        public static List<Email> GetEmails(string filterText)
        {
            List<Email> response = new List<Email>();
            //retrieve user details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " Id,Category,IsBodyHtml,Destination,Subject,Message,HasAttachments,CC,BCC,Source,ReplyTo,DeliveryCode,DeliveryMessage,Created,CreatedBy,SentOn,LastModified from EmailOutbox where Category like 'senpa_%' and Destination like '%" + filterText + "%' and Message like '%" + filterText + "%' and Subject like '%" + filterText + "%' order by Created desc","messaging");
            while (reader.Reader.Read())
            {
                Email email = new Email();
                email.Id = int.Parse(reader.Reader["Id"].ToString());
                email.Category = (reader.Reader["Category"].ToString());
                email.IsBodyHtml = reader.Reader.GetBoolean(2);
                email.Destination = (reader.Reader["Destination"].ToString());
                email.Subject = (reader.Reader["Subject"].ToString());                
                email.Message = (reader.Reader["Message"].ToString());
                email.HasAttachments = reader.Reader.GetBoolean(6);
                email.CC = (reader.Reader["CC"].ToString());
                email.BCC = (reader.Reader["BCC"].ToString());
                email.Source = (reader.Reader["Source"].ToString());
                email.ReplyTo = (reader.Reader["ReplyTo"].ToString());
                email.DeliveryCode = reader.Reader.GetInt32(11);
                email.DeliveryMessage = (reader.Reader["DeliveryMessage"].ToString());
                email.Created = reader.Reader.GetDateTime(13);
                email.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                email.SentOn = reader.Reader.GetDateTime(15);
                email.LastModified = reader.Reader.GetDateTime(16);


                response.Add(email);
            }
            reader.Close();

            return response;
        }

        //get smss
        public static List<SMS> GetSMSs(string filterText)
        {
            List<SMS> response = new List<SMS>();
            //retrieve user details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select top " + FilterBatch() + " Id,Category,Destination,Message,Source,DeliveryCode,DeliveryMessage,Created,CreatedBy,SentOn,LastModified from SMSOutbox where Category like 'senpa_%' and Destination like '%" + filterText + "%' and Message like '%" + filterText + "%' order by Created desc", "messaging");
            while (reader.Reader.Read())
            {
                SMS sms = new SMS();
                sms.Id = int.Parse(reader.Reader["Id"].ToString());
                sms.Category = (reader.Reader["Category"].ToString());
                sms.Destination = (reader.Reader["Destination"].ToString());
                sms.Message = (reader.Reader["Message"].ToString());
                sms.Source = (reader.Reader["Source"].ToString());
                sms.DeliveryCode = reader.Reader.GetInt32(5);
                sms.DeliveryMessage = (reader.Reader["DeliveryMessage"].ToString());
                sms.Created = reader.Reader.GetDateTime(7);
                sms.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                sms.SentOn = reader.Reader.GetDateTime(9);
                sms.LastModified = reader.Reader.GetDateTime(10);


                response.Add(sms);
            }
            reader.Close();

            return response;
        }

        public static bool ClearEmails()
        {
            int x = Utilities.ExecuteNonQuery("delete from EmailOutbox where Category like '%senpa%'", "messaging");
            return true;
        }

        public static bool ClearSMSs()
        {
            int x = Utilities.ExecuteNonQuery("delete from SMSOutbox where Category like '%senpa%'", "messaging");
            return true;
        }

        //get Email Message Design
        public static List<EmailMessageDesign> GetEmailMessageDesigns()
        {
            List<EmailMessageDesign> response = new List<EmailMessageDesign>();
            //retrieve user details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Category,MessageName,Subject,Message,Created,CreatedBy,LastModified,LastModifiedBy from EmailMessageDesign where Category like 'senpa%'", "messaging");
            while (reader.Reader.Read())
            {
                EmailMessageDesign msgDesign = new EmailMessageDesign();
                msgDesign.Id = int.Parse(reader.Reader["Id"].ToString());
                msgDesign.Category = (reader.Reader["Category"].ToString());
                msgDesign.MessageName = (reader.Reader["MessageName"].ToString());
                msgDesign.Subject = (reader.Reader["Subject"].ToString());
                msgDesign.Message = (reader.Reader["Message"].ToString());


                response.Add(msgDesign);
            }
            reader.Close();

            return response;
        }
       
        //get Email Message Design
        public static EmailMessageDesign GetEmailMessageDesign(string design)
        {
            EmailMessageDesign msgDesign = new EmailMessageDesign();
            //retrieve user details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Category,MessageName,Subject,Message,Created,CreatedBy,LastModified,LastModifiedBy from EmailMessageDesign where Category like 'senpa%' and MessageName='" + design + "'", "messaging");
            while (reader.Reader.Read())
            {               
                msgDesign.Id = int.Parse(reader.Reader["Id"].ToString());
                msgDesign.Category = (reader.Reader["Category"].ToString());
                msgDesign.MessageName = (reader.Reader["MessageName"].ToString());
                msgDesign.Subject = (reader.Reader["Subject"].ToString());
                msgDesign.Message = (reader.Reader["Message"].ToString());                
            }
            reader.Close();
            return msgDesign;
        }
    }

    public class Email
    {
        public Email() { }
        public Email(string emailTo, string design = "default")
        {
            this.Destination = emailTo;
            this.UseDesign = new EmailMessageDesign(design);
            this.Message = this.UseDesign.Message;
            this.Subject = this.UseDesign.Subject;
        }

        public Email(string emailTo, string subject, string message, string design = "default")
        {
            this.Destination = emailTo;
            this.Subject = subject;
            this.UseDesign = new EmailMessageDesign(design);
            this.Message = this.UseDesign.Message.Replace("<subject>",this.UseDesign.Subject).Replace("<message>",message);

            //dummy input
            this.CC = "";
            this.BCC = "";
            this.Source = "";
            this.ReplyTo = "";
            this.HasAttachments = false;
            this.DeliveryCode = 0;
            this.DeliveryMessage = "";
        }

        public void LogEmail(string category="general")
        {
            SqlCommand command = new SqlCommand("insert into EmailOutbox(Category,IsBodyHtml,Destination,Subject,Message,HasAttachments,CC,BCC,Source,ReplyTo,DeliveryCode,DeliveryMessage,Created,CreatedBy ,SentOn ,LastModified) values(@Category,@IsBodyHtml,@Destination,@Subject,@Message ,@HasAttachments,@CC,@BCC,@Source,@ReplyTo,@DeliveryCode,@DeliveryMessage,CURRENT_TIMESTAMP,@CreatedBy ,CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP)");

            command.Parameters.Add(new SqlParameter("@Category", "senpa_"+category));
            command.Parameters.Add(new SqlParameter("@IsBodyHtml", "True"));
            command.Parameters.Add(new SqlParameter("@Destination", this.Destination));
            command.Parameters.Add(new SqlParameter("@Subject", this.Subject));
            command.Parameters.Add(new SqlParameter("@Message", this.Message));
            command.Parameters.Add(new SqlParameter("@HasAttachments", this.HasAttachments));
            command.Parameters.Add(new SqlParameter("@CC", this.CC));
            command.Parameters.Add(new SqlParameter("@BCC", this.BCC));
            command.Parameters.Add(new SqlParameter("@Source", this.Source));
            command.Parameters.Add(new SqlParameter("@ReplyTo", this.ReplyTo));
            command.Parameters.Add(new SqlParameter("@DeliveryCode", this.DeliveryCode));
            command.Parameters.Add(new SqlParameter("@DeliveryMessage", this.DeliveryMessage));
            command.Parameters.Add(new SqlParameter("@CreatedBy", "System"));

            this.Id = Utilities.ExecuteNewRecord(command, "messaging");
        }

        public bool SendEmail(string gatewayName = "default")
        {
            this.UseGateway = new EmailGateway(gatewayName);
            this.Source = this.UseGateway.Username;
            this.IsBodyHtml = true;
            bool result = false;
            string error = "";
            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = this.UseGateway.Smtp;
            smtpClient.Port = this.UseGateway.Port;

            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Credentials = new NetworkCredential(this.UseGateway.Username, this.UseGateway.Password);
            using (MailMessage message = new MailMessage())
            {
                message.From = new MailAddress(this.Source);
                message.Subject = this.Subject;
                message.Body = this.Message;
                message.IsBodyHtml = this.IsBodyHtml;
                message.BodyEncoding = System.Text.Encoding.UTF8;
                message.To.Add(new MailAddress(this.Destination));

                try
                {
                    // smtpClient.Send(message);
                    smtpClient.SendMailAsync(message);
                    result = true;
                    int x = Utilities.ExecuteNonQuery("update EmailOutbox set DeliveryCode=1701,DeliveryMessage='" + error + "' where Id=" + this.Id, "messaging");
                }
                catch (Exception ex)
                {
                    result = false;
                    error = ex.ToString().Substring(0, 100);
                    int x = Utilities.ExecuteNonQuery("update EmailOutbox set DeliveryCode=1704,DeliveryMessage='" + error + "' where Id=" + this.Id, "messaging");
                }               
            }
            return result;
        }

        ///properties
        ///Email class properties
        public long Id { get; set; }
        public string Category { get; set; }
        public string Destination { get; set; }
        public string Message { get; set; }
        public int DeliveryCode { get; set; }
        public string DeliveryMessage { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime SentOn { get; set; }
        public DateTime LastModified { get; set; }
        public string Subject { get; set; }
        public bool HasAttachments { get; set; }
        public string CC { get; set; }
        public string BCC { get; set; }
        public string Source { get; set; }
        public string ReplyTo { get; set; }
        public bool IsBodyHtml { get; set; }
        public EmailGateway UseGateway { get; set; }
        public EmailMessageDesign UseDesign { get; set; }
    }

    public class SMS
    {       
        public SMS() { }
        public SMS(string sendto, string message, string design = "default")
        {
            this.Destination = sendto;
            this.UseDesign = new SMSMessageDesign(design);
            this.Message = ((message == "") ? this.UseDesign.Message : message);
            //populate other properties
            this.Source = "";
            this.DeliveryCode = 0;
            this.DeliveryMessage = "";
        }

        public void LogSMS(string category="general")
        {
            SqlCommand command = new SqlCommand("insert into SMSOutbox(Category,Destination,Message ,Source,DeliveryCode,DeliveryMessage,Created,CreatedBy ,SentOn ,LastModified) values(@Category,@Destination,@Message,@Source,@DeliveryCode,@DeliveryMessage,CURRENT_TIMESTAMP,@CreatedBy ,CURRENT_TIMESTAMP ,CURRENT_TIMESTAMP)");
        
            command.Parameters.Add(new SqlParameter("@Category", "senpa_"+category));
            command.Parameters.Add(new SqlParameter("@Destination", this.Destination));
            command.Parameters.Add(new SqlParameter("@Source", this.Source));
            command.Parameters.Add(new SqlParameter("@Message", this.Message));
            command.Parameters.Add(new SqlParameter("@DeliveryCode", this.DeliveryCode));
            command.Parameters.Add(new SqlParameter("@DeliveryMessage", this.DeliveryMessage));
            command.Parameters.Add(new SqlParameter("@CreatedBy", "System"));

            this.Id = Utilities.ExecuteNewRecord(command, "messaging");
        }
        
        public string SendSMS(string gatewayName = "default", string proxyName = "default")
        {
            Proxy proxy = new Proxy(proxyName);
            this.UseGateway = new SMSGateway(gatewayName);
            //Format the mobile number
            if (this.Destination.StartsWith("0") && !this.Destination.StartsWith("00"))
            {
                this.Destination = this.Destination.Remove(0, 1);
                this.Destination = String.Format("{0}{1}","248", this.Destination);
            }
            else if (this.Destination.StartsWith("00"))
            {
                this.Destination = this.Destination.Remove(0, 2);
            }
            else if(!this.Destination.StartsWith("248") && !this.Destination.StartsWith("+"))
            {
                this.Destination = String.Format("{0}{1}", "248", this.Destination);
            }
            else if (this.Destination.StartsWith("+"))
            {
                this.Destination = this.Destination.Replace("+", "");
            }           

            try
            {
                //process the request
                string[] result = new string[2];
                #region Send Requestet & Get Response
                string gatewayRequest = this.UseGateway.Url.Replace("<password>", this.UseGateway.Password).Replace("<msdsn>", this.Destination).Replace("<source>", this.UseGateway.Source).Replace("<message>", this.Message).Replace("<account>", this.UseGateway.Username);
                //format special characters
                gatewayRequest = gatewayRequest.Replace("#", "%23").Replace("<reference>", DateTime.Now.ToString("yMdHmsfff"));
                
                WebRequest request = WebRequest.Create(gatewayRequest);

                if (proxy.UseProxy)
                {
                    WebProxy ziproxy = new WebProxy(proxy.ProxyAddress,proxy.ProxyPort);
                    ziproxy.UseDefaultCredentials = true;
                    request.UseDefaultCredentials = true;
                    request.Proxy = ziproxy;
                }                
                 request.Method = "GET";

                request.Timeout = Convert.ToInt32(60000);

                WebResponse response = request.GetResponse();

                Stream dataStream = response.GetResponseStream();

                #endregion

                #region Process Response

                BinaryReader binaryReader = new BinaryReader(dataStream);

                String receivedMessageString = Encoding.ASCII.GetString(binaryReader.ReadBytes(2000));

                result = DecodeResponse(receivedMessageString, this.UseGateway.Type);

                #endregion

                int x = Utilities.ExecuteNonQuery("update SMSOutbox set DeliveryCode=" + result[0] + ",DeliveryMessage='" + result[1] + "' where Id=" + this.Id, "messaging");

                return result[0];
            }
            catch (Exception ex)
            {
                int x = Utilities.ExecuteNonQuery("update SMSOutbox set DeliveryCode=1704,DeliveryMessage='" + ex.ToString().Substring(0, 100) + "' where Id=" + this.Id, "messaging");

                return "1706";
            }
        }

        static string[] DecodeResponse(string responseMsg, string chooseMethod)
        {
            string[] result = new string[2];
            switch (chooseMethod)
            {
                case "ozeki":
                    result = Ozeki(responseMsg);
                    break;
                default:
                    result = Ozeki(responseMsg);
                    break;
            }

            string[] Ozeki(string response)
            {
                response = response.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                string[] deliveryResult = new string[] {"1704","" };
                XmlDocument responseXML = new XmlDocument();
                responseXML.LoadXml(response);
                XmlNode root = responseXML.FirstChild;
                //Display the contents of the child nodes.
                if (root.HasChildNodes)
                {
                    for (int i = 0; i < root.ChildNodes.Count; i++)
                    {
                        if (root.ChildNodes[i].Name.ToLower() == "data")
                        {
                            for (int j = 0; j < root.ChildNodes[i].ChildNodes.Count; j++)
                            {
                                if (root.ChildNodes[i].ChildNodes[j].Name.ToLower() == "acceptreport")
                                {
                                    for (int k = 0; k < root.ChildNodes[i].ChildNodes[j].ChildNodes.Count; k++)
                                    {
                                        if (root.ChildNodes[i].ChildNodes[j].ChildNodes[k].Name.ToLower() == "statuscode")
                                            deliveryResult[0] = root.ChildNodes[i].ChildNodes[j].ChildNodes[k].InnerText;
                                        else if (root.ChildNodes[i].ChildNodes[j].ChildNodes[k].Name.ToLower() == "errormessage")
                                        {
                                            deliveryResult[0] = "1704";
                                            deliveryResult[1] = root.ChildNodes[i].ChildNodes[j].ChildNodes[k].InnerText;
                                        }
                                        else if (root.ChildNodes[i].ChildNodes[j].ChildNodes[k].Name.ToLower() == "statusmessage")
                                        {
                                            if (deliveryResult[0] == "0")
                                                deliveryResult[0] = "1701";
                                            else
                                                deliveryResult[0] = "1702";
                                            deliveryResult[1] = root.ChildNodes[i].ChildNodes[j].ChildNodes[k].InnerText;
                                        }
                                    }
                                }
                                else
                                {
                                    if (root.ChildNodes[i].ChildNodes[j].Name.ToLower() == "statuscode")
                                        deliveryResult[0] = root.ChildNodes[i].ChildNodes[j].InnerText;
                                    else if (root.ChildNodes[i].ChildNodes[j].Name.ToLower() == "errormessage")
                                    {
                                        deliveryResult[0] = "1704";
                                        deliveryResult[1] = root.ChildNodes[i].ChildNodes[j].InnerText;
                                    }
                                    else if (root.ChildNodes[i].ChildNodes[j].Name.ToLower() == "statusmessage")
                                    {
                                        if (deliveryResult[0] == "0")
                                            deliveryResult[0] = "1701";
                                        else
                                            deliveryResult[0] = "1702";
                                        deliveryResult[1] = root.ChildNodes[i].ChildNodes[j].InnerText;
                                    }
                                }
                            }
                        }
                    }
                }
              
                return deliveryResult;
            }

            return result;
        }
        
        ///properties
        ///SMS class properties
        public long Id { get; set; }
        public string Category { get; set; }
        public string Destination { get; set; }
        public string Message { get; set; }
        public string Source { get; set; }
        public int DeliveryCode { get; set; }
        public string DeliveryMessage { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime SentOn { get; set; }
        public DateTime LastModified { get; set; }
        public SMSGateway UseGateway { get; set; }
        public SMSMessageDesign UseDesign { get; set; }
    }

    public class EmailGateway
    {
        public EmailGateway() { }

        public EmailGateway(string gatewayName = "default")
        {
            //get email gateway
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,GatewayName,Smtp,Username,Password,Port from EmailGateway where GatewayName = '" + gatewayName + "'", "messaging");
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Smtp = (reader.Reader["Smtp"].ToString());
                this.GatewayName = (reader.Reader["GatewayName"].ToString());
                this.Username = (reader.Reader["Username"].ToString());
                this.Password = (reader.Reader["Password"].ToString());
                this.Port = int.Parse(reader.Reader["Port"].ToString());
            }
            reader.Close();
        }

        public int Id { get; set; }
        public string GatewayName { get; set; }
        public string Smtp { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int Port { get; set; }
    }

    public class EmailMessageDesign
    {
        public EmailMessageDesign() { }
        public EmailMessageDesign(string messageName = "default")
        {
            //get email message design
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Category,MessageName,Subject,Message,Created,CreatedBy,LastModified,LastModifiedBy from EmailMessageDesign where MessageName='" + messageName + "'", "messaging");
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Category = (reader.Reader["Category"].ToString());
                this.Subject = (reader.Reader["Subject"].ToString());
                this.MessageName = (reader.Reader["MessageName"].ToString());
                this.Message = (reader.Reader["Message"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.Created = reader.Reader.GetDateTime(5);
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.LastModified = reader.Reader.GetDateTime(7);
            }
            reader.Close();
        }

        public int Id { get; set; }
        public string Category { get; set; }
        public string MessageName { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
    
    public class SMSGateway
    {
        public SMSGateway() { }
        public SMSGateway(string gatewayName = "default")
        {
            //get sms gateway
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,GatewayName,Url,Username,Password,Source,Type from SMSGateway where GatewayName = '" + gatewayName + "'", "messaging");
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.Source = (reader.Reader["Source"].ToString());
                this.GatewayName = (reader.Reader["GatewayName"].ToString());
                this.Username = (reader.Reader["Username"].ToString());
                this.Password = (reader.Reader["Password"].ToString());
                this.Type = (reader.Reader["Type"].ToString());
                this.Url = (reader.Reader["Url"].ToString());
            }
            reader.Close();
        }

        public int Id { get; set; }
        public string GatewayName { get; set; }
        public string Url { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Source { get; set; }
        public string Type { get; set; }
    }

    public class Proxy
    {
        public Proxy() { }
        public Proxy(string proxyName = "default")
        {
            //get sms message design
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,ProxyName,UseProxy,ProxyAddress,ProxyPort from Proxy where ProxyName = '" + proxyName + "'", "messaging");
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.ProxyName = (reader.Reader["ProxyName"].ToString());
                this.ProxyAddress = (reader.Reader["ProxyAddress"].ToString());
                this.ProxyPort = int.Parse(reader.Reader["ProxyPort"].ToString());
                this.UseProxy = reader.Reader.GetBoolean(2);
            }
            reader.Close();
        }

        public int Id { get; set; }
        public string ProxyName { get; set; }
        public bool UseProxy { get; set; }
        public string ProxyAddress { get; set; }
        public int ProxyPort { get; set; }
    }

    public class SMSMessageDesign
    {
        public SMSMessageDesign() { }
        public SMSMessageDesign(string messageName = "default")
        {
            //get sms message design
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select Id,Category,MessageName,Message,Created,CreatedBy,LastModified,LastModifiedBy from SMSMessageDesign where MessageName = '" + messageName + "'", "messaging");
            while (reader.Reader.Read())
            {
                this.Id = int.Parse(reader.Reader["Id"].ToString());
                this.MessageName = (reader.Reader["MessageName"].ToString());
                this.Message = (reader.Reader["Message"].ToString());
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.Created = reader.Reader.GetDateTime(4);
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());
                this.LastModified = reader.Reader.GetDateTime(6);
            }
            reader.Close();
        }
        public int Id { get; set; }
        public string Category { get; set; }
        public string MessageName { get; set; }
        public string Message { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

}