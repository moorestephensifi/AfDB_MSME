﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEnPA
{
    public partial class Utilities
    {
        public static List<SiteVisitReport> GetSiteVisitReports(long siteVisitId)
        {
            List<SiteVisitReport> response = new List<SiteVisitReport>();
            //retrieve details from database
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from SiteVisitReport where FK_SiteVisitId=" + siteVisitId);
            while (reader.Reader.Read())
            {
                SiteVisitReport report = new SiteVisitReport();
                report.Id = long.Parse(reader.Reader["Id"].ToString());
                report.DocumentLibraryId= long.Parse(reader.Reader["DocumentLibraryId"].ToString());
                report.FK_SiteVisitId = int.Parse(reader.Reader["FK_SiteVisitId"].ToString());
                report.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                report.Confirmed = bool.Parse(reader.Reader["Confirmed"].ToString());
                report.UploadStatus = bool.Parse(reader.Reader["UploadStatus"].ToString());
                report.UploadDate = DateTime.Parse(reader.Reader["UploadDate"].ToString());
                report.Created = DateTime.Now;
                report.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                report.LastModified = DateTime.Now;
                report.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

                response.Add(report);
            }
            reader.Close();
            return response;
        }

        public static long SaveSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId, string comments)
        {
            SiteVisitReport report = new SiteVisitReport(fK_SiteVisitId, fK_StakeholderId, comments);
            return report.Save();
        }

        public static SiteVisitReport GetSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId)
        {
            SiteVisitReport report = new SiteVisitReport(fK_SiteVisitId, fK_StakeholderId);
            return report;
        }

        public static bool RemoveSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId)
        {
            SiteVisitReport report = new SiteVisitReport(fK_SiteVisitId, fK_StakeholderId);
            return report.Remove();
        }

        public static bool ConfirmSiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId)
        {
            SiteVisitReport report = new SiteVisitReport(fK_SiteVisitId, fK_StakeholderId);
            return report.Confirm();
        }

        public static long CreateWorkflowSiteVisit(long Id, string entityType, long fK_RecommendationId = 0)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return 0;
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                SiteVisit site = new SiteVisit(long.Parse(wrkIdentity.DocumentId), wrkDoc.Id, wrkStage.Id, fK_RecommendationId, 1);
                return site.Create();
            }
        }

        public static SiteVisit GetCurrentWorkflowSiteVisit(long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return new SiteVisit();
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                SiteVisit site = new SiteVisit(long.Parse(wrkIdentity.DocumentId), wrkDoc.Id, wrkStage.Id);
                return site;
            }
        }

        public static SiteVisit GetCurrentWorkflowRecommendationSiteVisit(long recommendationId, long Id, string entityType)
        {
            WorkFlowIdentity wrkIdentity = new WorkFlowIdentity(Id, entityType);
            if (wrkIdentity.WorkFlowId == 0 || wrkIdentity.WorkFlowStatus == "Complete")
                return new SiteVisit();
            else
            {
                DocumentWorkflow wrkDoc = new DocumentWorkflow(wrkIdentity.WorkFlowId, wrkIdentity.DocumentId, wrkIdentity.DocumentType);
                WorkFlowStages wrkStage = new WorkFlowStages(wrkDoc.FK_WorkFlowId, wrkDoc.WorkFlowStatus);
                SiteVisit site = new SiteVisit(long.Parse(wrkIdentity.DocumentId), wrkDoc.Id, wrkStage.Id, recommendationId);
                return site;
            }
        }

        public static bool SaveSiteVisit(SiteVisit site)
        {
            return site.Save();
        }

        public static bool ScheduleSiteVisit(SiteVisit site)
        {
            return site.Schedule();
        }

        public static bool UploadSiteVisitWorkFlowDocument(long siteVisitId, int stakeholderId, string comments, long Id, string entityType, string fileName, byte[] fileData, int documentTypeId, long documentFolderId)
        {
            long docId = Utilities.UploadWorkFlowDocument(Id, entityType, fileName, fileData, documentTypeId, documentFolderId, true);
            if (docId>0)
            {
                SiteVisitReport report = new SiteVisitReport(siteVisitId, stakeholderId, comments);
                return report.Uploaded(docId);
            }
            else
                return false;

        }

        public static bool NotifySiteVisit(long Id)
        {
            return SendDocument("sitevisit", Id, true, true);
        }

        public static bool ConfirmSiteVisit(long Id)
        {
            SiteVisit site = new SiteVisit(Id);
            return site.Confirm();
        }
    }

    public class SiteVisit
    {
        public SiteVisit() { }

        public SiteVisit(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from SiteVisit where Id=" + id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                this.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                this.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                this.FK_RecommendationId = int.Parse(reader.Reader["FK_RecommendationId"].ToString());
                this.Origin = int.Parse(reader.Reader["Origin"].ToString());
                this.HasLoan = bool.Parse(reader.Reader["HasLoan"].ToString());
                this.FK_FinanceInstituteId = int.Parse(reader.Reader["FK_FinanceInstituteId"].ToString());
                this.LoanAmount = float.Parse(reader.Reader["LoanAmount"].ToString());
                this.LoanPurpose = (reader.Reader["LoanPurpose"].ToString());
                this.Background = (reader.Reader["Background"].ToString());
                this.BusinessDescription = (reader.Reader["BusinessDescription"].ToString());
                this.Premises = (reader.Reader["Premises"].ToString());
                this.Equipment = (reader.Reader["Equipment"].ToString());
                this.Marketing = (reader.Reader["Marketing"].ToString());
                this.Manpower = (reader.Reader["Manpower"].ToString());
                this.Training = (reader.Reader["Training"].ToString());
                this.Conclusion = (reader.Reader["Conclusion"].ToString());
                this.FK_BDO = int.Parse(reader.Reader["FK_BDO"].ToString());
                this.FK_BDM = int.Parse(reader.Reader["FK_BDM"].ToString());
                this.FK_HR = int.Parse(reader.Reader["FK_HR"].ToString());
                this.VisitDate = DateTime.Parse(reader.Reader["VisitDate"].ToString());
                this.VisitAddress = (reader.Reader["VisitAddress"].ToString());
                this.Confirmed = bool.Parse(reader.Reader["Confirmed"].ToString());
                this.Phone = bool.Parse(reader.Reader["Phone"].ToString());
                this.SMS = bool.Parse(reader.Reader["SMS"].ToString());
                this.Email = bool.Parse(reader.Reader["Email"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public SiteVisit(long fK_DocumentId, long fK_DocumentWorkFlowId, long fK_WorkFlowStageId, long recommendationId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from SiteVisit where FK_RecommendationId=" + recommendationId + " and FK_DocumentId=" + fK_DocumentId + " and FK_DocumentWorkFlowId=" + fK_DocumentWorkFlowId + " and FK_WorkFlowStageId=" + fK_WorkFlowStageId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                this.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                this.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                this.FK_RecommendationId = int.Parse(reader.Reader["FK_RecommendationId"].ToString());
                this.Origin = int.Parse(reader.Reader["Origin"].ToString());
                this.HasLoan = bool.Parse(reader.Reader["HasLoan"].ToString());
                this.FK_FinanceInstituteId = int.Parse(reader.Reader["FK_FinanceInstituteId"].ToString());
                this.LoanAmount = float.Parse(reader.Reader["LoanAmount"].ToString());
                this.LoanPurpose = (reader.Reader["LoanPurpose"].ToString());
                this.Background = (reader.Reader["Background"].ToString());
                this.BusinessDescription = (reader.Reader["BusinessDescription"].ToString());
                this.Premises = (reader.Reader["Premises"].ToString());
                this.Equipment = (reader.Reader["Equipment"].ToString());
                this.Marketing = (reader.Reader["Marketing"].ToString());
                this.Manpower = (reader.Reader["Manpower"].ToString());
                this.Training = (reader.Reader["Training"].ToString());
                this.Conclusion = (reader.Reader["Conclusion"].ToString());
                this.FK_BDO = int.Parse(reader.Reader["FK_BDO"].ToString());
                this.FK_BDM = int.Parse(reader.Reader["FK_BDM"].ToString());
                this.FK_HR = int.Parse(reader.Reader["FK_HR"].ToString());
                this.VisitDate = DateTime.Parse(reader.Reader["VisitDate"].ToString());
                this.VisitAddress = (reader.Reader["VisitAddress"].ToString());
                this.Confirmed = bool.Parse(reader.Reader["Confirmed"].ToString());
                this.Phone = bool.Parse(reader.Reader["Phone"].ToString());
                this.SMS = bool.Parse(reader.Reader["SMS"].ToString());
                this.Email = bool.Parse(reader.Reader["Email"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public SiteVisit(long fK_DocumentId, long fK_DocumentWorkFlowId, long fK_WorkFlowStageId, int origin = 1)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from SiteVisit where Origin=" + origin + " and FK_DocumentId=" + fK_DocumentId + " and FK_DocumentWorkFlowId=" + fK_DocumentWorkFlowId + " and FK_WorkFlowStageId=" + fK_WorkFlowStageId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.FK_DocumentId = long.Parse(reader.Reader["FK_DocumentId"].ToString());
                this.FK_DocumentWorkFlowId = long.Parse(reader.Reader["FK_DocumentWorkFlowId"].ToString());
                this.FK_WorkFlowStageId = long.Parse(reader.Reader["FK_WorkFlowStageId"].ToString());
                this.FK_RecommendationId = int.Parse(reader.Reader["FK_RecommendationId"].ToString());
                this.Origin = int.Parse(reader.Reader["Origin"].ToString());
                this.HasLoan = bool.Parse(reader.Reader["HasLoan"].ToString());
                this.FK_FinanceInstituteId = int.Parse(reader.Reader["FK_FinanceInstituteId"].ToString());
                this.LoanAmount = float.Parse(reader.Reader["LoanAmount"].ToString());
                this.LoanPurpose = (reader.Reader["LoanPurpose"].ToString());
                this.Background = (reader.Reader["Background"].ToString());
                this.BusinessDescription = (reader.Reader["BusinessDescription"].ToString());
                this.Premises = (reader.Reader["Premises"].ToString());
                this.Equipment = (reader.Reader["Equipment"].ToString());
                this.Marketing = (reader.Reader["Marketing"].ToString());
                this.Manpower = (reader.Reader["Manpower"].ToString());
                this.Training = (reader.Reader["Training"].ToString());
                this.Conclusion = (reader.Reader["Conclusion"].ToString());
                this.FK_BDO = int.Parse(reader.Reader["FK_BDO"].ToString());
                this.FK_BDM = int.Parse(reader.Reader["FK_BDM"].ToString());
                this.FK_HR = int.Parse(reader.Reader["FK_HR"].ToString());
                this.VisitDate= DateTime.Parse(reader.Reader["VisitDate"].ToString());
                this.VisitAddress= (reader.Reader["VisitAddress"].ToString());
                this.Confirmed= bool.Parse(reader.Reader["Confirmed"].ToString());
                this.Phone = bool.Parse(reader.Reader["Phone"].ToString());
                this.SMS = bool.Parse(reader.Reader["SMS"].ToString());
                this.Email = bool.Parse(reader.Reader["Email"].ToString());

                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public SiteVisit(long fK_DocumentId, long fK_DocumentWorkFlowId, long fK_WorkFlowStageId, long fK_RecommendationId, int origin)
        {
            this.FK_DocumentId = fK_DocumentId;
            this.FK_DocumentWorkFlowId = fK_DocumentWorkFlowId;
            this.FK_RecommendationId = fK_RecommendationId;
            this.FK_WorkFlowStageId = fK_WorkFlowStageId;
            int y = int.Parse(Utilities.ExecuteScalar("select count(Id) from SiteVisit where FK_DocumentId=" + fK_DocumentId + " and FK_DocumentWorkFlowId=" + fK_DocumentWorkFlowId + " and FK_WorkFlowStageId=" + fK_WorkFlowStageId));

            this.Origin = ((fK_RecommendationId == 0) ? origin : y);           
        }

        public long Create()
        {
            long x = Utilities.ExecuteNewRecord("insert into SiteVisit(FK_DocumentId,FK_DocumentWorkFlowId,FK_WorkFlowStageId,FK_RecommendationId,Origin,HasLoan,FK_FinanceInstituteId,LoanAmount,LoanPurpose,Background,BusinessDescription,Premises,Equipment,Marketing,Manpower,Training,Conclusion,FK_BDO,FK_BDM,FK_HR,VisitDate,VisitAddress,Confirmed,Phone,SMS,Email,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_DocumentId + "," + this.FK_DocumentWorkFlowId + "," + this.FK_WorkFlowStageId + "," + this.FK_RecommendationId + "," + this.Origin + ",'False',0,0,'','','','','','','','','',0,0,0,CURRENT_TIMESTAMP,'','False','True','False','False',CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");
            if (x > 0)
            {
                this.Id = x;
            }
            return x;
        }

        public bool Confirm()
        {
            long x = Utilities.ExecuteNonQuery("update SiteVisit set Confirmed='True',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + Id);
            return ((x > 0) ? true : false);
        }

        public bool Save()
        {
            long x = Utilities.ExecuteNonQuery("update SiteVisit set HasLoan='"+((HasLoan) ?"True":"False")+"',FK_FinanceInstituteId="+ FK_FinanceInstituteId + ",LoanAmount="+ LoanAmount + ",LoanPurpose='"+ LoanPurpose + "',Background='"+ Background + "',BusinessDescription='"+ BusinessDescription + "',Premises='"+ Premises + "',Equipment='"+ Equipment + "',Marketing='"+ Marketing + "',Manpower='"+ Manpower + "',Training='"+ Training + "',Conclusion='"+ Conclusion + "',FK_BDO="+ FK_BDO + ",FK_BDM="+ FK_BDM + ",FK_HR="+ FK_HR + ",LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + Id);
            return ((x > 0) ? true : false);
        }

        public bool Schedule()
        {
            long x = Utilities.ExecuteNonQuery("update SiteVisit set FK_BDO=" + FK_BDO + ",FK_BDM=" + FK_BDM + ",FK_HR=" + FK_HR + ",VisitDate='"+this.VisitDate.ToString("yyyy-MM-dd HH:mm:ss.000")+"',VisitAddress='"+this.VisitAddress+"',Phone='" + ((this.Phone) ? "True" : "False") + "',SMS='" + ((this.SMS) ? "True" : "False") + "',Email='" + ((this.Email) ? "True" : "False") + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where Id=" + Id);
            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long FK_DocumentId { get; set; }
        public long FK_DocumentWorkFlowId { get; set; }
        public long FK_WorkFlowStageId { get; set; }
        public long FK_RecommendationId { get; set; }
        public int Origin { get; set; }
        public bool HasLoan { get; set; }
        public int FK_FinanceInstituteId { get; set; }
        public float LoanAmount { get; set; }
        public string LoanPurpose { get; set; }
        public string Background { get; set; }
        public string BusinessDescription { get; set; }
        public string Premises { get; set; }
        public string Equipment { get; set; }
        public string Marketing { get; set; }
        public string Manpower { get; set; }
        public string Training { get; set; }
        public string Conclusion { get; set; }
        public int FK_BDO { get; set; }
        public int FK_BDM { get; set; }
        public int FK_HR { get; set; }
        public DateTime VisitDate { get; set; }
        public string VisitAddress { get; set; }
        public bool Confirmed { get; set; }
        public bool Phone { get; set; }
        public bool SMS { get; set; }
        public bool Email { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }

    public class SiteVisitReport
    {
        public SiteVisitReport() { }

        public SiteVisitReport(long id)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from SiteVisitReport where Id=" + Id);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.DocumentLibraryId= long.Parse(reader.Reader["DocumentLibraryId"].ToString());
                this.FK_SiteVisitId = int.Parse(reader.Reader["FK_SiteVisitId"].ToString());
                this.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                this.Confirmed = bool.Parse(reader.Reader["Confirmed"].ToString());
                this.UploadStatus = bool.Parse(reader.Reader["UploadStatus"].ToString());
                this.UploadDate = DateTime.Parse(reader.Reader["UploadDate"].ToString());
                this.Comments =(reader.Reader["Comments"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public SiteVisitReport(long fK_SiteVisitId, int fK_StakeholderId)
        {
            Utilities.DatabaseReader reader = new Utilities.DatabaseReader("select * from SiteVisitReport where FK_SiteVisitId=" + fK_SiteVisitId + " and FK_StakeholderId=" + fK_StakeholderId);
            while (reader.Reader.Read())
            {
                this.Id = long.Parse(reader.Reader["Id"].ToString());
                this.DocumentLibraryId = long.Parse(reader.Reader["DocumentLibraryId"].ToString());
                this.FK_SiteVisitId = int.Parse(reader.Reader["FK_SiteVisitId"].ToString());
                this.FK_StakeholderId = int.Parse(reader.Reader["FK_StakeholderId"].ToString());
                this.Confirmed = bool.Parse(reader.Reader["Confirmed"].ToString());
                this.UploadStatus = bool.Parse(reader.Reader["UploadStatus"].ToString());
                this.UploadDate = DateTime.Parse(reader.Reader["UploadDate"].ToString());
                this.Comments = (reader.Reader["Comments"].ToString());
                this.Created = DateTime.Now;
                this.CreatedBy = (reader.Reader["CreatedBy"].ToString());
                this.LastModified = DateTime.Now;
                this.LastModifiedBy = (reader.Reader["LastModifiedBy"].ToString());

            }
            reader.Close();
        }

        public SiteVisitReport(long fK_SiteVisitId,int fK_StakeholderId, string comments)
        {
            this.FK_SiteVisitId = fK_SiteVisitId;
            this.FK_StakeholderId = fK_StakeholderId;
            this.Confirmed = false;
            this.Comments = comments;
            this.UploadStatus = false;
        }

        public long Save()
        {
            long x =  Utilities.ExecuteNewRecord("insert into SiteVisitReport(FK_StakeholderId,FK_SiteVisitId,Confirmed,UploadStatus,UploadDate,Comments,DocumentLibraryId,Created,CreatedBy,LastModified,LastModifiedBy) values(" + this.FK_StakeholderId + "," + this.FK_SiteVisitId + ",'" + ((this.Confirmed) ? "True" : "False") + "','" + ((this.UploadStatus) ? "True" : "False") + "',CURRENT_TIMESTAMP,'" + this.Comments + "',0,CURRENT_TIMESTAMP,'" + Security.actingUser + "',CURRENT_TIMESTAMP,'" + Security.actingUser + "')");

            return x;
        }

        public bool Remove()
        {
            int x = Utilities.ExecuteNonQuery("delete from SiteVisitReport where Id="+this.Id);

            return ((x > 0) ? true : false);
        }

        public bool Confirm()
        {
            this.Confirmed = true;
            int x = Utilities.ExecuteNonQuery("update SiteVisitReport set Confirmed='" + ((this.Confirmed) ? "True" : "False") + "' where FK_SiteVisitId=" + this.FK_SiteVisitId + " and FK_StakeholderId=" + this.FK_StakeholderId);

            return ((x > 0) ? true : false);
        }

        public bool Uploaded(long docId)
        {
            this.UploadStatus = true;
            int x = Utilities.ExecuteNonQuery("update SiteVisitReport set DocumentLibraryId=" + docId + ",UploadStatus='" + ((this.UploadStatus) ? "True" : "False") + "',UploadDate=CURRENT_TIMESTAMP,Comments='" + this.Comments + "',LastModified=CURRENT_TIMESTAMP,LastModifiedBy='" + Security.actingUser + "' where FK_SiteVisitId=" + this.FK_SiteVisitId + " and FK_StakeholderId=" + this.FK_StakeholderId);

            return ((x > 0) ? true : false);
        }

        public long Id { get; set; }
        public long DocumentLibraryId { get; set; }
        public int FK_StakeholderId { get; set; }
        public long FK_SiteVisitId { get; set; }
        public bool Confirmed { get; set; }
        public bool UploadStatus { get; set; }
        public DateTime UploadDate { get; set; }
        public string Comments { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModified { get; set; }
        public string LastModifiedBy { get; set; }
    }
}